import Foundation
import SwiftUI
import WebKit

struct AJWebViewContainer: UIViewRepresentable {
    @ObservedObject var coordinator: WebViewCoordinator

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        config.defaultWebpagePreferences = prefs
        config.mediaTypesRequiringUserActionForPlayback = []
        config.allowsInlineMediaPlayback = true

        // Register the console bridge BEFORE the page loads so early logs aren't lost.
        config.userContentController.add(context.coordinator, name: "consoleLog")

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.scrollView.backgroundColor = .black
        webView.scrollView.bounces = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        if #available(iOS 16.4, *) { webView.isInspectable = true }

        coordinator.webView = webView
        coordinator.pageLoaded = false
        webView.load(context.coordinator.request)

        let threeFingerHold = UILongPressGestureRecognizer(target: context.coordinator,
                                                           action: #selector(Coordinator.handleThreeFingerHold(_:)))
        threeFingerHold.numberOfTouchesRequired = 3
        threeFingerHold.minimumPressDuration = 0.5
        threeFingerHold.cancelsTouchesInView = false
        webView.addGestureRecognizer(threeFingerHold)

        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler {
        var parent: AJWebViewContainer
        var consoleWindow: UIWindow?
        var consoleTextView: UITextView?
        private var logBuffer: [String] = []
        private var retries = 0

        let request = URLRequest(url: URL(string: "http://127.0.0.1:\(LocalHTTPServer.port)/")!,
                                 cachePolicy: .reloadIgnoringLocalAndRemoteCacheData)

        init(_ parent: AJWebViewContainer) { self.parent = parent }

        // MARK: Navigation

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            retries = 0
            parent.coordinator.pageDidLoad()
        }

        // The local server may not be listening yet on a cold start -> retry instead of staying black.
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            retryLoad(webView, error: error)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            retryLoad(webView, error: error)
        }

        func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
            parent.coordinator.pageLoaded = false
            webView.load(request)
        }

        private func retryLoad(_ webView: WKWebView, error: Error) {
            appendLog("Page load failed: \(error.localizedDescription)")
            guard retries < 20 else { return }
            retries += 1
            parent.coordinator.pageLoaded = false
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak webView, request] in
                webView?.load(request)
            }
        }

        // MARK: Console

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            if message.name == "consoleLog", let text = message.body as? String {
                DispatchQueue.main.async { self.appendLog(text) }
            }
        }

        @objc func handleThreeFingerHold(_ gesture: UILongPressGestureRecognizer) {
            if gesture.state == .began { toggleConsole() }
        }

        func toggleConsole() {
            if let w = consoleWindow {
                w.isHidden = true
                consoleWindow = nil
                consoleTextView = nil
                return
            }

            guard let windowScene = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene }).first else { return }
            let width = windowScene.screen.bounds.width
            let win = UIWindow(windowScene: windowScene)
            win.frame = CGRect(x: 20, y: 50, width: width - 40, height: 350)
            win.windowLevel = .alert + 1
            win.backgroundColor = UIColor.black.withAlphaComponent(0.85)
            win.layer.cornerRadius = 12
            win.layer.borderWidth = 1
            win.layer.borderColor = UIColor.green.cgColor
            win.clipsToBounds = true

            let vc = UIViewController()
            vc.view.backgroundColor = .clear
            win.rootViewController = vc

            let tv = UITextView(frame: win.bounds.insetBy(dx: 10, dy: 10))
            tv.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            tv.backgroundColor = .clear
            tv.textColor = .green
            tv.font = UIFont.monospacedSystemFont(ofSize: 11, weight: .regular)
            tv.isEditable = false
            tv.text = "[Console - hold 3 fingers again to close]\n" + logBuffer.joined(separator: "\n")
            vc.view.addSubview(tv)

            win.isHidden = false
            consoleWindow = win
            consoleTextView = tv
            scrollToBottom()
        }

        func appendLog(_ text: String) {
            logBuffer.append(text)
            if logBuffer.count > 500 { logBuffer.removeFirst(logBuffer.count - 500) }
            guard let tv = consoleTextView else { return }
            tv.text += "\n" + text
            scrollToBottom()
        }

        private func scrollToBottom() {
            guard let tv = consoleTextView else { return }
            let len = (tv.text as NSString).length
            if len > 0 { tv.scrollRangeToVisible(NSRange(location: len - 1, length: 1)) }
        }
    }
}

struct HTMLTemplate {
    static let playerHTML = #"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
        <style>
            html, body { width: 100%; height: 100%; margin: 0; padding: 0; background-color: #000; overflow: hidden; touch-action: none; -webkit-user-select: none; }
            #player-container { width: 100%; height: 100%; position: absolute; top: 0; left: 0; }
            ruffle-player { display: block; }
        </style>
        <script>
            // ---- Console -> native bridge ----
            (function () {
                var lines = [];
                window.__ajHadError = false;
                window.__ajShow = function (line) {
                    if (line !== null && line !== undefined) { lines.push(line); if (lines.length > 32) lines.shift(); }
                    var el = document.getElementById('ajstatus');
                    if (el) el.textContent = lines.join('\n');
                };
                window.__ajHide = function () {
                    var el = document.getElementById('ajstatus');
                    if (el) el.style.display = 'none';
                };
                function send(m) {
                    if (/^(ERROR|WARN|JS Exception|Unhandled)/.test(m)) window.__ajHadError = true;
                    try { window.__ajShow(m); } catch (e) {}
                    try { window.webkit.messageHandlers.consoleLog.postMessage(m); } catch (e) {}
                }
                ['log', 'info', 'warn', 'error', 'debug'].forEach(function (k) {
                    var orig = console[k];
                    console[k] = function () {
                        var msg = [].slice.call(arguments).map(function (x) {
                            try { return (typeof x === 'object') ? JSON.stringify(x) : String(x); } catch (e) { return String(x); }
                        }).join(' ');
                        send((k === 'log' ? '' : k.toUpperCase() + ': ') + msg);
                        try { orig.apply(console, arguments); } catch (e) {}
                    };
                });
                window.addEventListener('error', function (e) {
                    send('JS Exception: ' + e.message + ' @' + (e.filename || '') + ':' + (e.lineno || ''));
                });
                window.addEventListener('unhandledrejection', function (e) {
                    send('Unhandled rejection: ' + ((e.reason && e.reason.message) || e.reason));
                });
            })();


            // ---- Spy: which JS names does the SWF look up through ExternalInterface? ----
            (function () {
                var seen = {}, n = 0, F = window.Function;
                function note(args) {
                    try {
                        var b = String(args[args.length - 1] || '');
                        if (/^\s*return\s/.test(b) && b.length < 120 && !seen[b] && n < 60) {
                            seen[b] = 1; n++; console.log('FN: ' + b.replace(/\s+/g, ' '));
                        }
                    } catch (e) {}
                }
                try {
                    window.Function = new Proxy(F, {
                        construct: function (t, a, nt) { note(a); return Reflect.construct(t, a, nt); },
                        apply: function (t, th, a) { note(a); return Reflect.apply(t, th, a); }
                    });
                } catch (e) { console.warn('Function spy unavailable: ' + e); }
            })();

            // ---- Route cross-origin game requests through the local proxy (adds CORS) ----
            (function () {
                var ORIGIN = location.origin;
                var DIRECT_HOSTS = ['unpkg.com', 'cdn.jsdelivr.net'];
                function rewrite(u) {
                    try {
                        var abs = new URL(u, location.href);
                        if (abs.protocol !== 'http:' && abs.protocol !== 'https:') return u;
                        if (abs.origin === ORIGIN) return u;
                        if (DIRECT_HOSTS.indexOf(abs.hostname) !== -1) return u;
                        return ORIGIN + '/proxy/' + abs.protocol.slice(0, -1) + '/' + abs.host + abs.pathname + abs.search;
                    } catch (e) { return u; }
                }
                window.__ajRewrite = rewrite;

                var origFetch = window.fetch;
                window.fetch = function (input, init) {
                    try {
                        if (typeof input === 'string' || (window.URL && input instanceof URL)) {
                            return origFetch.call(this, rewrite(String(input)), init);
                        }
                        if (window.Request && input instanceof Request) {
                            var nu = rewrite(input.url);
                            if (nu !== input.url) return origFetch.call(this, new Request(nu, input), init);
                        }
                    } catch (e) { console.error('fetch rewrite failed: ' + e); }
                    return origFetch.call(this, input, init);
                };

                var origOpen = XMLHttpRequest.prototype.open;
                XMLHttpRequest.prototype.open = function (method, url) {
                    var args = [].slice.call(arguments);
                    args[1] = rewrite(String(url));
                    return origOpen.apply(this, args);
                };
            })();

            // ---- Ruffle config + loader with CDN fallback ----
            window.RufflePlayer = window.RufflePlayer || {};
            window.RufflePlayer.config = {
                autoplay: "on",
                unmuteOverlay: "hidden",
                splashScreen: false,
                allowScriptAccess: true,
                warnOnUnsupportedContent: false,
                letterbox: "on",
                upgradeToHttps: false,
                backgroundColor: "#000000"
            };

            (function loadRuffle(urls, i) {
                if (i >= urls.length) { console.error('Ruffle failed to load from every CDN (check internet connection).'); return; }
                var s = document.createElement('script');
                s.src = urls[i];
                s.onload = function () { console.log('Ruffle loaded from ' + urls[i]); };
                s.onerror = function () {
                    console.warn('Ruffle CDN failed: ' + urls[i]);
                    loadRuffle(urls, i + 1);
                };
                document.head.appendChild(s);
            })([
                'https://unpkg.com/@ruffle-rs/ruffle',
                'https://cdn.jsdelivr.net/npm/@ruffle-rs/ruffle'
            ], 0);
        </script>
        <script>
            // ---- Minimal LZMA decoder (SWF "ZWS") ----
            function lzmaDecode(props, input, inOff, outSize) {
              var d = props[0], lc = d % 9; d = (d / 9) | 0; var lp = d % 5, pb = (d / 5) | 0;
              var out = new Uint8Array(outSize), outPos = 0, pos = inOff;
              var range = 4294967295, code = 0;
              if (input[pos++] !== 0) throw new Error('bad lzma stream');
              for (var i = 0; i < 4; i++) code = code * 256 + input[pos++];
              function mk(n) { var a = new Uint16Array(n); a.fill(1024); return a; }
              var isMatch = mk(192), isRep = mk(12), isRepG0 = mk(12), isRepG1 = mk(12), isRepG2 = mk(12), isRep0Long = mk(192);
              var posSlotP = mk(256), specPos = mk(115), align = mk(16);
              function mkLen() { return { c: mk(2), low: mk(128), mid: mk(128), high: mk(256) }; }
              var lenDec = mkLen(), repLen = mkLen();
              var lit = mk(0x300 << (lc + lp));
              function norm() { if (range < 16777216) { range *= 256; code = code * 256 + input[pos++]; } }
              function bit(p, i) {
                var pr = p[i], bound = (range >>> 11) * pr, b;
                if (code < bound) { range = bound; p[i] = pr + ((2048 - pr) >>> 5); b = 0; }
                else { range -= bound; code -= bound; p[i] = pr - (pr >>> 5); b = 1; }
                norm(); return b;
              }
              function direct(n) {
                var r = 0;
                while (n--) { range = Math.floor(range / 2); var b = 0; if (code >= range) { code -= range; b = 1; } r = r * 2 + b; norm(); }
                return r;
              }
              function tree(p, off, n) { var m = 1; for (var i = 0; i < n; i++) m = (m << 1) + bit(p, off + m); return m - (1 << n); }
              function rtree(p, off, n) { var m = 1, s = 0; for (var i = 0; i < n; i++) { var b = bit(p, off + m); m = (m << 1) + b; s |= b << i; } return s; }
              function len(L, ps) {
                if (!bit(L.c, 0)) return tree(L.low, ps << 3, 3);
                if (!bit(L.c, 1)) return 8 + tree(L.mid, ps << 3, 3);
                return 16 + tree(L.high, 0, 8);
              }
              function dist(l) {
                var ls = l < 4 ? l : 3, slot = tree(posSlotP, ls << 6, 6);
                if (slot < 4) return slot;
                var nd = (slot >> 1) - 1, dd = (2 | (slot & 1)) * Math.pow(2, nd);
                if (slot < 14) return dd + rtree(specPos, dd - slot, nd);
                return dd + direct(nd - 4) * 16 + rtree(align, 0, 4);
              }
              var state = 0, rep0 = 0, rep1 = 0, rep2 = 0, rep3 = 0;
              while (outPos < outSize) {
                var ps = outPos & ((1 << pb) - 1);
                if (!bit(isMatch, (state << 4) + ps)) {
                  var prev = outPos > 0 ? out[outPos - 1] : 0;
                  var base = 0x300 * (((outPos & ((1 << lp) - 1)) << lc) + (prev >> (8 - lc)));
                  var sym = 1;
                  if (state >= 7) {
                    var mb = out[outPos - rep0 - 1];
                    do {
                      var mbit = (mb >> 7) & 1; mb <<= 1;
                      var b = bit(lit, base + ((1 + mbit) << 8) + sym);
                      sym = (sym << 1) | b;
                      if (mbit !== b) break;
                    } while (sym < 0x100);
                  }
                  while (sym < 0x100) sym = (sym << 1) | bit(lit, base + sym);
                  out[outPos++] = sym & 255;
                  state = state < 4 ? 0 : (state < 10 ? state - 3 : state - 6);
                  continue;
                }
                var l;
                if (bit(isRep, state)) {
                  if (outPos === 0) throw new Error('lzma: bad rep');
                  if (!bit(isRepG0, state)) {
                    if (!bit(isRep0Long, (state << 4) + ps)) {
                      state = state < 7 ? 9 : 11; out[outPos] = out[outPos - rep0 - 1]; outPos++; continue;
                    }
                  } else {
                    var dd;
                    if (!bit(isRepG1, state)) dd = rep1;
                    else { if (!bit(isRepG2, state)) dd = rep2; else { dd = rep3; rep3 = rep2; } rep2 = rep1; }
                    rep1 = rep0; rep0 = dd;
                  }
                  l = len(repLen, ps); state = state < 7 ? 8 : 11;
                } else {
                  rep3 = rep2; rep2 = rep1; rep1 = rep0;
                  l = len(lenDec, ps); state = state < 7 ? 7 : 10;
                  rep0 = dist(l);
                  if (rep0 === 4294967295) break;
                }
                l += 2;
                if (rep0 >= outPos) throw new Error('lzma: bad distance');
                for (var k = 0; k < l && outPos < outSize; k++) { out[outPos] = out[outPos - rep0 - 1]; outPos++; }
              }
              if (outPos !== outSize) throw new Error('lzma: short output');
              return out;
            }

            // ---- SWF patch: flash.net.SecureSocket -> flash.net.Socket (AIR-only class missing in Ruffle) ----
            window.__ajAbcStrings = window.__ajAbcStrings || [];
            function patchAbcStrings(abc, from, to) {
              var p = 4;
              function vr() { var r = 0, s = 0, b; do { b = abc[p++]; r += (b & 127) * Math.pow(2, s); s += 7; } while (b & 128); return r; }
              var n = vr(); for (var i = 1; i < n; i++) vr();            // ints
              n = vr(); for (i = 1; i < n; i++) vr();                    // uints
              n = vr(); p += n > 1 ? (n - 1) * 8 : 0;                    // doubles
              var strCount = vr(), dec = new TextDecoder(), enc = new TextEncoder();
              var repl = enc.encode(to), hitStart = -1, hitEnd = -1;
              for (i = 1; i < strCount; i++) {
                var start = p, l = vr(), bodyStart = p;
                p += l;
                var str = dec.decode(abc.subarray(bodyStart, bodyStart + l));
                window.__ajAbcStrings.push(str);
                if (hitStart < 0 && str === from) { hitStart = start; hitEnd = p; }
              }
              if (hitStart < 0) return null;
              var lenBytes = [repl.length]; // < 128
              var out = new Uint8Array(abc.length - (hitEnd - hitStart) + lenBytes.length + repl.length);
              out.set(abc.subarray(0, hitStart), 0);
              out.set(lenBytes, hitStart);
              out.set(repl, hitStart + lenBytes.length);
              out.set(abc.subarray(hitEnd), hitStart + lenBytes.length + repl.length);
              return out;
            }

            function patchSWF(buf, from, to) {
              var u8 = new Uint8Array(buf);
              var sig = String.fromCharCode(u8[0], u8[1], u8[2]);
              var body;
              if (sig === 'FWS') body = u8.subarray(8);
              else if (sig === 'ZWS') {
                var total = (u8[4] | (u8[5] << 8) | (u8[6] << 16) | (u8[7] << 24)) >>> 0;
                body = lzmaDecode(u8.subarray(12, 17), u8, 17, total - 8);
              } else throw new Error('Unsupported SWF signature ' + sig + ' (CWS needs inflate)');

              var nbits = body[0] >> 3, p = Math.ceil((5 + nbits * 4) / 8) + 4; // RECT + framerate + framecount
              var chunks = [body.subarray(0, p)], patched = false;
              while (p < body.length) {
                var h = body[p] | (body[p + 1] << 8), code = h >> 6, len = h & 63, hl = 2;
                if (len === 63) { len = (body[p + 2] | (body[p + 3] << 8) | (body[p + 4] << 16) | (body[p + 5] << 24)) >>> 0; hl = 6; }
                var data = body.subarray(p + hl, p + hl + len);
                if (code === 82 || code === 72) {
                  var off = 0;
                  if (code === 82) { off = 4; while (data[off++] !== 0) {} }
                  var abc = patchAbcStrings(data.subarray(off), from, to);
                  if (abc) {
                    var nd = new Uint8Array(off + abc.length);
                    nd.set(data.subarray(0, off), 0); nd.set(abc, off);
                    var hdr = new Uint8Array(6), nl = nd.length;
                    var nh = (code << 6) | 63;
                    hdr[0] = nh & 255; hdr[1] = nh >> 8; hdr[2] = nl & 255; hdr[3] = (nl >> 8) & 255; hdr[4] = (nl >> 16) & 255; hdr[5] = (nl >>> 24) & 255;
                    chunks.push(hdr, nd); patched = true; p += hl + len; continue;
                  }
                }
                chunks.push(body.subarray(p, p + hl + len));
                p += hl + len;
                if (code === 0) break;
              }
              var sz = 0; chunks.forEach(function (c) { sz += c.length; });
              var out = new Uint8Array(8 + sz);
              out[0] = 70; out[1] = 87; out[2] = 83; out[3] = u8[3];
              var tl = 8 + sz; out[4] = tl & 255; out[5] = (tl >> 8) & 255; out[6] = (tl >> 16) & 255; out[7] = (tl >>> 24) & 255;
              var o = 8; chunks.forEach(function (c) { out.set(c, o); o += c.length; });
              return { data: out, patched: patched };
            }
        </script>
    </head>
    <body>
        <div id="player-container"></div>
        <pre id="ajstatus" style="position:fixed;left:6px;right:6px;bottom:6px;margin:0;z-index:99999;pointer-events:none;color:#7CFC00;font:9px/1.25 Menlo,monospace;white-space:pre-wrap;word-break:break-all;text-shadow:0 0 3px #000;"></pre>
        <script>
            window.__ajShow(null);
            console.log('Player page ready. WebAssembly: ' + (typeof WebAssembly));
            var seenProp = {};
            function spyObj(name, obj) {
                return new Proxy(obj, {
                    get: function (t, p, r) {
                        if (typeof p === 'string' && !seenProp[name + p]) {
                            seenProp[name + p] = 1;
                            console.log('HOST ' + name + '.' + p + (p in t ? '' : '  (MISSING)'));
                        }
                        if (typeof p === 'string' && !(p in t) && p !== 'then') return function () { return null; };
                        return Reflect.get(t, p, r);
                    }
                });
            }
            window.aj = spyObj('aj', {
                ready: function () { return true; },
                login: function () {},
                logout: function () {},
                reload: function () { location.reload(); },
                openExternalUrl: function (url) { console.log("External URL: " + url); },
                getDF: function () { return window.__ajFlashvars ? window.__ajFlashvars.df : ""; },
                getAuthToken: function () { return window.__ajFlashvars ? window.__ajFlashvars.auth_token : ""; },
                getUsername: function () { return window.__ajFlashvars ? window.__ajFlashvars.username : ""; },
                getPlatform: function () { return "mac"; },
                // Experiment: report a very high app version in case the client only checks a minimum.
                getVersion: function () { return "99.99.99"; },
                minimize: function () {}, maximize: function () {}, close: function () {}, showWindow: function () {}
            });
            window.ipcRenderer = spyObj('ipcRenderer', {
                send: function (ch) { console.log("IPC send: " + ch); },
                on: function () {},
                invoke: function (ch) { console.log("IPC invoke: " + ch); return Promise.resolve({}); }
            });

            function dumpAbcHints() {
                try {
                    var S = window.__ajAbcStrings || [];
                    console.log('ABC strings: ' + S.length);
                    var re = /version|updat|restart|classic|electron|userAgent|navigator|ExternalInterface|desktop|platform|ipc|launcher|appVer/i;
                    var seen = {}, out = [];
                    S.forEach(function (x) { if (re.test(x) && x.length < 80 && !seen[x]) { seen[x] = 1; out.push(x); } });
                    console.log('HINTS(' + out.length + '): ' + out.slice(0, 70).join(' | '));
                    for (var i = 0; i < S.length; i++) {
                        if (/needs to be updated|classic\.animaljam/i.test(S[i])) {
                            console.log('NEAR #' + i + ': ' + S.slice(Math.max(0, i - 14), i + 15).map(function (x) { return x.slice(0, 45); }).join(' | '));
                            break;
                        }
                    }
                } catch (e) { console.error('dumpAbcHints failed: ' + e); }
            }

            function whenRuffleReady(cb, waited) {
                waited = waited || 0;
                if (window.RufflePlayer && typeof window.RufflePlayer.newest === 'function') { cb(); return; }
                if (waited > 30000) { console.error('Timed out waiting for Ruffle.'); return; }
                setTimeout(function () { whenRuffleReady(cb, waited + 200); }, 200);
            }

            window.startAJWithSession = function (flashvars, swfUrl, baseContentUrl, socketProxies) {
                window.__ajFlashvars = flashvars;
                console.log("Starting Ruffle with SWF: " + swfUrl);
                whenRuffleReady(function () {
                    var container = document.getElementById("player-container");
                    container.innerHTML = "";

                    var ruffle = window.RufflePlayer.newest();
                    if (!ruffle) { console.error("Ruffle failed to initialise."); return; }

                    try { console.log("Ruffle version: " + (ruffle.version || (window.RufflePlayer.sources && Object.keys(window.RufflePlayer.sources)) || "?")); } catch (e) {}
                    var player = ruffle.createPlayer();
                    player.addEventListener("loadedmetadata", function () {
                        try { console.log("SWF metadata: " + JSON.stringify(player.metadata)); } catch (e) {}
                    });
                    player.style.width = "100%";
                    player.style.height = "100%";
                    container.appendChild(player);

                    player.addEventListener("fscommand", function (e) {
                        console.log("FSCommand: " + e.detail.command + " " + e.detail.args);
                    });

                    var common = {
                        base: baseContentUrl,
                        parameters: flashvars,
                        allowScriptAccess: true,
                        allowNetworking: "all",
                        letterbox: "on",
                        upgradeToHttps: false,
                        autoplay: "on",
                        unmuteOverlay: "hidden",
                        splashScreen: false,
                        backgroundColor: "#000000",
                        socketProxy: socketProxies || []
                    };
                    function finished() {
                        console.log("Ruffle load() resolved");
                        setTimeout(function () { if (!window.__ajHadError) window.__ajHide(); }, 20000);
                    }
                    function byUrl(reason) {
                        console.error(reason + " - loading SWF by URL (unpatched)");
                        return player.load(Object.assign({ url: swfUrl }, common)).then(finished);
                    }

                    // Ruffle has no flash.net.SecureSocket (AIR-only). Patch the SWF to use
                    // flash.net.Socket; the native bridge already does the TLS.
                    fetch(swfUrl).then(function (r) {
                        console.log("SWF fetch status " + r.status);
                        if (!r.ok) throw new Error("HTTP " + r.status);
                        return r.arrayBuffer();
                    }).then(function (buf) {
                        var t0 = Date.now();
                        var res = patchSWF(buf, "SecureSocket", "Socket");
                        console.log("SWF " + buf.byteLength + " bytes, patch " +
                            (res.patched ? "applied (SecureSocket -> Socket)" : "NOT applied (string not found)") +
                            " in " + (Date.now() - t0) + "ms");
                        dumpAbcHints();
                        return player.load(Object.assign({ data: res.data, swfFileName: "ajclient.swf" }, common)).then(finished);
                    }).catch(function (err) {
                        return byUrl("Patch/load failed: " + err);
                    }).catch(function (err) {
                        console.error("Ruffle load error: " + err);
                    });
                });
            };
        </script>
    </body>
    </html>
    """#
}
