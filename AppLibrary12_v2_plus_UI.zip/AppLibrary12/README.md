# AppLibrary12

Backports the iOS 14 **App Library** to **iOS 12.0 – 12.5.x** (`arm64`, rootful jailbreaks).

## Features
- **Rightmost Home Screen Page**: Extends `SBIconScrollView` and `SBRootFolderView` so swiping past your last Home Screen page smoothly reveals the App Library and fades out the Dock (iPhone) and page dots. On iPad the Dock stays visible by default (toggle "Also Fade Dock on iPad" in Settings).
- **2x2 Category Pods**: Groups apps using `LSApplicationProxy` App Store genres plus built-in mappings for stock iOS 12 `com.apple.*` apps and common jailbreak utilities (`Sileo`, `Zebra`, `Filza`, `NewTerm`, `iCleaner Pro`, `Dopamine`).
- **Dynamic Suggestions & Recently Added**: Tracks app launches locally (across both Home Screen and App Library) for **Suggestions** and uses `registeredDate` for **Recently Added**.
- **SnowBoard Theme Support**: Fetches icons via `SBIconModel` (`-[SBIcon getIconImage:2]`) so active SnowBoard/Anemone themes apply automatically.
- **Expanded Category Modal & A–Z Search**: Tap a 4-icon mini-cluster to open the full 4-column category grid, or tap the top search bar to switch to the live-filtered A–Z list with section index scrubbing.
- **Low-RAM Mode**: PreferenceLoader toggle (`Settings -> AppLibrary12`) that replaces live `UIVisualEffectView` blurs with lightweight translucent surfaces for 1 GB RAM devices (e.g., iPhone 6).

## Build & Install (Theos)
```bash
export THEOS=/path/to/theos
cd AppLibrary12
make package install
```
Or build the `.deb` for Sileo/Zebra/Filza:
```bash
make package FINALPACKAGE=1
```
