#import <Preferences/PSListController.h>

@interface AL12RootListController : PSListController
@end
