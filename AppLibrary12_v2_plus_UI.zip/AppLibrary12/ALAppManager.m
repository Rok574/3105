#import "ALAppManager.h"
#import "SpringBoardHeaders.h"

static NSString *const kALUsageDefaultsKey = @"com.skylight.applibrary12.usageStats";
static NSString *const kALCustomCatDefaultsKey = @"com.skylight.applibrary12.customCategories";

@implementation ALAppItem
@end

@implementation ALAppCategory
@end

@interface ALAppManager ()
@property (nonatomic, strong) NSArray<ALAppCategory *> *cachedCategories;
@property (nonatomic, strong) NSArray<ALAppItem *> *cachedSortedApps;
@property (nonatomic, strong) NSCache<NSString *, UIImage *> *iconCache;
@end

@implementation ALAppManager

+ (instancetype)sharedManager {
    static ALAppManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[ALAppManager alloc] init];
    });
    return instance;
}

+ (NSArray<NSString *> *)allCategoryNames {
    return @[
        @"Social",
        @"Utilities",
        @"Creativity",
        @"Productivity & Finance",
        @"Entertainment",
        @"Information & Reading",
        @"Games",
        @"Health & Fitness",
        @"Shopping & Food",
        @"Travel",
        @"Other"
    ];
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _iconCache = [[NSCache alloc] init];
        _iconCache.countLimit = 80;
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(clearIconCache)
                                                     name:UIApplicationDidReceiveMemoryWarningNotification
                                                   object:nil];
    }
    return self;
}

- (void)clearIconCache {
    [self.iconCache removeAllObjects];
}

+ (NSDictionary<NSString *, NSString *> *)systemCategoryMap {
    static NSDictionary<NSString *, NSString *> *map = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        map = @{
            // Social
            @"com.apple.MobileSMS": @"Social",
            @"com.apple.mobilephone": @"Social",
            @"com.apple.facetime": @"Social",
            @"com.apple.mobilemail": @"Social",
            @"com.apple.MobileAddressBook": @"Social",

            // Utilities
            @"com.apple.Preferences": @"Utilities",
            @"com.apple.mobiletimer": @"Utilities",
            @"com.apple.calculator": @"Utilities",
            @"com.apple.compass": @"Utilities",
            @"com.apple.measure": @"Utilities",
            @"com.apple.VoiceMemos": @"Utilities",
            @"com.apple.DocumentsApp": @"Utilities",
            @"com.apple.shortcuts": @"Utilities",
            @"com.apple.Bridge": @"Utilities",
            @"com.apple.mobileme.fmf1": @"Utilities",
            @"com.apple.mobileme.fmip1": @"Utilities",
            @"com.apple.AppStore": @"Utilities",
            @"com.apple.Home": @"Utilities",
            @"com.apple.Tips": @"Utilities",
            // Jailbreak Utilities
            @"org.coolstar.SileoStore": @"Utilities",
            @"xyz.willy.Zebra": @"Utilities",
            @"com.saurik.Cydia": @"Utilities",
            @"com.tigisoftware.Filza": @"Utilities",
            @"ws.hbang.NewTerm2": @"Utilities",
            @"com.exile90.icleanerpro": @"Utilities",
            @"com.opa334.Dopamine": @"Utilities",
            @"com.opa334.TrollStore": @"Utilities",

            // Creativity
            @"com.apple.camera": @"Creativity",
            @"com.apple.mobileslideshow": @"Creativity",
            @"com.apple.iMovie": @"Creativity",
            @"com.apple.mobilegarageband": @"Creativity",

            // Productivity & Finance
            @"com.apple.mobilecal": @"Productivity & Finance",
            @"com.apple.mobilenotes": @"Productivity & Finance",
            @"com.apple.reminders": @"Productivity & Finance",
            @"com.apple.Passbook": @"Productivity & Finance",
            @"com.apple.stocks": @"Productivity & Finance",
            @"com.apple.Pages": @"Productivity & Finance",
            @"com.apple.Numbers": @"Productivity & Finance",
            @"com.apple.Keynote": @"Productivity & Finance",

            // Entertainment
            @"com.apple.Music": @"Entertainment",
            @"com.apple.tv": @"Entertainment",
            @"com.apple.podcasts": @"Entertainment",
            @"com.apple.iBooks": @"Entertainment",

            // Information & Reading
            @"com.apple.mobilesafari": @"Information & Reading",
            @"com.apple.weather": @"Information & Reading",
            @"com.apple.Maps": @"Information & Reading",
            @"com.apple.news": @"Information & Reading",

            // Health & Fitness
            @"com.apple.Health": @"Health & Fitness",
            @"com.apple.Fitness": @"Health & Fitness",

            // Games
            @"com.apple.gamecenter": @"Games"
        };
    });
    return map;
}

+ (NSDictionary<NSNumber *, NSString *> *)genreIDMap {
    static NSDictionary<NSNumber *, NSString *> *map = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        map = @{
            @6000: @"Productivity & Finance", // Business
            @6001: @"Information & Reading",  // Weather
            @6002: @"Utilities",              // Utilities
            @6003: @"Travel",                 // Travel
            @6004: @"Entertainment",          // Sports
            @6005: @"Social",                 // Social Networking
            @6006: @"Information & Reading",  // Reference
            @6007: @"Productivity & Finance", // Productivity
            @6008: @"Creativity",             // Photo & Video
            @6009: @"Information & Reading",  // News
            @6010: @"Travel",                 // Navigation
            @6011: @"Entertainment",          // Music
            @6012: @"Utilities",              // Lifestyle
            @6013: @"Health & Fitness",       // Health & Fitness
            @6014: @"Games",                  // Games
            @6015: @"Productivity & Finance", // Finance
            @6016: @"Entertainment",          // Entertainment
            @6017: @"Information & Reading",  // Education
            @6018: @"Information & Reading",  // Books
            @6020: @"Health & Fitness",       // Medical
            @6021: @"Information & Reading",  // Magazines & Newspapers
            @6022: @"Shopping & Food",        // Catalogs
            @6023: @"Shopping & Food",        // Food & Drink
            @6024: @"Shopping & Food",        // Shopping
            @6026: @"Utilities",              // Developer Tools
            @6027: @"Creativity"              // Graphics & Design
        };
    });
    return map;
}

- (NSString *)categoryForProxy:(LSApplicationProxy *)proxy bundleID:(NSString *)bundleID customMap:(NSDictionary *)customMap {
    NSString *custom = customMap[bundleID];
    if (custom.length > 0) {
        return custom;
    }

    NSString *systemCat = [ALAppManager systemCategoryMap][bundleID];
    if (systemCat) {
        return systemCat;
    }

    NSNumber *genreID = [proxy respondsToSelector:@selector(genreID)] ? proxy.genreID : nil;
    if (genreID && [genreID integerValue] > 0) {
        NSString *byID = [ALAppManager genreIDMap][genreID];
        if (byID) return byID;
    }

    NSString *genre = [proxy respondsToSelector:@selector(genre)] ? proxy.genre : nil;
    if (genre.length > 0) {
        NSString *g = genre.lowercaseString;
        if ([g containsString:@"game"]) return @"Games";
        if ([g containsString:@"social"] || [g containsString:@"messaging"]) return @"Social";
        if ([g containsString:@"photo"] || [g containsString:@"video"] || [g containsString:@"graphic"] || [g containsString:@"design"]) return @"Creativity";
        if ([g containsString:@"productiv"] || [g containsString:@"finance"] || [g containsString:@"business"]) return @"Productivity & Finance";
        if ([g containsString:@"entertain"] || [g containsString:@"music"] || [g containsString:@"sport"]) return @"Entertainment";
        if ([g containsString:@"news"] || [g containsString:@"book"] || [g containsString:@"reference"] || [g containsString:@"education"] || [g containsString:@"weather"] || [g containsString:@"magazine"]) return @"Information & Reading";
        if ([g containsString:@"utilit"] || [g containsString:@"developer"] || [g containsString:@"lifestyle"]) return @"Utilities";
        if ([g containsString:@"health"] || [g containsString:@"fitness"] || [g containsString:@"medical"]) return @"Health & Fitness";
        if ([g containsString:@"shop"] || [g containsString:@"food"] || [g containsString:@"drink"]) return @"Shopping & Food";
        if ([g containsString:@"travel"] || [g containsString:@"nav"]) return @"Travel";
    }

    // Jailbreak / common app name fallback so Utilities & Social stay accurate
    NSString *lowerID = bundleID.lowercaseString;
    if ([lowerID containsString:@"amethyst"] || [lowerID containsString:@"filza"] ||
        [lowerID containsString:@"icleaner"] || [lowerID containsString:@"newterm"] ||
        [lowerID containsString:@"sileo"] || [lowerID containsString:@"zebra"] ||
        [lowerID containsString:@"cydia"] || [lowerID containsString:@"cocoatop"] ||
        [lowerID containsString:@"choicy"] || [lowerID containsString:@"dopamine"]) {
        return @"Utilities";
    }
    if ([lowerID containsString:@"discord"] || [lowerID containsString:@"telegram"] ||
        [lowerID containsString:@"whatsapp"] || [lowerID containsString:@"snapchat"] ||
        [lowerID containsString:@"instagram"] || [lowerID containsString:@"facebook"] ||
        [lowerID containsString:@"twitter"] || [lowerID containsString:@"messenger"]) {
        return @"Social";
    }

    return @"Other";
}

- (void)reloadApps {
    SBApplicationController *appController = [NSClassFromString(@"SBApplicationController") sharedInstance];
    SBIconModel *iconModel = [(SBIconController *)[NSClassFromString(@"SBIconController") sharedInstance] model];
    NSDictionary<NSString *, NSDictionary *> *usageStats = [[NSUserDefaults standardUserDefaults] dictionaryForKey:kALUsageDefaultsKey] ?: @{};
    NSDictionary<NSString *, NSString *> *customMap = [[NSUserDefaults standardUserDefaults] dictionaryForKey:kALCustomCatDefaultsKey] ?: @{};

    NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
    NSMutableArray<ALAppItem *> *items = [NSMutableArray array];
    NSMutableSet<NSString *> *seenBundleIDs = [NSMutableSet set];

    for (SBApplication *sbApp in [appController allApplications]) {
        NSString *bundleID = sbApp.bundleIdentifier;
        if (!bundleID || [seenBundleIDs containsObject:bundleID]) continue;
        [seenBundleIDs addObject:bundleID];

        LSApplicationProxy *proxy = [NSClassFromString(@"LSApplicationProxy") applicationProxyForIdentifier:bundleID];
        if (!proxy) continue;
        if ([proxy.applicationType isEqualToString:@"Hidden"]) continue;
        if ([proxy respondsToSelector:@selector(appTags)] && [proxy.appTags containsObject:@"hidden"]) continue;
        if ([bundleID isEqualToString:@"com.apple.springboard"] ||
            [bundleID isEqualToString:@"com.apple.webapp"] ||
            [bundleID isEqualToString:@"com.apple.WebSheet"]) {
            continue;
        }

        SBApplicationIcon *sbIcon = [iconModel applicationIconForBundleIdentifier:bundleID];
        if (!sbIcon) continue;

        NSString *name = sbApp.displayName ?: proxy.localizedName ?: bundleID;
        if (name.length == 0) continue;

        NSDictionary *stat = usageStats[bundleID];
        double count = [stat[@"count"] doubleValue];
        double lastTs = [stat[@"last"] doubleValue];
        double hoursAgo = lastTs > 0 ? MAX(0.1, (now - lastTs) / 3600.0) : 9999.0;
        // Recency-weighted score: frequent + recently launched apps rank highest
        double score = (count * 1.5) + (lastTs > 0 ? (48.0 / (hoursAgo + 2.0)) : 0.0);

        ALAppItem *item = [[ALAppItem alloc] init];
        item.bundleIdentifier = bundleID;
        item.displayName = name;
        item.categoryName = [self categoryForProxy:proxy bundleID:bundleID customMap:customMap];
        NSDate *registered = [proxy respondsToSelector:@selector(registeredDate)] ? proxy.registeredDate : nil;
        item.installedDate = registered ?: [NSDate distantPast];
        item.badgeCount = [sbIcon respondsToSelector:@selector(badgeValue)] ? (NSInteger)[sbIcon badgeValue] : 0;
        item.suggestionScore = score;

        [items addObject:item];
    }

    // Alphabetical list
    self.cachedSortedApps = [items sortedArrayUsingComparator:^NSComparisonResult(ALAppItem *a, ALAppItem *b) {
        return [a.displayName localizedCaseInsensitiveCompare:b.displayName];
    }];

    // Group by category & sort apps within each category by suggestionScore then name
    NSMutableDictionary<NSString *, NSMutableArray<ALAppItem *> *> *grouped = [NSMutableDictionary dictionary];
    for (ALAppItem *item in self.cachedSortedApps) {
        NSMutableArray *list = grouped[item.categoryName];
        if (!list) {
            list = [NSMutableArray array];
            grouped[item.categoryName] = list;
        }
        [list addObject:item];
    }

    NSMutableArray<ALAppCategory *> *finalCategories = [NSMutableArray array];

    // 1. Suggestions
    NSArray<ALAppItem *> *byScore = [items sortedArrayUsingComparator:^NSComparisonResult(ALAppItem *a, ALAppItem *b) {
        if (fabs(a.suggestionScore - b.suggestionScore) > 0.001) {
            return a.suggestionScore > b.suggestionScore ? NSOrderedAscending : NSOrderedDescending;
        }
        return [a.displayName localizedCaseInsensitiveCompare:b.displayName];
    }];
    if (byScore.count > 0) {
        ALAppCategory *suggestions = [[ALAppCategory alloc] init];
        suggestions.title = @"Suggestions";
        suggestions.apps = [byScore subarrayWithRange:NSMakeRange(0, MIN(4, byScore.count))];
        [finalCategories addObject:suggestions];
    }

    // 2. Recently Added (user apps, newest first)
    NSMutableArray<ALAppItem *> *userApps = [NSMutableArray array];
    for (ALAppItem *item in items) {
        if (![item.bundleIdentifier hasPrefix:@"com.apple."]) {
            [userApps addObject:item];
        }
    }
    if (userApps.count > 0) {
        NSArray<ALAppItem *> *recent = [userApps sortedArrayUsingComparator:^NSComparisonResult(ALAppItem *a, ALAppItem *b) {
            return [b.installedDate compare:a.installedDate];
        }];
        ALAppCategory *recentlyAdded = [[ALAppCategory alloc] init];
        recentlyAdded.title = @"Recently Added";
        recentlyAdded.apps = [recent subarrayWithRange:NSMakeRange(0, MIN(7, recent.count))];
        [finalCategories addObject:recentlyAdded];
    }

    // 3. Dynamic category pods sorted by app count & total usage score (like iOS 14+)
    NSMutableArray<ALAppCategory *> *dynamicPods = [NSMutableArray array];
    for (NSString *catName in [ALAppManager allCategoryNames]) {
        NSArray<ALAppItem *> *catApps = grouped[catName];
        if (catApps.count > 0) {
            NSArray<ALAppItem *> *sortedPodApps = [catApps sortedArrayUsingComparator:^NSComparisonResult(ALAppItem *a, ALAppItem *b) {
                if (fabs(a.suggestionScore - b.suggestionScore) > 0.001) {
                    return a.suggestionScore > b.suggestionScore ? NSOrderedAscending : NSOrderedDescending;
                }
                return [a.displayName localizedCaseInsensitiveCompare:b.displayName];
            }];
            ALAppCategory *cat = [[ALAppCategory alloc] init];
            cat.title = catName;
            cat.apps = sortedPodApps;
            [dynamicPods addObject:cat];
        }
    }

    [dynamicPods sortUsingComparator:^NSComparisonResult(ALAppCategory *a, ALAppCategory *b) {
        if (a.apps.count != b.apps.count) {
            return a.apps.count > b.apps.count ? NSOrderedAscending : NSOrderedDescending;
        }
        return [a.title compare:b.title];
    }];

    [finalCategories addObjectsFromArray:dynamicPods];
    self.cachedCategories = finalCategories;
}

- (NSArray<ALAppCategory *> *)categories {
    if (!self.cachedCategories) {
        [self reloadApps];
    }
    return self.cachedCategories ?: @[];
}

- (NSArray<ALAppItem *> *)allAppsSorted {
    if (!self.cachedSortedApps) {
        [self reloadApps];
    }
    return self.cachedSortedApps ?: @[];
}

- (SBApplicationIcon *)sbIconForBundleIdentifier:(NSString *)bundleID {
    if (!bundleID) return nil;
    SBIconModel *iconModel = [(SBIconController *)[NSClassFromString(@"SBIconController") sharedInstance] model];
    return [iconModel applicationIconForBundleIdentifier:bundleID];
}

- (UIImage *)iconForBundleIdentifier:(NSString *)bundleID {
    if (!bundleID) return nil;
    UIImage *cached = [self.iconCache objectForKey:bundleID];
    if (cached) return cached;

    SBApplicationIcon *icon = [self sbIconForBundleIdentifier:bundleID];
    UIImage *img = nil;
    if ([icon respondsToSelector:@selector(getIconImage:)]) {
        img = [icon getIconImage:2];
    }
    if (img) {
        [self.iconCache setObject:img forKey:bundleID];
    }
    return img;
}

- (void)recordLaunchForBundleIdentifier:(NSString *)bundleID {
    if (!bundleID) return;
    NSMutableDictionary *stats = [[[NSUserDefaults standardUserDefaults] dictionaryForKey:kALUsageDefaultsKey] mutableCopy] ?: [NSMutableDictionary dictionary];
    NSMutableDictionary *entry = [stats[bundleID] mutableCopy] ?: [NSMutableDictionary dictionary];
    entry[@"count"] = @([entry[@"count"] unsignedIntegerValue] + 1);
    entry[@"last"] = @([[NSDate date] timeIntervalSince1970]);
    stats[bundleID] = entry;
    [[NSUserDefaults standardUserDefaults] setObject:stats forKey:kALUsageDefaultsKey];
}

- (void)setCustomCategory:(NSString *)categoryName forBundleIdentifier:(NSString *)bundleID {
    if (!bundleID) return;
    NSMutableDictionary *customMap = [[[NSUserDefaults standardUserDefaults] dictionaryForKey:kALCustomCatDefaultsKey] mutableCopy] ?: [NSMutableDictionary dictionary];
    if (categoryName.length > 0) {
        customMap[bundleID] = categoryName;
    } else {
        [customMap removeObjectForKey:bundleID];
    }
    [[NSUserDefaults standardUserDefaults] setObject:customMap forKey:kALCustomCatDefaultsKey];
    [self reloadApps];
}

- (void)launchAppWithBundleIdentifier:(NSString *)bundleID {
    if (!bundleID) return;
    [self recordLaunchForBundleIdentifier:bundleID];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ALAppLibrary12WillLaunchApp" object:bundleID];
    UIApplication *app = [UIApplication sharedApplication];
    if ([app respondsToSelector:@selector(launchApplicationWithIdentifier:suspended:)]) {
        [app launchApplicationWithIdentifier:bundleID suspended:NO];
        return;
    }
    // Fallback: activate through SBUIController.
    SBApplication *sbApp = [[NSClassFromString(@"SBApplicationController") sharedInstance] applicationWithBundleIdentifier:bundleID];
    id ui = [NSClassFromString(@"SBUIController") sharedInstance];
    if (sbApp && [ui respondsToSelector:@selector(activateApplicationAnimated:)]) {
        [ui activateApplicationAnimated:sbApp];
    }
}

@end
