#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import "Headers/SpringBoardHeaders.h"
#import "ALAppManager.h"
#import "ALAppLibraryView.h"

static CFStringRef const kALPrefsDomain = CFSTR("com.skylight.applibrary12");

static const void *kALViewAssocKey       = &kALViewAssocKey;
static const void *kALWasInLibraryKey    = &kALWasInLibraryKey;
static const void *kALBackdropBlurKey    = &kALBackdropBlurKey;
static const void *kALBackdropDimKey     = &kALBackdropDimKey;
static const void *kALBackdropStyleKey   = &kALBackdropStyleKey;
static const void *kALOrigWidthKey       = &kALOrigWidthKey;

static BOOL prefEnabled = YES;
static BOOL prefDarkStyle = YES;
static BOOL prefLowRAMMode = NO;
static BOOL prefHideDock = YES;
static BOOL prefHideDockOnPad = NO;   // iPad: dock stays visible unless the user opts in
static BOOL prefShowLabels = YES;

static BOOL al_isLaunchingFromLibrary = NO;
static NSUInteger al_launchToken = 0;
static CGFloat al_appLibraryProgress = 0.0;   // always recomputed from live scroll geometry
static BOOL al_dockModified = NO;             // true only while WE have changed the dock's alpha
static BOOL al_pageControlModified = NO;

#pragma mark - Helpers

static inline BOOL al_isPad(void) {
    return UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad;
}

static BOOL al_boolPref(NSString *key, BOOL fallback) {
    CFPropertyListRef value = CFPreferencesCopyAppValue((__bridge CFStringRef)key, kALPrefsDomain);
    if (!value) return fallback;
    id obj = CFBridgingRelease(value);
    return [obj respondsToSelector:@selector(boolValue)] ? [obj boolValue] : fallback;
}

static void loadPreferences(void) {
    CFPreferencesAppSynchronize(kALPrefsDomain);
    prefEnabled       = al_boolPref(@"enabled", YES);
    prefDarkStyle     = al_boolPref(@"darkStyle", YES);
    prefLowRAMMode    = al_boolPref(@"lowRAMMode", NO);
    prefHideDock      = al_boolPref(@"hideDock", YES);
    prefHideDockOnPad = al_boolPref(@"hideDockOnPad", NO);
    prefShowLabels    = al_boolPref(@"showLabels", YES);
}

static BOOL al_isEditing(void) {
    @try {
        id ic = [%c(SBIconController) sharedInstance];
        if ([ic respondsToSelector:@selector(isEditing)]) return [(SBIconController *)ic isEditing];
    } @catch (NSException *e) {}
    return NO;
}

// The extra App Library page exists only while enabled and NOT in Home Screen edit (jiggle) mode,
// exactly like iOS 14 where the library disappears while rearranging icons.
static BOOL al_extraPageActive(void) {
    return prefEnabled && !al_isEditing();
}

// Should the dock fade out while the App Library is showing?
static BOOL al_dockFadeEnabled(void) {
    if (!prefEnabled || !prefHideDock) return NO;
    if (al_isPad() && !prefHideDockOnPad) return NO;
    return YES;
}

static id al_call(id obj, NSString *selName) {
    SEL sel = NSSelectorFromString(selName);
    if (!obj || ![obj respondsToSelector:sel]) return nil;
    return ((id (*)(id, SEL))objc_msgSend)(obj, sel);
}

// iPad floating dock container (only exists on iPad).
static UIView *al_floatingDockContainer(void) {
    if (!al_isPad()) return nil;
    @try {
        id iconCtrl = [%c(SBIconController) sharedInstance];
        id dockCtrl = al_call(iconCtrl, @"floatingDockController");
        id vc = al_call(dockCtrl, @"floatingDockViewController");
        if ([vc isKindOfClass:[UIViewController class]] && [(UIViewController *)vc isViewLoaded]) {
            return ((UIViewController *)vc).view;
        }
    } @catch (NSException *e) {}
    return nil;
}

static void al_setDockState(SBRootFolderView *fv, CGFloat alpha, BOOL interactive) {
    UIView *dock = fv.dockView;
    if (dock) {
        dock.alpha = alpha;
        dock.userInteractionEnabled = interactive;
    }
    UIView *floating = al_floatingDockContainer();
    if (floating) {
        floating.alpha = alpha;
        floating.userInteractionEnabled = interactive;
    }
}

// Geometry of the extra App Library page, derived from the content width SpringBoard
// asked for (not from the padded size), so it stays correct across rotations.
static BOOL al_libraryGeometry(UIScrollView *sv, CGFloat *outPageWidth, CGFloat *outLastIconX, CGFloat *outLibraryX) {
    CGFloat pw = sv.bounds.size.width;
    if (pw <= 0.0) return NO;
    NSNumber *orig = objc_getAssociatedObject(sv, kALOrigWidthKey);
    if (!orig) return NO;
    CGFloat libX = [orig doubleValue];
    if (libX < pw - 0.5) return NO;                           // need at least one icon page
    if (fabs(sv.contentSize.width - (libX + pw)) > 1.0) return NO; // padding not applied / layout in flux
    if (outPageWidth) *outPageWidth = pw;
    if (outLastIconX) *outLastIconX = libX - pw;
    if (outLibraryX) *outLibraryX = libX;
    return YES;
}

static CGFloat al_libraryProgress(SBRootFolderView *fv) {
    if (!fv || !prefEnabled || !fv.window) return 0.0;
    CGFloat pw = 0, lastX = 0, libX = 0;
    if (!al_libraryGeometry(fv.scrollView, &pw, &lastX, &libX)) return 0.0;
    CGFloat progress = (fv.scrollView.contentOffset.x - lastX) / pw;
    progress = fmin(fmax(progress, 0.0), 1.0);
    return (progress < 0.02) ? 0.0 : progress;
}

// Single place that turns the scroll position into dock / page control / backdrop state.
static void al_refreshLibraryState(SBRootFolderView *fv) {
    if (!fv) return;
    CGFloat progress = al_libraryProgress(fv);
    al_appLibraryProgress = progress;

    // Dock: only touched while fading; restored exactly once afterwards.
    if (al_dockFadeEnabled() && progress > 0.0) {
        al_dockModified = YES;
        al_setDockState(fv, 1.0 - progress, progress < 0.5);
    } else if (al_dockModified) {
        al_dockModified = NO;
        al_setDockState(fv, 1.0, YES);
    }

    // Page dots
    if (fv.pageControl) {
        if (progress > 0.0) {
            al_pageControlModified = YES;
            fv.pageControl.alpha = 1.0 - progress;
        } else if (al_pageControlModified) {
            al_pageControlModified = NO;
            fv.pageControl.alpha = 1.0;
        }
    }

    // Backdrop (blur normally, plain translucent dim in Low-RAM mode)
    UIVisualEffectView *bgBlur = objc_getAssociatedObject(fv, kALBackdropBlurKey);
    UIView *bgDim = objc_getAssociatedObject(fv, kALBackdropDimKey);
    if (bgBlur) {
        bgBlur.hidden = prefLowRAMMode;
        bgBlur.alpha = prefLowRAMMode ? 0.0 : progress;
    }
    if (bgDim) {
        bgDim.hidden = !prefLowRAMMode;
        bgDim.alpha = prefLowRAMMode ? progress : 0.0;
    }

    // Entering / leaving the library
    ALAppLibraryView *libView = objc_getAssociatedObject(fv, kALViewAssocKey);
    BOOL wasInLibrary = [objc_getAssociatedObject(fv, kALWasInLibraryKey) boolValue];
    if (progress > 0.5 && !wasInLibrary) {
        objc_setAssociatedObject(fv, kALWasInLibraryKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    } else if (progress <= 0.02 && wasInLibrary) {
        objc_setAssociatedObject(fv, kALWasInLibraryKey, @NO, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        [libView resetToDefaultState];
        [libView reloadData]; // refresh Suggestions / badges for next visit
    }
}

static void prefsChangedCallback(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{
        loadPreferences();
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ALAppLibrary12PrefsUpdated" object:nil];
    });
}

static void themeReloadCallback(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[ALAppManager sharedManager] clearIconCache];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ALAppLibrary12ThemeUpdated" object:nil];
    });
}

#pragma mark - Scroll view (extra page)

%hook SBIconScrollView

- (void)setContentSize:(CGSize)contentSize {
    if ([self.delegate isKindOfClass:%c(SBRootFolderView)]) {
        // Remember what SpringBoard actually asked for.
        objc_setAssociatedObject(self, kALOrigWidthKey, @(contentSize.width), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        CGFloat pageWidth = self.bounds.size.width;
        if (al_extraPageActive() && pageWidth > 0 && contentSize.width > 0) {
            contentSize.width += pageWidth;
        }
    }
    %orig(contentSize);
}

%end

#pragma mark - Root folder view

%hook SBRootFolderView

- (void)layoutSubviews {
    %orig;

    UIScrollView *scrollView = self.scrollView;
    if (!scrollView) return;

    ALAppLibraryView *existing = objc_getAssociatedObject(self, kALViewAssocKey);

    if (!al_extraPageActive()) {
        existing.hidden = YES;
        // Remove the extra page (tweak disabled, or Home Screen is being edited).
        NSNumber *orig = objc_getAssociatedObject(scrollView, kALOrigWidthKey);
        if (orig && fabs(scrollView.contentSize.width - [orig doubleValue]) > 0.5) {
            scrollView.contentSize = CGSizeMake([orig doubleValue], scrollView.contentSize.height);
        }
        if (orig) {
            CGFloat maxX = MAX(0.0, [orig doubleValue] - scrollView.bounds.size.width);
            if (scrollView.contentOffset.x > maxX + 0.5) {
                [scrollView setContentOffset:CGPointMake(maxX, 0) animated:NO];
            }
        }
        [existing resetToDefaultState];
        al_refreshLibraryState(self);
        return;
    }

    CGFloat pageWidth = scrollView.bounds.size.width;
    CGFloat pageHeight = self.bounds.size.height;
    if (pageWidth <= 0 || pageHeight <= 0) return;

    // If the padding was missed (e.g. bounds were still zero when SpringBoard set the size), reapply it.
    NSNumber *orig = objc_getAssociatedObject(scrollView, kALOrigWidthKey);
    if (orig && fabs(scrollView.contentSize.width - ([orig doubleValue] + pageWidth)) > 0.5) {
        scrollView.contentSize = CGSizeMake([orig doubleValue], scrollView.contentSize.height); // hook pads it
    }

    // Backdrops
    UIVisualEffectView *bgBlur = objc_getAssociatedObject(self, kALBackdropBlurKey);
    UIView *bgDim = objc_getAssociatedObject(self, kALBackdropDimKey);
    if (!bgBlur) {
        bgBlur = [[UIVisualEffectView alloc] initWithEffect:nil];
        bgBlur.userInteractionEnabled = NO;
        bgBlur.alpha = 0.0;
        bgBlur.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [self insertSubview:bgBlur atIndex:0];
        objc_setAssociatedObject(self, kALBackdropBlurKey, bgBlur, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    if (!bgDim) {
        bgDim = [[UIView alloc] init];
        bgDim.userInteractionEnabled = NO;
        bgDim.alpha = 0.0;
        bgDim.hidden = YES;
        bgDim.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [self insertSubview:bgDim atIndex:0];
        objc_setAssociatedObject(self, kALBackdropDimKey, bgDim, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    NSNumber *appliedStyle = objc_getAssociatedObject(self, kALBackdropStyleKey);
    if (!appliedStyle || [appliedStyle boolValue] != prefDarkStyle) {
        bgBlur.effect = [UIBlurEffect effectWithStyle:prefDarkStyle ? UIBlurEffectStyleDark : UIBlurEffectStyleLight];
        bgDim.backgroundColor = prefDarkStyle ? [UIColor colorWithWhite:0.0 alpha:0.55]
                                              : [UIColor colorWithWhite:1.0 alpha:0.55];
        objc_setAssociatedObject(self, kALBackdropStyleKey, @(prefDarkStyle), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    if (!CGRectEqualToRect(bgBlur.frame, self.bounds)) bgBlur.frame = self.bounds;
    if (!CGRectEqualToRect(bgDim.frame, self.bounds)) bgDim.frame = self.bounds;

    ALAppLibraryView *libView = existing;
    if (!libView) {
        libView = [[ALAppLibraryView alloc] initWithFrame:CGRectMake(0, 0, pageWidth, pageHeight)];
        libView.darkStyle = prefDarkStyle;
        libView.lowRAMMode = prefLowRAMMode;
        libView.showCategoryLabels = prefShowLabels;
        [scrollView addSubview:libView];
        objc_setAssociatedObject(self, kALViewAssocKey, libView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

        __weak ALAppLibraryView *weakLib = libView;
        __weak SBRootFolderView *weakSelf = self;
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];

        [nc addObserverForName:@"ALAppLibrary12PrefsUpdated" object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
            ALAppLibraryView *lv = weakLib;
            if (!lv) return;
            lv.hidden = !prefEnabled;
            lv.darkStyle = prefDarkStyle;
            lv.lowRAMMode = prefLowRAMMode;
            lv.showCategoryLabels = prefShowLabels;
            [lv reloadData];
            SBRootFolderView *fv = weakSelf;
            [fv setNeedsLayout];
            al_refreshLibraryState(fv);
        }];

        [nc addObserverForName:@"ALAppLibrary12EditingChanged" object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
            SBRootFolderView *fv = weakSelf;
            if (!fv) return;
            [fv setNeedsLayout];
            [fv layoutIfNeeded];
            al_refreshLibraryState(fv);
        }];

        [nc addObserverForName:@"ALAppLibrary12ThemeUpdated" object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
            [weakLib reloadData];
        }];

        [nc addObserverForName:@"ALAppLibrary12OpenFromDock" object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
            SBRootFolderView *fv = weakSelf;
            if (!fv || !al_extraPageActive()) return;
            CGFloat pw = 0, lastX = 0, libX = 0;
            if (al_libraryGeometry(fv.scrollView, &pw, &lastX, &libX)) {
                [fv.scrollView setContentOffset:CGPointMake(libX, 0) animated:YES];
            }
        }];

        [nc addObserverForName:@"ALAppLibrary12DeviceLocked" object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
            SBRootFolderView *fv = weakSelf;
            if (!fv || !prefEnabled) return;
            CGFloat pw = 0, lastX = 0, libX = 0;
            if (al_libraryGeometry(fv.scrollView, &pw, &lastX, &libX) && fv.scrollView.contentOffset.x > lastX + 1.0) {
                [fv.scrollView setContentOffset:CGPointMake(lastX, 0) animated:NO];
            }
            [weakLib resetToDefaultState];
            al_refreshLibraryState(fv);
        }];
    }

    libView.hidden = NO;

    // Leave room for the dock when it stays visible over the library page.
    CGFloat bottomInset = 0.0;
    if (!al_dockFadeEnabled()) {
        UIView *dock = self.dockView;
        if (dock && dock.superview == self && !dock.hidden) {
            bottomInset = MAX(0.0, self.bounds.size.height - CGRectGetMinY(dock.frame));
        }
        if (al_isPad()) bottomInset = MAX(bottomInset, 130.0);
    }
    libView.bottomContentInset = bottomInset;

    CGFloat appLibraryX = orig ? [orig doubleValue] : MAX(0.0, scrollView.contentSize.width - pageWidth);
    CGRect targetFrame = CGRectMake(appLibraryX, 0, pageWidth, pageHeight);
    if (!CGRectEqualToRect(libView.frame, targetFrame)) {
        libView.frame = targetFrame;
    }

    al_refreshLibraryState(self);
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    %orig;
    if (scrollView != self.scrollView) return;
    al_refreshLibraryState(self);
}

- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(CGPoint *)targetContentOffset {
    %orig;
    if (!al_extraPageActive() || scrollView != self.scrollView) return;

    CGFloat pw = 0, lastX = 0, libX = 0;
    if (!al_libraryGeometry(scrollView, &pw, &lastX, &libX)) return;
    if (scrollView.contentOffset.x <= lastX - 10.0) return; // not near the library yet

    if (velocity.x > 0.25 || targetContentOffset->x > lastX + pw * 0.35) {
        targetContentOffset->x = libX;
    } else if (targetContentOffset->x > lastX) {
        targetContentOffset->x = lastX;
    }
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    if (al_extraPageActive() && self.scrollView) {
        CGFloat pw = 0, lastX = 0, libX = 0;
        if (al_libraryGeometry(self.scrollView, &pw, &lastX, &libX) &&
            self.scrollView.contentOffset.x > lastX + pw * 0.5) {
            // Keep a still-visible dock tappable.
            UIView *dock = self.dockView;
            if (dock && !dock.hidden && dock.alpha > 0.01 && dock.userInteractionEnabled &&
                CGRectContainsPoint(dock.frame, point)) {
                return %orig;
            }
            ALAppLibraryView *libView = objc_getAssociatedObject(self, kALViewAssocKey);
            if (libView && !libView.hidden) {
                CGPoint ptInLib = [libView convertPoint:point fromView:self];
                UIView *hit = [libView hitTest:ptInLib withEvent:event];
                if (hit) return hit;
            }
        }
    }
    return %orig;
}

- (BOOL)setCurrentPageIndex:(NSInteger)index animated:(BOOL)animated {
    BOOL result = %orig;
    // Scroll geometry may have changed; state (dock, dots, backdrop) is derived live, never forced.
    al_refreshLibraryState(self);
    return result;
}

%end

#pragma mark - Lock / launch tracking / icon refresh

%hook SBLockScreenManager

- (void)lockUIFromSource:(int)source withOptions:(id)options {
    %orig;
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ALAppLibrary12DeviceLocked" object:nil];
    });
}

%end

%hook SBIconController

- (void)setIsEditing:(BOOL)editing {
    %orig;
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ALAppLibrary12EditingChanged" object:nil];
    });
}

- (void)_launchIcon:(SBIcon *)icon {
    if (prefEnabled && [icon respondsToSelector:@selector(applicationBundleID)]) {
        NSString *bundleID = [icon applicationBundleID];
        if (bundleID) {
            [[ALAppManager sharedManager] recordLaunchForBundleIdentifier:bundleID];
        }
    }
    %orig;
}

%end

%hook SBIconImageCache

- (void)purgeAllCachedImages {
    %orig;
    dispatch_async(dispatch_get_main_queue(), ^{
        [[ALAppManager sharedManager] clearIconCache];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ALAppLibrary12ThemeUpdated" object:nil];
    });
}

%end

%hook SBIconModel

- (void)reloadIcons {
    %orig;
    dispatch_async(dispatch_get_main_queue(), ^{
        [[ALAppManager sharedManager] clearIconCache];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ALAppLibrary12ThemeUpdated" object:nil];
    });
}

%end

#pragma mark - Dock layout (iPad)

// SpringBoard may relayout the dock while the library is partly visible. Re-assert the faded state
// ONLY while a fade is actually in progress; otherwise leave the dock completely alone so
// SpringBoard keeps control of its visibility (this is what used to make the iPad dock vanish).
static void al_reassertDockFade(UIView *view) {
    if (!al_dockFadeEnabled() || al_appLibraryProgress <= 0.0) return;
    view.alpha = 1.0 - al_appLibraryProgress;
    view.userInteractionEnabled = (al_appLibraryProgress < 0.5);
}

%hook SBDockView
- (void)layoutSubviews {
    %orig;
    al_reassertDockFade((UIView *)self);
}
%end

%hook SBFloatingDockView
- (void)layoutSubviews {
    %orig;
    al_reassertDockFade((UIView *)self);
}
%end

%hook SBIconViewMap

- (id)mappedIconViewForIcon:(id)icon {
    if (al_isLaunchingFromLibrary) {
        return nil;
    }
    return %orig;
}

%end

%ctor {
    loadPreferences();

    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, prefsChangedCallback,
        CFSTR("com.skylight.applibrary12/ReloadPrefs"), NULL, CFNotificationSuspensionBehaviorDeliverImmediately);
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, themeReloadCallback,
        CFSTR("com.spark.snowboard.refresh"), NULL, CFNotificationSuspensionBehaviorDeliverImmediately);

    // Registered once, at load (previously only after the first prefs change).
    [[NSNotificationCenter defaultCenter] addObserverForName:@"ALAppLibrary12WillLaunchApp"
                                                      object:nil
                                                       queue:[NSOperationQueue mainQueue]
                                                  usingBlock:^(NSNotification *note) {
        al_isLaunchingFromLibrary = YES;
        NSUInteger token = ++al_launchToken;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (token == al_launchToken) al_isLaunchingFromLibrary = NO;
        });
    }];
}
