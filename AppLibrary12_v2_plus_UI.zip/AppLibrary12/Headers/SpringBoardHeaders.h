#import <UIKit/UIKit.h>

@interface LSApplicationProxy : NSObject
+ (instancetype)applicationProxyForIdentifier:(NSString *)bundleIdentifier;
@property (nonatomic, readonly) NSString *applicationIdentifier;
@property (nonatomic, readonly) NSString *applicationType;
@property (nonatomic, readonly) NSString *localizedName;
@property (nonatomic, readonly) NSString *genre;
@property (nonatomic, readonly) NSNumber *genreID;
@property (nonatomic, readonly) NSArray<NSString *> *appTags;
@property (nonatomic, readonly) NSDate *registeredDate;
@property (nonatomic, readonly) NSURL *bundleURL;
@end

@interface SBApplication : NSObject
@property (nonatomic, readonly) NSString *bundleIdentifier;
@property (nonatomic, readonly) NSString *displayName;
- (BOOL)isSystemApplication;
@end

@interface SBApplicationController : NSObject
+ (instancetype)sharedInstance;
- (NSArray<SBApplication *> *)allApplications;
- (SBApplication *)applicationWithBundleIdentifier:(NSString *)bundleIdentifier;
@end

@interface SBIcon : NSObject
- (NSString *)applicationBundleID;
- (NSString *)displayName;
- (UIImage *)getIconImage:(int)format;
- (long long)badgeValue;
@end

@interface SBApplicationIcon : SBIcon
- (SBApplication *)application;
@end

@interface SBIconImageView : UIView
- (void)setIcon:(SBIcon *)icon location:(long long)location animated:(BOOL)animated;
- (UIImage *)contentsImage;
@end

@interface SBIconImageCache : NSObject
- (void)purgeAllCachedImages;
@end

@interface SBIconModel : NSObject
- (SBApplicationIcon *)applicationIconForBundleIdentifier:(NSString *)bundleIdentifier;
- (NSSet<NSString *> *)visibleIconIdentifiers;
- (NSArray<SBIcon *> *)leafIcons;
- (void)reloadIcons;
@end

@interface SBIconController : NSObject
+ (instancetype)sharedInstance;
- (SBIconModel *)model;
- (BOOL)isEditing;
- (void)setIsEditing:(BOOL)editing;
@end

@interface SBUIController : NSObject
+ (instancetype)sharedInstance;
- (void)activateApplicationAnimated:(SBApplication *)application;
@end

@interface SBIconScrollView : UIScrollView
@end

@interface SBIconListPageControl : UIPageControl
@end

@interface SBFolderView : UIView <UIScrollViewDelegate>
@property (nonatomic, readonly) SBIconScrollView *scrollView;
@property (nonatomic, readonly) SBIconListPageControl *pageControl;
@property (nonatomic, readonly) NSInteger currentPageIndex;
@property (nonatomic, readonly) NSInteger minimumPageIndex;
@property (nonatomic, readonly) NSInteger maximumPageIndex;
@property (nonatomic, readonly) NSInteger pageCount;
- (BOOL)setCurrentPageIndex:(NSInteger)index animated:(BOOL)animated;
- (void)scrollViewDidScroll:(UIScrollView *)scrollView;
- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(CGPoint *)targetContentOffset;
@end

@interface SBRootFolderView : SBFolderView
@property (nonatomic, readonly) UIView *dockView;
@end

@interface SBRootFolderController : UIViewController
@property (nonatomic, readonly) SBRootFolderView *contentView;
@end

@interface UIApplication (Private)
- (BOOL)launchApplicationWithIdentifier:(NSString *)identifier suspended:(BOOL)suspended;
@end
