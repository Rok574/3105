#import "ALCategoryPodCell.h"
#import "SpringBoardHeaders.h"

@interface ALCategoryPodCell ()
@property (nonatomic, strong) UIView *podContainer;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) NSArray<UIButton *> *bigIconButtons;
@property (nonatomic, strong) UIButton *miniClusterButton;
@property (nonatomic, strong) NSArray<UIImageView *> *miniIconViews;
@property (nonatomic, strong) ALAppCategory *currentCategory;
@end

@implementation ALCategoryPodCell

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setupViews];
    }
    return self;
}

- (void)setupViews {
    self.podContainer = [[UIView alloc] init];
    self.podContainer.layer.cornerRadius = 26.0;
    self.podContainer.clipsToBounds = YES;
    [self.contentView addSubview:self.podContainer];

    NSMutableArray *bigButtons = [NSMutableArray arrayWithCapacity:4];

    for (NSInteger i = 0; i < 4; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.tag = i;
        btn.backgroundColor = [UIColor clearColor];
        btn.clipsToBounds = NO;
        btn.imageView.contentMode = UIViewContentModeScaleAspectFit;
        [btn addTarget:self action:@selector(bigIconTapped:) forControlEvents:UIControlEventTouchUpInside];


        [self.podContainer addSubview:btn];
        [bigButtons addObject:btn];
    }
    self.bigIconButtons = bigButtons;

    self.miniClusterButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.miniClusterButton.backgroundColor = [UIColor clearColor];
    [self.miniClusterButton addTarget:self action:@selector(expandTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.podContainer addSubview:self.miniClusterButton];

    NSMutableArray *miniViews = [NSMutableArray arrayWithCapacity:4];
    for (NSInteger i = 0; i < 4; i++) {
        UIImageView *iv = [[UIImageView alloc] init];
        iv.clipsToBounds = NO;
        iv.contentMode = UIViewContentModeScaleAspectFit;
        [self.miniClusterButton addSubview:iv];
        [miniViews addObject:iv];
    }
    self.miniIconViews = miniViews;

    self.titleLabel = [[UILabel alloc] init];
    self.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightRegular];
    self.titleLabel.textColor = [UIColor whiteColor];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.contentView addSubview:self.titleLabel];
}

- (void)layoutSubviews {
    [super layoutSubviews];

    CGFloat w = self.contentView.bounds.size.width;
    CGFloat labelHeight = self.titleLabel.hidden ? 0.0 : 20.0;
    CGFloat podSize = MIN(w, self.contentView.bounds.size.height - labelHeight - 4.0);

    self.podContainer.frame = CGRectMake((w - podSize) * 0.5, 0, podSize, podSize);
    self.podContainer.layer.cornerRadius = podSize * 0.175;

    CGFloat padding = podSize * 0.08;
    CGFloat spacing = podSize * 0.07;
    CGFloat slotSize = (podSize - padding * 2.0 - spacing) * 0.5;

    for (NSInteger i = 0; i < 4; i++) {
        NSInteger row = i / 2;
        NSInteger col = i % 2;
        CGRect slotFrame = CGRectMake(padding + col * (slotSize + spacing),
                                      padding + row * (slotSize + spacing),
                                      slotSize,
                                      slotSize);
        self.bigIconButtons[i].frame = slotFrame;
        if (i == 3) {
            self.miniClusterButton.frame = slotFrame;
            CGFloat miniSize = slotSize * 0.44;
            CGFloat miniSpacing = slotSize * 0.12;
            CGFloat miniInset = (slotSize - (miniSize * 2.0 + miniSpacing)) * 0.5;
            for (NSInteger m = 0; m < 4; m++) {
                NSInteger mRow = m / 2;
                NSInteger mCol = m % 2;
                UIImageView *iv = self.miniIconViews[m];
                iv.frame = CGRectMake(miniInset + mCol * (miniSize + miniSpacing),
                                      miniInset + mRow * (miniSize + miniSpacing),
                                      miniSize,
                                      miniSize);
            }
        }
    }

    self.titleLabel.frame = CGRectMake(0, podSize + 4.0, w, 18.0);
}

- (void)configureWithCategory:(ALAppCategory *)category
                    darkStyle:(BOOL)darkStyle
                    lowRAMMode:(BOOL)lowRAMMode
                    showLabel:(BOOL)showLabel {
    self.currentCategory = category;
    self.titleLabel.text = category.title;
    self.titleLabel.hidden = !showLabel;
    self.titleLabel.textColor = darkStyle ? [UIColor whiteColor] : [UIColor colorWithWhite:0.08 alpha:1.0];
    [self setNeedsLayout];

    self.podContainer.backgroundColor = darkStyle
        ? [UIColor colorWithWhite:0.12 alpha:0.44]
        : [UIColor colorWithWhite:0.95 alpha:0.42];

    NSArray<ALAppItem *> *apps = category.apps;
    BOOL hasMiniCluster = (apps.count > 4);

    for (NSInteger i = 0; i < 4; i++) {
        UIButton *btn = self.bigIconButtons[i];

        if (i == 3 && hasMiniCluster) {
            btn.hidden = YES;
            [btn setImage:nil forState:UIControlStateNormal];
            continue;
        }
        if (i < (NSInteger)apps.count) {
            btn.hidden = NO;
            // Always refresh: cells are reused and icons change with themes.
            UIImage *img = [[ALAppManager sharedManager] iconForBundleIdentifier:apps[i].bundleIdentifier];
            [btn setImage:img forState:UIControlStateNormal];
            btn.imageView.contentMode = UIViewContentModeScaleAspectFit;
        } else {
            btn.hidden = YES;
            [btn setImage:nil forState:UIControlStateNormal];
        }
    }

    self.miniClusterButton.hidden = !hasMiniCluster;
    if (hasMiniCluster) {
        for (NSInteger m = 0; m < 4; m++) {
            NSInteger appIndex = 3 + m;
            UIImageView *iv = self.miniIconViews[m];
            if (appIndex < (NSInteger)apps.count) {
                iv.hidden = NO;
                iv.image = [[ALAppManager sharedManager] iconForBundleIdentifier:apps[appIndex].bundleIdentifier];
            } else {
                iv.hidden = YES;
                iv.image = nil;
            }
        }
    }
}

- (void)bigIconTapped:(UIButton *)sender {
    NSInteger idx = sender.tag;
    if (idx < (NSInteger)self.currentCategory.apps.count) {
        [self.delegate categoryPodCell:self didTapApp:self.currentCategory.apps[idx]];
    }
}

- (void)expandTapped {
    if (self.currentCategory) {
        [self.delegate categoryPodCellDidTapExpand:self category:self.currentCategory];
    }
}

@end
