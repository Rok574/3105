#import <UIKit/UIKit.h>

@class SBApplicationIcon;

@interface ALAppItem : NSObject
@property (nonatomic, copy) NSString *bundleIdentifier;
@property (nonatomic, copy) NSString *displayName;
@property (nonatomic, copy) NSString *categoryName;
@property (nonatomic, strong) NSDate *installedDate;
@property (nonatomic, assign) NSInteger badgeCount;
@property (nonatomic, assign) double suggestionScore;
@end

@interface ALAppCategory : NSObject
@property (nonatomic, copy) NSString *title;
@property (nonatomic, strong) NSArray<ALAppItem *> *apps;
@end

@interface ALAppManager : NSObject

+ (instancetype)sharedManager;
+ (NSArray<NSString *> *)allCategoryNames;

- (void)reloadApps;
- (void)clearIconCache;
- (NSArray<ALAppCategory *> *)categories;
- (NSArray<ALAppItem *> *)allAppsSorted;
- (SBApplicationIcon *)sbIconForBundleIdentifier:(NSString *)bundleID;
- (UIImage *)iconForBundleIdentifier:(NSString *)bundleID;
- (void)launchAppWithBundleIdentifier:(NSString *)bundleID;
- (void)recordLaunchForBundleIdentifier:(NSString *)bundleID;
- (void)setCustomCategory:(NSString *)categoryName forBundleIdentifier:(NSString *)bundleID;

@end
