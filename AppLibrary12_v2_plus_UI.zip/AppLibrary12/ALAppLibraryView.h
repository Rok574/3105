#import <UIKit/UIKit.h>

@interface ALAppLibraryView : UIView

@property (nonatomic, assign) BOOL darkStyle;
@property (nonatomic, assign) BOOL lowRAMMode;
@property (nonatomic, assign) BOOL showCategoryLabels;
// Space to keep clear at the bottom (e.g. a dock that stays visible over the library page).
@property (nonatomic, assign) CGFloat bottomContentInset;

- (void)reloadData;
- (void)dismissOverlaysAnimated:(BOOL)animated;
- (void)resetToDefaultState;

@end
