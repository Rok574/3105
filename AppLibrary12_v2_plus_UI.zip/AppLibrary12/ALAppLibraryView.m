#import "ALAppLibraryView.h"
#import "ALAppManager.h"
#import "ALCategoryPodCell.h"
#import "SpringBoardHeaders.h"

static void al_expandedMetrics(CGFloat w, NSInteger *cols, CGFloat *pad, CGFloat *spacing, CGFloat *cellW, CGFloat *cellH) {
    if (w >= 650.0) {
        *cols = (w >= 950.0) ? 6 : 5;
        *pad = 28.0;
        *cellW = 80.0;
        *cellH = 86.0;
    } else {
        *cols = 4;
        *pad = 24.0;
        *cellW = MIN(66.0, floor((w - 48.0 - 3.0 * 8.0) / 4.0));
        *cellH = 80.0;
    }
    CGFloat sp = (w - 2.0 * (*pad) - (*cols) * (*cellW)) / ((*cols) - 1);
    *spacing = MAX(0.0, sp - 0.05);   // tiny epsilon so a full row always fits
}

@interface ALAlphaAppCell : UITableViewCell
@property (nonatomic, strong) UIImageView *appIconView;
@property (nonatomic, strong) UILabel *appNameLabel;
@end

@implementation ALAlphaAppCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;

        _appIconView = [[UIImageView alloc] init];
        _appIconView.contentMode = UIViewContentModeScaleAspectFit;
        _appIconView.clipsToBounds = NO;
        [self.contentView addSubview:_appIconView];

        _appNameLabel = [[UILabel alloc] init];
        _appNameLabel.textColor = [UIColor whiteColor];
        _appNameLabel.font = [UIFont systemFontOfSize:16.5 weight:UIFontWeightRegular];
        [self.contentView addSubview:_appNameLabel];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat h = self.contentView.bounds.size.height;
    CGFloat w = self.contentView.bounds.size.width;
    CGFloat iconSize = 42.0;
    self.appIconView.frame = CGRectMake(20.0, (h - iconSize) * 0.5, iconSize, iconSize);
    self.appNameLabel.frame = CGRectMake(20.0 + iconSize + 14.0, 0, w - (20.0 + iconSize + 36.0), h);
}
@end

@interface ALExpandedAppCell : UICollectionViewCell
@property (nonatomic, strong) UIImageView *appIconView;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *badgeLabel;
- (void)configureWithApp:(ALAppItem *)item textColor:(UIColor *)textColor;
@end

@implementation ALExpandedAppCell
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _appIconView = [[UIImageView alloc] init];
        _appIconView.clipsToBounds = NO;
        _appIconView.contentMode = UIViewContentModeScaleAspectFit;
        _appIconView.userInteractionEnabled = NO;
        [self.contentView addSubview:_appIconView];

        _nameLabel = [[UILabel alloc] init];
        _nameLabel.font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightRegular];
        _nameLabel.textColor = [UIColor whiteColor];
        _nameLabel.textAlignment = NSTextAlignmentCenter;
        _nameLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        [self.contentView addSubview:_nameLabel];

        _badgeLabel = [[UILabel alloc] init];
        _badgeLabel.backgroundColor = [UIColor colorWithRed:1.0 green:0.23 blue:0.19 alpha:1.0];
        _badgeLabel.textColor = [UIColor whiteColor];
        _badgeLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightMedium];
        _badgeLabel.textAlignment = NSTextAlignmentCenter;
        _badgeLabel.layer.cornerRadius = 11.0;
        _badgeLabel.clipsToBounds = YES;
        _badgeLabel.hidden = YES;
        [self.contentView addSubview:_badgeLabel];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat w = self.contentView.bounds.size.width;
    CGFloat iconSize = MIN(60.0, w - 4.0);
    CGFloat iconX = (w - iconSize) * 0.5;
    CGRect iconFrame = CGRectMake(iconX, 0.0, iconSize, iconSize);

    self.appIconView.frame = iconFrame;
    self.nameLabel.frame = CGRectMake(-4.0, iconSize + 5.0, w + 8.0, 16.0);

    if (!self.badgeLabel.hidden) {
        [self.badgeLabel sizeToFit];
        CGFloat bw = MAX(22.0, self.badgeLabel.bounds.size.width + 12.0);
        self.badgeLabel.frame = CGRectMake(iconX + iconSize - bw * 0.65, -2.0, bw, 22.0);
    }
}

- (void)configureWithApp:(ALAppItem *)item textColor:(UIColor *)textColor {
    self.nameLabel.text = item.displayName;
    self.nameLabel.textColor = textColor ?: [UIColor whiteColor];
    if (item.badgeCount > 0) {
        self.badgeLabel.hidden = NO;
        self.badgeLabel.text = [NSString stringWithFormat:@"%ld", (long)item.badgeCount];
    } else {
        self.badgeLabel.hidden = YES;
    }

    self.appIconView.image = [[ALAppManager sharedManager] iconForBundleIdentifier:item.bundleIdentifier];
    [self setNeedsLayout];
}
@end

@interface ALAppLibraryView () <UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, UIGestureRecognizerDelegate, ALCategoryPodCellDelegate>
@property (nonatomic, strong) UIVisualEffectView *backdropBlurView;
@property (nonatomic, strong) UIView *searchBarContainer;
@property (nonatomic, strong) UIImageView *searchIconView;
@property (nonatomic, strong) UILabel *centeredPlaceholderLabel;
@property (nonatomic, strong) UITextField *searchField;
@property (nonatomic, strong) UIButton *cancelSearchButton;
@property (nonatomic, strong) UICollectionView *podsCollectionView;

// A-Z List mode
@property (nonatomic, strong) UITableView *alphaTableView;
@property (nonatomic, assign) BOOL isSearching;
@property (nonatomic, strong) NSArray<NSString *> *sectionTitles;
@property (nonatomic, strong) NSDictionary<NSString *, NSArray<ALAppItem *> *> *sectionedApps;

// Expanded Category Overlay
@property (nonatomic, strong) UIView *expandedOverlayView;
@property (nonatomic, strong) UIVisualEffectView *expandedBlurView;
@property (nonatomic, strong) UILabel *expandedTitleLabel;
@property (nonatomic, strong) UICollectionView *expandedCollectionView;
@property (nonatomic, strong) ALAppCategory *expandedCategory;

@property (nonatomic, strong) NSArray<ALAppCategory *> *categories;
@property (nonatomic, assign) NSUInteger overlayToken;
@property (nonatomic, assign) NSUInteger emptyRetryCount;
@end

@interface ALAppLibraryView () { CGFloat _lastLayoutWidth; }
@end

@implementation ALAppLibraryView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _darkStyle = YES;
        _lowRAMMode = NO;
        _showCategoryLabels = YES;
        self.clipsToBounds = NO;
        [self setupUI];
        [self reloadData];
        // SpringBoard posts this when installed applications change. Refresh on the main
        // thread after LaunchServices has finished updating its application list.
        [[NSNotificationCenter defaultCenter] addObserver:self
                                               selector:@selector(installedApplicationsChanged:)
                                                   name:@"SBInstalledApplicationsDidChangeNotification"
                                                 object:nil];
    }
    return self;
}


- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)installedApplicationsChanged:(NSNotification *)notification {
    __weak ALAppLibraryView *weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        ALAppLibraryView *strongSelf = weakSelf;
        if (!strongSelf || strongSelf.hidden) return;
        [[ALAppManager sharedManager] clearIconCache];
        [strongSelf reloadData];
    });
}

- (UIColor *)primaryTextColor {
    return self.darkStyle ? [UIColor whiteColor] : [UIColor colorWithWhite:0.08 alpha:1.0];
}

- (UIColor *)secondaryTextColor {
    return self.darkStyle ? [UIColor colorWithWhite:1.0 alpha:0.65] : [UIColor colorWithWhite:0.0 alpha:0.55];
}

- (UIImage *)searchGlyphImage {
    UIColor *tint = [self secondaryTextColor];
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(15, 15), NO, 0);
    UIBezierPath *circle = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(1.5, 1.5, 8.5, 8.5)];
    circle.lineWidth = 1.5;
    [tint setStroke];
    [circle stroke];
    UIBezierPath *handle = [UIBezierPath bezierPath];
    [handle moveToPoint:CGPointMake(9.0, 9.0)];
    [handle addLineToPoint:CGPointMake(13.2, 13.2)];
    handle.lineWidth = 1.7;
    handle.lineCapStyle = kCGLineCapRound;
    [handle stroke];
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}

- (void)setupUI {
    self.backdropBlurView = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleDark]];
    [self addSubview:self.backdropBlurView];

    // Search Pill (1:1 iOS 14 centered pill)
    self.searchBarContainer = [[UIView alloc] init];
    self.searchBarContainer.layer.cornerRadius = 13.0;
    self.searchBarContainer.clipsToBounds = YES;
    self.searchBarContainer.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.16];
    [self addSubview:self.searchBarContainer];

    self.searchIconView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 15, 15)];
    self.searchIconView.userInteractionEnabled = NO;
    self.searchIconView.image = [self searchGlyphImage];
    [self.searchBarContainer addSubview:self.searchIconView];

    self.centeredPlaceholderLabel = [[UILabel alloc] init];
    self.centeredPlaceholderLabel.text = @"App Library";
    self.centeredPlaceholderLabel.font = [UIFont systemFontOfSize:16.5 weight:UIFontWeightRegular];
    self.centeredPlaceholderLabel.textColor = [UIColor colorWithWhite:1.0 alpha:0.65];
    self.centeredPlaceholderLabel.userInteractionEnabled = NO;
    [self.searchBarContainer addSubview:self.centeredPlaceholderLabel];

    self.searchField = [[UITextField alloc] init];
    self.searchField.delegate = self;
    self.searchField.textColor = [UIColor whiteColor];
    self.searchField.font = [UIFont systemFontOfSize:16.5 weight:UIFontWeightRegular];
    self.searchField.returnKeyType = UIReturnKeySearch;
    self.searchField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [self.searchField addTarget:self action:@selector(searchTextChanged:) forControlEvents:UIControlEventEditingChanged];
    [self.searchBarContainer addSubview:self.searchField];

    self.cancelSearchButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.cancelSearchButton setTitle:@"Cancel" forState:UIControlStateNormal];
    [self.cancelSearchButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.cancelSearchButton.titleLabel.font = [UIFont systemFontOfSize:16.5 weight:UIFontWeightRegular];
    self.cancelSearchButton.alpha = 0.0;
    [self.cancelSearchButton addTarget:self action:@selector(cancelSearchTapped) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:self.cancelSearchButton];

    // Pods CollectionView
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.minimumInteritemSpacing = 16.0;
    layout.minimumLineSpacing = 12.0;
    layout.sectionInset = UIEdgeInsetsMake(12.0, 24.0, 28.0, 24.0);

    self.podsCollectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    self.podsCollectionView.backgroundColor = [UIColor clearColor];
    self.podsCollectionView.alwaysBounceVertical = YES;
    self.podsCollectionView.showsVerticalScrollIndicator = NO;
    if (@available(iOS 11.0, *)) { self.podsCollectionView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever; }
    self.podsCollectionView.dataSource = self;
    self.podsCollectionView.delegate = self;
    [self.podsCollectionView registerClass:[ALCategoryPodCell class] forCellWithReuseIdentifier:@"PodCell"];
    [self addSubview:self.podsCollectionView];

    // A-Z TableView
    self.alphaTableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    self.alphaTableView.backgroundColor = [UIColor clearColor];
    self.alphaTableView.separatorColor = [UIColor colorWithWhite:1.0 alpha:0.12];
    self.alphaTableView.sectionIndexColor = [UIColor colorWithWhite:1.0 alpha:0.85];
    self.alphaTableView.sectionIndexBackgroundColor = [UIColor clearColor];
    self.alphaTableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    if (@available(iOS 11.0, *)) { self.alphaTableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever; }
    self.alphaTableView.dataSource = self;
    self.alphaTableView.delegate = self;
    self.alphaTableView.hidden = YES;
    self.alphaTableView.alpha = 0.0;
    [self addSubview:self.alphaTableView];

    UILongPressGestureRecognizer *tableLongPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleTableLongPress:)];
    [self.alphaTableView addGestureRecognizer:tableLongPress];

    // Expanded Category Overlay (1:1 iOS 14 Creativity-style view)
    self.expandedOverlayView = [[UIView alloc] init];
    self.expandedOverlayView.hidden = YES;
    self.expandedOverlayView.alpha = 0.0;
    [self addSubview:self.expandedOverlayView];

    self.expandedBlurView = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleDark]];
    [self.expandedOverlayView addSubview:self.expandedBlurView];

    // Tapping empty space anywhere in the overlay (not on an icon) closes it.
    UITapGestureRecognizer *dismissTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissExpandedOverlay)];
    dismissTap.cancelsTouchesInView = NO;
    dismissTap.delegate = self;
    [self.expandedOverlayView addGestureRecognizer:dismissTap];

    self.expandedTitleLabel = [[UILabel alloc] init];
    self.expandedTitleLabel.font = [UIFont systemFontOfSize:34.0 weight:UIFontWeightBold];
    self.expandedTitleLabel.textColor = [UIColor whiteColor];
    [self.expandedOverlayView addSubview:self.expandedTitleLabel];

    UICollectionViewFlowLayout *expLayout = [[UICollectionViewFlowLayout alloc] init];
    expLayout.minimumInteritemSpacing = 12.0;
    expLayout.minimumLineSpacing = 22.0;
    expLayout.sectionInset = UIEdgeInsetsMake(12.0, 20.0, 32.0, 20.0);

    self.expandedCollectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:expLayout];
    self.expandedCollectionView.backgroundColor = [UIColor clearColor];
    self.expandedCollectionView.alwaysBounceVertical = YES;
    if (@available(iOS 11.0, *)) { self.expandedCollectionView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever; }
    self.expandedCollectionView.dataSource = self;
    self.expandedCollectionView.delegate = self;
    [self.expandedCollectionView registerClass:[ALExpandedAppCell class] forCellWithReuseIdentifier:@"ExpandedCell"];
    [self.expandedOverlayView addSubview:self.expandedCollectionView];

    UILongPressGestureRecognizer *expLongPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleExpandedLongPress:)];
    [self.expandedCollectionView addGestureRecognizer:expLongPress];
}

- (void)layoutSubviews {
    [super layoutSubviews];

    CGFloat w = self.bounds.size.width;
    CGFloat h = self.bounds.size.height;
    if (fabs(w - _lastLayoutWidth) > 0.5) {
        _lastLayoutWidth = w;
        [self.podsCollectionView.collectionViewLayout invalidateLayout];
        [self.expandedCollectionView.collectionViewLayout invalidateLayout];
    }
    BOOL isPad = (w >= 650.0);
    CGFloat topInset = isPad ? ((h > w) ? 76.0 : 30.0) : 34.0;
    CGFloat safeTopInset = 0.0;
    if (@available(iOS 11.0, *)) { safeTopInset = self.safeAreaInsets.top; }
    BOOL hasNotch = (!isPad && safeTopInset >= 40.0);
    if (isPad) {
        topInset = MAX(topInset, safeTopInset + 16.0);
    } else if (hasNotch) {
        topInset = safeTopInset + 16.0;      // notch iPhones
    } else {
        topInset = 20.0 + 12.0;              // status-bar iPhones (6/7/8/SE): just under the status bar
    }
    // iOS 14 look: wide rounded pill, about 46pt tall on iPhone.
    const CGFloat searchH = isPad ? 44.0 : 46.0;
    self.searchBarContainer.layer.cornerRadius = 13.0;
    CGFloat placeholderSize = 17.0;
    if (fabs(self.centeredPlaceholderLabel.font.pointSize - placeholderSize) > 0.1) {
        self.centeredPlaceholderLabel.font = [UIFont systemFontOfSize:placeholderSize weight:UIFontWeightRegular];
        self.searchField.font = [UIFont systemFontOfSize:placeholderSize weight:UIFontWeightRegular];
    }

    // Extend blur well past top & bottom bounds so status bar seam never shows
    CGRect fullBleedFrame = CGRectMake(0, -60.0, w, h + 120.0);
    self.backdropBlurView.frame = fullBleedFrame;

    CGFloat cancelWidth = self.isSearching ? 62.0 : 0.0;
    CGFloat maxBarRowW = (w >= 650.0) ? 340.0 : (w - 48.0);
    CGFloat rowLeft = (w - maxBarRowW) * 0.5;
    CGFloat searchWidth = maxBarRowW - (self.isSearching ? cancelWidth + 8.0 : 0.0);
    self.searchBarContainer.frame = CGRectMake(rowLeft, topInset, searchWidth, searchH);
    self.cancelSearchButton.frame = CGRectMake(rowLeft + maxBarRowW - cancelWidth, topInset, cancelWidth, searchH);
    self.cancelSearchButton.userInteractionEnabled = self.isSearching;

    if (self.isSearching) {
        self.searchIconView.frame = CGRectMake(12.0, (searchH - 15.0) * 0.5, 15.0, 15.0);
        self.searchField.frame = CGRectMake(34.0, 0, searchWidth - 40.0, searchH);
        self.centeredPlaceholderLabel.hidden = (self.searchField.text.length > 0);
        self.centeredPlaceholderLabel.frame = CGRectMake(34.0, 0, 120.0, searchH);
    } else {
        [self.centeredPlaceholderLabel sizeToFit];
        CGFloat labelW = self.centeredPlaceholderLabel.bounds.size.width;
        CGFloat totalW = 15.0 + 7.0 + labelW;
        CGFloat startX = (searchWidth - totalW) * 0.5;
        self.searchIconView.frame = CGRectMake(startX, (searchH - 15.0) * 0.5, 15.0, 15.0);
        self.centeredPlaceholderLabel.hidden = NO;
        self.centeredPlaceholderLabel.frame = CGRectMake(startX + 22.0, 0, labelW, searchH);
        self.searchField.frame = self.searchBarContainer.bounds;
    }

    CGFloat contentTop = topInset + searchH + 20.0;
    CGRect contentFrame = CGRectMake(0, contentTop, w, MAX(0.0, h - contentTop));
    self.podsCollectionView.frame = contentFrame;
    self.alphaTableView.frame = contentFrame;
    CGFloat safeBottom = 0.0;
    if (@available(iOS 11.0, *)) { safeBottom = self.safeAreaInsets.bottom; }
    CGFloat bottomPad = self.bottomContentInset + safeBottom + (isPad ? 40.0 : 48.0);
    UIEdgeInsets bottomInsets = UIEdgeInsetsMake(0, 0, bottomPad, 0);
    self.podsCollectionView.contentInset = bottomInsets;
    self.podsCollectionView.scrollIndicatorInsets = bottomInsets;
    self.alphaTableView.contentInset = bottomInsets;
    self.alphaTableView.scrollIndicatorInsets = bottomInsets;

    // Use bounds/center: setting frame while the overlay has a transform (during its animation) is undefined.
    self.expandedOverlayView.bounds = CGRectMake(0, 0, w, h);
    self.expandedOverlayView.center = CGPointMake(w * 0.5, h * 0.5);
    self.expandedBlurView.frame = fullBleedFrame;
    CGFloat expSafe = MAX(20.0, safeTopInset);
    CGFloat expTitleTop = isPad ? (topInset + 28.0) : (expSafe + 62.0);
    CGFloat expGridTop  = isPad ? (topInset + 82.0) : (expSafe + 129.0);
    self.expandedTitleLabel.frame = CGRectMake(isPad ? 24.0 : 27.0, expTitleTop, w - 54.0, 44.0);
    self.expandedCollectionView.frame = CGRectMake(0, expGridTop, w, MAX(0.0, h - expGridTop));
    self.expandedCollectionView.contentInset = bottomInsets;
    self.expandedCollectionView.scrollIndicatorInsets = bottomInsets;
}

- (void)setDarkStyle:(BOOL)darkStyle {
    _darkStyle = darkStyle;
    [self updateThemeAppearance];
}

- (void)setLowRAMMode:(BOOL)lowRAMMode {
    _lowRAMMode = lowRAMMode;
    [self updateThemeAppearance];
}

- (void)setBottomContentInset:(CGFloat)bottomContentInset {
    if (fabs(_bottomContentInset - bottomContentInset) < 0.5) return;
    _bottomContentInset = bottomContentInset;
    [self setNeedsLayout];
}

- (void)updateThemeAppearance {
    // The page backdrop (blur or Low-RAM dim) is drawn by the home screen, so this view stays clear.
    self.backdropBlurView.hidden = YES;
    self.backgroundColor = [UIColor clearColor];

    UIColor *primary = [self primaryTextColor];
    self.searchBarContainer.backgroundColor = self.darkStyle ? [UIColor colorWithWhite:1.0 alpha:0.16]
                                                             : [UIColor colorWithWhite:0.0 alpha:0.10];
    self.searchIconView.image = [self searchGlyphImage];
    self.centeredPlaceholderLabel.textColor = [self secondaryTextColor];
    self.searchField.textColor = primary;
    self.searchField.keyboardAppearance = self.darkStyle ? UIKeyboardAppearanceDark : UIKeyboardAppearanceLight;
    [self.cancelSearchButton setTitleColor:primary forState:UIControlStateNormal];
    self.expandedTitleLabel.textColor = primary;
    self.alphaTableView.separatorColor = self.darkStyle ? [UIColor colorWithWhite:1.0 alpha:0.12] : [UIColor colorWithWhite:0.0 alpha:0.12];
    self.alphaTableView.sectionIndexColor = self.darkStyle ? [UIColor colorWithWhite:1.0 alpha:0.85] : [UIColor colorWithWhite:0.0 alpha:0.7];
    self.expandedBlurView.effect = [UIBlurEffect effectWithStyle:self.darkStyle ? UIBlurEffectStyleDark : UIBlurEffectStyleLight];

    [self.podsCollectionView reloadData];
    [self.alphaTableView reloadData];
    if (!self.expandedOverlayView.hidden) {
        [self.expandedCollectionView reloadData];
    }
}

- (void)reloadData {
    [[ALAppManager sharedManager] reloadApps];
    self.categories = [[ALAppManager sharedManager] categories];
    [self rebuildAlphabeticalSectionsWithFilter:self.searchField.text];
    [self.podsCollectionView reloadData];
    [self.alphaTableView reloadData];

    // SpringBoard's icon model may not be ready right after respring: retry a few times.
    if (self.categories.count == 0 && self.emptyRetryCount < 6) {
        self.emptyRetryCount++;
        __weak ALAppLibraryView *weakSelf = self;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf reloadData];
        });
    } else if (self.categories.count > 0) {
        self.emptyRetryCount = 0;
    }

    if (!self.expandedOverlayView.hidden && self.expandedCategory) {
        for (ALAppCategory *cat in self.categories) {
            if ([cat.title isEqualToString:self.expandedCategory.title]) {
                self.expandedCategory = cat;
                break;
            }
        }
        [self.expandedCollectionView reloadData];
    }
}

- (void)rebuildAlphabeticalSectionsWithFilter:(NSString *)filter {
    NSArray<ALAppItem *> *allApps = [[ALAppManager sharedManager] allAppsSorted];
    NSMutableDictionary<NSString *, NSMutableArray<ALAppItem *> *> *sections = [NSMutableDictionary dictionary];

    NSString *trimmed = [filter stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    for (ALAppItem *item in allApps) {
        if (trimmed.length > 0 && [item.displayName rangeOfString:trimmed options:NSCaseInsensitiveSearch].location == NSNotFound) {
            continue;
        }
        NSString *first = item.displayName.length > 0 ? [[item.displayName substringToIndex:1] uppercaseString] : @"#";
        unichar c = [first characterAtIndex:0];
        if (c < 'A' || c > 'Z') {
            first = @"#";
        }
        NSMutableArray *arr = sections[first];
        if (!arr) {
            arr = [NSMutableArray array];
            sections[first] = arr;
        }
        [arr addObject:item];
    }

    NSArray *sortedKeys = [[sections allKeys] sortedArrayUsingComparator:^NSComparisonResult(NSString *a, NSString *b) {
        if ([a isEqualToString:@"#"]) return NSOrderedDescending;
        if ([b isEqualToString:@"#"]) return NSOrderedAscending;
        return [a compare:b];
    }];

    self.sectionTitles = sortedKeys;
    self.sectionedApps = sections;
}

#pragma mark - Long Press Category Override

- (void)handleExpandedLongPress:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan) return;
    CGPoint pt = [gesture locationInView:self.expandedCollectionView];
    NSIndexPath *ip = [self.expandedCollectionView indexPathForItemAtPoint:pt];
    if (!ip || ip.item >= (NSInteger)self.expandedCategory.apps.count) return;
    [self presentActionsForApp:self.expandedCategory.apps[ip.item]];
}

- (void)handleTableLongPress:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan) return;
    CGPoint pt = [gesture locationInView:self.alphaTableView];
    NSIndexPath *ip = [self.alphaTableView indexPathForRowAtPoint:pt];
    if (!ip) return;
    NSString *key = self.sectionTitles[ip.section];
    ALAppItem *item = self.sectionedApps[key][ip.row];
    [self presentActionsForApp:item];
}

- (void)presentActionsForApp:(ALAppItem *)item {
    UIViewController *topVC = self.window.rootViewController ?: [UIApplication sharedApplication].keyWindow.rootViewController;
    while (topVC.presentedViewController) {
        topVC = topVC.presentedViewController;
    }
    if (!topVC) return;

    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:item.displayName
                                                                   message:[NSString stringWithFormat:@"Current Category: %@", item.categoryName]
                                                            preferredStyle:UIAlertControllerStyleActionSheet];

    [sheet addAction:[UIAlertAction actionWithTitle:@"Move to Category…" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self presentCategoryPickerForApp:item fromVC:topVC];
    }]];

    [sheet addAction:[UIAlertAction actionWithTitle:@"Reset to Automatic Category" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [[ALAppManager sharedManager] setCustomCategory:nil forBundleIdentifier:item.bundleIdentifier];
        [self reloadData];
    }]];

    [sheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    UIPopoverPresentationController *popover = sheet.popoverPresentationController;
    if (popover) {
        popover.sourceView = self;
        popover.sourceRect = CGRectMake(self.bounds.size.width * 0.5, self.bounds.size.height * 0.5, 1.0, 1.0);
        popover.permittedArrowDirections = 0;
    }
    [topVC presentViewController:sheet animated:YES completion:nil];
}

- (void)presentCategoryPickerForApp:(ALAppItem *)item fromVC:(UIViewController *)vc {
    UIAlertController *picker = [UIAlertController alertControllerWithTitle:[NSString stringWithFormat:@"Move %@", item.displayName]
                                                                    message:@"Choose a category"
                                                             preferredStyle:UIAlertControllerStyleActionSheet];
    for (NSString *catName in [ALAppManager allCategoryNames]) {
        [picker addAction:[UIAlertAction actionWithTitle:catName style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [[ALAppManager sharedManager] setCustomCategory:catName forBundleIdentifier:item.bundleIdentifier];
            [self reloadData];
        }]];
    }
    [picker addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    UIPopoverPresentationController *popover = picker.popoverPresentationController;
    if (popover) {
        popover.sourceView = self;
        popover.sourceRect = CGRectMake(self.bounds.size.width * 0.5, self.bounds.size.height * 0.5, 1.0, 1.0);
        popover.permittedArrowDirections = 0;
    }
    if (vc.presentedViewController) return;
    [vc presentViewController:picker animated:YES completion:nil];
}

#pragma mark - Search Mode

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    [self setSearchMode:YES animated:YES];
}

- (void)searchTextChanged:(UITextField *)textField {
    self.centeredPlaceholderLabel.hidden = (textField.text.length > 0);
    [self rebuildAlphabeticalSectionsWithFilter:textField.text];
    [self.alphaTableView reloadData];
}

- (void)cancelSearchTapped {
    self.searchField.text = @"";
    [self.searchField resignFirstResponder];
    [self rebuildAlphabeticalSectionsWithFilter:@""];
    [self.alphaTableView reloadData];
    [self setSearchMode:NO animated:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)setSearchMode:(BOOL)searching animated:(BOOL)animated {
    if (self.isSearching == searching) return;
    self.isSearching = searching;

    if (searching) {
        self.alphaTableView.hidden = NO;
    }

    [UIView animateWithDuration:animated ? 0.25 : 0.0 animations:^{
        [self setNeedsLayout];
        [self layoutIfNeeded];
        self.cancelSearchButton.alpha = searching ? 1.0 : 0.0;
        self.podsCollectionView.alpha = searching ? 0.0 : 1.0;
        self.alphaTableView.alpha = searching ? 1.0 : 0.0;
    } completion:^(BOOL finished) {
        if (!searching) {
            self.alphaTableView.hidden = YES;
        }
    }];
}

#pragma mark - UICollectionViewDataSource & Delegate

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (collectionView == self.podsCollectionView) {
        return self.categories.count;
    }
    return self.expandedCategory.apps.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (collectionView == self.podsCollectionView) {
        ALCategoryPodCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PodCell" forIndexPath:indexPath];
        cell.delegate = self;
        [cell configureWithCategory:self.categories[indexPath.item]
                          darkStyle:self.darkStyle
                          lowRAMMode:self.lowRAMMode
                          showLabel:self.showCategoryLabels];
        return cell;
    }

    ALExpandedAppCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ExpandedCell" forIndexPath:indexPath];
    [cell configureWithApp:self.expandedCategory.apps[indexPath.item] textColor:[self primaryTextColor]];
    return cell;
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    CGFloat w = collectionView.bounds.size.width;
    if (collectionView == self.podsCollectionView) {
        if (w >= 650.0) {
            CGFloat maxGridW = MIN(w - 56.0, 840.0);
            CGFloat pad = (w - maxGridW) * 0.5;
            return UIEdgeInsetsMake(14.0, pad, 24.0, pad);
        }
        return UIEdgeInsetsMake(12.0, 24.0, 28.0, 24.0);
    }
    NSInteger ec; CGFloat ep, es, ew, eh;
    al_expandedMetrics(w, &ec, &ep, &es, &ew, &eh);
    return UIEdgeInsetsMake(8.0, ep, 32.0, ep);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    CGFloat w = collectionView.bounds.size.width;
    if (collectionView == self.podsCollectionView) {
        return 20.0;
    }
    NSInteger ec; CGFloat ep, es, ew, eh;
    al_expandedMetrics(w, &ec, &ep, &es, &ew, &eh);
    return es;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    CGFloat w = collectionView.bounds.size.width;
    if (collectionView == self.podsCollectionView) return (w >= 650.0) ? 16.0 : 12.0;
    return (w >= 650.0) ? 22.0 : 15.0;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat w = collectionView.bounds.size.width;
    if (collectionView == self.podsCollectionView) {
        NSInteger cols = (w >= 650.0) ? 4 : 2;
        CGFloat pad = (w >= 650.0) ? ((w - MIN(w - 56.0, 840.0)) * 0.5) : 24.0;
        CGFloat spacing = 20.0;
        CGFloat podWidth = floor((w - pad * 2.0 - spacing * (cols - 1)) / cols);
        CGFloat labelExtra = self.showCategoryLabels ? 24.0 : 0.0;
        return CGSizeMake(podWidth, podWidth + labelExtra);
    }
    NSInteger ec; CGFloat ep, es, ew, eh;
    al_expandedMetrics(w, &ec, &ep, &es, &ew, &eh);
    return CGSizeMake(ew, eh);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (collectionView == self.expandedCollectionView) {
        ALAppItem *item = self.expandedCategory.apps[indexPath.item];
        [self dismissOverlaysAnimated:NO];
        [[ALAppManager sharedManager] launchAppWithBundleIdentifier:item.bundleIdentifier];
    }
}

#pragma mark - ALCategoryPodCellDelegate

- (void)categoryPodCell:(ALCategoryPodCell *)cell didTapApp:(ALAppItem *)app {
    [[ALAppManager sharedManager] launchAppWithBundleIdentifier:app.bundleIdentifier];
}

- (void)categoryPodCellDidTapExpand:(ALCategoryPodCell *)cell category:(ALAppCategory *)category {
    self.expandedCategory = category;
    self.expandedTitleLabel.text = category.title;
    self.expandedBlurView.effect = [UIBlurEffect effectWithStyle:self.darkStyle ? UIBlurEffectStyleDark : UIBlurEffectStyleLight];
    [self.expandedCollectionView reloadData];

    self.overlayToken++;
    [self.expandedCollectionView setContentOffset:CGPointZero animated:NO];
    self.expandedOverlayView.hidden = NO;
    self.expandedOverlayView.transform = CGAffineTransformMakeScale(0.92, 0.92);
    [UIView animateWithDuration:0.24 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        self.expandedOverlayView.alpha = 1.0;
        self.expandedOverlayView.transform = CGAffineTransformIdentity;
    } completion:nil];
}

- (void)dismissExpandedOverlay {
    [self dismissOverlaysAnimated:YES];
}

- (void)resetToDefaultState {
    [self dismissOverlaysAnimated:NO];
    [self.podsCollectionView setContentOffset:CGPointZero animated:NO];
    [self.alphaTableView setContentOffset:CGPointZero animated:NO];
    [self.expandedCollectionView setContentOffset:CGPointZero animated:NO];
}

- (void)dismissOverlaysAnimated:(BOOL)animated {
    if (!self.expandedOverlayView.hidden) {
        NSUInteger token = ++self.overlayToken;
        [UIView animateWithDuration:animated ? 0.2 : 0.0 animations:^{
            self.expandedOverlayView.alpha = 0.0;
            self.expandedOverlayView.transform = CGAffineTransformMakeScale(0.94, 0.94);
        } completion:^(BOOL finished) {
            if (token != self.overlayToken) return; // re-opened meanwhile
            self.expandedOverlayView.hidden = YES;
            self.expandedOverlayView.transform = CGAffineTransformIdentity;
        }];
    }
    if (self.isSearching) {
        [self cancelSearchTapped];
    }
}

#pragma mark - UIGestureRecognizerDelegate

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    // Don't dismiss when the tap lands on an app icon.
    UIView *v = touch.view;
    while (v && v != self.expandedOverlayView) {
        if ([v isKindOfClass:[UICollectionViewCell class]]) return NO;
        v = v.superview;
    }
    return YES;
}

#pragma mark - UITableViewDataSource & Delegate (A-Z List)

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.sectionTitles.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSString *key = self.sectionTitles[section];
    return self.sectionedApps[key].count;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return self.sectionTitles[section];
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section {
    if ([view isKindOfClass:[UITableViewHeaderFooterView class]]) {
        UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
        header.backgroundView.backgroundColor = [UIColor clearColor];
        header.textLabel.textColor = [self secondaryTextColor];
        header.textLabel.font = [UIFont systemFontOfSize:14.0 weight:UIFontWeightBold];
    }
}

- (NSArray<NSString *> *)sectionIndexTitlesForTableView:(UITableView *)tableView {
    return self.sectionTitles;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"AlphaAppCell";
    ALAlphaAppCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[ALAlphaAppCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }

    NSString *key = self.sectionTitles[indexPath.section];
    ALAppItem *item = self.sectionedApps[key][indexPath.row];
    cell.appNameLabel.text = item.displayName;
    cell.appNameLabel.textColor = [self primaryTextColor];
    cell.appIconView.image = [[ALAppManager sharedManager] iconForBundleIdentifier:item.bundleIdentifier];

    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 64.0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *key = self.sectionTitles[indexPath.section];
    ALAppItem *item = self.sectionedApps[key][indexPath.row];
    [self cancelSearchTapped];
    [[ALAppManager sharedManager] launchAppWithBundleIdentifier:item.bundleIdentifier];
}

@end
