#import <UIKit/UIKit.h>
#import "ALAppManager.h"

@class ALCategoryPodCell;

@protocol ALCategoryPodCellDelegate <NSObject>
- (void)categoryPodCell:(ALCategoryPodCell *)cell didTapApp:(ALAppItem *)app;
- (void)categoryPodCellDidTapExpand:(ALCategoryPodCell *)cell category:(ALAppCategory *)category;
@end

@interface ALCategoryPodCell : UICollectionViewCell

@property (nonatomic, weak) id<ALCategoryPodCellDelegate> delegate;
- (void)configureWithCategory:(ALAppCategory *)category
                    darkStyle:(BOOL)darkStyle
                    lowRAMMode:(BOOL)lowRAMMode
                    showLabel:(BOOL)showLabel;

@end
