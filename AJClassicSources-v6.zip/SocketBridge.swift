import Foundation
import Network

final class SocketBridge {
    static let shared = SocketBridge()
    private var listener: NWListener?
    private var connections: [NWConnection] = []

    func startLocalBridge(port: UInt16 = 8765) {
        do {
            let parameters = NWParameters.tcp
            parameters.allowLocalEndpointReuse = true
            listener = try NWListener(using: parameters, on: NWEndpoint.Port(rawValue: port)!)
            
            listener?.stateUpdateHandler = { state in
                print("SocketBridge state: \(state)")
            }
            
            listener?.newConnectionHandler = { [weak self] newConn in
                self?.handleNewConnection(newConn)
            }
            
            listener?.start(queue: .global(qos: .userInitiated))
        } catch {
            print("Failed to start SocketBridge: \(error)")
        }
    }

    private func handleNewConnection(_ connection: NWConnection) {
        connections.append(connection)
        connection.start(queue: .global(qos: .userInitiated))
    }
}
