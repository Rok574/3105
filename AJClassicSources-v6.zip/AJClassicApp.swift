import SwiftUI
import WebKit

@main
struct AJClassicApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @State private var useTLSSocket = true
    @State private var currentSession: AJSession? = nil
    @State private var webViewProxy = WebViewCoordinator()
    @State private var isLoggedIn = false

    var body: some View {
        ZStack(alignment: .top) {
            Color.black.ignoresSafeArea()

            AJWebViewContainer(session: $currentSession, coordinator: webViewProxy)
                .ignoresSafeArea()

            if !isLoggedIn {
                VStack {
                    LoginControlBar(useTLSSocket: $useTLSSocket) { session in
                        currentSession = session
                        withAnimation {
                            isLoggedIn = true
                        }
                        webViewProxy.bootGame(with: session)
                    }
                    .background(.ultraThinMaterial)
                    .cornerRadius(12)
                    .padding(.horizontal, 16)
                    .padding(.top, 8)
                    
                    Spacer()
                }
                .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
    }
}

class WebViewCoordinator: ObservableObject {
    var webView: WKWebView?
    var activeSession: AJSession?

    func bootGame(with session: AJSession) {
        self.activeSession = session
        guard let webView = webView else { return }
        
        var fv = session.flashvars
        if let sfs = fv["smartfoxServer"] {
            fv["smartfoxServer"] = sfs.trimmingCharacters(in: .whitespacesAndNewlines)
        }

        let deployVersion = fv["deploy_version"] ?? fv["smoke_version"] ?? "1830"
        let rawContentBase = fv["content"] ?? "https://ajcontent.akamaized.net/"
        
        let proxiedContentBase = rawContentBase.replacingOccurrences(of: "https://", with: "ajproxy://")
        let swfURL = "\(proxiedContentBase)\(deployVersion)/ajclient.swf"

        guard let fvData = try? JSONSerialization.data(withJSONObject: fv),
              let fvJSON = String(data: fvData, encoding: .utf8) else { return }

        let sfsHost = fv["smartfoxServer"] ?? "lb-iss02-classic-prod.animaljam.com"
        let sfsPort = Int(fv["smartfoxPort"] ?? "443") ?? 443

        let js = """
        window.startAJWithSession(
            \(fvJSON),
            "\(swfURL)",
            "\(proxiedContentBase)\(deployVersion)/",
            [{ host: "\(sfsHost)", port: \(sfsPort), proxyUrl: window.__socketBridgeUrl || "ws://127.0.0.1:8765" }]
        );
        """
        webView.evaluateJavaScript(js)
    }
}
