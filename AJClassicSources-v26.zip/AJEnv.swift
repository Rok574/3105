import Foundation

/// Identity the AJ Classic client expects from its host app.
/// The game parses `AJClassic/x.y.z` and `Electron/x.y.z` out of navigator.userAgent and shows
/// "The AJ Classic app needs to be updated!" if they are missing or below the server's minimum.
/// Bump these if that popup ever returns.
enum AJEnv {
    static let appVersion = "2.0.0"
    static let electronVersion = "33.2.1"
    static let chromeVersion = "130.0.6723.191"

    static let userAgent =
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) " +
        "AJClassic/\(appVersion) Chrome/\(chromeVersion) Electron/\(electronVersion) Safari/537.36"
}
