import Foundation
import CryptoKit

struct AJSession {
    let username: String
    let authToken: String
    let refreshToken: String?
    let df: String
    let flashvars: [String: String]
}

enum AJAuthError: LocalizedError {
    case otpRequired
    case invalidCredentials(String)
    case serverError(Int, String)
    case invalidResponse

    var errorDescription: String? {
        switch self {
        case .otpRequired:
            return "2-Step Verification code required. Check your email."
        case .invalidCredentials(let msg):
            return msg
        case .serverError(let code, let msg):
            return "Auth HTTP \(code): \(msg)"
        case .invalidResponse:
            return "Unexpected response from Animal Jam servers."
        }
    }
}

final class AJAuthenticator {
    static let shared = AJAuthenticator()

    private let authURL = URL(string: "https://authenticator.animaljam.com/authenticate")!
    private let flashvarsURL = URL(string: "https://www.animaljam.com/flashvars")!
    private let desktopUA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) AJClassic/1.6.4 Chrome/87.0.4280.141 Electron/11.5.0 Safari/537.36"

    var deviceFingerprint: String {
        let key = "aj_classic_df"
        if let existing = UserDefaults.standard.string(forKey: key), existing.count == 64 {
            return existing
        }
        let seed = UUID().uuidString + "-" + UUID().uuidString
        let digest = SHA256.hash(data: Data(seed.utf8))
        let hex = digest.map { String(format: "%02x", $0) }.joined()
        UserDefaults.standard.set(hex, forKey: key)
        return hex
    }

    func fetchFlashvars() async throws -> [String: String] {
        var req = URLRequest(url: flashvarsURL)
        req.setValue(desktopUA, forHTTPHeaderField: "User-Agent")
        req.setValue("application/json", forHTTPHeaderField: "Accept")

        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw AJAuthError.invalidResponse
        }
        guard let raw = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw AJAuthError.invalidResponse
        }

        var result: [String: String] = [:]
        for (k, v) in raw {
            if v is NSNull { continue }
            result[k] = "\(v)"
        }
        return result
    }

    func login(
        username: String,
        password: String,
        otp: String? = nil,
        refreshToken: String? = nil
    ) async throws -> AJSession {
        let trimmedUser = username.trimmingCharacters(in: .whitespacesAndNewlines)
        let df = deviceFingerprint
        var fv = try await fetchFlashvars()

        var body: [String: Any] = [
            "domain": "flash",
            "df": df
        ]

        if let refreshToken, !refreshToken.isEmpty, password.isEmpty {
            body["refresh_token"] = refreshToken
        } else {
            body["username"] = trimmedUser
            body["password"] = password
        }

        if let otp = otp?.trimmingCharacters(in: .whitespacesAndNewlines), !otp.isEmpty {
            body["otp"] = otp
        }

        var req = URLRequest(url: authURL)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        req.setValue(desktopUA, forHTTPHeaderField: "User-Agent")
        req.setValue("https://www.animaljam.com", forHTTPHeaderField: "Origin")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: req)
        let statusCode = (response as? HTTPURLResponse)?.statusCode ?? 0
        let json = (try? JSONSerialization.jsonObject(with: data) as? [String: Any]) ?? [:]

        let errString = ("\(json["error"] ?? "") \(json["message"] ?? "") \(json["error_code"] ?? "")").lowercased()
        if errString.contains("otp") || errString.contains("two_factor") || errString.contains("2fa") || (json["otp_needed"] as? Bool == true) {
            throw AJAuthError.otpRequired
        }

        guard (200..<300).contains(statusCode) else {
            let msg = (json["message"] as? String) ?? (json["error"] as? String) ?? "Invalid username or password."
            throw AJAuthError.serverError(statusCode, msg)
        }

        guard let authToken = json["auth_token"] as? String, !authToken.isEmpty else {
            let msg = (json["message"] as? String) ?? (json["error"] as? String) ?? "No auth_token returned."
            throw AJAuthError.invalidCredentials(msg)
        }

        let newRefresh = json["refresh_token"] as? String
        let canonicalUser = Self.extractCanonicalUsername(from: authToken) ?? trimmedUser

        fv["username"] = canonicalUser
        fv["auth_token"] = authToken
        fv["df"] = df
        fv["locale"] = fv["locale"] ?? "en"
        if let newRefresh {
            fv["refresh_token"] = newRefresh
        }

        return AJSession(
            username: canonicalUser,
            authToken: authToken,
            refreshToken: newRefresh,
            df: df,
            flashvars: fv
        )
    }

    private static func extractCanonicalUsername(from jwt: String) -> String? {
        let parts = jwt.split(separator: ".")
        guard parts.count >= 2 else { return nil }
        var base64 = String(parts[1])
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        while base64.count % 4 != 0 { base64.append("=") }
        guard let payloadData = Data(base64Encoded: base64),
              let jsonObj = try? JSONSerialization.jsonObject(with: payloadData),
              let payload = jsonObj as? [String: Any] else {
            return nil
        }
        return (payload["screen_name"] as? String) ?? (payload["username"] as? String)
    }
}
