<h1 align="center">
  <img src="https://images.weserv.nl/?url=https://raw.githubusercontent.com/Rok574/GestaltTweak/main/GestaltTweak/Assets.xcassets/AppIcon.appiconset/AppIcon.png&w=256&h=256&mask=ellipse" width="40" height="40" align="absmiddle" alt="GestaltTweak Icon">
  GestaltTweak
</h1>

<p align="center">
  <strong>Modify MobileGestalt On iOS 27 Dev Beta 1–4, iOS 27.0.1, & iOS 27.2!</strong>
</p>

---

**Supported iOS Versions:**

| iOS Version | Build Number | Support | Recommended Engine |
|---|---|---|---|
| iOS ≤ 26.x | Any | unsupported | — |
| iOS 27.0 dev beta 1–4 | `24A5355q`, `24A5370h`, `24A5380h`, `24A5390f` | supported | `bad_query` / `cmg` / `worse_query` |
| iOS 27.0 public beta 1–2 | `24A5380l` | supported | `bad_query` / `cmg` / `worse_query` |
| iOS 27.0 dev beta ≥ 5 | Various | unsupported | — |
| iOS 27.0 public beta ≥ 3 | Various | unsupported | — |
| iOS 27.0.1 | `24A446` (released September 28, 2026) | supported | `worse_query` |
| iOS 27.2 | `24B119` | supported | `worse_query` |

---

**Implemented:**

- Engines: `bad_query`, `worse_query` (App Group sandbox escape), and `cmg`
- MobileGestalt Editor
- PosterBoard
- HouseArrest File Browser
- System App Opener

---

## Credits & Acknowledgments

GestaltTweak is made possible thanks to the work of the following developers and projects and AI:

- [forcequitOS/bad_query](https://github.com/forcequitOS/bad_query) & [forcequitOS/worse_query](https://github.com/forcequitOS/worse_query) – Primary sandbox escape methods
- [sasobhabha/Gester](https://github.com/sasobhabha/Gester) – KAMUI multi-strategy escape, dynamic App Group discovery, and modern iOS PosterBoard fix
- [rooootdev/mond](https://github.com/rooootdev/mond) – Implementations for PosterBoard + Housearrest
- [leminlimez/Nugget](https://github.com/leminlimez/Nugget) – MobileGestalt key mappings and iPadOS `CacheData` patch
- [rooootdev/neospring](https://github.com/rooootdev/neospring) – Respring implementation (neonmodder123 / skadz108)
- [SerStars/Nugget-Wallpapers](https://github.com/SerStars/Nugget-Wallpapers) – PosterBoard wallpaper catalog

---

## License

This project is licensed under the [MIT License](LICENSE).
Portions derived from [forcequitOS/worse_query](https://github.com/forcequitOS/worse_query) are licensed under the GNU General Public License v3.0.
