//
//  GXEntitlementsReader.h
//  GestaltTweak
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXEntitlementsReader : NSObject

+ (nullable NSDictionary<NSString *, id> *)entitlementsInMachOData:(NSData *)data;
+ (nullable NSString *)usableAppGroup;
+ (NSArray<NSString *> *)allAppGroups;

@end

NS_ASSUME_NONNULL_END
