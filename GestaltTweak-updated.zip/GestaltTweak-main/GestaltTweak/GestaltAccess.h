#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GestaltAccess : NSObject

+ (instancetype)shared;

+ (BOOL)isRunningSupportedOS;

+ (NSString *)currentOSBuild;

+ (NSString *)currentMethod;

- (BOOL)connectWithError:(NSError **)error;

- (nullable NSDictionary *)readGestaltWithError:(NSError **)error;
- (nullable NSData *)readGestaltDataWithError:(NSError **)error;
- (BOOL)saveGestalt:(NSDictionary *)plist error:(NSError **)error;

@end

NS_ASSUME_NONNULL_END