//
//  WorseQueryBridge.h
//  GestaltTweak
//
//  Integration bridge for forcequitOS/worse_query sandbox escape.
//  https://github.com/forcequitOS/worse_query
//
//  Licensed under the GPL-3.0 License.
//

#import <Foundation/Foundation.h>
#import "worse_query.h"
#import "pathleak.h"

NS_ASSUME_NONNULL_BEGIN

@interface WorseQueryLease : NSObject

@property (nonatomic, copy, readonly) NSString *targetPath;
@property (nonatomic, copy, readonly) NSString *appGroup;
@property (nonatomic, readonly) int64_t handle;
@property (nonatomic, readonly, getter=isActive) BOOL active;

+ (nullable instancetype)leaseForPath:(NSString *)path
                                error:(NSString * _Nullable * _Nullable)error;

+ (nullable instancetype)leaseForPath:(NSString *)path
                             appGroup:(nullable NSString *)appGroup
                                error:(NSString * _Nullable * _Nullable)error;

- (void)invalidate;

+ (NSString *)autoDetectAppGroup;
+ (NSArray<NSString *> *)allCandidateAppGroups;
+ (NSString *)defaultAppGroupIdentifier;
+ (void)setDefaultAppGroupIdentifier:(NSString *)appGroup;

@end

FOUNDATION_EXPORT BOOL WorseQueryBridgeAvailable(void);

FOUNDATION_EXPORT WorseQueryLease * _Nullable WQLeaseForPath(NSString *path,
                                                             NSString * _Nullable * _Nullable error);

FOUNDATION_EXPORT WorseQueryLease * _Nullable WQLeaseForPathWithGroup(NSString *path,
                                                                      NSString * _Nullable appGroup,
                                                                      NSString * _Nullable * _Nullable error);

FOUNDATION_EXPORT NSArray<NSString *> * _Nullable WQListContainers(NSString *path,
                                                                   uint64_t max_inode);

NS_ASSUME_NONNULL_END
