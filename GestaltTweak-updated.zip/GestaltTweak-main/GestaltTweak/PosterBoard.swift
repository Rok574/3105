//
//  PosterBoard.swift
//  GestaltTweak
//
//  PosterBoard (tendies) engine derived from rooootdev/mond's
//  helpers/posterboard (AGPL-3.0), enhanced with KAMUI / Gester modern iOS support
//  by sasobhabha (https://github.com/sasobhabha/Gester).
//  Licensed under the MIT License.
//

import Combine
import Foundation
import ZIPFoundation

nonisolated enum pb_error: LocalizedError {
    case container_404
    case not_zip(URL)
    case no_descriptors(URL)
    case access_denied(String)

    var errorDescription: String? {
        switch self {
        case .container_404:
            return "could not find the PosterBoard container."
        case .not_zip(let url):
            return "\(url.lastPathComponent) is not a valid tendies/zip archive."
        case .no_descriptors(let url):
            return "no descriptors found in \(url.lastPathComponent)."
        case .access_denied(let path):
            return "failed to gain write access to \(path)."
        }
    }
}

enum PosterPaths {
    static var tendies: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        let dir = base.appendingPathComponent("tendies", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }
}

func isPBArchive(_ url: URL) -> Bool {
    switch url.pathExtension.lowercased() {
    case "tendies", "zip":
        return true
    default:
        return false
    }
}

nonisolated enum pb {
    static let pb_bid = "com.apple.PosterBoard"
    static let collections_legacy_ext = "com.apple.WallpaperKit.CollectionsPoster"
    static let collections_modern_ext = "com.apple.Posters.CollectionsPosterApp"
    static let mercury_ext = "com.apple.MercuryPoster"
    static let photos_ext = "com.apple.PhotosUIPrivate.PhotosPosterProvider"
    static let ext_version = "61"

    static let all_extensions = [
        collections_legacy_ext,
        collections_modern_ext,
        mercury_ext,
        photos_ext
    ]

    static let container_roots = [
        "/var/mobile/Containers/Data/Application",
        "/var/mobile/Containers/Data/InternalDaemon",
        "/var/mobile/Containers/Data/PluginKitPlugin",
    ]

    private static let fm = FileManager.default
    private static let list_cache_lock = NSLock()
    private static var list_cache: [String: [String]] = [:]

    static func find_pb_container() throws -> URL {
        // 1. Fast path: check cached container from UserDefaults
        if let cached = UserDefaults.standard.string(forKey: "BQPBContainer"),
           !cached.isEmpty,
           is_valid_pb_container(cached) {
            AppLogger.shared.log("[PosterBoard] Using cached container: \(cached)")
            return URL(fileURLWithPath: cached, isDirectory: true)
        }

        // 2. Scan container roots across Applications, Daemons, and Plugins
        for root in container_roots {
            for child in list_containers(root) {
                // Check A: Directly check for PRBPosterExtensionDataStore directory (Gester method)
                if is_valid_pb_container(child) {
                    UserDefaults.standard.set(child, forKey: "BQPBContainer")
                    AppLogger.shared.log("[PosterBoard] Found container via PRB: \(child)", level: .success)
                    return URL(fileURLWithPath: child, isDirectory: true)
                }

                // Check B: Fallback to metadata identifier check
                let child_url = URL(fileURLWithPath: child, isDirectory: true)
                let hidden = child_url.appendingPathComponent(".com.apple.mobile_container_manager.metadata.plist")
                if let id = read_meta_key(at: hidden, key: "MCMMetadataIdentifier"), id == pb_bid {
                    UserDefaults.standard.set(child, forKey: "BQPBContainer")
                    AppLogger.shared.log("[PosterBoard] Found container via hidden metadata: \(child)", level: .success)
                    return child_url
                }

                let plain = child_url.appendingPathComponent("com.apple.mobile_container_manager.metadata.plist")
                if let id = read_meta_key(at: plain, key: "MCMMetadataIdentifier"), id == pb_bid {
                    UserDefaults.standard.set(child, forKey: "BQPBContainer")
                    AppLogger.shared.log("[PosterBoard] Found container via metadata: \(child)", level: .success)
                    return child_url
                }
            }
        }

        AppLogger.shared.log("[PosterBoard] PosterBoard container not found", level: .error)
        throw pb_error.container_404
    }

    private static func is_valid_pb_container(_ path: String) -> Bool {
        let prb = URL(fileURLWithPath: path, isDirectory: true)
            .appendingPathComponent("Library")
            .appendingPathComponent("Application Support")
            .appendingPathComponent("PRBPosterExtensionDataStore")

        guard let lease = try? acquire(prb.path) else { return false }
        defer { lease.invalidate() }

        var isDir: ObjCBool = false
        return fm.fileExists(atPath: prb.path, isDirectory: &isDir) && isDir.boolValue
    }

    static func list_containers(_ root: String) -> [String] {
        var norm = root
        if norm.hasPrefix("/private/") { norm.removeFirst("/private/".count - 1) }
        if norm.hasSuffix("/") { norm.removeLast() }

        list_cache_lock.lock()
        defer { list_cache_lock.unlock() }

        if let cached = list_cache[norm] {
            return cached
        }

        let list = GTListContainers(norm, 2_000_000) ?? []
        list_cache[norm] = list
        return list
    }

    static func read_meta_key(at url: URL, key: String) -> String? {
        guard let lease = try? acquire(url.path) else { return nil }
        defer { lease.invalidate() }

        guard let data = try? Data(contentsOf: url),
              let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any] else {
            return nil
        }

        return plist[key] as? String
    }

    static func poster_extensions_root(container: URL) -> URL {
        container
            .appendingPathComponent("Library")
            .appendingPathComponent("Application Support")
            .appendingPathComponent("PRBPosterExtensionDataStore")
            .appendingPathComponent(ext_version)
            .appendingPathComponent("Extensions")
    }

    static func descriptors_url(container: URL, ext: String) -> URL {
        poster_extensions_root(container: container)
            .appendingPathComponent(ext)
            .appendingPathComponent("descriptors")
    }

    // Forces PosterBoard provider cache to refresh on modern iOS
    static func write_pb_refresh_prefs(container: URL) {
        let prefsDir = container.appendingPathComponent("Library").appendingPathComponent("Preferences")
        try? ensure_directory(at: prefsDir.path)

        guard let lease = try? acquire(prefsDir.path) else { return }
        defer { lease.invalidate() }

        let plistDict: [String: Any] = [
            "PBF_RESET_FILE_PROTECTIONS": true,
            "PBF_LOCALE_DID_CHANGE": false,
            "PersistedPosterContainerBundleIdentifiers": [collections_modern_ext, collections_legacy_ext],
            "CompletedPosterBundleIdentifierMigrations": [
                "com.apple.Posters.UnityPosterApp.ExtragalacticPoster",
                "com.apple.Posters.WeatherPosterApp.WeatherPoster",
                "com.apple.Posters.UnityPosterApp.Unity2025Poster",
                "com.apple.Posters.UnityPosterApp.UnityPosterExtension",
                "com.apple.Posters.UnityPosterApp.RhizomePoster",
                "com.apple.Posters.KaleidoscopePosterApp.KaleidoscopePoster"
            ]
        ]

        if let data = try? PropertyListSerialization.data(fromPropertyList: plistDict, format: .binary, options: 0) {
            let plistFile = prefsDir.appendingPathComponent("com.apple.PosterBoard.unprotectedUserDefaults.plist")
            try? data.write(to: plistFile)
            AppLogger.shared.log("[PosterBoard] Refreshed unprotectedUserDefaults.plist for provider cache rebuild", level: .success)
        }
    }

    static func apply(at urls: [URL]) throws -> Int {
        var written = 0
        var allFailed = true

        // Primary: Attempt via worse_query BQApplyTendies engine (sasobhabha/Gester)
        for url in urls {
            var count: Int32 = 0
            var bqErr: NSString? = nil
            if BQApplyTendies(url, &count, &bqErr) {
                written += Int(count)
                allFailed = false
                AppLogger.shared.log("[PosterBoard] worse_query BQApplyTendies applied \(count) descriptor(s) for \(url.lastPathComponent)", level: .success)
            } else {
                AppLogger.shared.log("[PosterBoard] BQApplyTendies failed: \(bqErr ?? "unknown"), attempting fallback for \(url.lastPathComponent)...", level: .warning)
                do {
                    let fallbackCount = try fallback_apply(urls: [url])
                    written += fallbackCount
                    allFailed = false
                } catch {
                    AppLogger.shared.log("[PosterBoard] Fallback apply failed for \(url.lastPathComponent): \(error.localizedDescription)", level: .error)
                }
            }
        }

        if allFailed && !urls.isEmpty {
            throw pb_error.access_denied("Could not apply wallpapers via worse_query BQApplyTendies or fallback.")
        }
        return written
    }

    static func reset() throws {
        var bqErr: NSString? = nil
        if BQResetPosterBoard(&bqErr) {
            AppLogger.shared.log("[PosterBoard] Reset PosterBoard descriptors via worse_query BQResetPosterBoard", level: .success)
            return
        }
        AppLogger.shared.log("[PosterBoard] BQResetPosterBoard failed: \(bqErr ?? "unknown"), attempting fallback reset...", level: .warning)
        try fallback_reset()
    }

    private static func fallback_apply(urls: [URL]) throws -> Int {
        let container = try find_pb_container()
        var written = 0

        for url in urls {
            let unzip_dir = try unzip(url)
            defer { try? fm.removeItem(at: unzip_dir) }

            let descriptors = try find_descriptors(in: unzip_dir)
            guard !descriptors.isEmpty else { throw pb_error.no_descriptors(url) }

            for (ext, folders) in descriptors {
                for folder in folders {
                    guard folder.lastPathComponent != "__MACOSX" else { continue }
                    randomize_id(in: folder)

                    // Write to target extension
                    try write_descriptor(at: folder, container: container, ext: ext)
                    
                    // For collections on modern iOS (iOS 17, 18, 26, 27), also write to CollectionsPosterApp
                    if ext == collections_legacy_ext {
                        try? write_descriptor(at: folder, container: container, ext: collections_modern_ext)
                    }

                    written += 1
                }
            }
        }

        if written > 0 {
            write_pb_refresh_prefs(container: container)
            AppLogger.shared.log("[PosterBoard] Fallback applied \(written) descriptor(s) and wrote refresh prefs", level: .success)
        }

        return written
    }

    private static func fallback_reset() throws {
        let container = try find_pb_container()
        let root = poster_extensions_root(container: container)

        guard let root_lease = try? acquire(root.path) else { return }
        defer { root_lease.invalidate() }

        guard fm.fileExists(atPath: root.path) else { return }

        for ext in all_extensions {
            let desc_path = root.appendingPathComponent(ext).appendingPathComponent("descriptors")
            guard fm.fileExists(atPath: desc_path.path) else { continue }

            guard let lease = try? acquire(desc_path.path) else { continue }
            defer { lease.invalidate() }

            for item in (try? fm.contentsOfDirectory(atPath: desc_path.path)) ?? [] {
                try? fm.removeItem(at: desc_path.appendingPathComponent(item))
            }
        }

        write_pb_refresh_prefs(container: container)
        AppLogger.shared.log("[PosterBoard] Fallback reset all poster descriptors and refreshed cache", level: .info)
    }

    static func ensure_directory(at path: String) throws {
        if fm.fileExists(atPath: path) { return }

        let components = path.split(separator: "/").map(String.init)
        var built = ""
        var last_existing = ""
        for part in components {
            built += "/" + part
            if fm.fileExists(atPath: built) { last_existing = built }
        }

        let anchor = last_existing.isEmpty ? path : last_existing
        let lease = try acquire(anchor)
        defer { lease.invalidate() }

        try fm.createDirectory(atPath: path, withIntermediateDirectories: true)
    }

    private static func acquire(_ path: String) throws -> BadQueryLease {
        var failure: NSString?
        guard let lease = GTLeaseForPath(path, &failure) else {
            throw pb_error.access_denied((failure as String?) ?? path)
        }
        return lease
    }

    private static func unzip(_ url: URL) throws -> URL {
        guard let data = try? Data(contentsOf: url), data.count >= 4, data[0] == 0x50, data[1] == 0x4B else {
            throw pb_error.not_zip(url)
        }

        let dest = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try fm.createDirectory(at: dest, withIntermediateDirectories: true)
        try fm.unzipItem(at: url, to: dest)

        return dest
    }

    private static func find_descriptors(in root: URL) throws -> [String: [URL]] {
        var result: [String: [URL]] = [:]

        let top = try fm.contentsOfDirectory(at: root, includingPropertiesForKeys: [.isDirectoryKey], options: .skipsHiddenFiles)

        if let container = top.first(where: { $0.lastPathComponent.lowercased() == "container" }) {
            let ext_dir = poster_extensions_root(container: container)

            if fm.fileExists(atPath: ext_dir.path) {
                for ext in try fm.contentsOfDirectory(at: ext_dir, includingPropertiesForKeys: nil, options: .skipsHiddenFiles) {
                    let d = ext.appendingPathComponent("descriptors")
                    if fm.fileExists(atPath: d.path) {
                        result[ext.lastPathComponent, default: []].append(contentsOf: descriptor_folders(in: d))
                    }
                }

                return result
            }
        }

        for dir in top {
            let lower = dir.lastPathComponent.lowercased()
            if lower.contains("video-descriptor") || lower.contains("photosposter") {
                result[photos_ext, default: []].append(contentsOf: descriptor_folders(in: dir))
            } else if lower.contains("mercuryposter") {
                result[mercury_ext, default: []].append(contentsOf: descriptor_folders(in: dir))
            } else if lower.contains("descriptor") || lower.contains("wallpaperkit") {
                result[collections_legacy_ext, default: []].append(contentsOf: descriptor_folders(in: dir))
            }
        }

        if !result.isEmpty {
            return result
        }

        if let enumerator = fm.enumerator(at: root, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles, .skipsPackageDescendants]) {
            for case let dir as URL in enumerator {
                guard dir.lastPathComponent != "__MACOSX",
                      (try? dir.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true else { continue }

                let lower = dir.lastPathComponent.lowercased()
                let ext: String
                if lower.contains("video") || lower.contains("photos") {
                    ext = photos_ext
                } else if lower.contains("mercury") {
                    ext = mercury_ext
                } else {
                    ext = collections_legacy_ext
                }

                if is_descriptor_container(dir) {
                    result[ext, default: []].append(contentsOf: descriptor_folders(in: dir))
                } else if is_descriptor(dir) {
                    result[ext, default: []].append(dir)
                }
            }
        }

        return result
    }

    private static func descriptor_folders(in dir: URL) -> [URL] {
        guard let children = try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil, options: .skipsHiddenFiles) else {
            return []
        }

        return children.filter { $0.lastPathComponent != "__MACOSX" }
    }

    private static func is_descriptor_container(_ dir: URL) -> Bool {
        let lower = dir.lastPathComponent.lowercased()
        return lower.contains("descriptor")
    }

    private static func is_descriptor(_ dir: URL) -> Bool {
        guard let children = try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil, options: .skipsHiddenFiles) else {
            return false
        }

        return children.contains { $0.lastPathComponent == "com.apple.posterkit.provider.descriptor.identifier" }
    }

    private static func write_descriptor(at src: URL, container: URL, ext: String) throws {
        let dest_dir = descriptors_url(container: container, ext: ext)
        try ensure_directory(at: dest_dir.path)

        let lease = try acquire(dest_dir.path)
        defer { lease.invalidate() }

        let dest_url = dest_dir.appendingPathComponent(UUID().uuidString)
        if fm.fileExists(atPath: dest_url.path) { try? fm.removeItem(at: dest_url) }
        try fm.copyItem(at: src, to: dest_url)
    }

    private static func randomize_id(in url: URL) {
        let id = Int.random(in: 9999...99999)
        guard let enumerator = fm.enumerator(at: url, includingPropertiesForKeys: [.isRegularFileKey], options: [.skipsHiddenFiles, .skipsPackageDescendants]) else { return }

        for case let file as URL in enumerator {
            switch file.lastPathComponent {
            case "com.apple.posterkit.provider.descriptor.identifier":
                try? String(id).data(using: .utf8)?.write(to: file)
            case "com.apple.posterkit.provider.contents.userInfo":
                set_plist_val(key: "wallpaperRepresentingIdentifier", value: id, at: file)
            case "Wallpaper.plist":
                set_plist_val(key: "identifier", value: id, at: file)
            default:
                break
            }
        }
    }

    private static func set_plist_val(key: String, value: Any, at file: URL) {
        guard let data = fm.contents(atPath: file.path), var plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any] else { return }
        plist[key] = value
        guard let updated = try? PropertyListSerialization.data(fromPropertyList: plist, format: .xml, options: 0) else { return }
        try? updated.write(to: file)
    }
}

// MARK: - Tendies catalog

struct tendies: Identifiable, Codable, Hashable {
    let id: Int
    let name: String
    let description: String?
    let url: String
    let preview: String
    let authors: String?
    let contest: String?

    var preview_url: URL? {
        URL(string: "https://raw.githubusercontent.com/SerStars/Nugget-Wallpapers/main/\(preview)")
    }

    var download_url: URL? {
        URL(string: "https://raw.githubusercontent.com/SerStars/Nugget-Wallpapers/main/\(url)")
    }
}


@MainActor
final class TendiesVM: ObservableObject {
    @Published var wallpapers: [tendies] = []
    @Published var loading = false
    @Published var error_msg: String?
    @Published var query = ""

    var filtered: [tendies] {
        if query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return wallpapers
        }
        let q = query.lowercased()
        return wallpapers.filter { item in
            item.name.lowercased().contains(q) ||
            (item.description?.lowercased().contains(q) ?? false) ||
            (item.authors?.lowercased().contains(q) ?? false)
        }
    }

    func load() async {
        guard !loading else { return }
        loading = true
        error_msg = nil
        defer { loading = false }

        let catalogURLs = [
            "https://raw.githubusercontent.com/SerStars/Nugget-Wallpapers/main/wallpapers-custom.json",
            "https://raw.githubusercontent.com/SerStars/Nugget-Wallpapers/main/wallpapers-apple.json"
        ]

        var fetched: [tendies] = []
        var lastError: Error?

        for urlString in catalogURLs {
            guard let url = URL(string: urlString) else { continue }
            do {
                let (data, _) = try await URLSession.shared.data(from: url)
                let items = try JSONDecoder().decode([tendies].self, from: data)
                fetched.append(contentsOf: items)
            } catch {
                lastError = error
            }
        }

        if fetched.isEmpty {
            error_msg = lastError?.localizedDescription ?? "Could not load wallpaper catalog."
        } else {
            var unique: [tendies] = []
            var seen = Set<String>()
            for item in fetched {
                if !seen.contains(item.url) {
                    seen.insert(item.url)
                    unique.append(item)
                }
            }
            wallpapers = unique.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        }
    }
}

func download_tendies(_ wallpaper: tendies) async throws -> URL {
    guard let downloadURL = wallpaper.download_url else {
        throw URLError(.badURL)
    }

    let (data, response) = try await URLSession.shared.data(from: downloadURL)
    guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
        throw URLError(.badServerResponse)
    }

    let dir = PosterPaths.tendies
    try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)

    let filename = (wallpaper.url as NSString).lastPathComponent
    let leaf = filename.isEmpty ? "\(wallpaper.id).tendies" : filename
    var destination = dir.appendingPathComponent(leaf)

    if FileManager.default.fileExists(atPath: destination.path) {
        destination = dir.appendingPathComponent("\(UUID().uuidString)-\(leaf)")
    }

    try data.write(to: destination, options: .atomic)
    return destination
}
