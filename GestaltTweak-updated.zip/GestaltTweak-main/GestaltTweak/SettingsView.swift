//
//  SettingsView.swift
//  GestaltTweak
//
//  Licensed under the MIT License.
//

import SwiftUI
import UIKit

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var viewModel: GestaltViewModel

    @AppStorage("method") private var method = GestaltAccess.currentMethod()
    @AppStorage("worse_query_app_group") private var worseQueryAppGroup = WorseQueryLease.autoDetectAppGroup()
    @AppStorage("dismiss_after_import") private var dismissAfterImport = false
    @AppStorage("backup_before_write") private var backupBeforeWrite = true

    @State private var showsRespringConfirmation = false

    var body: some View {
        NavigationStack {
            List {
                Section { appInfoRow }

                Section {
                    Picker("Method", selection: $method) {
                        Text("bad_query").tag("bad_query")
                        Text("worse_query").tag("worse_query")
                        Text("cmg").tag("cmg")
                    }
                    .pickerStyle(.segmented)

                    if method == "worse_query" {
                        VStack(alignment: .leading, spacing: 4) {
                            HStack {
                                Text("App Group Identifier")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                Spacer()
                                Label("Auto-Detected", systemImage: "checkmark.seal.fill")
                                    .font(.caption2.weight(.semibold))
                                    .foregroundStyle(.green)
                            }
                            TextField("group.cc.forcequit.worse-query", text: $worseQueryAppGroup)
                                .font(.system(.subheadline, design: .monospaced))
                                .textInputAutocapitalization(.never)
                                .disableAutocorrection(true)
                            Text("Automatically detected from your app's signing profile. You can leave this as-is.")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    }

                    Button {
                        viewModel.runExploit()
                    } label: {
                        Text("Run Exploit")
                    }
                    .disabled(viewModel.isBusy)
                } header: {
                    Text("Engine")
                } footer: {
                    Text(engineFooterText)
                }

                Section {
                    Toggle("Dismiss After Import", isOn: $dismissAfterImport)
                    Toggle("Backup Before Write", isOn: $backupBeforeWrite)
                } header: {
                    Text("Behavior")
                }

                Section {
                    Button {
                        viewModel.backupCurrentPlist()
                    } label: {
                        Label("Backup MobileGestalt Now", systemImage: "arrow.down.doc")
                    }

                    Button {
                        viewModel.restoreLatestBackup()
                    } label: {
                        Label("Restore Latest Backup", systemImage: "arrow.counterclockwise")
                    }
                    .disabled(!viewModel.hasBackups)
                } header: {
                    Text("Backups")
                }

                Section {
                    Button(role: .destructive) {
                        showsRespringConfirmation = true
                    } label: {
                        Label("Respring SpringBoard", systemImage: "arrow.clockwise")
                    }
                } header: {
                    Text("SpringBoard")
                } footer: {
                    Text("Restarts SpringBoard so modified Gestalt keys can take effect.")
                }

                Section {
                    CreditsRow(name: "Rok574", role: "Original GestaltTweak author", profile: URL(string: "https://github.com/Rok574")!)
                    CreditsRow(name: "forcequit", role: "bad_query & worse_query exploit author", profile: URL(string: "https://github.com/forcequitOS")!)
                    CreditsRow(name: "neonmodder123", role: "Respring method", profile: URL(string: "https://github.com/neonmodder123")!)
                } header: {
                    Text("Credits")
                }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done") { dismiss() }
                }
            }
            .confirmationDialog(
                "Are you sure you want to respring?",
                isPresented: $showsRespringConfirmation,
                titleVisibility: .visible
            ) {
                Button("Respring", role: .destructive) {
                    viewModel.respring()
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("This will reload SpringBoard. Unsaved app state may be lost.")
            }
            .alert(item: $viewModel.notice) { notice in
                Alert(
                    title: Text(notice.title),
                    message: Text(notice.message),
                    dismissButton: .default(Text("OK"))
                )
            }
            .onAppear {
                if worseQueryAppGroup.isEmpty || worseQueryAppGroup.contains("No App Group") || worseQueryAppGroup.contains("Self App") {
                    let detected = WorseQueryLease.autoDetectAppGroup()
                    if !detected.contains("No App Group") {
                        worseQueryAppGroup = detected
                    }
                }
            }
        }
    }

    private var engineFooterText: String {
        switch method {
        case "worse_query":
            return "worse_query: works on iOS 26.0 - 26.7.2, 27.0.1 (24A446), and 27.2 (24B119). Replaces bad_query via App Group sandbox escape. Credit to forcequit."
        case "cmg":
            return "CMG: works on iOS 27.0 b1 - b4. Only MobileGestalt is reachable this way. Fall back to it when bad_query is a no-go."
        default:
            return "bad_query: works on iOS 27.0 b1 - b4. Credit to forcequit."
        }
    }

    private var appInfoRow: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(Color(.secondarySystemBackground))
                    .frame(width: 50, height: 50)
                Image(systemName: "bolt.fill")
                    .font(.system(size: 21, weight: .semibold))
                    .foregroundStyle(Color.accentColor)
            }

            VStack(alignment: .leading, spacing: 2) {
                Text("GestaltTweak")
                    .font(.headline)
                Text("Version \(versionText)")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Spacer()
        }
    }

    private var versionText: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "1.0"
    }
}

struct CreditsRow: View {
    @Environment(\.openURL) private var openURL

    let name: String
    let role: String
    let profile: URL

    var body: some View {
        HStack(alignment: .top) {
            AsyncImage(url: avatarURL) { image in
                image
                    .resizable()
                    .scaledToFill()
            } placeholder: {
                ProgressView()
            }
            .frame(width: 40, height: 40)
            .clipShape(Circle())

            VStack(alignment: .leading, spacing: 2) {
                Text(name)
                    .font(.headline)
                Text(role)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Spacer()
        }
        .contentShape(Rectangle())
        .onTapGesture {
            openURL(profile)
        }
    }

    private var avatarURL: URL {
        URL(string: profile.absoluteString + ".png") ?? profile
    }
}