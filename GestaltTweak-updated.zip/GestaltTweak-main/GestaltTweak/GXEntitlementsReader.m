//
//  GXEntitlementsReader.m
//  GestaltTweak
//

#import "GXEntitlementsReader.h"
#import "BQCore.h"
#import "GTLog.h"
#import <dlfcn.h>
#import <mach-o/dyld.h>
#import <mach-o/loader.h>
#import <mach-o/fat.h>
#import <arpa/inet.h>

typedef struct __SecTask *SecTaskRef;
typedef SecTaskRef (*SecTaskCreateFromSelf_fn)(CFAllocatorRef);
typedef CFTypeRef (*SecTaskCopyValueForEntitlement_fn)(SecTaskRef, CFStringRef, CFErrorRef *);

@implementation GXEntitlementsReader

+ (nullable NSDictionary<NSString *, id> *)entitlementsInMachOData:(NSData *)data
{
    if (data.length < sizeof(struct mach_header_64)) return nil;

    const uint8_t *bytes = (const uint8_t *)data.bytes;
    NSUInteger totalLength = data.length;
    uint32_t magic = *(const uint32_t *)bytes;

    uint32_t headerOffset = 0;
    if (magic == FAT_MAGIC || magic == FAT_CIGAM) {
        if (totalLength < sizeof(struct fat_header)) return nil;
        const struct fat_header *fat = (const struct fat_header *)bytes;
        uint32_t narch = ntohl(fat->nfat_arch);
        if (totalLength < sizeof(struct fat_header) + narch * sizeof(struct fat_arch)) return nil;
        const struct fat_arch *archs = (const struct fat_arch *)(bytes + sizeof(struct fat_header));
        BOOL found = NO;
        for (uint32_t i = 0; i < narch; i++) {
            cpu_type_t cputype = ntohl(archs[i].cputype);
            if (cputype == CPU_TYPE_ARM64) {
                headerOffset = ntohl(archs[i].offset);
                found = YES;
                break;
            }
        }
        if (!found && narch > 0) {
            headerOffset = ntohl(archs[0].offset);
        }
    }

    if (headerOffset + sizeof(struct mach_header_64) > totalLength) return nil;
    const struct mach_header_64 *mh = (const struct mach_header_64 *)(bytes + headerOffset);
    if (mh->magic != MH_MAGIC_64) return nil;

    uint32_t ncmds = mh->ncmds;
    uint32_t cmdOffset = headerOffset + sizeof(struct mach_header_64);
    uint32_t csOffset = 0;
    uint32_t csSize = 0;

    for (uint32_t i = 0; i < ncmds; i++) {
        if (cmdOffset + sizeof(struct load_command) > totalLength) break;
        const struct load_command *lc = (const struct load_command *)(bytes + cmdOffset);
        if (lc->cmd == LC_CODE_SIGNATURE) {
            const struct linkedit_data_command *ldc = (const struct linkedit_data_command *)lc;
            csOffset = headerOffset + ldc->dataoff;
            csSize = ldc->datasize;
            break;
        }
        cmdOffset += lc->cmdsize;
    }

    if (csOffset == 0 || csSize == 0 || csOffset + csSize > totalLength) return nil;
    const uint8_t *csBytes = bytes + csOffset;

    if (csSize < 12) return nil;
    uint32_t csMagic = ntohl(*(const uint32_t *)csBytes);
    if (csMagic != 0xfade0cc0) return nil; // CS_MAGIC_EMBEDDED_SIGNATURE

    uint32_t count = ntohl(*(const uint32_t *)(csBytes + 8));
    for (uint32_t i = 0; i < count; i++) {
        if (12 + (i + 1) * 8 > csSize) break;
        uint32_t slotType = ntohl(*(const uint32_t *)(csBytes + 12 + i * 8));
        uint32_t slotOffset = ntohl(*(const uint32_t *)(csBytes + 16 + i * 8));
        if (slotType == 5) { // CSSLOT_ENTITLEMENTS
            if (slotOffset + 8 > csSize) break;
            uint32_t entMagic = ntohl(*(const uint32_t *)(csBytes + slotOffset));
            uint32_t entLen = ntohl(*(const uint32_t *)(csBytes + slotOffset + 4));
            if (entMagic == 0xfade7171 && slotOffset + entLen <= csSize) {
                NSData *entData = [NSData dataWithBytes:(csBytes + slotOffset + 8) length:(entLen - 8)];
                id plist = [NSPropertyListSerialization propertyListWithData:entData options:0 format:NULL error:nil];
                if ([plist isKindOfClass:[NSDictionary class]]) {
                    return plist;
                }
            }
            break;
        }
    }
    return nil;
}

+ (NSArray<NSString *> *)groupsFromSecurityFramework
{
    // Match Gester dynamic resolution across RTLD_DEFAULT and Security.framework
    void *sec = dlopen("/System/Library/Frameworks/Security.framework/Security", RTLD_NOW);
    SecTaskCreateFromSelf_fn create = (SecTaskCreateFromSelf_fn)dlsym(RTLD_DEFAULT, "SecTaskCreateFromSelf");
    if (!create && sec) create = (SecTaskCreateFromSelf_fn)dlsym(sec, "SecTaskCreateFromSelf");
    SecTaskCopyValueForEntitlement_fn copy = (SecTaskCopyValueForEntitlement_fn)dlsym(RTLD_DEFAULT, "SecTaskCopyValueForEntitlement");
    if (!copy && sec) copy = (SecTaskCopyValueForEntitlement_fn)dlsym(sec, "SecTaskCopyValueForEntitlement");

    if (!create || !copy) {
        if (sec) dlclose(sec);
        return @[];
    }

    SecTaskRef task = create(kCFAllocatorDefault);
    if (!task) {
        if (sec) dlclose(sec);
        return @[];
    }

    CFErrorRef err = NULL;
    CFTypeRef val = copy(task, CFSTR("com.apple.security.application-groups"), &err);
    CFRelease(task);
    if (sec) dlclose(sec);

    if (!val) return @[];

    NSMutableArray<NSString *> *groups = [NSMutableArray array];
    if (CFGetTypeID(val) == CFArrayGetTypeID()) {
        NSArray *arr = (__bridge NSArray *)val;
        for (id item in arr) {
            if ([item isKindOfClass:[NSString class]]) {
                [groups addObject:item];
            }
        }
    } else if (CFGetTypeID(val) == CFStringGetTypeID()) {
        [groups addObject:(__bridge NSString *)val];
    }
    CFRelease(val);
    GTLog(@"[GXEntitlementsReader] Task signature contains %lu group(s)", (unsigned long)groups.count);
    return groups;
}

+ (NSArray<NSString *> *)groupsFromMainExecutable
{
    const char *mainPath = _dyld_get_image_name(0);
    if (!mainPath) return @[];

    NSData *data = [NSData dataWithContentsOfFile:[NSString stringWithUTF8String:mainPath] options:NSDataReadingMappedIfSafe error:nil];
    if (!data) return @[];

    NSDictionary *entitlements = [self entitlementsInMachOData:data];
    if (!entitlements) return @[];

    id val = entitlements[@"com.apple.security.application-groups"];
    NSMutableArray<NSString *> *groups = [NSMutableArray array];
    if ([val isKindOfClass:[NSArray class]]) {
        for (id item in val) {
            if ([item isKindOfClass:[NSString class]]) {
                [groups addObject:item];
            }
        }
    } else if ([val isKindOfClass:[NSString class]]) {
        [groups addObject:val];
    }
    GTLog(@"[GXEntitlementsReader] dyld main-image contains %lu group(s)", (unsigned long)groups.count);
    return groups;
}

+ (NSArray<NSString *> *)allAppGroups
{
    NSMutableOrderedSet<NSString *> *candidates = [NSMutableOrderedSet orderedSet];

    // 1. User manual override if saved
    NSString *saved = [[NSUserDefaults standardUserDefaults] stringForKey:@"worse_query_app_group"];
    if (saved.length > 0 && [saved hasPrefix:@"group."]) {
        [candidates addObject:saved];
    }

    // 2. Gester BQGroupID / BQGroupIDs (proven 100% in LiveContainer)
    for (NSString *g in BQGroupIDs()) {
        if (g.length > 0) [candidates addObject:g];
    }

    // 3. Entitlements from running process via Security.framework
    for (NSString *g in [self groupsFromSecurityFramework]) {
        if (g.length > 0) [candidates addObject:g];
    }

    // 4. Entitlements from dyld image 0 (LiveContainer executable)
    for (NSString *g in [self groupsFromMainExecutable]) {
        if (g.length > 0) [candidates addObject:g];
    }

    // 5. Derived from bundle identifier
    NSString *bundleID = [[NSBundle mainBundle] bundleIdentifier];
    if (bundleID.length > 0) {
        [candidates addObject:[@"group." stringByAppendingString:bundleID]];
    }

    // 6. Common fallbacks
    [candidates addObject:@"group.com.kamui.escape"];
    [candidates addObject:@"group.com.gestalttweak.app"];
    [candidates addObject:@"group.cc.forcequit.worse-query"];

    return [candidates array];
}

+ (nullable NSString *)usableAppGroup
{
    // Fast path: Gester active group ID
    NSString *bg = BQGroupID();
    if (bg.length > 0) {
        NSURL *u = [[NSFileManager defaultManager] containerURLForSecurityApplicationGroupIdentifier:bg];
        if (u != nil) {
            GTLog(@"[GXEntitlementsReader] Selected accessible App Group via Gester: %@", bg);
            return bg;
        }
    }

    NSArray<NSString *> *candidates = [self allAppGroups];
    NSFileManager *fm = [NSFileManager defaultManager];

    for (NSString *candidate in candidates) {
        if (![candidate hasPrefix:@"group."]) continue;
        NSURL *url = [fm containerURLForSecurityApplicationGroupIdentifier:candidate];
        if (url != nil) {
            GTLog(@"[GXEntitlementsReader] Selected accessible App Group: %@", candidate);
            return candidate;
        }
    }

    GTLog(@"[GXEntitlementsReader] No accessible App Group container found on device");
    return nil;
}

@end
