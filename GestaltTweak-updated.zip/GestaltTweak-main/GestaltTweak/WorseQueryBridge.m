//
//  WorseQueryBridge.m
//  GestaltTweak
//
//  Integration bridge for forcequitOS/worse_query sandbox escape.
//  https://github.com/forcequitOS/worse_query
//
//  Licensed under the GPL-3.0 License.
//

#import "WorseQueryBridge.h"
#import <sys/stat.h>

@interface WorseQueryLease ()
@property (nonatomic, copy, readwrite) NSString *targetPath;
@property (nonatomic, copy, readwrite) NSString *appGroup;
@property (nonatomic, readwrite) int64_t handle;
@property (nonatomic, readwrite, getter=isActive) BOOL active;
@end

@implementation WorseQueryLease

+ (NSString *)defaultAppGroupIdentifier
{
    NSString *configured = [[NSUserDefaults standardUserDefaults] stringForKey:@"worse_query_app_group"];
    if (configured.length > 0) {
        NSURL *url = [[NSFileManager defaultManager] containerURLForSecurityApplicationGroupIdentifier:configured];
        if (url) return configured;
    }
    
    NSArray<NSString *> *candidates = @[
        @"group.cc.forcequit.worse-query",
        @"group.com.gestalttweak.app"
    ];
    for (NSString *candidate in candidates) {
        NSURL *url = [[NSFileManager defaultManager] containerURLForSecurityApplicationGroupIdentifier:candidate];
        if (url) return candidate;
    }
    
    return configured.length > 0 ? configured : @"group.cc.forcequit.worse-query";
}

+ (void)setDefaultAppGroupIdentifier:(NSString *)appGroup
{
    if (appGroup.length > 0) {
        [[NSUserDefaults standardUserDefaults] setObject:appGroup forKey:@"worse_query_app_group"];
    } else {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"worse_query_app_group"];
    }
}

+ (instancetype)leaseForPath:(NSString *)path error:(NSString **)error
{
    return [self leaseForPath:path appGroup:nil error:error];
}

+ (instancetype)leaseForPath:(NSString *)path
                    appGroup:(NSString *)appGroup
                       error:(NSString **)error
{
    if (path.length == 0) {
        if (error) *error = @"worse_query requires a target path.";
        return nil;
    }
    
    NSString *group = appGroup.length > 0 ? appGroup : [self defaultAppGroupIdentifier];
    BOOL altFlags = (NSProcessInfo.processInfo.operatingSystemVersion.majorVersion == 26 &&
                     [path containsString:@"/var/mobile/Containers/Shared/AppGroup"]);
    
    // First try with create_dir = false; if target cannot be lstat'd in sandbox (-255), retry with create_dir = true
    int64_t handle = worse_query(path, group, altFlags, false);
    if (handle == -255) {
        handle = worse_query(path, group, altFlags, true);
    }
    
    if (handle < 0) {
        if (error) {
            switch (handle) {
                case -1:
                    *error = [NSString stringWithFormat:@"worse_query failed to access App Group container '%@'. Ensure the entitlement is set.", group];
                    break;
                case -2:
                    *error = @"worse_query failed to resolve ContainerManager symbols (unsupported OS).";
                    break;
                case -3:
                    *error = @"worse_query failed to create container query.";
                    break;
                case -4:
                    *error = @"worse_query failed to create symlink in App Group Caches.";
                    break;
                case -5:
                    *error = @"worse_query was rejected by containermanagerd.";
                    break;
                case -6:
                    *error = @"worse_query kernel refused sandbox extension issue.";
                    break;
                case -255:
                    *error = [NSString stringWithFormat:@"worse_query target does not exist: %@", path];
                    break;
                default:
                    *error = [NSString stringWithFormat:@"worse_query failed with error code %lld.", handle];
                    break;
            }
        }
        return nil;
    }
    
    WorseQueryLease *lease = [WorseQueryLease new];
    lease.targetPath = path;
    lease.appGroup = group;
    lease.handle = handle;
    lease.active = YES;
    if (error) *error = nil;
    return lease;
}

- (void)invalidate
{
    if (!self.active) return;
    worse_query_release(self.handle);
    self.handle = -1;
    self.active = NO;
}

- (void)dealloc
{
    [self invalidate];
}

@end

BOOL WorseQueryBridgeAvailable(void)
{
    return worse_query_available();
}

WorseQueryLease *WQLeaseForPath(NSString *path, NSString **error)
{
    return [WorseQueryLease leaseForPath:path error:error];
}

WorseQueryLease *WQLeaseForPathWithGroup(NSString *path, NSString *appGroup, NSString **error)
{
    return [WorseQueryLease leaseForPath:path appGroup:appGroup error:error];
}

NSArray<NSString *> *WQListContainers(NSString *path, uint64_t max_inode)
{
    return pathleak(path, max_inode);
}
