//
//  WorseQueryBridge.m
//  GestaltTweak
//
//  Integration bridge for forcequitOS/worse_query sandbox escape.
//  https://github.com/forcequitOS/worse_query
//
//  Licensed under the GPL-3.0 License.
//

#import "WorseQueryBridge.h"
#import "GXEntitlementsReader.h"
#import <sys/stat.h>
#import <string.h>

@interface WorseQueryLease ()
@property (nonatomic, copy, readwrite) NSString *targetPath;
@property (nonatomic, copy, readwrite) NSString *appGroup;
@property (nonatomic, readwrite) int64_t handle;
@property (nonatomic, readwrite, getter=isActive) BOOL active;
@end

@implementation WorseQueryLease

+ (NSArray<NSString *> *)allCandidateAppGroups
{
    return [GXEntitlementsReader allAppGroups];
}

+ (NSString *)autoDetectAppGroup
{
    NSString *detected = [GXEntitlementsReader usableAppGroup];
    if (detected.length > 0) return detected;
    return @"(No App Group Container Found)";
}

+ (NSString *)defaultAppGroupIdentifier
{
    return [self autoDetectAppGroup];
}

+ (void)setDefaultAppGroupIdentifier:(NSString *)appGroup
{
    if (appGroup.length > 0) {
        [[NSUserDefaults standardUserDefaults] setObject:appGroup forKey:@"worse_query_app_group"];
    } else {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"worse_query_app_group"];
    }
}

+ (instancetype)leaseForPath:(NSString *)path error:(NSString **)error
{
    return [self leaseForPath:path appGroup:nil error:error];
}

+ (instancetype)leaseForPath:(NSString *)path
                    appGroup:(NSString *)appGroup
                       error:(NSString **)error
{
    if (path.length == 0) {
        if (error) *error = @"worse_query requires a target path.";
        return nil;
    }

    NSString *targetGroup = appGroup;
    if (targetGroup.length == 0 || [targetGroup containsString:@"No App Group"] || [targetGroup containsString:@"Self App"]) {
        targetGroup = [GXEntitlementsReader usableAppGroup];
    }

    NSMutableOrderedSet<NSString *> *groupsToTry = [NSMutableOrderedSet orderedSet];
    if (targetGroup.length > 0) {
        [groupsToTry addObject:targetGroup];
    }
    for (NSString *g in [GXEntitlementsReader allAppGroups]) {
        if ([g hasPrefix:@"group."]) [groupsToTry addObject:g];
    }

    int64_t handle = -1;
    NSString *successfulGroup = nil;

    for (NSString *group in groupsToTry) {
        // Try permutation 1: alt_flags = false, create_dir = false
        handle = worse_query(path, group, false, false);
        if (handle == -255) {
            handle = worse_query(path, group, false, true);
        }
        if (handle < 0) {
            // Try permutation 2: alt_flags = true
            handle = worse_query(path, group, true, false);
            if (handle == -255) {
                handle = worse_query(path, group, true, true);
            }
        }
        if (handle >= 0) {
            successfulGroup = group;
            break;
        }
    }

    if (handle < 0) {
        if (error) {
            switch (handle) {
                case -1:
                    *error = @"worse_query could not find an accessible App Group container on device.";
                    break;
                case -2:
                    *error = @"worse_query failed to resolve ContainerManager symbols (unsupported OS).";
                    break;
                case -3:
                    *error = @"worse_query failed to allocate container query.";
                    break;
                case -4:
                    *error = @"worse_query failed to create symlink in Caches.";
                    break;
                case -5:
                    *error = @"worse_query was rejected by containermanagerd. Please check signing entitlements.";
                    break;
                case -6:
                    *error = @"worse_query kernel refused sandbox extension issue.";
                    break;
                case -255:
                    *error = [NSString stringWithFormat:@"worse_query target does not exist: %@", path];
                    break;
                default:
                    *error = [NSString stringWithFormat:@"worse_query failed with error code %lld.", handle];
                    break;
            }
        }
        return nil;
    }

    WorseQueryLease *lease = [WorseQueryLease new];
    lease.targetPath = path;
    lease.appGroup = successfulGroup;
    lease.handle = handle;
    lease.active = YES;
    if (error) *error = nil;
    return lease;
}

- (void)invalidate
{
    if (!self.active) return;
    worse_query_release(self.handle);
    self.handle = -1;
    self.active = NO;
}

- (void)dealloc
{
    [self invalidate];
}

@end

BOOL WorseQueryBridgeAvailable(void)
{
    return worse_query_available();
}

WorseQueryLease *WQLeaseForPath(NSString *path, NSString **error)
{
    return [WorseQueryLease leaseForPath:path error:error];
}

WorseQueryLease *WQLeaseForPathWithGroup(NSString *path, NSString *appGroup, NSString **error)
{
    return [WorseQueryLease leaseForPath:path appGroup:appGroup error:error];
}

NSArray<NSString *> *WQListContainers(NSString *path, uint64_t max_inode)
{
    return pathleak(path, max_inode);
}
