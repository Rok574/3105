//
//  WorseQueryBridge.m
//  GestaltTweak
//
//  Integration bridge for forcequitOS/worse_query sandbox escape.
//  https://github.com/forcequitOS/worse_query
//
//  Licensed under the GPL-3.0 License.
//

#import "WorseQueryBridge.h"
#import <sys/stat.h>
#import <string.h>

typedef struct __SecTask *SecTaskRef;
extern SecTaskRef SecTaskCreateFromSelf(CFAllocatorRef allocator) __attribute__((weak_import));
extern CFTypeRef SecTaskCopyValueForEntitlement(SecTaskRef task, CFStringRef entitlement, CFErrorRef *error) __attribute__((weak_import));

@interface WorseQueryLease ()
@property (nonatomic, copy, readwrite) NSString *targetPath;
@property (nonatomic, copy, readwrite) NSString *appGroup;
@property (nonatomic, readwrite) int64_t handle;
@property (nonatomic, readwrite, getter=isActive) BOOL active;
@end

@implementation WorseQueryLease

+ (NSArray<NSString *> *)groupsFromSecTask
{
    if (!SecTaskCreateFromSelf || !SecTaskCopyValueForEntitlement) return @[];
    SecTaskRef task = SecTaskCreateFromSelf(NULL);
    if (!task) return @[];

    CFErrorRef err = NULL;
    CFTypeRef val = SecTaskCopyValueForEntitlement(task, CFSTR("com.apple.security.application-groups"), &err);
    CFRelease(task);
    if (!val) return @[];

    NSMutableArray<NSString *> *res = [NSMutableArray array];
    if (CFGetTypeID(val) == CFArrayGetTypeID()) {
        NSArray *arr = (__bridge NSArray *)val;
        for (id item in arr) {
            if ([item isKindOfClass:[NSString class]]) {
                [res addObject:item];
            }
        }
    } else if (CFGetTypeID(val) == CFStringGetTypeID()) {
        [res addObject:(__bridge NSString *)val];
    }
    CFRelease(val);
    return res;
}

+ (NSArray<NSString *> *)groupsFromProvisioningProfile
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"embedded" ofType:@"mobileprovision"];
    if (!path) return @[];

    NSData *data = [NSData dataWithContentsOfFile:path options:0 error:nil];
    if (!data) return @[];

    const char *bytes = (const char *)data.bytes;
    NSUInteger length = data.length;

    const char *xmlStartStr = "<?xml";
    const char *xmlEndStr = "</plist>";

    const void *startPtr = memmem(bytes, length, xmlStartStr, strlen(xmlStartStr));
    if (!startPtr) return @[];

    const void *endPtr = memmem(bytes, length, xmlEndStr, strlen(xmlEndStr));
    if (!endPtr) return @[];

    NSUInteger offset = (const char *)startPtr - bytes;
    NSUInteger plistLen = ((const char *)endPtr - (const char *)startPtr) + strlen(xmlEndStr);

    NSData *xmlData = [data subdataWithRange:NSMakeRange(offset, plistLen)];
    NSDictionary *plist = [NSPropertyListSerialization propertyListWithData:xmlData options:0 format:NULL error:nil];
    if ([plist isKindOfClass:[NSDictionary class]]) {
        NSDictionary *entitlements = plist[@"Entitlements"];
        if ([entitlements isKindOfClass:[NSDictionary class]]) {
            id groups = entitlements[@"com.apple.security.application-groups"];
            if ([groups isKindOfClass:[NSArray class]]) {
                return (NSArray<NSString *> *)groups;
            } else if ([groups isKindOfClass:[NSString class]]) {
                return @[(NSString *)groups];
            }
        }
    }
    return @[];
}

+ (NSArray<NSString *> *)allCandidateAppGroups
{
    NSMutableOrderedSet<NSString *> *candidates = [NSMutableOrderedSet orderedSet];

    NSString *configured = [[NSUserDefaults standardUserDefaults] stringForKey:@"worse_query_app_group"];
    if (configured.length > 0) {
        if (![configured hasPrefix:@"group."]) configured = [@"group." stringByAppendingString:configured];
        [candidates addObject:configured];
    }

    for (NSString *g in [self groupsFromSecTask]) {
        if (g.length > 0) [candidates addObject:g];
    }

    for (NSString *g in [self groupsFromProvisioningProfile]) {
        if (g.length > 0) [candidates addObject:g];
    }

    // Dynamically derive group from the running app bundle ID
    NSString *bundleID = [[NSBundle mainBundle] bundleIdentifier];
    if (bundleID.length > 0) {
        [candidates addObject:[@"group." stringByAppendingString:bundleID]];
        // Also check if bundle has a prefix like .notification or team suffix
        NSRange dotRange = [bundleID rangeOfString:@"." options:NSBackwardsSearch];
        if (dotRange.location != NSNotFound) {
            NSString *parentBundle = [bundleID substringToIndex:dotRange.location];
            [candidates addObject:[@"group." stringByAppendingString:parentBundle]];
        }
    }

    [candidates addObject:@"group.com.gestalttweak.app"];
    [candidates addObject:@"group.cc.forcequit.worse-query"];

    return [candidates array];
}

+ (NSString *)autoDetectAppGroup
{
    NSArray<NSString *> *candidates = [self allCandidateAppGroups];
    NSFileManager *files = [NSFileManager defaultManager];

    for (NSString *candidate in candidates) {
        NSURL *url = [files containerURLForSecurityApplicationGroupIdentifier:candidate];
        if (url != nil) {
            return candidate;
        }
    }

    // If no App Group container exists on device, indicate Free Personal Apple ID fallback
    return @"(Self App Container / Free Cert)";
}

+ (NSString *)defaultAppGroupIdentifier
{
    return [self autoDetectAppGroup];
}

+ (void)setDefaultAppGroupIdentifier:(NSString *)appGroup
{
    if (appGroup.length > 0) {
        [[NSUserDefaults standardUserDefaults] setObject:appGroup forKey:@"worse_query_app_group"];
    } else {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"worse_query_app_group"];
    }
}

+ (instancetype)leaseForPath:(NSString *)path error:(NSString **)error
{
    return [self leaseForPath:path appGroup:nil error:error];
}

+ (instancetype)leaseForPath:(NSString *)path
                    appGroup:(NSString *)appGroup
                       error:(NSString **)error
{
    if (path.length == 0) {
        if (error) *error = @"worse_query requires a target path.";
        return nil;
    }

    NSArray<NSString *> *groupsToTry;
    if (appGroup.length > 0 && ![appGroup containsString:@"Self App Container"]) {
        NSString *cleaned = appGroup;
        if (![cleaned hasPrefix:@"group."]) cleaned = [@"group." stringByAppendingString:cleaned];
        NSMutableOrderedSet<NSString *> *set = [NSMutableOrderedSet orderedSetWithObject:cleaned];
        [set addObjectsFromArray:[self allCandidateAppGroups]];
        groupsToTry = [set array];
    } else {
        groupsToTry = [self allCandidateAppGroups];
    }

    BOOL altFlags = (NSProcessInfo.processInfo.operatingSystemVersion.majorVersion == 26 &&
                     [path containsString:@"/var/mobile/Containers/Shared/AppGroup"]);

    int64_t handle = -1;
    NSString *successfulGroup = nil;

    // Phase 1: Try App Groups (Class 7)
    for (NSString *group in groupsToTry) {
        handle = worse_query(path, group, altFlags, false);
        if (handle == -255) {
            handle = worse_query(path, group, altFlags, true);
        }
        if (handle >= 0) {
            successfulGroup = group;
            break;
        }
    }

    // Phase 2: Free Certificate Fallback (Self App Container / Class 2 & 1)
    if (handle < 0) {
        handle = worse_query(path, @"", altFlags, false);
        if (handle == -255) {
            handle = worse_query(path, @"", altFlags, true);
        }
        if (handle >= 0) {
            successfulGroup = @"(Self App Container / Free Cert)";
        }
    }

    if (handle < 0) {
        if (error) {
            switch (handle) {
                case -1:
                    *error = @"worse_query could not access container. If using a free Apple ID, ensure developer mode is enabled.";
                    break;
                case -2:
                    *error = @"worse_query failed to resolve ContainerManager symbols (unsupported OS).";
                    break;
                case -3:
                    *error = @"worse_query failed to create container query.";
                    break;
                case -4:
                    *error = @"worse_query failed to create symlink in Caches.";
                    break;
                case -5:
                    *error = @"worse_query was rejected by containermanagerd. Please check signing entitlements.";
                    break;
                case -6:
                    *error = @"worse_query kernel refused sandbox extension issue.";
                    break;
                case -255:
                    *error = [NSString stringWithFormat:@"worse_query target does not exist: %@", path];
                    break;
                default:
                    *error = [NSString stringWithFormat:@"worse_query failed with error code %lld.", handle];
                    break;
            }
        }
        return nil;
    }

    WorseQueryLease *lease = [WorseQueryLease new];
    lease.targetPath = path;
    lease.appGroup = successfulGroup;
    lease.handle = handle;
    lease.active = YES;
    if (error) *error = nil;
    return lease;
}

- (void)invalidate
{
    if (!self.active) return;
    worse_query_release(self.handle);
    self.handle = -1;
    self.active = NO;
}

- (void)dealloc
{
    [self invalidate];
}

@end

BOOL WorseQueryBridgeAvailable(void)
{
    return worse_query_available();
}

WorseQueryLease *WQLeaseForPath(NSString *path, NSString **error)
{
    return [WorseQueryLease leaseForPath:path error:error];
}

WorseQueryLease *WQLeaseForPathWithGroup(NSString *path, NSString *appGroup, NSString **error)
{
    return [WorseQueryLease leaseForPath:path appGroup:appGroup error:error];
}

NSArray<NSString *> *WQListContainers(NSString *path, uint64_t max_inode)
{
    return pathleak(path, max_inode);
}
