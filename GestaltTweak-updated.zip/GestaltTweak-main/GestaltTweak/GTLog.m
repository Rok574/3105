//
//  GTLog.m
//  GestaltTweak
//

#import "GTLog.h"

void GTLog(NSString *format, ...) {
    va_list args;
    va_start(args, format);
    NSString *msg = [[NSString alloc] initWithFormat:format arguments:args];
    va_end(args);
    
    NSLog(@"[GestaltTweak] %@", msg);
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:@"GestaltTweakLogNotification"
                                                            object:nil
                                                          userInfo:@{@"message": msg}];
    });
}
