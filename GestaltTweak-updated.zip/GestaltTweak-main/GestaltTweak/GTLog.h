//
//  GTLog.h
//  GestaltTweak
//

#import <Foundation/Foundation.h>

#ifdef __cplusplus
extern "C" {
#endif

void GTLog(NSString *format, ...) NS_FORMAT_FUNCTION(1, 2);

#ifdef __cplusplus
}
#endif
