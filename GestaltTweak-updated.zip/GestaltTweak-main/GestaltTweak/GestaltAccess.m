//
//  GestaltAccess.m
//  GestaltTweak
//
//  bad_query / worse_query / cmg path traversal & sandbox escape (iOS 26 / 27)
//  Licensed under the MIT License.
//

#import "GestaltAccess.h"
#import "BadQueryBridge.h"
#import "WorseQueryBridge.h"
#import "GestaltTweak-Swift.h"

#import <errno.h>
#import <fcntl.h>
#import <sys/sysctl.h>
#import <unistd.h>

static NSString * const kGestaltPlistFileName = @"com.apple.MobileGestalt.plist";

static NSString * const kMobileGestaltCacheDirectory =
    @"/private/var/containers/Shared/SystemGroup/"
     "systemgroup.com.apple.mobilegestaltcache/Library/Caches";
static NSString * const kBadQueryMobileGestaltCacheDirectory =
    @"/var/containers/Shared/SystemGroup/"
     "systemgroup.com.apple.mobilegestaltcache/Library/Caches";

static NSError *GestaltError(NSInteger code, NSString *message)
{
    return [NSError errorWithDomain:@"com.gestalttweak.access"
                               code:code
                           userInfo:@{ NSLocalizedDescriptionKey: message }];
}

static BOOL GestaltCanOpenReadWrite(NSString *path)
{
    int fd = open(path.fileSystemRepresentation,
                  O_RDWR | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) return NO;
    close(fd);
    return YES;
}

static BOOL GestaltWriteAll(int fd, NSData *data)
{
    const uint8_t *bytes = data.bytes;
    NSUInteger remaining = data.length;
    while (remaining > 0) {
        ssize_t written = write(fd, bytes, remaining);
        if (written < 0 && errno == EINTR) continue;
        if (written <= 0) return NO;
        bytes += written;
        remaining -= (NSUInteger)written;
    }
    return YES;
}

/// Reads the whole file through the given descriptor, returning nil on error.
/// Used to verify an in-place write against the exact bytes we just wrote,
/// avoiding the race of reopening the path (the system may rewrite the cache
/// file between our write and a separate read).
static NSData *GestaltReadAll(int fd)
{
    NSMutableData *buffer = [NSMutableData data];
    uint8_t chunk[64 * 1024];
    while (1) {
        ssize_t count = read(fd, chunk, sizeof(chunk));
        if (count > 0) {
            [buffer appendBytes:chunk length:(NSUInteger)count];
            continue;
        }
        if (count == 0) return buffer;
        if (errno == EINTR) continue;
        return nil;
    }
}

@interface GestaltAccess ()
@property (nonatomic, assign) BOOL isConnected;
@property (nonatomic, copy) NSString *plistPath;
@property (nonatomic, assign) NSPropertyListFormat lastReadFormat;
@end

@implementation GestaltAccess
{
    BadQueryLease *_activeBadQueryLease;
    NSString *_lastMethod;
}

+ (instancetype)shared
{
    static GestaltAccess *shared;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ shared = [GestaltAccess new]; });
    return shared;
}

+ (NSString *)currentOSBuild
{
    size_t length = 0;
    if (sysctlbyname("kern.osversion", NULL, &length, NULL, 0) != 0 ||
        length == 0) {
        return @"";
    }

    NSMutableData *data = [NSMutableData dataWithLength:length];
    if (sysctlbyname("kern.osversion", data.mutableBytes, &length, NULL, 0) != 0)
        return @"";

    return [NSString stringWithUTF8String:data.bytes] ?: @"";
}

+ (BOOL)isRunningSupportedOS
{
    NSOperatingSystemVersion version = NSProcessInfo.processInfo.operatingSystemVersion;
    NSString *build = self.currentOSBuild;

    return version.majorVersion == 27 && (
        [build isEqualToString:@"24A5355q"] || // iOS / iPadOS 27 beta 1
        [build isEqualToString:@"24A5370h"] || // iOS / iPadOS 27 beta 2
        [build isEqualToString:@"24A5380h"] || // iOS / iPadOS 27 beta 3
        [build isEqualToString:@"24A5380i"] || // iPadOS 27 beta 3 v2
        [build isEqualToString:@"24A5380l"] || // iOS / iPadOS 27 Public Beta 1 (revised beta 3)
        [build isEqualToString:@"24A5390f"] || // iOS / iPadOS 27 beta 4
        [build isEqualToString:@"24A446"]   || // iOS 27.0.1 (released September 28, 2026)
        [build isEqualToString:@"24B119"]      // iOS 27.2
    );
}

/// The selected exploit method, read from UserDefaults ("bad_query", "worse_query", or "cmg").
+ (NSString *)currentMethod
{
    NSString *method = [[NSUserDefaults standardUserDefaults] stringForKey:@"method"];
    if (method.length > 0) return method;

    NSString *build = self.currentOSBuild;
    if ([build isEqualToString:@"24A446"] || [build isEqualToString:@"24B119"]) {
        return @"worse_query";
    }
    return @"bad_query";
}

#pragma mark - Connection

- (BOOL)connectWithError:(NSError **)error
{
    if (!GestaltAccess.isRunningSupportedOS) {
        if (error) *error = GestaltError(0,
            @"GestaltTweak supports iOS 27 beta 1–4, iOS 27.0.1 (24A446), and iOS 27.2 (24B119).");
        return NO;
    }

    NSString *method = GestaltAccess.currentMethod;
    NSString *build = GestaltAccess.currentOSBuild;

    if (([build isEqualToString:@"24A446"] || [build isEqualToString:@"24B119"]) &&
        ![method isEqualToString:@"worse_query"]) {
        if (error) *error = GestaltError(1,
            [NSString stringWithFormat:@"%@ does not work on iOS build %@. Please select 'worse_query' in Settings.", method, build]);
        return NO;
    }

    BOOL usesCmg = [method isEqualToString:@"cmg"];
    BOOL usesWorseQuery = [method isEqualToString:@"worse_query"];

    if (![_lastMethod isEqualToString:method]) {
        [_activeBadQueryLease invalidate];
        _activeBadQueryLease = nil;
        self.isConnected = NO;
        self.plistPath = nil;
        _lastMethod = [method copy];
    }

    if (self.isConnected) {
        if (error) *error = nil;
        return YES;
    }

    NSString *plistPath = [kMobileGestaltCacheDirectory
        stringByAppendingPathComponent:kGestaltPlistFileName];

    if (usesCmg) {
        if ([CmgExploit run] < 0) {
            if (error) *error = GestaltError(2,
                @"cmg exploit failed (unsupported build or the ContainerManager API is unavailable).");
            return NO;
        }
        if (!GestaltCanOpenReadWrite(plistPath)) {
            if (error) *error = GestaltError(3,
                @"cmg acquired a sandbox extension, but the MobileGestalt plist is not writable.");
            return NO;
        }

        self.plistPath = plistPath;
        self.isConnected = YES;
        if (error) *error = nil;
        return YES;
    }

    if (usesWorseQuery) {
        [_activeBadQueryLease invalidate];
        _activeBadQueryLease = nil;
        self.isConnected = NO;
        self.plistPath = nil;

        NSString *group = [[NSUserDefaults standardUserDefaults] stringForKey:@"worse_query_app_group"];
        if (group.length == 0) group = nil;

        // Try leasing the MobileGestalt directory or file via worse_query
        NSArray<NSString *> *targetCandidates = @[
            kBadQueryMobileGestaltCacheDirectory,
            kMobileGestaltCacheDirectory,
            [kBadQueryMobileGestaltCacheDirectory stringByAppendingPathComponent:kGestaltPlistFileName],
            [kMobileGestaltCacheDirectory stringByAppendingPathComponent:kGestaltPlistFileName]
        ];

        BadQueryLease *lease = nil;
        NSString *leaseError = nil;

        for (NSString *target in targetCandidates) {
            NSString *err = nil;
            lease = [BadQueryLease leaseForPathUsingWorseQuery:target appGroup:group error:&err];
            if (lease) {
                if (GestaltCanOpenReadWrite(plistPath)) {
                    self.plistPath = plistPath;
                    break;
                }
                NSString *altPath = [kBadQueryMobileGestaltCacheDirectory stringByAppendingPathComponent:kGestaltPlistFileName];
                if (GestaltCanOpenReadWrite(altPath)) {
                    self.plistPath = altPath;
                    break;
                }
                [lease invalidate];
                lease = nil;
            }
            if (!leaseError && err) leaseError = err;
        }

        if (!lease || self.plistPath.length == 0) {
            [lease invalidate];
            if (error) *error = GestaltError(2,
                leaseError ?: @"worse_query acquired a sandbox extension, but the MobileGestalt plist is not writable.");
            return NO;
        }

        _activeBadQueryLease = lease;
        self.isConnected = YES;
        if (error) *error = nil;
        return YES;
    }

    // Default to bad_query
    if (!BadQueryBridgeAvailable()) {
        if (error) *error = GestaltError(1,
            @"bad_query is unavailable (required ContainerManager or sandbox extension APIs are missing).");
        return NO;
    }

    [_activeBadQueryLease invalidate];
    _activeBadQueryLease = nil;
    self.isConnected = NO;
    self.plistPath = nil;

    NSString *badQueryTarget = [kBadQueryMobileGestaltCacheDirectory
        stringByAppendingPathComponent:kGestaltPlistFileName];
    NSString *badQueryDetail = nil;
    BadQueryLease *badQueryLease = [BadQueryLease leaseForPath:badQueryTarget
                                                        error:&badQueryDetail];
    if (!badQueryLease) {
        if (error) *error = GestaltError(2,
            badQueryDetail ?: @"bad_query failed.");
        return NO;
    }
    if (!GestaltCanOpenReadWrite(plistPath)) {
        [badQueryLease invalidate];
        if (error) *error = GestaltError(3,
            @"bad_query acquired a sandbox extension, but the MobileGestalt plist is not writable.");
        return NO;
    }

    _activeBadQueryLease = badQueryLease;
    self.isConnected = YES;
    self.plistPath = plistPath;
    if (error) *error = nil;
    return YES;
}

#pragma mark - Read / Write

- (NSData *)readGestaltDataWithError:(NSError **)error
{
    if (![self connectWithError:error]) return nil;
    if (![[NSFileManager defaultManager] fileExistsAtPath:self.plistPath]) {
        if (error) *error = GestaltError(3,
            [NSString stringWithFormat:@"The plist does not exist: %@", self.plistPath]);
        return nil;
    }

    NSError *readError = nil;
    NSData *data = [NSData dataWithContentsOfFile:self.plistPath
                                          options:NSDataReadingMappedIfSafe
                                            error:&readError];
    if (!data) {
        if (error) *error = readError ?: GestaltError(4, @"Failed to read the plist.");
        return nil;
    }
    if (error) *error = nil;
    return data;
}

- (NSDictionary *)readGestaltWithError:(NSError **)error
{
    NSData *data = [self readGestaltDataWithError:error];
    if (!data) return nil;

    NSPropertyListFormat format = NSPropertyListBinaryFormat_v1_0;
    NSError *parseError = nil;
    id plist = [NSPropertyListSerialization propertyListWithData:data
                                                         options:0
                                                          format:&format
                                                           error:&parseError];
    if (![plist isKindOfClass:NSDictionary.class]) {
        if (error) *error = parseError ?: GestaltError(5,
            @"The plist top level is not a dictionary.");
        return nil;
    }
    self.lastReadFormat = format;
    return plist;
}

- (BOOL)saveGestalt:(NSDictionary *)plist error:(NSError **)error
{
    if (![self connectWithError:error]) return NO;
    if (![plist isKindOfClass:NSDictionary.class]) {
        if (error) *error = GestaltError(6, @"The content to save is not a dictionary.");
        return NO;
    }

    NSPropertyListFormat format = self.lastReadFormat;
    if (format != NSPropertyListXMLFormat_v1_0 &&
        format != NSPropertyListBinaryFormat_v1_0)
        format = NSPropertyListBinaryFormat_v1_0;

    NSError *serializeError = nil;
    NSData *data = [NSPropertyListSerialization dataWithPropertyList:plist
                                                              format:format
                                                             options:0
                                                               error:&serializeError];
    if (!data) {
        if (error) *error = serializeError ?: GestaltError(7, @"Failed to serialize the plist.");
        return NO;
    }

    NSString *targetPath = self.plistPath;
    NSError *readError = nil;
    NSData *original = [NSData dataWithContentsOfFile:targetPath
                                              options:0
                                                error:&readError];
    if (!original) {
        if (error) *error = readError ?: GestaltError(8, @"Failed to read the original plist.");
        return NO;
    }

    // Retry once with a freshly re-acquired sandbox extension: the OS may have
    // revoked the lease while the app was backgrounded, which makes the first
    // open fail even though the tweak was never applied.
    for (int attempt = 0; ; attempt++) {
        NSError *writeError = nil;
        BOOL ok = [self writeData:data
                     overOriginal:original
                           atPath:targetPath
                            error:&writeError];
        if (ok) {
            if (error) *error = nil;
            return YES;
        }
        if (attempt >= 1 || ![self refreshSandboxExtensionWithError:&writeError]) {
            if (error) *error = writeError;
            return NO;
        }
    }
}

/// The in-place write itself, including rollback and verification. The file
/// is rewritten on the same inode: atomic file replacement would swap the
/// inode, which SpringBoard ignores because it tracks the original one, and
/// creating a temp file in the shared SystemGroup directory is not covered by
/// the bad_query lease.
- (BOOL)writeData:(NSData *)data
     overOriginal:(NSData *)original
           atPath:(NSString *)targetPath
            error:(NSError **)error
{
    int fd = open(targetPath.fileSystemRepresentation,
                  O_RDWR | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) {
        if (error) *error = GestaltError(9,
            [NSString stringWithFormat:@"Failed to open the plist (errno=%d).", errno]);
        return NO;
    }

    BOOL wrote = ftruncate(fd, 0) == 0 &&
        lseek(fd, 0, SEEK_SET) == 0 &&
        GestaltWriteAll(fd, data) &&
        fsync(fd) == 0;
    int writeErrno = errno;

    BOOL verified = NO;
    if (wrote && lseek(fd, 0, SEEK_SET) >= 0) {
        NSData *readback = GestaltReadAll(fd);
        verified = readback != nil && [readback isEqualToData:data];
    }

    if (!wrote || !verified) {
        ftruncate(fd, 0);
        lseek(fd, 0, SEEK_SET);
        GestaltWriteAll(fd, original);
        fsync(fd);
        close(fd);
        if (error) *error = GestaltError(verified ? 10 : 11,
            verified
                ? [NSString stringWithFormat:@"Failed to write the plist (errno=%d).", writeErrno]
                : @"Post-write verification failed.");
        return NO;
    }
    close(fd);

    if (error) *error = nil;
    return YES;
}

/// Drops the current sandbox extension and connection state, then re-runs the
/// exploit so the next write starts with a fresh lease.
- (BOOL)refreshSandboxExtensionWithError:(NSError **)error
{
    [_activeBadQueryLease invalidate];
    _activeBadQueryLease = nil;
    self.isConnected = NO;
    self.plistPath = nil;
    return [self connectWithError:error];
}

@end