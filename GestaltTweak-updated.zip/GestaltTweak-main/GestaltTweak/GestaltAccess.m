//
//  GestaltAccess.m
//  GestaltTweak
//
//  bad_query / worse_query / cmg path traversal & sandbox escape (iOS 26 / 27)
//  Licensed under the MIT License.
//

#import "GestaltAccess.h"
#import "BadQueryBridge.h"
#import "WorseQueryBridge.h"
#import "GXEntitlementsReader.h"
#import "GTLog.h"
#import "GestaltTweak-Swift.h"

#import <dlfcn.h>
#import <errno.h>
#import <fcntl.h>
#import <sys/sysctl.h>
#import <unistd.h>
#import <xpc/xpc.h>

static NSString * const kGestaltPlistFileName = @"com.apple.MobileGestalt.plist";

static NSString * const kMobileGestaltCacheDirectory =
    @"/private/var/containers/Shared/SystemGroup/"
     "systemgroup.com.apple.mobilegestaltcache/Library/Caches";
static NSString * const kBadQueryMobileGestaltCacheDirectory =
    @"/var/containers/Shared/SystemGroup/"
     "systemgroup.com.apple.mobilegestaltcache/Library/Caches";

static NSError *GestaltError(NSInteger code, NSString *message)
{
    GTLog(@"[GestaltAccess] Error %ld: %@", (long)code, message);
    return [NSError errorWithDomain:@"com.gestalttweak.access"
                               code:code
                           userInfo:@{ NSLocalizedDescriptionKey: message }];
}

static BOOL GestaltCanOpenReadWrite(NSString *path)
{
    int fd = open(path.fileSystemRepresentation,
                  O_RDWR | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) return NO;
    close(fd);
    return YES;
}

static BOOL GestaltWriteAll(int fd, NSData *data)
{
    const uint8_t *bytes = data.bytes;
    NSUInteger remaining = data.length;
    while (remaining > 0) {
        ssize_t written = write(fd, bytes, remaining);
        if (written < 0 && errno == EINTR) continue;
        if (written <= 0) return NO;
        bytes += written;
        remaining -= (NSUInteger)written;
    }
    return YES;
}

/// Reads the whole file through the given descriptor, returning nil on error.
static NSData *GestaltReadAll(int fd)
{
    NSMutableData *buffer = [NSMutableData data];
    uint8_t chunk[64 * 1024];
    while (1) {
        ssize_t count = read(fd, chunk, sizeof(chunk));
        if (count > 0) {
            [buffer appendBytes:chunk length:(NSUInteger)count];
            continue;
        }
        if (count == 0) return buffer;
        if (errno == EINTR) continue;
        return nil;
    }
}

@interface GestaltAccess ()
@property (nonatomic, assign) BOOL isConnected;
@property (nonatomic, copy) NSString *plistPath;
@property (nonatomic, assign) NSPropertyListFormat lastReadFormat;
@end

@implementation GestaltAccess
{
    BadQueryLease *_activeBadQueryLease;
    NSString *_lastMethod;
}

+ (instancetype)shared
{
    static GestaltAccess *shared;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ shared = [GestaltAccess new]; });
    return shared;
}

+ (NSString *)currentOSBuild
{
    size_t length = 0;
    if (sysctlbyname("kern.osversion", NULL, &length, NULL, 0) != 0 ||
        length == 0) {
        return @"";
    }

    NSMutableData *data = [NSMutableData dataWithLength:length];
    if (sysctlbyname("kern.osversion", data.mutableBytes, &length, NULL, 0) != 0)
        return @"";

    return [NSString stringWithUTF8String:data.bytes] ?: @"";
}

+ (BOOL)isRunningSupportedOS
{
    NSOperatingSystemVersion version = NSProcessInfo.processInfo.operatingSystemVersion;
    return version.majorVersion >= 26;
}

/// The selected exploit method, read from UserDefaults ("bad_query", "worse_query", or "cmg").
+ (NSString *)currentMethod
{
    NSString *method = [[NSUserDefaults standardUserDefaults] stringForKey:@"method"];
    if (method.length > 0) return method;

    NSOperatingSystemVersion version = NSProcessInfo.processInfo.operatingSystemVersion;
    if (version.majorVersion >= 27) {
        return @"worse_query";
    }
    return @"bad_query";
}

#pragma mark - Connection

- (BOOL)connectWithError:(NSError **)error
{
    if (!GestaltAccess.isRunningSupportedOS) {
        if (error) *error = GestaltError(0,
            @"GestaltTweak requires iOS 26.0 or higher.");
        return NO;
    }

    NSString *method = GestaltAccess.currentMethod;
    NSOperatingSystemVersion osVer = NSProcessInfo.processInfo.operatingSystemVersion;
    GTLog(@"[GestaltAccess] Connect requested (OS: %ld.%ld.%ld, build: %@, engine: %@)",
          (long)osVer.majorVersion, (long)osVer.minorVersion, (long)osVer.patchVersion,
          GestaltAccess.currentOSBuild, method);

    if (osVer.majorVersion >= 27 && [method isEqualToString:@"bad_query"]) {
        GTLog(@"[GestaltAccess] bad_query is patched on iOS 27+; switching to worse_query");
        method = @"worse_query";
    }

    BOOL usesCmg = [method isEqualToString:@"cmg"];
    BOOL usesWorseQuery = [method isEqualToString:@"worse_query"];

    if (![_lastMethod isEqualToString:method]) {
        [_activeBadQueryLease invalidate];
        _activeBadQueryLease = nil;
        self.isConnected = NO;
        self.plistPath = nil;
        _lastMethod = [method copy];
    }

    if (self.isConnected && self.plistPath.length > 0 && GestaltCanOpenReadWrite(self.plistPath)) {
        GTLog(@"[GestaltAccess] Reusing active sandbox lease at %@", self.plistPath);
        if (error) *error = nil;
        return YES;
    }

    NSString *plistPath = [kMobileGestaltCacheDirectory
        stringByAppendingPathComponent:kGestaltPlistFileName];

    if (usesCmg) {
        GTLog(@"[GestaltAccess] Executing CMG exploit...");
        if ([CmgExploit run] < 0) {
            if (error) *error = GestaltError(2,
                @"cmg exploit failed (unsupported build or the ContainerManager API is unavailable).");
            return NO;
        }
        if (!GestaltCanOpenReadWrite(plistPath)) {
            if (error) *error = GestaltError(3,
                @"cmg acquired a sandbox extension, but the MobileGestalt plist is not writable.");
            return NO;
        }

        self.plistPath = plistPath;
        self.isConnected = YES;
        GTLog(@"[GestaltAccess] CMG connected successfully at %@", plistPath);
        if (error) *error = nil;
        return YES;
    }

    if (usesWorseQuery) {
        [_activeBadQueryLease invalidate];
        _activeBadQueryLease = nil;
        self.isConnected = NO;
        self.plistPath = nil;

        NSString *group = [[NSUserDefaults standardUserDefaults] stringForKey:@"worse_query_app_group"];
        if (group.length == 0 || [group containsString:@"No App Group"] || [group containsString:@"Self App"]) {
            group = [GXEntitlementsReader usableAppGroup];
        }
        GTLog(@"[GestaltAccess] Using App Group for worse_query: %@", group);

        NSArray<NSString *> *targetCandidates = @[
            [kMobileGestaltCacheDirectory stringByAppendingPathComponent:kGestaltPlistFileName],
            [kBadQueryMobileGestaltCacheDirectory stringByAppendingPathComponent:kGestaltPlistFileName],
            kMobileGestaltCacheDirectory,
            kBadQueryMobileGestaltCacheDirectory
        ];

        BadQueryLease *lease = nil;
        NSString *leaseError = nil;

        for (NSString *target in targetCandidates) {
            NSString *err = nil;
            GTLog(@"[GestaltAccess] Trying worse_query target: %@", target);
            lease = [BadQueryLease leaseForPathUsingWorseQuery:target appGroup:group error:&err];
            if (lease) {
                NSArray<NSString *> *testPlistPaths = @[
                    [kMobileGestaltCacheDirectory stringByAppendingPathComponent:kGestaltPlistFileName],
                    [kBadQueryMobileGestaltCacheDirectory stringByAppendingPathComponent:kGestaltPlistFileName]
                ];

                for (NSString *testPath in testPlistPaths) {
                    if (GestaltCanOpenReadWrite(testPath)) {
                        self.plistPath = testPath;
                        GTLog(@"[GestaltAccess] Verified read/write access to %@", testPath);
                        break;
                    }
                }

                if (self.plistPath.length > 0) {
                    break;
                }

                [lease invalidate];
                lease = nil;
            }
            if (!leaseError && err) leaseError = err;
        }

        if (!lease || self.plistPath.length == 0) {
            [lease invalidate];
            if (error) *error = GestaltError(2,
                leaseError ?: @"worse_query could not gain read/write access to MobileGestalt. Please verify App Group signing or LiveContainer host group.");
            return NO;
        }

        _activeBadQueryLease = lease;
        self.isConnected = YES;
        GTLog(@"[GestaltAccess] worse_query connected successfully! MobileGestalt is mounted.");
        if (error) *error = nil;
        return YES;
    }

    // Default to bad_query
    if (!BadQueryBridgeAvailable()) {
        if (error) *error = GestaltError(1,
            @"bad_query is unavailable (required ContainerManager or sandbox extension APIs are missing).");
        return NO;
    }

    [_activeBadQueryLease invalidate];
    _activeBadQueryLease = nil;
    self.isConnected = NO;
    self.plistPath = nil;

    NSString *badQueryTarget = [kBadQueryMobileGestaltCacheDirectory
        stringByAppendingPathComponent:kGestaltPlistFileName];
    NSString *badQueryDetail = nil;
    GTLog(@"[GestaltAccess] Trying bad_query target: %@", badQueryTarget);
    BadQueryLease *badQueryLease = [BadQueryLease leaseForPath:badQueryTarget
                                                        error:&badQueryDetail];
    if (!badQueryLease) {
        if (error) *error = GestaltError(2,
            badQueryDetail ?: @"bad_query failed.");
        return NO;
    }
    if (!GestaltCanOpenReadWrite(plistPath)) {
        [badQueryLease invalidate];
        if (error) *error = GestaltError(3,
            @"bad_query acquired a sandbox extension, but the MobileGestalt plist is not writable.");
        return NO;
    }

    _activeBadQueryLease = badQueryLease;
    self.isConnected = YES;
    self.plistPath = plistPath;
    GTLog(@"[GestaltAccess] bad_query connected successfully!");
    if (error) *error = nil;
    return YES;
}

#pragma mark - Read / Write

- (NSData *)readGestaltDataWithError:(NSError **)error
{
    if (![self connectWithError:error]) return nil;
    if (![[NSFileManager defaultManager] fileExistsAtPath:self.plistPath]) {
        if (error) *error = GestaltError(3,
            [NSString stringWithFormat:@"The plist does not exist: %@", self.plistPath]);
        return nil;
    }

    int fd = open(self.plistPath.fileSystemRepresentation,
                  O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) {
        if (error) *error = GestaltError(errno,
            [NSString stringWithFormat:@"Failed to open plist for reading: %s",
             strerror(errno)]);
        return nil;
    }

    NSData *data = GestaltReadAll(fd);
    close(fd);

    if (!data) {
        if (error) *error = GestaltError(EIO, @"Failed to read plist contents.");
        return nil;
    }
    GTLog(@"[GestaltAccess] Read %lu bytes from %@", (unsigned long)data.length, self.plistPath);
    return data;
}

- (NSDictionary<NSString *, id> *)readGestaltDictionaryWithError:(NSError **)error
{
    NSData *data = [self readGestaltDataWithError:error];
    if (!data) return nil;

    NSPropertyListFormat format = 0;
    NSError *plistError = nil;
    id obj = [NSPropertyListSerialization propertyListWithData:data
                                                       options:NSPropertyListMutableContainersAndLeaves
                                                        format:&format
                                                         error:&plistError];
    if (![obj isKindOfClass:[NSDictionary class]]) {
        if (error) *error = GestaltError(4,
            plistError.localizedDescription ?: @"The MobileGestalt plist is malformed.");
        return nil;
    }

    self.lastReadFormat = format;
    NSDictionary<NSString *, id> *dict = (NSDictionary<NSString *, id> *)obj;
    GTLog(@"[GestaltAccess] Parsed MobileGestalt dictionary (%lu root keys)", (unsigned long)dict.count);
    return dict;
}

- (BOOL)writeGestaltData:(NSData *)data error:(NSError **)error
{
    if (data.length == 0) {
        if (error) *error = GestaltError(EINVAL, @"Refusing to write empty data.");
        return NO;
    }
    if (![self connectWithError:error]) return NO;

    int fd = open(self.plistPath.fileSystemRepresentation,
                  O_WRONLY | O_TRUNC | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) {
        if (error) *error = GestaltError(errno,
            [NSString stringWithFormat:@"Failed to open plist for writing: %s",
             strerror(errno)]);
        return NO;
    }

    BOOL ok = GestaltWriteAll(fd, data);
    if (ok) {
        fsync(fd);
    }
    close(fd);

    if (!ok && error) {
        *error = GestaltError(errno,
            [NSString stringWithFormat:@"Failed to write all bytes: %s", strerror(errno)]);
    } else {
        GTLog(@"[GestaltAccess] Successfully wrote %lu bytes to MobileGestalt (fsync OK)", (unsigned long)data.length);
    }
    return ok;
}

- (BOOL)writeGestaltDictionary:(NSDictionary<NSString *, id> *)dictionary
                         error:(NSError **)error
{
    NSPropertyListFormat format = self.lastReadFormat ?: NSPropertyListBinaryFormat_v1_0;
    NSError *serializeError = nil;
    NSData *data = [NSPropertyListSerialization dataWithPropertyList:dictionary
                                                              format:format
                                                             options:0
                                                               error:&serializeError];
    if (!data) {
        if (error) *error = GestaltError(5,
            serializeError.localizedDescription ?: @"Failed to serialize MobileGestalt plist.");
        return NO;
    }

    return [self writeGestaltData:data error:error];
}

- (void)disconnect
{
    GTLog(@"[GestaltAccess] Disconnecting active lease");
    [_activeBadQueryLease invalidate];
    _activeBadQueryLease = nil;
    self.isConnected = NO;
    self.plistPath = nil;
}

@end