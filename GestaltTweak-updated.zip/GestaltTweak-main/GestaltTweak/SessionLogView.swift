//
//  SessionLogView.swift
//  GestaltTweak
//

import SwiftUI

struct SessionLogView: View {
    @ObservedObject private var logger = AppLogger.shared
    @Environment(\.dismiss) private var dismiss

    @State private var filterText = ""
    @State private var hasCopied = false
    @State private var autoScroll = true

    var filteredEntries: [LogEntry] {
        if filterText.isEmpty {
            return logger.entries
        }
        return logger.entries.filter { $0.message.localizedCaseInsensitiveContains(filterText) }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Search filter bar
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(.secondary)
                    TextField("Filter logs...", text: $filterText)
                        .font(.system(.subheadline, design: .monospaced))
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                    if !filterText.isEmpty {
                        Button {
                            filterText = ""
                        } label: {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(Color(.secondarySystemBackground))

                Divider()

                // Console output
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 4) {
                            if filteredEntries.isEmpty {
                                Text("No logs recorded yet.")
                                    .font(.system(.caption, design: .monospaced))
                                    .foregroundStyle(.secondary)
                                    .padding()
                            } else {
                                ForEach(filteredEntries) { entry in
                                    logRow(for: entry)
                                        .id(entry.id)
                                }
                            }
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                    }
                    .background(Color(red: 0.08, green: 0.08, blue: 0.10))
                    .onChange(of: logger.entries.count) { _ in
                        if autoScroll, let last = filteredEntries.last {
                            withAnimation(.easeOut(duration: 0.15)) {
                                proxy.scrollTo(last.id, anchor: .bottom)
                            }
                        }
                    }
                }
            }
            .navigationTitle("Console Logs")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done") {
                        dismiss()
                    }
                }

                ToolbarItemGroup(placement: .primaryAction) {
                    Button {
                        UIPasteboard.general.string = logger.plainText
                        hasCopied = true
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            hasCopied = false
                        }
                    } label: {
                        Label(hasCopied ? "Copied" : "Copy", systemImage: hasCopied ? "checkmark" : "doc.on.doc")
                    }

                    ShareLink(item: logger.plainText) {
                        Label("Share", systemImage: "square.and.arrow.up")
                    }

                    Button(role: .destructive) {
                        logger.clear()
                    } label: {
                        Label("Clear", systemImage: "trash")
                    }
                }
            }
        }
    }

    private func logRow(for entry: LogEntry) -> some View {
        HStack(alignment: .top, spacing: 6) {
            Text(entry.formattedTime)
                .font(.system(size: 11, weight: .regular, design: .monospaced))
                .foregroundStyle(.gray)

            Text("[\(entry.level.rawValue)]")
                .font(.system(size: 11, weight: .bold, design: .monospaced))
                .foregroundStyle(color(for: entry.level))

            Text(entry.message)
                .font(.system(size: 11, weight: .regular, design: .monospaced))
                .foregroundStyle(.white)
                .textSelection(.enabled)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func color(for level: LogEntry.LogLevel) -> Color {
        switch level {
        case .info:
            return .cyan
        case .success:
            return .green
        case .warning:
            return .orange
        case .error:
            return .red
        }
    }
}
