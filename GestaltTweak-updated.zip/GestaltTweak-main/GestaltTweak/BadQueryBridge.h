//
//  BadQueryBridge.h
//  GestaltTweak
//
//  Path-based ContainerManager query derived from forcequitOS/bad_query.
//  https://github.com/forcequitOS/bad_query
//
//  Licensed under the MIT License. Portions derived from frs0n/GestaltEdit.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BadQueryLease : NSObject

@property(nonatomic, copy, readonly) NSString *targetPath;
@property(nonatomic, readonly, getter=isActive) BOOL active;

+ (nullable instancetype)leaseForPath:(NSString *)path
                                error:(NSString * _Nullable * _Nullable)error;

+ (nullable instancetype)leaseForPathUsingWorseQuery:(NSString *)path
                                            appGroup:(nullable NSString *)appGroup
                                               error:(NSString * _Nullable * _Nullable)error;

- (void)invalidate;

@end

FOUNDATION_EXPORT BOOL BadQueryBridgeAvailable(void);

FOUNDATION_EXPORT BadQueryLease * _Nullable GTLeaseForPath(NSString *path,
                                                           NSString * _Nullable * _Nullable error);

FOUNDATION_EXPORT NSArray<NSString *> * _Nullable GTListContainers(NSString *path,
                                                                   int64_t max_inode);

FOUNDATION_EXPORT BOOL GTLaunchApplication(NSString *bundleID);

NS_ASSUME_NONNULL_END