//
//  AppLogger.swift
//  GestaltTweak
//

import Foundation
import Combine
import SwiftUI

public struct LogEntry: Identifiable, Equatable {
    public let id = UUID()
    public let timestamp: Date
    public let message: String
    public let level: LogLevel

    public enum LogLevel: String {
        case info = "INFO"
        case success = "SUCCESS"
        case warning = "WARN"
        case error = "ERROR"
    }

    public var formattedTime: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss.SSS"
        return formatter.string(from: timestamp)
    }
}

public final class AppLogger: ObservableObject {
    public static let shared = AppLogger()

    @Published public private(set) var entries: [LogEntry] = []

    private init() {
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("GestaltTweakLogNotification"),
            object: nil,
            queue: .main
        ) { [weak self] notification in
            if let msg = notification.userInfo?["message"] as? String {
                var level = LogEntry.LogLevel.info
                let lower = msg.lowercased()
                if lower.contains("error") || lower.contains("fail") || lower.contains("rejected") {
                    level = .error
                } else if lower.contains("success") || lower.contains("ok") || lower.contains("mounted") || lower.contains("selected accessible") {
                    level = .success
                } else if lower.contains("warn") || lower.contains("retry") {
                    level = .warning
                }
                self?.log(msg, level: level)
            }
        }

        log("[GestaltTweak] Session started on iOS \(ProcessInfo.processInfo.operatingSystemVersionString)", level: .info)
        log("[Device] OS Build \(GestaltAccess.currentOSBuild())", level: .info)
        let group = WorseQueryLease.autoDetectAppGroup()
        log("[AppGroup] Auto-detected: \(group)", level: .info)
    }

    public func log(_ message: String, level: LogEntry.LogLevel = .info) {
        let entry = LogEntry(timestamp: Date(), message: message, level: level)
        DispatchQueue.main.async {
            self.entries.append(entry)
            if self.entries.count > 1500 {
                self.entries.removeFirst(200)
            }
        }
    }

    public func clear() {
        entries.removeAll()
        log("[Log] Cleared console buffer", level: .info)
    }

    public var plainText: String {
        entries.map { "[\($0.formattedTime)] [\($0.level.rawValue)] \($0.message)" }.joined(separator: "\n")
    }
}
