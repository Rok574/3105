import WidgetKit
import SwiftUI

struct Provider: TimelineProvider {
    func placeholder(in context: Context) -> SimpleEntry {
        SimpleEntry(date: Date())
    }

    func getSnapshot(in context: Context, completion: @escaping (SimpleEntry) -> Void) {
        completion(SimpleEntry(date: Date()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<SimpleEntry>) -> Void) {
        let timeline = Timeline(entries: [SimpleEntry(date: Date())], policy: .never)
        completion(timeline)
    }
}

struct SimpleEntry: TimelineEntry {
    let date: Date
}

struct GestaltTweakWidgetEntryView: View {
    var entry: Provider.Entry

    var body: some View {
        VStack {
            Text("GestaltTweak")
                .font(.headline)
            Text("Helper")
                .font(.caption)
        }
        .containerBackground(.fill.tertiary, for: .widget)
    }
}

@main
struct GestaltTweakWidget: Widget {
    let kind: String = "GestaltTweakWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            GestaltTweakWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("GestaltTweak Widget")
        .description("Extension helper for GestaltTweak.")
        .supportedFamilies([.systemSmall])
    }
}
