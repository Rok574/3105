import WebKit
import Network

/// Listens on ws://127.0.0.1:8765 and relays each WebSocket to a raw TCP connection to the game server.
/// The page tells us the target (from the flashvars) via webkit.messageHandlers.bridge.postMessage({host, port, tls}).
final class SocketBridge: NSObject, WKScriptMessageHandlerWithReply {
    static let shared = SocketBridge()
    private let localPort: UInt16 = 8765
    private let q = DispatchQueue(label: "aj.bridge")
    private var listener: NWListener?
    private var host = ""
    private var port: UInt16 = 443
    private var tls = false

    func userContentController(_ c: WKUserContentController, didReceive m: WKScriptMessage,
                               replyHandler: @escaping (Any?, String?) -> Void) {
        guard let d = m.body as? [String: Any], let h = d["host"] as? String, let p = d["port"] as? Int,
              h.hasSuffix("animaljam.com"), (1...65535).contains(p) else {
            return replyHandler(nil, "bad target")
        }
        host = h; port = UInt16(p); tls = (d["tls"] as? Bool) ?? false
        do { try startIfNeeded(); replyHandler(Int(localPort), nil) }
        catch { replyHandler(nil, "listen failed: \(error)") }
    }

    private func startIfNeeded() throws {
        guard listener == nil else { return }
        let params = NWParameters.tcp
        let ws = NWProtocolWebSocket.Options()
        ws.autoReplyPing = true
        params.defaultProtocolStack.applicationProtocols.insert(ws, at: 0)
        params.requiredInterfaceType = .loopback
        let l = try NWListener(using: params, on: NWEndpoint.Port(rawValue: localPort)!)
        l.newConnectionHandler = { [weak self] conn in self?.relay(conn) }
        l.start(queue: q)
        listener = l
    }

    private func relay(_ ws: NWConnection) {
        let tcp = NWConnection(host: NWEndpoint.Host(host), port: NWEndpoint.Port(rawValue: port)!,
                               using: tls ? .tls : .tcp)
        ws.start(queue: q)
        tcp.start(queue: q)

        func closeBoth() { ws.cancel(); tcp.cancel() }

        func readWS() {
            ws.receiveMessage { data, ctx, _, err in
                if let data, !data.isEmpty { tcp.send(content: data, completion: .contentProcessed { _ in }) }
                let md = ctx?.protocolMetadata(definition: NWProtocolWebSocket.definition) as? NWProtocolWebSocket.Metadata
                if err != nil || md?.opcode == .close { return closeBoth() }
                readWS()
            }
        }

        func readTCP() {
            tcp.receive(minimumIncompleteLength: 1, maximumLength: 65536) { data, _, done, err in
                if let data, !data.isEmpty {
                    let md = NWProtocolWebSocket.Metadata(opcode: .binary)
                    let c = NWConnection.ContentContext(identifier: "bin", metadata: [md])
                    ws.send(content: data, contentContext: c, isComplete: true, completion: .contentProcessed { _ in })
                }
                if done || err != nil { return closeBoth() }
                readTCP()
            }
        }

        readWS()
        readTCP()
    }
}
