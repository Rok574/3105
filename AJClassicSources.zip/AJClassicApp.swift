import SwiftUI
import WebKit

@main
struct AJClassicApp: App {
    var body: some Scene {
        WindowGroup {
            GameView().ignoresSafeArea()
        }
    }
}

struct GameView: UIViewRepresentable {
    func makeUIView(context: Context) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        // aj://app/p/<host>/<path> is fetched natively by the app, so there is no CORS and no Worker.
        cfg.setURLSchemeHandler(ProxyHandler(), forURLScheme: "aj")
        // The page asks the app to open the local WebSocket -> TCP bridge for the game server.
        cfg.userContentController.addScriptMessageHandler(SocketBridge.shared, contentWorld: .page, name: "bridge")
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []

        let web = WKWebView(frame: .zero, configuration: cfg)
        web.isOpaque = false
        web.backgroundColor = .black
        web.scrollView.isScrollEnabled = false
        if #available(iOS 16.4, *) { web.isInspectable = true } // Safari Web Inspector from a Mac
        web.loadHTMLString(Page.html, baseURL: URL(string: "aj://app/"))
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
