enum Page {
    static let html = #"""
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<style>
  html,body{margin:0;height:100%;background:#000;color:#eee;font-family:-apple-system,system-ui,sans-serif}
  body{display:flex;flex-direction:column;box-sizing:border-box;padding:env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left)}
  #bar{display:flex;gap:8px;align-items:center;padding:8px;font-size:13px}
  #status{flex:1;opacity:.85}
  button{background:#2a6;border:0;color:#fff;padding:8px 12px;border-radius:8px;font-size:14px}
  label{font-size:12px;opacity:.8}
  #log{margin:0;padding:4px 8px;font-size:11px;max-height:22vh;overflow:auto;white-space:pre-wrap;color:#e9a;background:#181818}
  #log:empty{display:none}
  #stage{flex:1;min-height:0}
  ruffle-player{width:100%;height:100%;display:block}
</style>
</head>
<body>
<div id="bar">
  <span id="status">Tap Start.</span>
  <label><input id="tls" type="checkbox"> TLS socket</label>
  <button id="start">Start</button>
</div>
<pre id="log"></pre>
<div id="stage"></div>

<script src="https://cdn.jsdelivr.net/npm/@ruffle-rs/ruffle"></script>
<script>
const $ = id => document.getElementById(id);
const status = t => $('status').textContent = t;
const str = x => { try { return typeof x === 'string' ? x : (x && x.message) || JSON.stringify(x); } catch { return String(x); } };
const addLog = (...a) => { const l = $('log'); l.textContent += a.map(str).join(' ').slice(0, 300) + '\n'; l.scrollTop = l.scrollHeight; };
['warn', 'error'].forEach(k => { const o = console[k]; console[k] = (...a) => { addLog(k.toUpperCase() + ':', ...a); o.apply(console, a); }; });
window.addEventListener('error', e => addLog('JS error:', e.message));
window.addEventListener('unhandledrejection', e => addLog('Rejected:', e.reason));
const _fetch = window.fetch.bind(window);
window.fetch = async (...a) => {
  const u = String((a[0] && a[0].url) || a[0]).slice(-90);
  try { const r = await _fetch(...a); if (!r.ok) addLog('HTTP', r.status, u); return r; }
  catch (e) { addLog('FETCH FAIL', u, e.message); throw e; }
};

const HOSTS = ['animaljam.com', 'authenticator.animaljam.com', 'ajcontent.akamaized.net', 'classic-download.animaljam.com'];
const P = 'aj://app/p/';
const toApp = u => u.replace(/^https?:\/\/([^\/]+)\/?/, (m, h) => HOSTS.includes(h) ? P + h + '/' : m);
let player;

$('start').onclick = async () => {
  try {
    status('Fetching game config…');
    const fv = await (await _fetch(P + 'animaljam.com/flashvars')).json();

    status('Opening socket bridge…');
    const localPort = await window.webkit.messageHandlers.bridge.postMessage({
      host: fv.smartfoxServer, port: Number(fv.smartfoxPort), tls: $('tls').checked,
    });

    let client = String(fv.clientURL || '');
    if (client.startsWith('//')) client = 'https:' + client;
    const swf = toApp(client);

    const options = {
      url: swf,
      base: swf.split('?')[0].replace(/[^\/]*$/, ''),
      parameters: Object.fromEntries(Object.entries(fv).map(([k, v]) => [k, String(v)])),
      urlRewriteRules: HOSTS.map(h => ['^https?://' + h.replace(/\./g, '\\.') + '/(.*)$', P + h + '/$1']),
      socketProxy: [{ host: fv.smartfoxServer, port: Number(fv.smartfoxPort), proxyUrl: 'ws://127.0.0.1:' + localPort }],
      letterbox: 'on', unmuteOverlay: 'visible', autoplay: 'on', allowScriptAccess: false, logLevel: 'warn',
    };

    if (player) player.remove();
    player = window.RufflePlayer.newest().createPlayer();
    $('stage').appendChild(player);
    status('Loading client…');
    await player.ruffle().load(options);
    status('Client loaded. Log in inside the game.');
  } catch (e) {
    status('Error: ' + str(e));
  }
};
</script>
</body>
</html>
"""#
}
