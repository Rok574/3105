import WebKit

/// Serves aj://app/p/<host>/<path>?<query> by fetching https://<host>/<path>?<query> with URLSession.
/// Only the hosts below are reachable. Responses get permissive CORS headers (the page is aj://app anyway).
final class ProxyHandler: NSObject, WKURLSchemeHandler {
    static let allowed: Set<String> = [
        "animaljam.com",
        "authenticator.animaljam.com",
        "ajcontent.akamaized.net",
        "classic-download.animaljam.com",
    ]

    private let session = URLSession(configuration: .ephemeral)
    private var tasks: [ObjectIdentifier: URLSessionDataTask] = [:]

    func webView(_ webView: WKWebView, start task: WKURLSchemeTask) {
        guard let url = task.request.url else { return task.didFailWithError(URLError(.badURL)) }
        let parts = url.path.split(separator: "/", maxSplits: 2).map(String.init) // ["p", host, rest]
        guard parts.count >= 2, parts[0] == "p", Self.allowed.contains(parts[1]) else {
            return task.didFailWithError(URLError(.resourceUnavailable))
        }

        var c = URLComponents()
        c.scheme = "https"
        c.host = parts[1]
        c.path = "/" + (parts.count > 2 ? parts[2] : "")
        c.percentEncodedQuery = URLComponents(url: url, resolvingAgainstBaseURL: false)?.percentEncodedQuery
        guard let target = c.url else { return task.didFailWithError(URLError(.badURL)) }

        var req = URLRequest(url: target)
        req.httpMethod = task.request.httpMethod
        req.httpBody = Self.body(of: task.request)
        for h in ["Content-Type", "Accept", "Range"] {
            if let v = task.request.value(forHTTPHeaderField: h) { req.setValue(v, forHTTPHeaderField: h) }
        }

        let key = ObjectIdentifier(task)
        let dt = session.dataTask(with: req) { [weak self] data, resp, err in
            DispatchQueue.main.async {
                // If the web view already stopped this task, do not touch it.
                guard let self, self.tasks.removeValue(forKey: key) != nil else { return }
                if let err { return task.didFailWithError(err) }
                guard let http = resp as? HTTPURLResponse, let data else {
                    return task.didFailWithError(URLError(.badServerResponse))
                }
                var headers: [String: String] = [:]
                for (k, v) in http.allHeaderFields {
                    let name = "\(k)"
                    // URLSession already decoded the body, so drop encoding/length headers.
                    if ["content-encoding", "content-length"].contains(name.lowercased()) { continue }
                    headers[name] = "\(v)"
                }
                headers["Content-Length"] = String(data.count)
                headers["Access-Control-Allow-Origin"] = "*"
                let out = HTTPURLResponse(url: url, statusCode: http.statusCode, httpVersion: "HTTP/1.1", headerFields: headers)!
                task.didReceive(out)
                task.didReceive(data)
                task.didFinish()
            }
        }
        tasks[key] = dt
        dt.resume()
    }

    func webView(_ webView: WKWebView, stop task: WKURLSchemeTask) {
        tasks.removeValue(forKey: ObjectIdentifier(task))?.cancel()
    }

    private static func body(of r: URLRequest) -> Data? {
        if let b = r.httpBody { return b }
        guard let s = r.httpBodyStream else { return nil }
        s.open(); defer { s.close() }
        var out = Data()
        var buf = [UInt8](repeating: 0, count: 16384)
        while s.hasBytesAvailable {
            let n = s.read(&buf, maxLength: buf.count)
            if n <= 0 { break }
            out.append(buf, count: n)
        }
        return out
    }
}
