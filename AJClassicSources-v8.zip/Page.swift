import Foundation
import SwiftUI
import WebKit

struct AJWebViewContainer: UIViewRepresentable {
    @Binding var session: AJSession?
    @ObservedObject var coordinator: WebViewCoordinator

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let proxy = ProxyHandler()
        config.setURLSchemeHandler(proxy, forURLScheme: "ajproxy")
        config.setURLSchemeHandler(proxy, forURLScheme: "ajapp")

        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        config.defaultWebpagePreferences = prefs

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        
        coordinator.webView = webView

        // Load via custom ajapp:// scheme so Ruffle sees an http/https-like secure origin and never triggers file: protocol checks
        if let url = URL(string: "ajapp://www.animaljam.com/index.html") {
            webView.load(URLRequest(url: url))
        }

        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, WKNavigationDelegate {
        var parent: AJWebViewContainer
        init(_ parent: AJWebViewContainer) { self.parent = parent }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            print("AJ Classic Ruffle wrapper loaded via ajapp scheme.")
        }
    }
}

struct HTMLTemplate {
    static let playerHTML = """
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <style>
            html, body { width: 100%; height: 100%; margin: 0; padding: 0; background-color: #1a1a1a; overflow: hidden; }
            #player-container { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; }
        </style>
        <script>
            // Polyfill window.location so Ruffle considers protocol secure (non-file)
            (function() {
                try {
                    const loc = window.location;
                    if (loc.protocol === 'file:' || loc.protocol === 'ajapp:') {
                        Object.defineProperty(window, 'location', {
                            value: new Proxy(loc, {
                                get(target, prop) {
                                    if (prop === 'protocol') return 'https:';
                                    if (prop === 'href') return target.href.replace(/^(file|ajapp):/, 'https:');
                                    if (prop === 'origin') return 'https://www.animaljam.com';
                                    const val = target[prop];
                                    return typeof val === 'function' ? val.bind(target) : val;
                                }
                            }),
                            writable: false
                        });
                    }
                } catch(e) {}
            })();
        </script>
        <script src="https://unpkg.com/@ruffle-rs/ruffle"></script>
    </head>
    <body>
        <div id="player-container"></div>
        <script>
            window.aj = window.aj || {
                ready: function() { console.log("AJ ExternalInterface: ready"); },
                login: function() {},
                logout: function() { console.log("AJ ExternalInterface: logout"); },
                reload: function() { location.reload(); },
                openExternalUrl: function(url) { console.log("External URL:", url); },
                getDF: function() { return window.__ajFlashvars ? window.__ajFlashvars.df : ""; }
            };

            window.startAJWithSession = function(flashvars, swfUrl, baseContentUrl, socketProxies) {
                window.__ajFlashvars = flashvars;
                const ruffle = window.RufflePlayer.newest();
                const container = document.getElementById("player-container");
                container.innerHTML = "";

                const player = ruffle.createPlayer();
                player.style.width = "100%";
                player.style.height = "100%";
                container.appendChild(player);

                player.load({
                    url: swfUrl,
                    base: baseContentUrl,
                    parameters: flashvars,
                    allowScriptAccess: "always",
                    allowNetworking: "all",
                    wmode: "direct",
                    letterbox: "on",
                    upgradeToHttps: false,
                    socketProxy: socketProxies || []
                });
            };
        </script>
    </body>
    </html>
    """
}
