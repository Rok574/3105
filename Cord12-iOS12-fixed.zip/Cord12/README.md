# Cord12 — UIKit Discord Client for iOS 12 (iPhone 6)

A lightweight, pure UIKit Discord client built specifically for **iOS 12.0+** and tuned for the **iPhone 6 (A8, 1GB RAM, iOS 12.5.8)**.

## Key Features
- **Two-Device QR Remote Auth Login**: Implements `wss://remote-auth-gateway.discord.gg/?v=2` with 2048-bit RSA-OAEP-SHA256 (`Security.framework`) and `CIQRCodeGenerator`, plus a direct token fallback.
- **Native iOS 12 Networking**: Pure Swift RFC 6455 WebSocket built on `Network.framework` (`NWConnection`)—no `URLSessionWebSocketTask` (iOS 13+) or third-party dependencies required.
- **Full Profile & Cosmetics Support**:
  - **Badges** (`/users/{id}/profile` badge icons)
  - **Banners & Accent Colors**
  - **Profile Frames / Avatar Decorations** (`avatar_decoration_data`)
  - **Nameplates** (`collectibles.nameplate` with palette gradients)
  - **Custom Name Fonts & Effects** (`display_name_styles` fonts + Solid, Gradient, Neon, Toon, Pop, Glow, Prism)
  - **Nitro Profile Themes (`theme_colors`)** & **App-wide Nitro Client Themes** (Dark, Onyx, Ash, Light, Midnight Blurple, Chroma Glow, Cotton Candy, Aurora, Sunset, Crimson)
  - **Live Profile Editor** (`PATCH /users/@me` and `PATCH /users/@me/profile`)
- **iPhone 6 Memory & 60fps Optimization**: `CGImageSource` thumbnail downsampling with a 28 MB `NSCache` cap and automatic memory-warning purge, CoreGraphics vector icons (no iOS 13+ SF Symbols), and capped in-memory message history.

## Building an Unsigned `.ipa`
1. Push this folder to a GitHub repository and run the included `.github/workflows/build-ipa.yml` workflow, or locally on macOS:
   ```bash
   brew install xcodegen
   xcodegen generate
   xcodebuild -project Cord12.xcodeproj -scheme Cord12 -configuration Release -sdk iphoneos -arch arm64 CODE_SIGNING_ALLOWED=NO
   ```
2. Install the resulting `Cord12-iOS12.ipa` on your iPhone 6 via Sideloadly or AppSync Unified.

## Troubleshooting
- **App looks zoomed / letterboxed on iPhone 6**: the built `Info.plist` must contain `UILaunchStoryboardName`. XcodeGen regenerates `Info.plist` from `project.yml`, so launch-screen and orientation keys live in the `info.properties` block there. The CI workflow now fails the build if the key is missing.
