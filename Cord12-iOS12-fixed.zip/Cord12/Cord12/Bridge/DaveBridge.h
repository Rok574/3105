#ifndef DaveBridge_h
#define DaveBridge_h

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

bool cord_dave_is_available(void);
uint16_t cord_dave_max_version(void);
void cord_dave_free(void *ptr);

void *cord_dave_session_create(const char *auth_session_id);
void cord_dave_session_destroy(void *session);
void cord_dave_session_init(void *session, uint16_t version, uint64_t group_id, const char *self_user_id);
void cord_dave_session_reset(void *session);
void cord_dave_session_set_external_sender(void *session, const uint8_t *data, size_t len);
uint8_t *cord_dave_session_get_key_package(void *session, size_t *out_len);
uint8_t *cord_dave_session_process_proposals(void *session, const uint8_t *data, size_t len, const char **user_ids, size_t user_count, size_t *out_len);
int cord_dave_session_process_commit(void *session, const uint8_t *data, size_t len);
bool cord_dave_session_process_welcome(void *session, const uint8_t *data, size_t len, const char **user_ids, size_t user_count);

void *cord_dave_encryptor_create(void);
void cord_dave_encryptor_destroy(void *enc);
void cord_dave_encryptor_set_key_ratchet(void *enc, void *session, const char *self_user_id);
void cord_dave_encryptor_set_passthrough(void *enc, bool passthrough);
void cord_dave_encryptor_assign_opus(void *enc, uint32_t ssrc);
int cord_dave_encrypt_audio(void *enc, uint32_t ssrc, const uint8_t *in_data, size_t in_len, uint8_t *out_data, size_t out_cap);

void *cord_dave_decryptor_create(void);
void cord_dave_decryptor_destroy(void *dec);
void cord_dave_decryptor_transition_key_ratchet(void *dec, void *session, const char *user_id);
void cord_dave_decryptor_set_passthrough(void *dec, bool passthrough);
int cord_dave_decrypt_audio(void *dec, const uint8_t *in_data, size_t in_len, uint8_t *out_data, size_t out_cap);

#endif
