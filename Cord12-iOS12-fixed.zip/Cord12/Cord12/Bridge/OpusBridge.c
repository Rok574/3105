#include "OpusBridge.h"
#include <stddef.h>

#if __has_include("opus.h")
#include "opus.h"
#define CORD_HAS_OPUS 1
#elif __has_include(<opus/opus.h>)
#include <opus/opus.h>
#define CORD_HAS_OPUS 1
#else
#define CORD_HAS_OPUS 0
#endif

bool cord_opus_is_available(void) {
    return CORD_HAS_OPUS == 1;
}

void *cord_opus_encoder_create(int sample_rate, int channels) {
#if CORD_HAS_OPUS
    int err = 0;
    OpusEncoder *enc = opus_encoder_create(sample_rate, channels, OPUS_APPLICATION_VOIP, &err);
    if (err != OPUS_OK) return NULL;
    opus_encoder_ctl(enc, OPUS_SET_BITRATE(64000));
    opus_encoder_ctl(enc, OPUS_SET_INBAND_FEC(1));
    return (void *)enc;
#else
    (void)sample_rate; (void)channels;
    return NULL;
#endif
}

void cord_opus_encoder_destroy(void *encoder) {
#if CORD_HAS_OPUS
    if (encoder) opus_encoder_destroy((OpusEncoder *)encoder);
#else
    (void)encoder;
#endif
}

int cord_opus_encode(void *encoder, const int16_t *pcm, int frame_size, uint8_t *out_data, int max_bytes) {
#if CORD_HAS_OPUS
    if (!encoder || !pcm || !out_data) return -1;
    return opus_encode((OpusEncoder *)encoder, pcm, frame_size, out_data, max_bytes);
#else
    (void)encoder; (void)pcm; (void)frame_size; (void)out_data; (void)max_bytes;
    return -1;
#endif
}

void *cord_opus_decoder_create(int sample_rate, int channels) {
#if CORD_HAS_OPUS
    int err = 0;
    OpusDecoder *dec = opus_decoder_create(sample_rate, channels, &err);
    return (err == OPUS_OK) ? (void *)dec : NULL;
#else
    (void)sample_rate; (void)channels;
    return NULL;
#endif
}

void cord_opus_decoder_destroy(void *decoder) {
#if CORD_HAS_OPUS
    if (decoder) opus_decoder_destroy((OpusDecoder *)decoder);
#else
    (void)decoder;
#endif
}

int cord_opus_decode(void *decoder, const uint8_t *in_data, int in_len, int16_t *out_pcm, int max_frame_size) {
#if CORD_HAS_OPUS
    if (!decoder || !out_pcm) return -1;
    return opus_decode((OpusDecoder *)decoder, in_data, in_len, out_pcm, max_frame_size, 0);
#else
    (void)decoder; (void)in_data; (void)in_len; (void)out_pcm; (void)max_frame_size;
    return -1;
#endif
}
