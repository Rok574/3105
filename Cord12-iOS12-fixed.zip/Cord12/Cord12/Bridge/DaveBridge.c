#include "DaveBridge.h"
#include <stdlib.h>
#include <string.h>

#if __has_include(<dave/dave.h>)
#include <dave/dave.h>
#define CORD_HAS_DAVE 1
#elif __has_include("dave/dave.h")
#include "dave/dave.h"
#define CORD_HAS_DAVE 1
#else
#define CORD_HAS_DAVE 0
#endif

#if CORD_HAS_DAVE
static void cord_dave_mls_failure_cb(const char *source, const char *reason, void *user_data) {
    (void)source; (void)reason; (void)user_data;
}
#endif

bool cord_dave_is_available(void) {
    return CORD_HAS_DAVE == 1;
}

uint16_t cord_dave_max_version(void) {
#if CORD_HAS_DAVE
    return daveMaxSupportedProtocolVersion();
#else
    return 0;
#endif
}

void cord_dave_free(void *ptr) {
    if (ptr) free(ptr);
}

void *cord_dave_session_create(const char *auth_session_id) {
#if CORD_HAS_DAVE
    return (void *)daveSessionCreate(NULL, auth_session_id ? auth_session_id : "", cord_dave_mls_failure_cb, NULL);
#else
    (void)auth_session_id;
    return NULL;
#endif
}

void cord_dave_session_destroy(void *session) {
#if CORD_HAS_DAVE
    if (session) daveSessionDestroy((DAVESessionHandle)session);
#else
    (void)session;
#endif
}

void cord_dave_session_init(void *session, uint16_t version, uint64_t group_id, const char *self_user_id) {
#if CORD_HAS_DAVE
    if (session && self_user_id) {
        daveSessionInit((DAVESessionHandle)session, version, group_id, self_user_id);
    }
#else
    (void)session; (void)version; (void)group_id; (void)self_user_id;
#endif
}

void cord_dave_session_reset(void *session) {
#if CORD_HAS_DAVE
    if (session) daveSessionReset((DAVESessionHandle)session);
#else
    (void)session;
#endif
}

void cord_dave_session_set_external_sender(void *session, const uint8_t *data, size_t len) {
#if CORD_HAS_DAVE
    if (session && data && len > 0) {
        daveSessionSetExternalSender((DAVESessionHandle)session, data, len);
    }
#else
    (void)session; (void)data; (void)len;
#endif
}

uint8_t *cord_dave_session_get_key_package(void *session, size_t *out_len) {
    if (out_len) *out_len = 0;
#if CORD_HAS_DAVE
    if (!session || !out_len) return NULL;
    uint8_t *kp = NULL;
    size_t len = 0;
    daveSessionGetMarshalledKeyPackage((DAVESessionHandle)session, &kp, &len);
    if (!kp || len == 0) return NULL;
    uint8_t *copy = (uint8_t *)malloc(len);
    if (copy) {
        memcpy(copy, kp, len);
        *out_len = len;
    }
    daveFree(kp);
    return copy;
#else
    (void)session;
    return NULL;
#endif
}

uint8_t *cord_dave_session_process_proposals(void *session, const uint8_t *data, size_t len, const char **user_ids, size_t user_count, size_t *out_len) {
    if (out_len) *out_len = 0;
#if CORD_HAS_DAVE
    if (!session || !data || !out_len) return NULL;
    uint8_t *cw = NULL;
    size_t cw_len = 0;
    daveSessionProcessProposals((DAVESessionHandle)session, data, len, user_ids, user_count, &cw, &cw_len);
    if (!cw || cw_len == 0) return NULL;
    uint8_t *copy = (uint8_t *)malloc(cw_len);
    if (copy) {
        memcpy(copy, cw, cw_len);
        *out_len = cw_len;
    }
    daveFree(cw);
    return copy;
#else
    (void)session; (void)data; (void)len; (void)user_ids; (void)user_count;
    return NULL;
#endif
}

int cord_dave_session_process_commit(void *session, const uint8_t *data, size_t len) {
#if CORD_HAS_DAVE
    if (!session || !data) return -1;
    DAVECommitResultHandle res = daveSessionProcessCommit((DAVESessionHandle)session, data, len);
    if (!res) return -1;
    bool failed = daveCommitResultIsFailed(res);
    bool ignored = daveCommitResultIsIgnored(res);
    daveCommitResultDestroy(res);
    if (failed) return -1;
    if (ignored) return 1;
    return 0;
#else
    (void)session; (void)data; (void)len;
    return -1;
#endif
}

bool cord_dave_session_process_welcome(void *session, const uint8_t *data, size_t len, const char **user_ids, size_t user_count) {
#if CORD_HAS_DAVE
    if (!session || !data) return false;
    DAVEWelcomeResultHandle res = daveSessionProcessWelcome((DAVESessionHandle)session, data, len, user_ids, user_count);
    if (!res) return false;
    daveWelcomeResultDestroy(res);
    return true;
#else
    (void)session; (void)data; (void)len; (void)user_ids; (void)user_count;
    return false;
#endif
}

void *cord_dave_encryptor_create(void) {
#if CORD_HAS_DAVE
    return (void *)daveEncryptorCreate();
#else
    return NULL;
#endif
}

void cord_dave_encryptor_destroy(void *enc) {
#if CORD_HAS_DAVE
    if (enc) daveEncryptorDestroy((DAVEEncryptorHandle)enc);
#else
    (void)enc;
#endif
}

void cord_dave_encryptor_set_key_ratchet(void *enc, void *session, const char *self_user_id) {
#if CORD_HAS_DAVE
    if (!enc || !session || !self_user_id) return;
    DAVEKeyRatchetHandle kr = daveSessionGetKeyRatchet((DAVESessionHandle)session, self_user_id);
    if (kr) {
        daveEncryptorSetKeyRatchet((DAVEEncryptorHandle)enc, kr);
        daveKeyRatchetDestroy(kr);
    }
#else
    (void)enc; (void)session; (void)self_user_id;
#endif
}

void cord_dave_encryptor_set_passthrough(void *enc, bool passthrough) {
#if CORD_HAS_DAVE
    if (enc) daveEncryptorSetPassthroughMode((DAVEEncryptorHandle)enc, passthrough);
#else
    (void)enc; (void)passthrough;
#endif
}

void cord_dave_encryptor_assign_opus(void *enc, uint32_t ssrc) {
#if CORD_HAS_DAVE
    if (enc) daveEncryptorAssignSsrcToCodec((DAVEEncryptorHandle)enc, ssrc, DAVE_CODEC_OPUS);
#else
    (void)enc; (void)ssrc;
#endif
}

int cord_dave_encrypt_audio(void *enc, uint32_t ssrc, const uint8_t *in_data, size_t in_len, uint8_t *out_data, size_t out_cap) {
#if CORD_HAS_DAVE
    if (!enc || !in_data || !out_data) return -1;
    size_t written = 0;
    DAVEEncryptorResultCode rc = daveEncryptorEncrypt((DAVEEncryptorHandle)enc, DAVE_MEDIA_TYPE_AUDIO, ssrc, in_data, in_len, out_data, out_cap, &written);
    return (rc == DAVE_ENCRYPTOR_RESULT_CODE_SUCCESS) ? (int)written : -1;
#else
    (void)enc; (void)ssrc; (void)in_data; (void)in_len; (void)out_data; (void)out_cap;
    return -1;
#endif
}

void *cord_dave_decryptor_create(void) {
#if CORD_HAS_DAVE
    return (void *)daveDecryptorCreate();
#else
    return NULL;
#endif
}

void cord_dave_decryptor_destroy(void *dec) {
#if CORD_HAS_DAVE
    if (dec) daveDecryptorDestroy((DAVEDecryptorHandle)dec);
#else
    (void)dec;
#endif
}

void cord_dave_decryptor_transition_key_ratchet(void *dec, void *session, const char *user_id) {
#if CORD_HAS_DAVE
    if (!dec || !session || !user_id) return;
    DAVEKeyRatchetHandle kr = daveSessionGetKeyRatchet((DAVESessionHandle)session, user_id);
    if (kr) {
        daveDecryptorTransitionToKeyRatchet((DAVEDecryptorHandle)dec, kr);
        daveKeyRatchetDestroy(kr);
    }
#else
    (void)dec; (void)session; (void)user_id;
#endif
}

void cord_dave_decryptor_set_passthrough(void *dec, bool passthrough) {
#if CORD_HAS_DAVE
    if (dec) daveDecryptorTransitionToPassthroughMode((DAVEDecryptorHandle)dec, passthrough);
#else
    (void)dec; (void)passthrough;
#endif
}

int cord_dave_decrypt_audio(void *dec, const uint8_t *in_data, size_t in_len, uint8_t *out_data, size_t out_cap) {
#if CORD_HAS_DAVE
    if (!dec || !in_data || !out_data) return -1;
    size_t written = 0;
    DAVEDecryptorResultCode rc = daveDecryptorDecrypt((DAVEDecryptorHandle)dec, DAVE_MEDIA_TYPE_AUDIO, in_data, in_len, out_data, out_cap, &written);
    return (rc == DAVE_DECRYPTOR_RESULT_CODE_SUCCESS) ? (int)written : -1;
#else
    (void)dec; (void)in_data; (void)in_len; (void)out_data; (void)out_cap;
    return -1;
#endif
}
