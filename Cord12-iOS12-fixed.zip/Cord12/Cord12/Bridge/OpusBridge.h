#ifndef OpusBridge_h
#define OpusBridge_h

#include <stdint.h>
#include <stdbool.h>

bool cord_opus_is_available(void);
void *cord_opus_encoder_create(int sample_rate, int channels);
void cord_opus_encoder_destroy(void *encoder);
int cord_opus_encode(void *encoder, const int16_t *pcm, int frame_size, uint8_t *out_data, int max_bytes);

void *cord_opus_decoder_create(int sample_rate, int channels);
void cord_opus_decoder_destroy(void *decoder);
int cord_opus_decode(void *decoder, const uint8_t *in_data, int in_len, int16_t *out_pcm, int max_frame_size);

#endif
