import Foundation
import Security
import CommonCrypto

final class RSAOAEPHelper {
    private let privateKey: SecKey
    private let publicKey: SecKey
    let spkiBase64: String
    let fingerprintBase64URL: String

    init?() {
        let attributes: [String: Any] = [
            kSecAttrKeyType as String: kSecAttrKeyTypeRSA,
            kSecAttrKeySizeInBits as String: 2048
        ]
        var error: Unmanaged<CFError>?
        guard let priv = SecKeyCreateRandomKey(attributes as CFDictionary, &error),
              let pub = SecKeyCopyPublicKey(priv),
              let pkcs1Data = SecKeyCopyExternalRepresentation(pub, &error) as Data? else {
            return nil
        }
        self.privateKey = priv
        self.publicKey = pub

        let spkiData = RSAOAEPHelper.wrapPKCS1InSPKI(pkcs1Data)
        self.spkiBase64 = spkiData.base64EncodedString()

        var digest = [UInt8](repeating: 0, count: Int(CC_SHA256_DIGEST_LENGTH))
        spkiData.withUnsafeBytes { rawBuffer in
            if let baseAddress = rawBuffer.baseAddress {
                _ = CC_SHA256(baseAddress, CC_LONG(spkiData.count), &digest)
            }
        }
        self.fingerprintBase64URL = RSAOAEPHelper.base64URLEncode(Data(digest))
    }

    func decrypt(base64String: String) -> Data? {
        var b64 = base64String
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        let rem = b64.count % 4
        if rem > 0 { b64 += String(repeating: "=", count: 4 - rem) }
        guard let encrypted = Data(base64Encoded: b64, options: .ignoreUnknownCharacters) else { return nil }
        var error: Unmanaged<CFError>?
        guard let plain = SecKeyCreateDecryptedData(
            privateKey,
            .rsaEncryptionOAEPSHA256,
            encrypted as CFData,
            &error
        ) as Data? else {
            return nil
        }
        return plain
    }

    static func base64URLEncode(_ data: Data) -> String {
        return data.base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }

    private static func wrapPKCS1InSPKI(_ pkcs1: Data) -> Data {
        // BIT STRING: 0x03 <len> 0x00 <pkcs1>
        var bitStringBody = Data([0x00])
        bitStringBody.append(pkcs1)
        var bitString = Data([0x03])
        bitString.append(encodeDERLength(bitStringBody.count))
        bitString.append(bitStringBody)

        // AlgorithmIdentifier: rsaEncryption (1.2.840.113549.1.1.1) + NULL
        let algoID = Data([
            0x30, 0x0D,
            0x06, 0x09, 0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x01, 0x01,
            0x05, 0x00
        ])

        var inner = Data()
        inner.append(algoID)
        inner.append(bitString)

        var spki = Data([0x30])
        spki.append(encodeDERLength(inner.count))
        spki.append(inner)
        return spki
    }

    private static func encodeDERLength(_ length: Int) -> Data {
        if length < 128 {
            return Data([UInt8(length)])
        } else if length < 256 {
            return Data([0x81, UInt8(length)])
        } else {
            return Data([0x82, UInt8((length >> 8) & 0xFF), UInt8(length & 0xFF)])
        }
    }
}
