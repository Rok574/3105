import UIKit

/// Pure CoreGraphics vector icons so iOS 12 never depends on iOS 13+ SF Symbols.
enum DiscordIcons {
    enum Kind {
        case hash
        case speaker
        case lock
        case menu
        case back
        case send
        case reply
        case close
        case qrCode
        case person
        case servers
        case dm
        case edit
        case gear
        case sparkles
        case badge
        case plus
        case check
        case gif
        case play
        case star
        case starFilled
        case smile
        case members
        case share
        case bell
        case chevronDown
        case chevronRight
        case mic
        case micOff
        case headset
        case headsetOff
        case phoneOff
        case folder
    }

    static func image(_ kind: Kind, size: CGFloat = 20, color: UIColor = .white, template: Bool = true) -> UIImage {
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: size, height: size))
        let img = renderer.image { ctx in
            let cg = ctx.cgContext
            cg.setStrokeColor(color.cgColor)
            cg.setFillColor(color.cgColor)
            cg.setLineCap(.round)
            cg.setLineJoin(.round)
            let w = size
            let h = size
            cg.setLineWidth(max(1.5, size * 0.09))

            switch kind {
            case .hash:
                cg.move(to: CGPoint(x: w * 0.36, y: h * 0.18))
                cg.addLine(to: CGPoint(x: w * 0.28, y: h * 0.82))
                cg.move(to: CGPoint(x: w * 0.72, y: h * 0.18))
                cg.addLine(to: CGPoint(x: w * 0.64, y: h * 0.82))
                cg.move(to: CGPoint(x: w * 0.16, y: h * 0.38))
                cg.addLine(to: CGPoint(x: w * 0.84, y: h * 0.38))
                cg.move(to: CGPoint(x: w * 0.12, y: h * 0.64))
                cg.addLine(to: CGPoint(x: w * 0.80, y: h * 0.64))
                cg.strokePath()

            case .speaker:
                let path = UIBezierPath()
                path.move(to: CGPoint(x: w * 0.18, y: h * 0.40))
                path.addLine(to: CGPoint(x: w * 0.36, y: h * 0.40))
                path.addLine(to: CGPoint(x: w * 0.56, y: h * 0.22))
                path.addLine(to: CGPoint(x: w * 0.56, y: h * 0.78))
                path.addLine(to: CGPoint(x: w * 0.36, y: h * 0.60))
                path.addLine(to: CGPoint(x: w * 0.18, y: h * 0.60))
                path.close()
                path.fill()
                cg.addArc(center: CGPoint(x: w * 0.62, y: h * 0.50), radius: w * 0.16, startAngle: -.pi / 4, endAngle: .pi / 4, clockwise: false)
                cg.strokePath()
                cg.addArc(center: CGPoint(x: w * 0.62, y: h * 0.50), radius: w * 0.28, startAngle: -.pi / 4, endAngle: .pi / 4, clockwise: false)
                cg.strokePath()

            case .lock:
                let body = UIBezierPath(roundedRect: CGRect(x: w * 0.22, y: h * 0.44, width: w * 0.56, height: h * 0.40), cornerRadius: w * 0.08)
                body.fill()
                cg.addArc(center: CGPoint(x: w * 0.50, y: h * 0.44), radius: w * 0.18, startAngle: .pi, endAngle: 0, clockwise: false)
                cg.strokePath()

            case .menu:
                for y in [0.28, 0.50, 0.72] as [CGFloat] {
                    cg.move(to: CGPoint(x: w * 0.16, y: h * y))
                    cg.addLine(to: CGPoint(x: w * 0.84, y: h * y))
                }
                cg.strokePath()

            case .back:
                cg.move(to: CGPoint(x: w * 0.65, y: h * 0.20))
                cg.addLine(to: CGPoint(x: w * 0.30, y: h * 0.50))
                cg.addLine(to: CGPoint(x: w * 0.65, y: h * 0.80))
                cg.strokePath()

            case .send:
                let path = UIBezierPath()
                path.move(to: CGPoint(x: w * 0.14, y: h * 0.20))
                path.addLine(to: CGPoint(x: w * 0.88, y: h * 0.50))
                path.addLine(to: CGPoint(x: w * 0.14, y: h * 0.80))
                path.addLine(to: CGPoint(x: w * 0.28, y: h * 0.52))
                path.close()
                path.fill()

            case .reply:
                cg.move(to: CGPoint(x: w * 0.42, y: h * 0.26))
                cg.addLine(to: CGPoint(x: w * 0.16, y: h * 0.46))
                cg.addLine(to: CGPoint(x: w * 0.42, y: h * 0.66))
                cg.move(to: CGPoint(x: w * 0.16, y: h * 0.46))
                cg.addLine(to: CGPoint(x: w * 0.68, y: h * 0.46))
                cg.addQuadCurve(to: CGPoint(x: w * 0.84, y: h * 0.74), control: CGPoint(x: w * 0.84, y: h * 0.46))
                cg.strokePath()

            case .close:
                cg.move(to: CGPoint(x: w * 0.24, y: h * 0.24))
                cg.addLine(to: CGPoint(x: w * 0.76, y: h * 0.76))
                cg.move(to: CGPoint(x: w * 0.76, y: h * 0.24))
                cg.addLine(to: CGPoint(x: w * 0.24, y: h * 0.76))
                cg.strokePath()

            case .qrCode:
                let rects = [
                    CGRect(x: w * 0.14, y: h * 0.14, width: w * 0.28, height: h * 0.28),
                    CGRect(x: w * 0.58, y: h * 0.14, width: w * 0.28, height: h * 0.28),
                    CGRect(x: w * 0.14, y: h * 0.58, width: w * 0.28, height: h * 0.28)
                ]
                for r in rects {
                    UIBezierPath(roundedRect: r, cornerRadius: w * 0.04).stroke()
                }
                UIBezierPath(rect: CGRect(x: w * 0.58, y: h * 0.58, width: w * 0.12, height: h * 0.12)).fill()
                UIBezierPath(rect: CGRect(x: w * 0.74, y: h * 0.74, width: w * 0.12, height: h * 0.12)).fill()

            case .person:
                let head = UIBezierPath(ovalIn: CGRect(x: w * 0.34, y: h * 0.16, width: w * 0.32, height: h * 0.32))
                head.fill()
                let body = UIBezierPath()
                body.move(to: CGPoint(x: w * 0.20, y: h * 0.84))
                body.addQuadCurve(to: CGPoint(x: w * 0.80, y: h * 0.84), controlPoint: CGPoint(x: w * 0.50, y: h * 0.50))
                body.close()
                body.fill()

            case .servers:
                for y in [0.22, 0.48, 0.74] as [CGFloat] {
                    let r = UIBezierPath(roundedRect: CGRect(x: w * 0.18, y: h * (y - 0.08), width: w * 0.64, height: h * 0.16), cornerRadius: w * 0.04)
                    r.stroke()
                }

            case .dm:
                let bubble = UIBezierPath(roundedRect: CGRect(x: w * 0.14, y: h * 0.20, width: w * 0.72, height: h * 0.52), cornerRadius: w * 0.14)
                bubble.stroke()
                cg.move(to: CGPoint(x: w * 0.30, y: h * 0.72))
                cg.addLine(to: CGPoint(x: w * 0.22, y: h * 0.86))
                cg.addLine(to: CGPoint(x: w * 0.44, y: h * 0.72))
                cg.strokePath()

            case .edit:
                cg.move(to: CGPoint(x: w * 0.22, y: h * 0.78))
                cg.addLine(to: CGPoint(x: w * 0.28, y: h * 0.58))
                cg.addLine(to: CGPoint(x: w * 0.68, y: h * 0.18))
                cg.addLine(to: CGPoint(x: w * 0.82, y: h * 0.32))
                cg.addLine(to: CGPoint(x: w * 0.42, y: h * 0.72))
                cg.close()
                cg.strokePath()

            case .gear:
                cg.addArc(center: CGPoint(x: w * 0.5, y: h * 0.5), radius: w * 0.20, startAngle: 0, endAngle: .pi * 2, clockwise: false)
                cg.strokePath()
                for i in 0..<8 {
                    let angle = CGFloat(i) * (.pi / 4)
                    cg.move(to: CGPoint(x: w * 0.5 + cos(angle) * w * 0.26, y: h * 0.5 + sin(angle) * h * 0.26))
                    cg.addLine(to: CGPoint(x: w * 0.5 + cos(angle) * w * 0.36, y: h * 0.5 + sin(angle) * h * 0.36))
                }
                cg.strokePath()

            case .sparkles:
                let star = UIBezierPath()
                star.move(to: CGPoint(x: w * 0.50, y: h * 0.12))
                star.addLine(to: CGPoint(x: w * 0.58, y: h * 0.42))
                star.addLine(to: CGPoint(x: w * 0.88, y: h * 0.50))
                star.addLine(to: CGPoint(x: w * 0.58, y: h * 0.58))
                star.addLine(to: CGPoint(x: w * 0.50, y: h * 0.88))
                star.addLine(to: CGPoint(x: w * 0.42, y: h * 0.58))
                star.addLine(to: CGPoint(x: w * 0.12, y: h * 0.50))
                star.addLine(to: CGPoint(x: w * 0.42, y: h * 0.42))
                star.close()
                star.fill()

            case .badge:
                let hex = UIBezierPath()
                for i in 0..<6 {
                    let a = CGFloat(i) * (.pi / 3) - .pi / 2
                    let pt = CGPoint(x: w * 0.5 + cos(a) * w * 0.34, y: h * 0.5 + sin(a) * h * 0.34)
                    if i == 0 { hex.move(to: pt) } else { hex.addLine(to: pt) }
                }
                hex.close()
                hex.stroke()

            case .plus:
                cg.move(to: CGPoint(x: w * 0.5, y: h * 0.2))
                cg.addLine(to: CGPoint(x: w * 0.5, y: h * 0.8))
                cg.move(to: CGPoint(x: w * 0.2, y: h * 0.5))
                cg.addLine(to: CGPoint(x: w * 0.8, y: h * 0.5))
                cg.strokePath()

            case .check:
                cg.move(to: CGPoint(x: w * 0.22, y: h * 0.52))
                cg.addLine(to: CGPoint(x: w * 0.42, y: h * 0.72))
                cg.addLine(to: CGPoint(x: w * 0.78, y: h * 0.28))
                cg.strokePath()

            case .gif:
                let box = UIBezierPath(roundedRect: CGRect(x: w * 0.10, y: h * 0.24, width: w * 0.80, height: h * 0.52), cornerRadius: w * 0.12)
                box.stroke()
                let attrs: [NSAttributedString.Key: Any] = [
                    .font: UIFont.systemFont(ofSize: size * 0.34, weight: .heavy),
                    .foregroundColor: color
                ]
                let str = "GIF" as NSString
                let s = str.size(withAttributes: attrs)
                str.draw(at: CGPoint(x: (w - s.width) / 2, y: (h - s.height) / 2), withAttributes: attrs)

            case .play:
                let tri = UIBezierPath()
                tri.move(to: CGPoint(x: w * 0.28, y: h * 0.18))
                tri.addLine(to: CGPoint(x: w * 0.80, y: h * 0.50))
                tri.addLine(to: CGPoint(x: w * 0.28, y: h * 0.82))
                tri.close()
                tri.fill()

            case .star, .starFilled:
                let path = UIBezierPath()
                let center = CGPoint(x: w * 0.5, y: h * 0.52)
                let outerR = w * 0.38
                let innerR = w * 0.17
                for i in 0..<10 {
                    let angle = CGFloat(i) * (.pi / 5) - .pi / 2
                    let r = (i % 2 == 0) ? outerR : innerR
                    let pt = CGPoint(x: center.x + cos(angle) * r, y: center.y + sin(angle) * r)
                    if i == 0 { path.move(to: pt) } else { path.addLine(to: pt) }
                }
                path.close()
                if kind == .starFilled { path.fill() } else { path.stroke() }

            case .smile:
                cg.addArc(center: CGPoint(x: w * 0.5, y: h * 0.5), radius: w * 0.36, startAngle: 0, endAngle: .pi * 2, clockwise: false)
                cg.strokePath()
                UIBezierPath(ovalIn: CGRect(x: w * 0.34, y: h * 0.36, width: w * 0.09, height: h * 0.09)).fill()
                UIBezierPath(ovalIn: CGRect(x: w * 0.57, y: h * 0.36, width: w * 0.09, height: h * 0.09)).fill()
                cg.addArc(center: CGPoint(x: w * 0.5, y: h * 0.52), radius: w * 0.18, startAngle: 0.2, endAngle: .pi - 0.2, clockwise: false)
                cg.strokePath()

            case .members:
                let h1 = UIBezierPath(ovalIn: CGRect(x: w * 0.24, y: h * 0.20, width: w * 0.24, height: h * 0.24))
                h1.fill()
                let h2 = UIBezierPath(ovalIn: CGRect(x: w * 0.56, y: h * 0.26, width: w * 0.20, height: h * 0.20))
                h2.fill()
                cg.addArc(center: CGPoint(x: w * 0.36, y: h * 0.78), radius: w * 0.20, startAngle: .pi, endAngle: 0, clockwise: false)
                cg.strokePath()

            case .share:
                cg.move(to: CGPoint(x: w * 0.50, y: h * 0.62))
                cg.addLine(to: CGPoint(x: w * 0.50, y: h * 0.16))
                cg.move(to: CGPoint(x: w * 0.32, y: h * 0.34))
                cg.addLine(to: CGPoint(x: w * 0.50, y: h * 0.16))
                cg.addLine(to: CGPoint(x: w * 0.68, y: h * 0.34))
                cg.strokePath()
                let tray = UIBezierPath()
                tray.move(to: CGPoint(x: w * 0.22, y: h * 0.52))
                tray.addLine(to: CGPoint(x: w * 0.22, y: h * 0.80))
                tray.addLine(to: CGPoint(x: w * 0.78, y: h * 0.80))
                tray.addLine(to: CGPoint(x: w * 0.78, y: h * 0.52))
                tray.stroke()

            case .bell:
                let dome = UIBezierPath()
                dome.move(to: CGPoint(x: w * 0.20, y: h * 0.68))
                dome.addLine(to: CGPoint(x: w * 0.26, y: h * 0.42))
                dome.addCurve(
                    to: CGPoint(x: w * 0.74, y: h * 0.42),
                    controlPoint1: CGPoint(x: w * 0.28, y: h * 0.16),
                    controlPoint2: CGPoint(x: w * 0.72, y: h * 0.16)
                )
                dome.addLine(to: CGPoint(x: w * 0.80, y: h * 0.68))
                dome.close()
                dome.stroke()
                cg.addArc(center: CGPoint(x: w * 0.50, y: h * 0.74), radius: w * 0.08, startAngle: 0, endAngle: .pi, clockwise: false)
                cg.strokePath()

            case .chevronDown:
                cg.move(to: CGPoint(x: w * 0.24, y: h * 0.36))
                cg.addLine(to: CGPoint(x: w * 0.50, y: h * 0.64))
                cg.addLine(to: CGPoint(x: w * 0.76, y: h * 0.36))
                cg.strokePath()

            case .chevronRight:
                cg.move(to: CGPoint(x: w * 0.36, y: h * 0.24))
                cg.addLine(to: CGPoint(x: w * 0.64, y: h * 0.50))
                cg.addLine(to: CGPoint(x: w * 0.36, y: h * 0.76))
                cg.strokePath()

            case .mic, .micOff:
                let pill = UIBezierPath(roundedRect: CGRect(x: w * 0.36, y: h * 0.16, width: w * 0.28, height: h * 0.44), cornerRadius: w * 0.14)
                pill.fill()
                cg.addArc(center: CGPoint(x: w * 0.50, y: h * 0.50), radius: w * 0.24, startAngle: 0, endAngle: .pi, clockwise: false)
                cg.strokePath()
                cg.move(to: CGPoint(x: w * 0.50, y: h * 0.74))
                cg.addLine(to: CGPoint(x: w * 0.50, y: h * 0.86))
                cg.move(to: CGPoint(x: w * 0.34, y: h * 0.86))
                cg.addLine(to: CGPoint(x: w * 0.66, y: h * 0.86))
                cg.strokePath()
                if kind == .micOff {
                    cg.move(to: CGPoint(x: w * 0.20, y: h * 0.20))
                    cg.addLine(to: CGPoint(x: w * 0.80, y: h * 0.80))
                    cg.strokePath()
                }

            case .headset, .headsetOff:
                cg.addArc(center: CGPoint(x: w * 0.50, y: h * 0.52), radius: w * 0.32, startAngle: .pi, endAngle: 0, clockwise: false)
                cg.strokePath()
                UIBezierPath(roundedRect: CGRect(x: w * 0.14, y: h * 0.50, width: w * 0.14, height: h * 0.28), cornerRadius: w * 0.05).fill()
                UIBezierPath(roundedRect: CGRect(x: w * 0.72, y: h * 0.50, width: w * 0.14, height: h * 0.28), cornerRadius: w * 0.05).fill()
                if kind == .headsetOff {
                    cg.move(to: CGPoint(x: w * 0.20, y: h * 0.20))
                    cg.addLine(to: CGPoint(x: w * 0.80, y: h * 0.80))
                    cg.strokePath()
                }

            case .phoneOff:
                cg.move(to: CGPoint(x: w * 0.18, y: h * 0.58))
                cg.addQuadCurve(to: CGPoint(x: w * 0.82, y: h * 0.58), control: CGPoint(x: w * 0.50, y: h * 0.36))
                cg.strokePath()
                cg.move(to: CGPoint(x: w * 0.20, y: h * 0.22))
                cg.addLine(to: CGPoint(x: w * 0.80, y: h * 0.82))
                cg.strokePath()

            case .folder:
                let f = UIBezierPath()
                f.move(to: CGPoint(x: w * 0.14, y: h * 0.26))
                f.addLine(to: CGPoint(x: w * 0.42, y: h * 0.26))
                f.addLine(to: CGPoint(x: w * 0.50, y: h * 0.34))
                f.addLine(to: CGPoint(x: w * 0.86, y: h * 0.34))
                f.addLine(to: CGPoint(x: w * 0.86, y: h * 0.76))
                f.addLine(to: CGPoint(x: w * 0.14, y: h * 0.76))
                f.close()
                f.fill()
            }
        }
        return template ? img.withRenderingMode(UIImage.RenderingMode.alwaysTemplate) : img
    }
}
