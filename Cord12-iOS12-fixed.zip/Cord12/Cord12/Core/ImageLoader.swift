import UIKit
import ImageIO

/// Memory-conscious image & animated GIF loader/downsampler tuned for iPhone 6 (1GB RAM, iOS 12).
final class ImageLoader {
    static let shared = ImageLoader()

    private let cache = NSCache<NSString, UIImage>()
    private let session: URLSession
    private let decodeQueue: OperationQueue = {
        let q = OperationQueue()
        q.name = "com.sky.cord12.imagedecode"
        q.maxConcurrentOperationCount = 2
        q.qualityOfService = .userInitiated
        return q
    }()

    private init() {
        cache.countLimit = 160
        cache.totalCostLimit = 20 * 1024 * 1024 // 20 MB cap for iPhone 6 1GB RAM
        let config = URLSessionConfiguration.default
        config.urlCache = URLCache(memoryCapacity: 4 * 1024 * 1024, diskCapacity: 64 * 1024 * 1024, diskPath: "cord12_images")
        config.requestCachePolicy = .returnCacheDataElseLoad
        config.httpAdditionalHeaders = [
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 12_5_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
            "Accept": "image/png,image/jpeg,image/gif,*/*;q=0.8"
        ]
        self.session = URLSession(configuration: config)

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleMemoryWarning),
            name: UIApplication.didReceiveMemoryWarningNotification,
            object: nil
        )
    }

    @objc private func handleMemoryWarning() {
        cache.removeAllObjects()
    }

    func cachedImage(urlString: String?, maxPixelSize: CGFloat = 160, animated: Bool = true) -> UIImage? {
        guard let urlString = urlString else { return nil }
        let key = "\(urlString)#\(Int(maxPixelSize))#\(animated ? 1 : 0)" as NSString
        return cache.object(forKey: key)
    }

    @discardableResult
    func load(urlString: String?, maxPixelSize: CGFloat = 160, animated: Bool = true, completion: @escaping (UIImage?) -> Void) -> URL? {
        guard let urlString = urlString, !urlString.isEmpty, let url = URL(string: urlString) else {
            DispatchQueue.main.async { completion(nil) }
            return nil
        }

        let key = "\(urlString)#\(Int(maxPixelSize))#\(animated ? 1 : 0)" as NSString
        if let cached = cache.object(forKey: key) {
            DispatchQueue.main.async { completion(cached) }
            return url
        }

        var req = URLRequest(url: url)
        req.cachePolicy = .returnCacheDataElseLoad
        req.timeoutInterval = 20

        let task = session.dataTask(with: req) { [weak self] data, response, _ in
            let status = (response as? HTTPURLResponse)?.statusCode ?? 200
            guard let self = self, (200..<300).contains(status), let data = data, !data.isEmpty else {
                // Evict any bad cached response so future retries can succeed
                self?.session.configuration.urlCache?.removeCachedResponse(for: req)
                DispatchQueue.main.async { completion(nil) }
                return
            }
            self.decodeQueue.addOperation {
                let image = self.decodeImage(data: data, maxDimension: maxPixelSize * UIScreen.main.scale, allowAnimated: animated)
                if let img = image {
                    let frameCount = img.images?.count ?? 1
                    let cost = Int(img.size.width * img.size.height * 4) * min(frameCount, 6)
                    self.cache.setObject(img, forKey: key, cost: cost)
                }
                DispatchQueue.main.async {
                    completion(image)
                }
            }
        }
        task.resume()
        return url
    }

    private func decodeImage(data: Data, maxDimension: CGFloat, allowAnimated: Bool) -> UIImage? {
        let options: [CFString: Any] = [kCGImageSourceShouldCache: false]
        guard let source = CGImageSourceCreateWithData(data as CFData, options as CFDictionary) else {
            return UIImage(data: data)
        }

        let count = CGImageSourceGetCount(source)
        let downsampleOptions: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: max(48, Int(maxDimension))
        ]

        if allowAnimated && count > 1 {
            let maxFrames = min(count, 16) // Keep RAM safe on iPhone 6 1GB
            let step = max(1, count / maxFrames)
            var frames: [UIImage] = []
            var totalDuration: TimeInterval = 0

            var idx = 0
            while idx < count && frames.count < maxFrames {
                if let cg = CGImageSourceCreateThumbnailAtIndex(source, idx, downsampleOptions as CFDictionary) {
                    frames.append(UIImage(cgImage: cg))
                    totalDuration += frameDelay(source: source, index: idx) * Double(step)
                }
                idx += step
            }

            if !frames.isEmpty {
                return UIImage.animatedImage(with: frames, duration: max(0.25, totalDuration))
            }
        }

        guard let cgImage = CGImageSourceCreateThumbnailAtIndex(source, 0, downsampleOptions as CFDictionary) else {
            return UIImage(data: data)
        }
        return UIImage(cgImage: cgImage)
    }

    private func frameDelay(source: CGImageSource, index: Int) -> TimeInterval {
        var delay: TimeInterval = 0.08
        guard let props = CGImageSourceCopyPropertiesAtIndex(source, index, nil) as? [CFString: Any],
              let gifProps = props[kCGImagePropertyGIFDictionary] as? [CFString: Any] else {
            return delay
        }
        if let unclamped = gifProps[kCGImagePropertyGIFUnclampedDelayTime] as? Double, unclamped > 0.01 {
            delay = unclamped
        } else if let clamped = gifProps[kCGImagePropertyGIFDelayTime] as? Double, clamped > 0.01 {
            delay = clamped
        }
        return delay
    }
}
