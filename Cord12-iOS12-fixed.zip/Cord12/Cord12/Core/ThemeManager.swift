import UIKit

enum CordThemeID: String, CaseIterable {
    case ash = "ash"
    case dark = "dark"
    case onyx = "onyx"
    case light = "light"
    case nitroMidnightBlurple = "nitro_midnight_blurple"
    case nitroChromaGlow = "nitro_chroma_glow"
    case nitroCottonCandy = "nitro_cotton_candy"
    case nitroAurora = "nitro_aurora"
    case nitroSunset = "nitro_sunset"
    case nitroCrimson = "nitro_crimson"

    var displayName: String {
        switch self {
        case .ash: return "Ash (Classic Discord)"
        case .dark: return "Dark"
        case .onyx: return "Onyx (AMOLED Black)"
        case .light: return "Light"
        case .nitroMidnightBlurple: return "Nitro: Midnight Blurple"
        case .nitroChromaGlow: return "Nitro: Chroma Glow"
        case .nitroCottonCandy: return "Nitro: Cotton Candy"
        case .nitroAurora: return "Nitro: Aurora"
        case .nitroSunset: return "Nitro: Sunset"
        case .nitroCrimson: return "Nitro: Crimson Dark"
        }
    }

    var isNitroGradient: Bool {
        switch self {
        case .dark, .onyx, .ash, .light: return false
        default: return true
        }
    }
}

struct CordTheme {
    let id: CordThemeID
    let backgroundPrimary: UIColor
    let backgroundSecondary: UIColor
    let backgroundTertiary: UIColor
    let surfaceCard: UIColor
    let textPrimary: UIColor
    let textSecondary: UIColor
    let textMuted: UIColor
    let accent: UIColor
    let separator: UIColor
    let gradientColors: [UIColor]?
    let isDark: Bool
}

extension Notification.Name {
    static let cordThemeDidChange = Notification.Name("cordThemeDidChange")
}

final class ThemeManager {
    static let shared = ThemeManager()
    private let defaultsKey = "cord12_selected_theme"

    private(set) var current: CordTheme

    private init() {
        let saved = UserDefaults.standard.string(forKey: defaultsKey)
        let themeID = saved.flatMap(CordThemeID.init(rawValue:)) ?? .ash
        self.current = ThemeManager.makeTheme(for: themeID)
    }

    func setTheme(_ id: CordThemeID) {
        UserDefaults.standard.set(id.rawValue, forKey: defaultsKey)
        current = ThemeManager.makeTheme(for: id)
        NotificationCenter.default.post(name: .cordThemeDidChange, object: nil)
    }

    func applyGradientIfNeeded(to view: UIView, layerName: String = "CordNitroGradient") {
        view.layer.sublayers?.removeAll(where: { $0.name == layerName })
        guard let colors = current.gradientColors, colors.count >= 2 else { return }
        let gradient = CAGradientLayer()
        gradient.name = layerName
        gradient.colors = colors.map { $0.cgColor }
        gradient.startPoint = CGPoint(x: 0.0, y: 0.0)
        gradient.endPoint = CGPoint(x: 1.0, y: 1.0)
        gradient.frame = view.bounds
        view.layer.insertSublayer(gradient, at: 0)
    }

    static func makeTheme(for id: CordThemeID) -> CordTheme {
        let blurple = UIColor(hex: 0x5865F2)
        switch id {
        case .dark:
            return CordTheme(
                id: id,
                backgroundPrimary: UIColor(hex: 0x1A1A1E),
                backgroundSecondary: UIColor(hex: 0x121214),
                backgroundTertiary: UIColor(hex: 0x0D0D0F),
                surfaceCard: UIColor(hex: 0x242429),
                textPrimary: UIColor(hex: 0xF2F3F5),
                textSecondary: UIColor(hex: 0xB5BAC1),
                textMuted: UIColor(hex: 0x80848E),
                accent: blurple,
                separator: UIColor(hex: 0x2E2E35),
                gradientColors: nil,
                isDark: true
            )
        case .onyx:
            return CordTheme(
                id: id,
                backgroundPrimary: UIColor(hex: 0x000000),
                backgroundSecondary: UIColor(hex: 0x0A0A0C),
                backgroundTertiary: UIColor(hex: 0x050507),
                surfaceCard: UIColor(hex: 0x141418),
                textPrimary: UIColor(hex: 0xFFFFFF),
                textSecondary: UIColor(hex: 0xB5BAC1),
                textMuted: UIColor(hex: 0x72767D),
                accent: blurple,
                separator: UIColor(hex: 0x1E1E24),
                gradientColors: nil,
                isDark: true
            )
        case .ash:
            return CordTheme(
                id: id,
                backgroundPrimary: UIColor(hex: 0x313338),
                backgroundSecondary: UIColor(hex: 0x2B2D31),
                backgroundTertiary: UIColor(hex: 0x1E1F22),
                surfaceCard: UIColor(hex: 0x383A40),
                textPrimary: UIColor(hex: 0xF2F3F5),
                textSecondary: UIColor(hex: 0xDBDEE1),
                textMuted: UIColor(hex: 0x949BA4),
                accent: blurple,
                separator: UIColor(hex: 0x3F4147),
                gradientColors: nil,
                isDark: true
            )
        case .light:
            return CordTheme(
                id: id,
                backgroundPrimary: UIColor(hex: 0xFFFFFF),
                backgroundSecondary: UIColor(hex: 0xF2F3F5),
                backgroundTertiary: UIColor(hex: 0xE3E5E8),
                surfaceCard: UIColor(hex: 0xEBEDEF),
                textPrimary: UIColor(hex: 0x060607),
                textSecondary: UIColor(hex: 0x4E5058),
                textMuted: UIColor(hex: 0x80848E),
                accent: blurple,
                separator: UIColor(hex: 0xE3E5E8),
                gradientColors: nil,
                isDark: false
            )
        case .nitroMidnightBlurple:
            return CordTheme(
                id: id,
                backgroundPrimary: UIColor(hex: 0x13152B),
                backgroundSecondary: UIColor(hex: 0x0E1022),
                backgroundTertiary: UIColor(hex: 0x080A16),
                surfaceCard: UIColor(hex: 0x1E2142),
                textPrimary: UIColor(hex: 0xF2F3F5),
                textSecondary: UIColor(hex: 0xC4C9F2),
                textMuted: UIColor(hex: 0x8A91C7),
                accent: UIColor(hex: 0x7289DA),
                separator: UIColor(hex: 0x2B2F5C),
                gradientColors: [UIColor(hex: 0x1D2252), UIColor(hex: 0x0B0C1A)],
                isDark: true
            )
        case .nitroChromaGlow:
            return CordTheme(
                id: id,
                backgroundPrimary: UIColor(hex: 0x1A1228),
                backgroundSecondary: UIColor(hex: 0x120C1C),
                backgroundTertiary: UIColor(hex: 0x0B0712),
                surfaceCard: UIColor(hex: 0x271B3B),
                textPrimary: UIColor(hex: 0xF8F2FF),
                textSecondary: UIColor(hex: 0xD2B8F5),
                textMuted: UIColor(hex: 0x997BC2),
                accent: UIColor(hex: 0xB46BFF),
                separator: UIColor(hex: 0x382654),
                gradientColors: [UIColor(hex: 0x2E1A47), UIColor(hex: 0x101E38)],
                isDark: true
            )
        case .nitroCottonCandy:
            return CordTheme(
                id: id,
                backgroundPrimary: UIColor(hex: 0x261729),
                backgroundSecondary: UIColor(hex: 0x1D1120),
                backgroundTertiary: UIColor(hex: 0x140B17),
                surfaceCard: UIColor(hex: 0x331E38),
                textPrimary: UIColor(hex: 0xFFF2FA),
                textSecondary: UIColor(hex: 0xF2C2E4),
                textMuted: UIColor(hex: 0xB884AA),
                accent: UIColor(hex: 0xFF73B9),
                separator: UIColor(hex: 0x452A4B),
                gradientColors: [UIColor(hex: 0x3D1E3B), UIColor(hex: 0x1C2947)],
                isDark: true
            )
        case .nitroAurora:
            return CordTheme(
                id: id,
                backgroundPrimary: UIColor(hex: 0x0F2024),
                backgroundSecondary: UIColor(hex: 0x0A161A),
                backgroundTertiary: UIColor(hex: 0x061012),
                surfaceCard: UIColor(hex: 0x172F35),
                textPrimary: UIColor(hex: 0xEFFCF8),
                textSecondary: UIColor(hex: 0xA8E0D4),
                textMuted: UIColor(hex: 0x6AA398),
                accent: UIColor(hex: 0x23D5AB),
                separator: UIColor(hex: 0x22444C),
                gradientColors: [UIColor(hex: 0x0F3338), UIColor(hex: 0x181B3A)],
                isDark: true
            )
        case .nitroSunset:
            return CordTheme(
                id: id,
                backgroundPrimary: UIColor(hex: 0x24161A),
                backgroundSecondary: UIColor(hex: 0x1A0F13),
                backgroundTertiary: UIColor(hex: 0x120A0D),
                surfaceCard: UIColor(hex: 0x331E24),
                textPrimary: UIColor(hex: 0xFFF5F0),
                textSecondary: UIColor(hex: 0xF0C2B6),
                textMuted: UIColor(hex: 0xB58277),
                accent: UIColor(hex: 0xFF7B54),
                separator: UIColor(hex: 0x472A32),
                gradientColors: [UIColor(hex: 0x3D1C26), UIColor(hex: 0x2B193D)],
                isDark: true
            )
        case .nitroCrimson:
            return CordTheme(
                id: id,
                backgroundPrimary: UIColor(hex: 0x1F0F14),
                backgroundSecondary: UIColor(hex: 0x160A0E),
                backgroundTertiary: UIColor(hex: 0x0F0609),
                surfaceCard: UIColor(hex: 0x2B141B),
                textPrimary: UIColor(hex: 0xFFF0F3),
                textSecondary: UIColor(hex: 0xE5AAB6),
                textMuted: UIColor(hex: 0x9E6772),
                accent: UIColor(hex: 0xED4245),
                separator: UIColor(hex: 0x3D1C26),
                gradientColors: [UIColor(hex: 0x36101B), UIColor(hex: 0x12080C)],
                isDark: true
            )
        }
    }
}

extension UIColor {
    convenience init(hex: Int, alpha: CGFloat = 1.0) {
        let r = CGFloat((hex >> 16) & 0xFF) / 255.0
        let g = CGFloat((hex >> 8) & 0xFF) / 255.0
        let b = CGFloat(hex & 0xFF) / 255.0
        self.init(red: r, green: g, blue: b, alpha: alpha)
    }

    var hexInt: Int {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        getRed(&r, green: &g, blue: &b, alpha: &a)
        return (Int(r * 255) << 16) | (Int(g * 255) << 8) | Int(b * 255)
    }
}
