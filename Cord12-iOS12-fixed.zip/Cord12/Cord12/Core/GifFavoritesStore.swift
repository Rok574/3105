import Foundation

extension Notification.Name {
    static let cordGifFavoritesDidChange = Notification.Name("cordGifFavoritesDidChange")
}

final class GifFavoritesStore {
    static let shared = GifFavoritesStore()
    private let key = "cord12_favorite_gifs"

    private(set) var favorites: [DiscordGifItem] = []

    private init() {
        load()
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: key),
              let decoded = try? JSONDecoder().decode([DiscordGifItem].self, from: data) else {
            favorites = []
            return
        }
        favorites = decoded
    }

    private func save() {
        if let data = try? JSONEncoder().encode(favorites) {
            UserDefaults.standard.set(data, forKey: key)
        }
        NotificationCenter.default.post(name: .cordGifFavoritesDidChange, object: nil)
    }

    func syncFromDiscord() {
        DiscordRESTClient.shared.requestData(path: "/users/@me/settings-proto/2") { [weak self] res in
            guard let self = self,
                  case .success(let data) = res,
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let b64 = json["settings"] as? String,
                  let protoData = Data(base64Encoded: b64) else { return }

            let extractedURLs = GifFavoritesStore.extractGifURLs(fromProtobuf: protoData)
            var added = false
            for url in extractedURLs.reversed() {
                if !self.isFavorite(url: url) {
                    let item = DiscordGifItem(
                        id: url,
                        title: "Discord Favorite",
                        url: url,
                        gifSrc: url,
                        preview: url,
                        width: nil,
                        height: nil
                    )
                    self.favorites.insert(item, at: 0)
                    added = true
                }
            }
            if added {
                self.save()
            }
        }
    }

    /// Scans Discord FrecencyUserSettings protobuf for synced favorite GIF URLs.
    private static func extractGifURLs(fromProtobuf data: Data) -> [String] {
        guard let raw = String(data: data, encoding: .isoLatin1) else { return [] }
        let pattern = "https://[A-Za-z0-9\\-._~:/?#\\[\\]@!$&'()*+,;=%]+"
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return [] }
        let matches = regex.matches(in: raw, range: NSRange(location: 0, length: (raw as NSString).length))
        var seen = Set<String>()
        var results: [String] = []
        for m in matches {
            let url = (raw as NSString).substring(with: m.range)
            let lower = url.lowercased()
            let isGifHost = lower.contains(".gif") || lower.contains("tenor.com") || lower.contains("giphy.com") || lower.contains("discordapp.") || lower.contains("klipy.")
            if isGifHost && !seen.contains(url) {
                seen.insert(url)
                results.append(url)
            }
        }
        return results
    }

    func isFavorite(url: String) -> Bool {
        return favorites.contains { $0.effectiveGifURL == url || $0.url == url }
    }

    func toggleFavorite(url: String, title: String? = nil) -> Bool {
        if isFavorite(url: url) {
            favorites.removeAll { $0.effectiveGifURL == url || $0.url == url }
            save()
            return false
        } else {
            let item = DiscordGifItem(
                id: UUID().uuidString,
                title: title ?? "Favorite GIF",
                url: url,
                gifSrc: url,
                preview: url,
                width: nil,
                height: nil
            )
            favorites.insert(item, at: 0)
            save()
            return true
        }
    }

    func addFavorite(_ item: DiscordGifItem) {
        guard !isFavorite(url: item.effectiveGifURL) else { return }
        favorites.insert(item, at: 0)
        save()
    }
}
