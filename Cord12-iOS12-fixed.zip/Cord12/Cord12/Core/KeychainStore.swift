import Foundation
import Security

final class KeychainStore {
    static let shared = KeychainStore()
    private let service = "com.sky.cord12"
    private let tokenAccount = "discord_user_token"
    private let defaultsFallbackKey = "cord12_saved_token_v1"

    private init() {}

    func saveToken(_ token: String) {
        UserDefaults.standard.set(token, forKey: defaultsFallbackKey)
        UserDefaults.standard.synchronize()

        guard let data = token.data(using: .utf8) else { return }
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: tokenAccount
        ]
        SecItemDelete(query as CFDictionary)

        var addQuery = query
        addQuery[kSecValueData as String] = data
        addQuery[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlock
        SecItemAdd(addQuery as CFDictionary, nil)
    }

    func loadToken() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: tokenAccount,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var item: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        if status == errSecSuccess, let data = item as? Data, let str = String(data: data, encoding: .utf8), !str.isEmpty {
            return str
        }
        return UserDefaults.standard.string(forKey: defaultsFallbackKey)
    }

    func clearToken() {
        UserDefaults.standard.removeObject(forKey: defaultsFallbackKey)
        UserDefaults.standard.synchronize()

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: tokenAccount
        ]
        SecItemDelete(query as CFDictionary)
    }
}
