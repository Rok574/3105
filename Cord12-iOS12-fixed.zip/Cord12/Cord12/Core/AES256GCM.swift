import Foundation
import CommonCrypto

/// Pure Swift + CommonCrypto AES-256-GCM implementation for iOS 12+ (where CryptoKit is unavailable).
/// Implements NIST SP 800-38D for Discord's `aead_aes256_gcm_rtpsize` voice packet encryption.
enum AES256GCM {
    static func seal(key: [UInt8], nonce12: [UInt8], plaintext: [UInt8], aad: [UInt8]) -> (ciphertext: [UInt8], tag: [UInt8])? {
        guard key.count == 32, nonce12.count == 12 else { return nil }
        guard let h = aes256ECBBlock(key: key, block: [UInt8](repeating: 0, count: 16)) else { return nil }

        // J0 = nonce12 || 0x00000001
        var j0 = nonce12 + [0, 0, 0, 1]
        var counter = increment32(j0)

        var ciphertext = [UInt8](repeating: 0, count: plaintext.count)
        var offset = 0
        while offset < plaintext.count {
            guard let keystream = aes256ECBBlock(key: key, block: counter) else { return nil }
            let chunk = min(16, plaintext.count - offset)
            for i in 0..<chunk {
                ciphertext[offset + i] = plaintext[offset + i] ^ keystream[i]
            }
            offset += chunk
            counter = increment32(counter)
        }

        let tag = computeTag(key: key, h: h, j0: &j0, aad: aad, ciphertext: ciphertext)
        guard let tag = tag else { return nil }
        return (ciphertext, tag)
    }

    static func open(key: [UInt8], nonce12: [UInt8], ciphertext: [UInt8], tag: [UInt8], aad: [UInt8]) -> [UInt8]? {
        guard key.count == 32, nonce12.count == 12, tag.count == 16 else { return nil }
        guard let h = aes256ECBBlock(key: key, block: [UInt8](repeating: 0, count: 16)) else { return nil }

        var j0 = nonce12 + [0, 0, 0, 1]
        guard let expectedTag = computeTag(key: key, h: h, j0: &j0, aad: aad, ciphertext: ciphertext) else { return nil }

        // Constant-time tag compare
        var diff: UInt8 = 0
        for i in 0..<16 { diff |= expectedTag[i] ^ tag[i] }
        guard diff == 0 else { return nil }

        var counter = increment32(j0)
        var plaintext = [UInt8](repeating: 0, count: ciphertext.count)
        var offset = 0
        while offset < ciphertext.count {
            guard let keystream = aes256ECBBlock(key: key, block: counter) else { return nil }
            let chunk = min(16, ciphertext.count - offset)
            for i in 0..<chunk {
                plaintext[offset + i] = ciphertext[offset + i] ^ keystream[i]
            }
            offset += chunk
            counter = increment32(counter)
        }
        return plaintext
    }

    private static func computeTag(key: [UInt8], h: [UInt8], j0: inout [UInt8], aad: [UInt8], ciphertext: [UInt8]) -> [UInt8]? {
        var s = [UInt8](repeating: 0, count: 16)
        ghashUpdate(&s, h: h, data: aad)
        ghashUpdate(&s, h: h, data: ciphertext)

        var lenBlock = [UInt8](repeating: 0, count: 16)
        let aadBits = UInt64(aad.count) * 8
        let ctBits = UInt64(ciphertext.count) * 8
        for i in 0..<8 {
            lenBlock[i] = UInt8((aadBits >> (56 - i * 8)) & 0xFF)
            lenBlock[8 + i] = UInt8((ctBits >> (56 - i * 8)) & 0xFF)
        }
        for i in 0..<16 { s[i] ^= lenBlock[i] }
        s = gf128Mul(s, h)

        guard let ej0 = aes256ECBBlock(key: key, block: j0) else { return nil }
        var tag = [UInt8](repeating: 0, count: 16)
        for i in 0..<16 { tag[i] = s[i] ^ ej0[i] }
        return tag
    }

    private static func ghashUpdate(_ state: inout [UInt8], h: [UInt8], data: [UInt8]) {
        var offset = 0
        while offset < data.count {
            let chunk = min(16, data.count - offset)
            for i in 0..<chunk {
                state[i] ^= data[offset + i]
            }
            state = gf128Mul(state, h)
            offset += 16
        }
    }

    private static func gf128Mul(_ x: [UInt8], _ y: [UInt8]) -> [UInt8] {
        var z = [UInt8](repeating: 0, count: 16)
        var v = y
        for i in 0..<16 {
            for bit in (0..<8).reversed() {
                if (x[i] >> bit) & 1 != 0 {
                    for k in 0..<16 { z[k] ^= v[k] }
                }
                let lsb = v[15] & 1
                for k in (1..<16).reversed() {
                    v[k] = (v[k] >> 1) | ((v[k - 1] & 1) << 7)
                }
                v[0] >>= 1
                if lsb != 0 {
                    v[0] ^= 0xE1
                }
            }
        }
        return z
    }

    private static func increment32(_ block: [UInt8]) -> [UInt8] {
        var out = block
        for i in (12..<16).reversed() {
            out[i] &+= 1
            if out[i] != 0 { break }
        }
        return out
    }

    private static func aes256ECBBlock(key: [UInt8], block: [UInt8]) -> [UInt8]? {
        var out = [UInt8](repeating: 0, count: 16)
        var numBytes = 0
        let status = CCCrypt(
            CCOperation(kCCEncrypt),
            CCAlgorithm(kCCAlgorithmAES),
            CCOptions(kCCOptionECBMode),
            key, 32,
            nil,
            block, 16,
            &out, 16,
            &numBytes
        )
        return (status == kCCSuccess && numBytes == 16) ? out : nil
    }
}
