import UIKit

protocol GuildChannelListDelegate: AnyObject {
    func guildChannelList(_ vc: GuildChannelListViewController, didSelectChannel channel: DiscordChannel)
}

private enum RailRow {
    case dm
    case separator
    case folderHeader(GuildFolder, [DiscordGuild], isExpanded: Bool)
    case guild(DiscordGuild, inFolder: Bool, folderColor: Int?)
}

private enum ChannelRow {
    case channel(DiscordChannel)
    case voiceParticipant(VoiceState)
}

final class GuildChannelListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, FriendsViewControllerDelegate {
    weak var delegate: GuildChannelListDelegate?

    private let guildTable = UITableView(frame: .zero, style: .plain)
    private let channelPanel = UIView()
    private let channelTable = UITableView(frame: .zero, style: .plain)
    private let headerLabel = UILabel()
    private let friendsButton = UIButton(type: .system)

    // Active Voice Bar
    private let voiceBar = UIView()
    private let voiceStatusLabel = UILabel()
    private let voiceMuteBtn = UIButton(type: .system)
    private let voiceLeaveBtn = UIButton(type: .system)
    private var voiceBarHeightConstraint: NSLayoutConstraint!

    private var selectedGuildId: String? = nil
    private var railRows: [RailRow] = [.dm, .separator]
    private var channelRows: [ChannelRow] = []
    private var collapsedCategories: Set<String> = []
    private var expandedFolders: Set<String> = []

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        applyTheme()
        NotificationCenter.default.addObserver(self, selector: #selector(reloadAll), name: .cordStoreDidUpdateGuilds, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(onVoiceUpdated), name: .cordStoreDidUpdateVoiceStates, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(onVoiceUpdated), name: .cordVoiceStateDidChange, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(onThemeChanged), name: .cordThemeDidChange, object: nil)
        reloadAll()
    }

    private func setupUI() {
        guildTable.dataSource = self
        guildTable.delegate = self
        guildTable.separatorStyle = .none
        guildTable.showsVerticalScrollIndicator = false
        guildTable.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(guildTable)

        channelPanel.layer.cornerRadius = 16
        if #available(iOS 11.0, *) {
            channelPanel.layer.maskedCorners = [.layerMinXMinYCorner]
        }
        channelPanel.clipsToBounds = true
        channelPanel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(channelPanel)

        headerLabel.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        headerLabel.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        headerLabel.translatesAutoresizingMaskIntoConstraints = false
        channelPanel.addSubview(headerLabel)

        friendsButton.setImage(DiscordIcons.image(.members, size: 18), for: .normal)
        friendsButton.layer.cornerRadius = 15
        friendsButton.addTarget(self, action: #selector(friendsTapped), for: .touchUpInside)
        friendsButton.translatesAutoresizingMaskIntoConstraints = false
        channelPanel.addSubview(friendsButton)

        channelTable.dataSource = self
        channelTable.delegate = self
        channelTable.separatorStyle = .none
        channelTable.translatesAutoresizingMaskIntoConstraints = false
        channelPanel.addSubview(channelTable)

        voiceBar.clipsToBounds = true
        voiceBar.translatesAutoresizingMaskIntoConstraints = false
        voiceBar.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(voiceBarTapped)))
        channelPanel.addSubview(voiceBar)
        voiceBarHeightConstraint = voiceBar.heightAnchor.constraint(equalToConstant: 0)

        voiceStatusLabel.font = UIFont.systemFont(ofSize: 12, weight: .semibold)
        voiceStatusLabel.translatesAutoresizingMaskIntoConstraints = false
        voiceBar.addSubview(voiceStatusLabel)

        voiceMuteBtn.setImage(DiscordIcons.image(.mic, size: 16), for: .normal)
        voiceMuteBtn.addTarget(self, action: #selector(voiceMuteTapped), for: .touchUpInside)
        voiceMuteBtn.translatesAutoresizingMaskIntoConstraints = false
        voiceBar.addSubview(voiceMuteBtn)

        voiceLeaveBtn.setImage(DiscordIcons.image(.phoneOff, size: 16), for: .normal)
        voiceLeaveBtn.tintColor = UIColor(hex: 0xDA373C)
        voiceLeaveBtn.addTarget(self, action: #selector(voiceLeaveTapped), for: .touchUpInside)
        voiceLeaveBtn.translatesAutoresizingMaskIntoConstraints = false
        voiceBar.addSubview(voiceLeaveBtn)

        let topAnchorRef: NSLayoutYAxisAnchor
        if #available(iOS 11.0, *) {
            topAnchorRef = view.safeAreaLayoutGuide.topAnchor
        } else {
            topAnchorRef = view.topAnchor
        }

        NSLayoutConstraint.activate([
            guildTable.topAnchor.constraint(equalTo: topAnchorRef),
            guildTable.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            guildTable.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            guildTable.widthAnchor.constraint(equalToConstant: 70),

            channelPanel.topAnchor.constraint(equalTo: topAnchorRef, constant: 4),
            channelPanel.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            channelPanel.leadingAnchor.constraint(equalTo: guildTable.trailingAnchor),
            channelPanel.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            headerLabel.topAnchor.constraint(equalTo: channelPanel.topAnchor, constant: 14),
            headerLabel.leadingAnchor.constraint(equalTo: channelPanel.leadingAnchor, constant: 14),
            headerLabel.trailingAnchor.constraint(lessThanOrEqualTo: friendsButton.leadingAnchor, constant: -8),
            headerLabel.heightAnchor.constraint(equalToConstant: 26),

            friendsButton.centerYAnchor.constraint(equalTo: headerLabel.centerYAnchor),
            friendsButton.trailingAnchor.constraint(equalTo: channelPanel.trailingAnchor, constant: -12),
            friendsButton.widthAnchor.constraint(equalToConstant: 30),
            friendsButton.heightAnchor.constraint(equalToConstant: 30),

            channelTable.topAnchor.constraint(equalTo: headerLabel.bottomAnchor, constant: 8),
            channelTable.bottomAnchor.constraint(equalTo: voiceBar.topAnchor),
            channelTable.leadingAnchor.constraint(equalTo: channelPanel.leadingAnchor),
            channelTable.trailingAnchor.constraint(equalTo: channelPanel.trailingAnchor),

            voiceBar.leadingAnchor.constraint(equalTo: channelPanel.leadingAnchor),
            voiceBar.trailingAnchor.constraint(equalTo: channelPanel.trailingAnchor),
            voiceBar.bottomAnchor.constraint(equalTo: channelPanel.bottomAnchor),
            voiceBarHeightConstraint,

            voiceStatusLabel.leadingAnchor.constraint(equalTo: voiceBar.leadingAnchor, constant: 12),
            voiceStatusLabel.centerYAnchor.constraint(equalTo: voiceBar.centerYAnchor),
            voiceStatusLabel.trailingAnchor.constraint(lessThanOrEqualTo: voiceMuteBtn.leadingAnchor, constant: -8),

            voiceMuteBtn.centerYAnchor.constraint(equalTo: voiceBar.centerYAnchor),
            voiceMuteBtn.trailingAnchor.constraint(equalTo: voiceLeaveBtn.leadingAnchor, constant: -10),
            voiceMuteBtn.widthAnchor.constraint(equalToConstant: 28),
            voiceMuteBtn.heightAnchor.constraint(equalToConstant: 28),

            voiceLeaveBtn.centerYAnchor.constraint(equalTo: voiceBar.centerYAnchor),
            voiceLeaveBtn.trailingAnchor.constraint(equalTo: voiceBar.trailingAnchor, constant: -12),
            voiceLeaveBtn.widthAnchor.constraint(equalToConstant: 28),
            voiceLeaveBtn.heightAnchor.constraint(equalToConstant: 28)
        ])
    }

    @objc private func onThemeChanged() {
        applyTheme()
        guildTable.reloadData()
        channelTable.reloadData()
    }

    private func applyTheme() {
        let t = ThemeManager.shared.current
        view.backgroundColor = t.backgroundTertiary
        guildTable.backgroundColor = t.backgroundTertiary
        channelPanel.backgroundColor = t.backgroundSecondary
        channelTable.backgroundColor = t.backgroundSecondary
        headerLabel.textColor = t.textPrimary
        friendsButton.backgroundColor = t.surfaceCard
        friendsButton.tintColor = t.textPrimary
        voiceBar.backgroundColor = t.backgroundTertiary
        voiceStatusLabel.textColor = UIColor(hex: 0x23A55A)
        voiceMuteBtn.tintColor = t.textPrimary
    }

    @objc private func friendsTapped() {
        let vc = FriendsViewController()
        vc.delegate = self
        present(UINavigationController(rootViewController: vc), animated: true)
    }

    @objc private func onVoiceUpdated() {
        let vc = DiscordVoiceClient.shared
        if let _ = vc.channelId {
            voiceBarHeightConstraint.constant = 46
            voiceStatusLabel.text = "\(vc.phase.rawValue) • \(vc.channelName)"
            voiceMuteBtn.setImage(DiscordIcons.image(vc.isMuted ? .micOff : .mic, size: 16), for: .normal)
            voiceMuteBtn.tintColor = vc.isMuted ? UIColor(hex: 0xDA373C) : ThemeManager.shared.current.textPrimary
        } else {
            voiceBarHeightConstraint.constant = 0
        }
        refreshChannelList()
    }

    @objc private func voiceBarTapped() {
        guard let cid = DiscordVoiceClient.shared.channelId,
              let gid = DiscordVoiceClient.shared.guildId,
              let ch = DiscordStore.shared.channelsByGuild[gid]?.first(where: { $0.id == cid }) else { return }
        let vc = VoiceCallViewController(channel: ch)
        present(UINavigationController(rootViewController: vc), animated: true)
    }

    @objc private func voiceMuteTapped() {
        DiscordVoiceClient.shared.setMuted(!DiscordVoiceClient.shared.isMuted)
        DiscordStore.shared.syncLocalVoiceMuteDeaf()
    }

    @objc private func voiceLeaveTapped() {
        DiscordStore.shared.leaveVoiceChannel()
    }

    @objc private func reloadAll() {
        rebuildRailRows()
        guildTable.reloadData()
        refreshChannelList()
    }

    private func rebuildRailRows() {
        var rows: [RailRow] = [.dm, .separator]
        for item in DiscordStore.shared.orderedServerItems {
            switch item {
            case .guild(let g):
                rows.append(.guild(g, inFolder: false, folderColor: nil))
            case .folder(let folder, let guilds):
                let isExp = expandedFolders.contains(folder.folderKey)
                rows.append(.folderHeader(folder, guilds, isExpanded: isExp))
                if isExp {
                    for g in guilds {
                        rows.append(.guild(g, inFolder: true, folderColor: folder.color))
                    }
                }
            }
        }
        self.railRows = rows
    }

    private func refreshChannelList() {
        if let gid = selectedGuildId {
            friendsButton.isHidden = true
            let guild = DiscordStore.shared.guilds.first(where: { $0.id == gid })
            headerLabel.text = guild?.name ?? "Server"
            DiscordStore.shared.loadChannelsIfNeeded(guildId: gid) { [weak self] channels in
                guard let self = self else { return }
                let filtered = channels.filter { ch in
                    let validType = (ch.type == 0 || ch.type == 2 || ch.type == 4 || ch.type == 5)
                    guard validType else { return false }
                    if ch.type == 4 { return true }
                    if let pid = ch.parentId, self.collapsedCategories.contains(pid) { return false }
                    return true
                }
                var rows: [ChannelRow] = []
                for ch in filtered {
                    rows.append(.channel(ch))
                    if ch.type == 2, let vstates = DiscordStore.shared.voiceStatesByChannel[ch.id] {
                        for vs in vstates {
                            rows.append(.voiceParticipant(vs))
                        }
                    }
                }
                self.channelRows = rows
                self.channelTable.reloadData()
            }
        } else {
            friendsButton.isHidden = false
            headerLabel.text = "Messages"
            channelRows = DiscordStore.shared.dmChannels.map { .channel($0) }
            channelTable.reloadData()
        }
    }

    func friendsViewController(_ vc: FriendsViewController, didOpenDM channel: DiscordChannel) {
        delegate?.guildChannelList(self, didSelectChannel: channel)
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView === guildTable {
            return railRows.count
        }
        return channelRows.count
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView === guildTable {
            if case .separator = railRows[indexPath.row] { return 10 }
            return 56
        }
        switch channelRows[indexPath.row] {
        case .channel(let ch):
            if ch.type == 1 || ch.type == 3 { return 54 }
            return ch.type == 4 ? 30 : 38
        case .voiceParticipant:
            return 28
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let t = ThemeManager.shared.current
        if tableView === guildTable {
            let cell = tableView.dequeueReusableCell(withIdentifier: "GuildCell") ?? UITableViewCell(style: .default, reuseIdentifier: "GuildCell")
            cell.backgroundColor = .clear
            cell.selectionStyle = .none
            cell.contentView.subviews.forEach { $0.removeFromSuperview() }

            switch railRows[indexPath.row] {
            case .separator:
                let line = UIView(frame: CGRect(x: 19, y: 4, width: 32, height: 2))
                line.backgroundColor = t.separator
                line.layer.cornerRadius = 1
                cell.contentView.addSubview(line)
                return cell

            case .dm:
                let btn = UIImageView(frame: CGRect(x: 11, y: 4, width: 48, height: 48))
                btn.layer.cornerRadius = selectedGuildId == nil ? 16 : 24
                btn.clipsToBounds = true
                btn.image = DiscordIcons.image(.dm, size: 22, color: .white, template: false)
                btn.contentMode = .center
                btn.backgroundColor = selectedGuildId == nil ? t.accent : t.surfaceCard
                if selectedGuildId == nil {
                    let pill = UIView(frame: CGRect(x: 0, y: 10, width: 4, height: 36))
                    pill.backgroundColor = .white
                    pill.layer.cornerRadius = 2
                    cell.contentView.addSubview(pill)
                }
                cell.contentView.addSubview(btn)
                return cell

            case .folderHeader(let folder, let guilds, let isExpanded):
                let folderColor = folder.color.map { UIColor(hex: $0) } ?? t.accent
                let box = UIView(frame: CGRect(x: 11, y: 4, width: 48, height: 48))
                box.layer.cornerRadius = 16
                box.clipsToBounds = true
                box.backgroundColor = folderColor.withAlphaComponent(0.24)
                cell.contentView.addSubview(box)

                if isExpanded {
                    let iv = UIImageView(frame: CGRect(x: 13, y: 13, width: 22, height: 22))
                    iv.image = DiscordIcons.image(.folder, size: 22)
                    iv.tintColor = folderColor
                    box.addSubview(iv)
                } else {
                    for (idx, g) in guilds.prefix(4).enumerated() {
                        let col = idx % 2
                        let row = idx / 2
                        let mini = UIImageView(frame: CGRect(x: 6 + col * 19, y: 6 + row * 19, width: 17, height: 17))
                        mini.layer.cornerRadius = 8.5
                        mini.clipsToBounds = true
                        mini.backgroundColor = t.surfaceCard
                        mini.contentMode = .scaleAspectFill
                        if let url = g.iconURL(size: 64) {
                            ImageLoader.shared.load(urlString: url, maxPixelSize: 32, animated: false) { img in
                                mini.image = img
                            }
                        }
                        box.addSubview(mini)
                    }
                    if let sel = selectedGuildId, guilds.contains(where: { $0.id == sel }) {
                        let pill = UIView(frame: CGRect(x: 0, y: 10, width: 4, height: 36))
                        pill.backgroundColor = .white
                        pill.layer.cornerRadius = 2
                        cell.contentView.addSubview(pill)
                    }
                }
                return cell

            case .guild(let guild, let inFolder, let folderColor):
                if inFolder {
                    let bg = UIView(frame: CGRect(x: 8, y: 0, width: 54, height: 56))
                    let tint = folderColor.map { UIColor(hex: $0) } ?? t.surfaceCard
                    bg.backgroundColor = tint.withAlphaComponent(0.14)
                    cell.contentView.addSubview(bg)
                }

                let btn = UIImageView(frame: CGRect(x: 11, y: 4, width: 48, height: 48))
                btn.layer.cornerRadius = (selectedGuildId == guild.id) ? 16 : 24
                btn.clipsToBounds = true
                btn.contentMode = .scaleAspectFill
                btn.backgroundColor = t.surfaceCard

                if selectedGuildId == guild.id {
                    let pill = UIView(frame: CGRect(x: 0, y: 10, width: 4, height: 36))
                    pill.backgroundColor = .white
                    pill.layer.cornerRadius = 2
                    cell.contentView.addSubview(pill)
                }
                if let url = guild.iconURL(size: 128) {
                    ImageLoader.shared.load(urlString: url, maxPixelSize: 128, animated: true) { img in
                        btn.image = img
                    }
                } else {
                    let lbl = UILabel(frame: btn.bounds)
                    lbl.text = String(guild.name.prefix(2)).uppercased()
                    lbl.textColor = t.textPrimary
                    lbl.font = UIFont.systemFont(ofSize: 15, weight: .bold)
                    lbl.textAlignment = .center
                    btn.addSubview(lbl)
                }
                cell.contentView.addSubview(btn)
                return cell
            }
        }

        let cell = tableView.dequeueReusableCell(withIdentifier: "ChanCell") ?? UITableViewCell(style: .default, reuseIdentifier: "ChanCell")
        cell.backgroundColor = .clear
        cell.contentView.subviews.forEach { $0.removeFromSuperview() }
        cell.textLabel?.text = nil
        cell.imageView?.image = nil

        switch channelRows[indexPath.row] {
        case .voiceParticipant(let vs):
            let user = DiscordStore.shared.usersById[vs.userId]
            let av = AvatarWithDecorationView(frame: CGRect(x: 34, y: 4, width: 20, height: 20))
            av.showsStatusDot = false
            av.configure(user: user, status: nil, pixelSize: 32)
            cell.contentView.addSubview(av)

            let lbl = UILabel(frame: CGRect(x: 62, y: 4, width: tableView.bounds.width - 74, height: 20))
            lbl.text = user?.effectiveDisplayName ?? "User"
            lbl.font = UIFont.systemFont(ofSize: 13)
            lbl.textColor = t.textSecondary
            cell.contentView.addSubview(lbl)
            return cell

        case .channel(let ch):
            if ch.type == 1 || ch.type == 3 {
                let rec = ch.resolvedRecipients.first
                let nameplate = NameplateBannerView(frame: CGRect(x: 8, y: 3, width: tableView.bounds.width - 16, height: 48))
                nameplate.configure(nameplate: rec?.collectibles?.nameplate)
                cell.contentView.addSubview(nameplate)

                let av = AvatarWithDecorationView(frame: CGRect(x: 14, y: 9, width: 36, height: 36))
                let status = rec.flatMap { DiscordStore.shared.presencesByUserId[$0.id] }
                av.configure(user: rec, status: status, pixelSize: 64)
                cell.contentView.addSubview(av)

                let nameLbl = StyledNameLabel(frame: CGRect(x: 58, y: 9, width: tableView.bounds.width - 70, height: 20))
                nameLbl.baseFontSize = 15
                nameLbl.defaultColor = t.textPrimary
                nameLbl.style = rec?.displayNameStyles
                nameLbl.text = ch.displayName
                cell.contentView.addSubview(nameLbl)

                let subLbl = UILabel(frame: CGRect(x: 58, y: 29, width: tableView.bounds.width - 70, height: 16))
                subLbl.text = ch.type == 3 ? "\(ch.resolvedRecipients.count + 1) Members" : (rec.map { "@\($0.username)" } ?? "Direct Message")
                subLbl.font = UIFont.systemFont(ofSize: 12)
                subLbl.textColor = rec?.collectibles?.nameplate != nil ? UIColor.white.withAlphaComponent(0.85) : t.textMuted
                cell.contentView.addSubview(subLbl)
                return cell
            }

            if ch.type == 4 {
                let isCollapsed = collapsedCategories.contains(ch.id)
                let chev = UIImageView(frame: CGRect(x: 10, y: 9, width: 12, height: 12))
                chev.image = DiscordIcons.image(isCollapsed ? .chevronRight : .chevronDown, size: 12)
                chev.tintColor = t.textMuted
                cell.contentView.addSubview(chev)

                let lbl = UILabel(frame: CGRect(x: 26, y: 5, width: tableView.bounds.width - 34, height: 20))
                lbl.text = ch.displayName.uppercased()
                lbl.font = UIFont.systemFont(ofSize: 11, weight: .bold)
                lbl.textColor = t.textMuted
                cell.contentView.addSubview(lbl)
            } else {
                let iconKind: DiscordIcons.Kind = ch.isLockedForEveryone ? .lock : (ch.type == 2 ? .speaker : .hash)
                let iv = UIImageView(frame: CGRect(x: 14, y: 10, width: 18, height: 18))
                iv.image = DiscordIcons.image(iconKind, size: 18)
                iv.tintColor = t.textMuted
                cell.contentView.addSubview(iv)

                let lbl = UILabel(frame: CGRect(x: 40, y: 8, width: tableView.bounds.width - 52, height: 22))
                lbl.text = ch.displayName
                lbl.font = UIFont.systemFont(ofSize: 15, weight: .medium)
                lbl.textColor = (DiscordVoiceClient.shared.channelId == ch.id) ? UIColor(hex: 0x23A55A) : t.textSecondary
                cell.contentView.addSubview(lbl)
            }
            return cell
        }
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView === guildTable {
            switch railRows[indexPath.row] {
            case .separator:
                return
            case .dm:
                selectedGuildId = nil
                guildTable.reloadData()
                refreshChannelList()
            case .folderHeader(let folder, _, _):
                let key = folder.folderKey
                if expandedFolders.contains(key) {
                    expandedFolders.remove(key)
                } else {
                    expandedFolders.insert(key)
                }
                rebuildRailRows()
                guildTable.reloadData()
            case .guild(let g, _, _):
                selectedGuildId = g.id
                guildTable.reloadData()
                refreshChannelList()
            }
            return
        }

        tableView.deselectRow(at: indexPath, animated: true)
        switch channelRows[indexPath.row] {
        case .voiceParticipant:
            return
        case .channel(let ch):
            if ch.type == 4 {
                if collapsedCategories.contains(ch.id) {
                    collapsedCategories.remove(ch.id)
                } else {
                    collapsedCategories.insert(ch.id)
                }
                refreshChannelList()
                return
            }
            if ch.type == 2 {
                if DiscordVoiceClient.shared.channelId != ch.id {
                    DiscordStore.shared.joinVoiceChannel(ch)
                }
                let vc = VoiceCallViewController(channel: ch)
                present(UINavigationController(rootViewController: vc), animated: true)
                return
            }
            delegate?.guildChannelList(self, didSelectChannel: ch)
        }
    }
}
