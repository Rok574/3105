import UIKit

/// Root container managing the 3 main tabs (Home, Notifications, You) + full-screen slide-over Chat drawer
/// using explicit Auto Layout constraints and a solid UITabBar so nothing bleeds behind it on iOS 12.
final class MainContainerViewController: UIViewController, UITabBarDelegate, GuildChannelListDelegate, ChatViewControllerDelegate {
    private let contentContainer = UIView()
    private let tabBar = UITabBar()
    private var tabBarHeightConstraint: NSLayoutConstraint!

    private let drawerContainer = UIViewController()
    private let guildListVC = GuildChannelListViewController()
    private let chatVC = ChatViewController()
    private lazy var chatNav = UINavigationController(rootViewController: chatVC)
    private let dimOverlay = UIView()

    private lazy var notifVC = NotificationsViewController()
    private lazy var notifNav = UINavigationController(rootViewController: notifVC)

    private lazy var profileVC = UserProfileViewController(userId: nil, guildId: nil, initialUser: DiscordStore.shared.currentUser)
    private lazy var profileNav = UINavigationController(rootViewController: profileVC)

    private var activeTabController: UIViewController?
    private var drawerLeadingConstraint: NSLayoutConstraint!
    private var isDrawerOpen = true

    private lazy var homeItem = UITabBarItem(title: "Home", image: DiscordIcons.image(.servers, size: 21), tag: 0)
    private lazy var notifItem = UITabBarItem(title: "Notifications", image: DiscordIcons.image(.bell, size: 21), tag: 1)
    private lazy var profileItem = UITabBarItem(title: "You", image: DiscordIcons.image(.person, size: 21), tag: 2)

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return ThemeManager.shared.current.isDark ? .lightContent : .default
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupContainer()
        setupDrawer()
        applyTheme()
        selectTab(index: 0)
        NotificationCenter.default.addObserver(self, selector: #selector(applyTheme), name: .cordThemeDidChange, object: nil)
    }

    private func setupContainer() {
        contentContainer.clipsToBounds = true
        contentContainer.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(contentContainer)

        tabBar.delegate = self
        tabBar.items = [homeItem, notifItem, profileItem]
        tabBar.selectedItem = homeItem
        tabBar.isTranslucent = false
        tabBar.clipsToBounds = true
        tabBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tabBar)

        let bottomRef: NSLayoutYAxisAnchor
        if #available(iOS 11.0, *) {
            bottomRef = view.safeAreaLayoutGuide.bottomAnchor
        } else {
            bottomRef = view.bottomAnchor
        }
        tabBarHeightConstraint = tabBar.heightAnchor.constraint(equalToConstant: 49)

        NSLayoutConstraint.activate([
            contentContainer.topAnchor.constraint(equalTo: view.topAnchor),
            contentContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            contentContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            contentContainer.bottomAnchor.constraint(equalTo: tabBar.topAnchor),

            tabBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tabBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tabBar.bottomAnchor.constraint(equalTo: bottomRef),
            tabBarHeightConstraint
        ])
    }

    private func setupDrawer() {
        guildListVC.delegate = self
        chatVC.delegate = self

        drawerContainer.addChild(guildListVC)
        drawerContainer.view.addSubview(guildListVC.view)
        guildListVC.didMove(toParent: drawerContainer)

        drawerContainer.addChild(chatNav)
        drawerContainer.view.addSubview(chatNav.view)
        chatNav.didMove(toParent: drawerContainer)

        dimOverlay.backgroundColor = UIColor.black.withAlphaComponent(0.55)
        dimOverlay.alpha = 1.0
        dimOverlay.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(closeDrawerTapped)))
        dimOverlay.translatesAutoresizingMaskIntoConstraints = false
        chatNav.view.addSubview(dimOverlay)

        guildListVC.view.translatesAutoresizingMaskIntoConstraints = false
        chatNav.view.translatesAutoresizingMaskIntoConstraints = false

        let drawerWidth: CGFloat = min(318, UIScreen.main.bounds.width * 0.86)
        drawerLeadingConstraint = chatNav.view.leadingAnchor.constraint(equalTo: drawerContainer.view.leadingAnchor, constant: drawerWidth)

        NSLayoutConstraint.activate([
            guildListVC.view.topAnchor.constraint(equalTo: drawerContainer.view.topAnchor),
            guildListVC.view.bottomAnchor.constraint(equalTo: drawerContainer.view.bottomAnchor),
            guildListVC.view.leadingAnchor.constraint(equalTo: drawerContainer.view.leadingAnchor),
            guildListVC.view.widthAnchor.constraint(equalToConstant: drawerWidth),

            chatNav.view.topAnchor.constraint(equalTo: drawerContainer.view.topAnchor),
            chatNav.view.bottomAnchor.constraint(equalTo: drawerContainer.view.bottomAnchor),
            drawerLeadingConstraint,
            chatNav.view.widthAnchor.constraint(equalTo: drawerContainer.view.widthAnchor),

            dimOverlay.topAnchor.constraint(equalTo: chatNav.view.topAnchor),
            dimOverlay.bottomAnchor.constraint(equalTo: chatNav.view.bottomAnchor),
            dimOverlay.leadingAnchor.constraint(equalTo: chatNav.view.leadingAnchor),
            dimOverlay.trailingAnchor.constraint(equalTo: chatNav.view.trailingAnchor)
        ])

        let edgePan = UIScreenEdgePanGestureRecognizer(target: self, action: #selector(handleEdgePan(_:)))
        edgePan.edges = .left
        chatNav.view.addGestureRecognizer(edgePan)
    }

    private func selectTab(index: Int) {
        let target: UIViewController
        switch index {
        case 1: target = notifNav
        case 2: target = profileNav
        default: target = drawerContainer
        }
        if activeTabController === target { return }

        if let current = activeTabController {
            current.willMove(toParent: nil)
            current.view.removeFromSuperview()
            current.removeFromParent()
        }

        addChild(target)
        target.view.translatesAutoresizingMaskIntoConstraints = false
        contentContainer.addSubview(target.view)
        NSLayoutConstraint.activate([
            target.view.topAnchor.constraint(equalTo: contentContainer.topAnchor),
            target.view.bottomAnchor.constraint(equalTo: contentContainer.bottomAnchor),
            target.view.leadingAnchor.constraint(equalTo: contentContainer.leadingAnchor),
            target.view.trailingAnchor.constraint(equalTo: contentContainer.trailingAnchor)
        ])
        target.didMove(toParent: self)
        activeTabController = target
    }

    func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        selectTab(index: item.tag)
    }

    @objc private func applyTheme() {
        let t = ThemeManager.shared.current
        view.backgroundColor = t.backgroundPrimary
        tabBar.backgroundColor = t.backgroundSecondary
        tabBar.barTintColor = t.backgroundSecondary
        tabBar.isTranslucent = false
        tabBar.tintColor = t.textPrimary
        if #available(iOS 10.0, *) {
            tabBar.unselectedItemTintColor = t.textMuted
        }
        setNeedsStatusBarAppearanceUpdate()
    }

    private func setDrawerOpen(_ open: Bool, animated: Bool = true) {
        isDrawerOpen = open
        let drawerWidth: CGFloat = min(318, UIScreen.main.bounds.width * 0.86)
        drawerLeadingConstraint.constant = open ? drawerWidth : 0
        tabBarHeightConstraint.constant = open ? 49 : 0
        tabBar.isHidden = !open
        dimOverlay.isUserInteractionEnabled = open
        if animated {
            UIView.animate(withDuration: 0.22, delay: 0, options: .curveEaseOut, animations: {
                self.dimOverlay.alpha = open ? 1.0 : 0.0
                self.view.layoutIfNeeded()
            })
        } else {
            dimOverlay.alpha = open ? 1.0 : 0.0
            view.layoutIfNeeded()
        }
    }

    @objc private func closeDrawerTapped() {
        setDrawerOpen(false)
    }

    @objc private func handleEdgePan(_ gr: UIScreenEdgePanGestureRecognizer) {
        if gr.state == .ended {
            setDrawerOpen(true)
        }
    }

    func guildChannelList(_ vc: GuildChannelListViewController, didSelectChannel channel: DiscordChannel) {
        chatVC.loadChannel(channel)
        setDrawerOpen(false)
    }

    func chatViewControllerDidTapMenu(_ vc: ChatViewController) {
        setDrawerOpen(!isDrawerOpen)
    }
}
