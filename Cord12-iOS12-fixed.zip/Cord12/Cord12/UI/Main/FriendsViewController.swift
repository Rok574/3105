import UIKit

protocol FriendsViewControllerDelegate: AnyObject {
    func friendsViewController(_ vc: FriendsViewController, didOpenDM channel: DiscordChannel)
}

final class FriendsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    weak var delegate: FriendsViewControllerDelegate?

    private let tableView = UITableView(frame: .zero, style: .plain)
    private var relationships: [DiscordRelationship] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Friends"
        let t = ThemeManager.shared.current
        view.backgroundColor = t.backgroundPrimary
        navigationController?.navigationBar.barTintColor = t.backgroundSecondary
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.tintColor = t.textPrimary
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: t.textPrimary]

        navigationItem.leftBarButtonItem = UIBarButtonItem(
            image: DiscordIcons.image(.close, size: 18),
            style: .plain,
            target: self,
            action: #selector(closeTapped)
        )
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            image: DiscordIcons.image(.plus, size: 20),
            style: .plain,
            target: self,
            action: #selector(addFriendTapped)
        )

        tableView.dataSource = self
        tableView.delegate = self
        tableView.backgroundColor = .clear
        tableView.separatorColor = t.separator
        tableView.rowHeight = 58
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        loadRelationships()
    }

    private func loadRelationships() {
        DiscordRESTClient.shared.fetchRelationships { [weak self] res in
            if case .success(let list) = res {
                self?.relationships = list.filter { $0.type == 1 || $0.type == 3 || $0.type == 4 }
                self?.tableView.reloadData()
            }
        }
    }

    @objc private func closeTapped() {
        dismiss(animated: true)
    }

    @objc private func addFriendTapped() {
        let alert = UIAlertController(title: "Add Friend", message: "Enter their Discord username:", preferredStyle: .alert)
        alert.addTextField { tf in
            tf.placeholder = "username"
            tf.autocapitalizationType = .none
        }
        alert.addAction(UIAlertAction(title: "Send Request", style: .default) { [weak self] _ in
            let name = alert.textFields?.first?.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            guard !name.isEmpty else { return }
            DiscordRESTClient.shared.sendFriendRequest(username: name) { err in
                let msg = err == nil ? "Friend request sent to @\(name)." : err!.localizedDescription
                let done = UIAlertController(title: "Friends", message: msg, preferredStyle: .alert)
                done.addAction(UIAlertAction(title: "OK", style: .default))
                self?.present(done, animated: true)
                self?.loadRelationships()
            }
        })
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return relationships.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let t = ThemeManager.shared.current
        let cell = tableView.dequeueReusableCell(withIdentifier: "FriendCell") ?? UITableViewCell(style: .default, reuseIdentifier: "FriendCell")
        cell.backgroundColor = .clear
        cell.contentView.subviews.forEach { $0.removeFromSuperview() }

        let rel = relationships[indexPath.row]
        let status = DiscordStore.shared.presencesByUserId[rel.user.id] ?? "offline"
        let av = AvatarWithDecorationView(frame: CGRect(x: 14, y: 11, width: 36, height: 36))
        av.configure(user: rel.user, status: status, pixelSize: 64)
        cell.contentView.addSubview(av)

        let nameLbl = UILabel(frame: CGRect(x: 60, y: 10, width: tableView.bounds.width - 74, height: 20))
        nameLbl.text = rel.user.effectiveDisplayName
        nameLbl.textColor = t.textPrimary
        nameLbl.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
        cell.contentView.addSubview(nameLbl)

        let relLabel = rel.type == 3 ? "Incoming Request" : (rel.type == 4 ? "Outgoing Request" : status.capitalized)
        let subLbl = UILabel(frame: CGRect(x: 60, y: 31, width: tableView.bounds.width - 74, height: 16))
        subLbl.text = "@\(rel.user.username) • \(relLabel)"
        subLbl.textColor = t.textMuted
        subLbl.font = UIFont.systemFont(ofSize: 12)
        cell.contentView.addSubview(subLbl)
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let rel = relationships[indexPath.row]
        DiscordRESTClient.shared.createDM(recipientId: rel.user.id) { [weak self] res in
            guard let self = self else { return }
            if case .success(let channel) = res {
                self.dismiss(animated: true) {
                    self.delegate?.friendsViewController(self, didOpenDM: channel)
                }
            }
        }
    }
}
