import UIKit

final class NotificationsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private let tableView = UITableView(frame: .zero, style: .plain)
    private var mentions: [DiscordMessage] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Notifications"
        let t = ThemeManager.shared.current
        view.backgroundColor = t.backgroundPrimary
        navigationController?.navigationBar.barTintColor = t.backgroundSecondary
        navigationController?.navigationBar.tintColor = t.textPrimary
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: t.textPrimary]
        navigationController?.navigationBar.isTranslucent = false

        tableView.dataSource = self
        tableView.delegate = self
        tableView.backgroundColor = .clear
        tableView.separatorColor = t.separator
        tableView.estimatedRowHeight = 68
        tableView.rowHeight = UITableView.automaticDimension
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)

        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        loadMentions()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadMentions()
    }

    private func loadMentions() {
        DiscordRESTClient.shared.requestDecodable(path: "/users/@me/mentions?limit=30") { [weak self] (res: Result<[DiscordMessage], Error>) in
            if case .success(let list) = res {
                self?.mentions = list
                self?.tableView.reloadData()
            }
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mentions.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let t = ThemeManager.shared.current
        let cell = tableView.dequeueReusableCell(withIdentifier: "NotifCell") ?? UITableViewCell(style: .subtitle, reuseIdentifier: "NotifCell")
        cell.backgroundColor = .clear
        let m = mentions[indexPath.row]
        cell.textLabel?.text = "@\(m.author.effectiveDisplayName) mentioned you"
        cell.textLabel?.textColor = t.textPrimary
        cell.textLabel?.font = UIFont.systemFont(ofSize: 14, weight: .bold)
        cell.detailTextLabel?.text = m.content
        cell.detailTextLabel?.textColor = t.textSecondary
        cell.detailTextLabel?.numberOfLines = 2
        cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 13)
        return cell
    }
}
