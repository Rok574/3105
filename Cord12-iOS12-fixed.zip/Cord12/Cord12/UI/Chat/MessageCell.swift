import UIKit

protocol MessageCellDelegate: AnyObject {
    func messageCell(_ cell: MessageCell, didTapAuthor user: DiscordUser)
    func messageCell(_ cell: MessageCell, didTapImageURL url: String, isGif: Bool)
    func messageCell(_ cell: MessageCell, didTapVideoURL url: String)
    func messageCell(_ cell: MessageCell, didTapLinkURL url: URL)
    func messageCell(_ cell: MessageCell, didTapInviteCode code: String)
    func messageCell(_ cell: MessageCell, didToggleReaction reaction: DiscordReaction, message: DiscordMessage)
    func messageCell(_ cell: MessageCell, didTapAddReaction message: DiscordMessage)
    func messageCell(_ cell: MessageCell, didVotePoll answerId: Int, message: DiscordMessage)
    func messageCellNeedsRelayout(_ cell: MessageCell)
}

final class MessageCell: UITableViewCell {
    static let reuseID = "Cord12MessageCell"

    weak var delegate: MessageCellDelegate?
    private var message: DiscordMessage?
    private var currentMediaURL: String?

    private let mentionBar = UIView()
    private let replyBar = UILabel()
    private let avatarView = AvatarWithDecorationView()
    private let nameLabel = StyledNameLabel()
    private let timeLabel = UILabel()
    private let bodyLabel = UILabel()

    private let mediaContainer = UIView()
    private let mediaImageView = UIImageView()
    private let videoPlayBadge = UIImageView()
    private let gifBadge = UILabel()

    private let embedCard = UIView()
    private let embedAccentBar = UIView()
    private let embedTitleLabel = UILabel()
    private let embedDescLabel = UILabel()
    private let embedImageView = UIImageView()

    private let pollCard = UIView()
    private let pollStack = UIStackView()

    private let reactionsScroll = UIScrollView()
    private let reactionsStack = UIStackView()

    private var replyTopConstraint: NSLayoutConstraint!
    private var replyHeightConstraint: NSLayoutConstraint!
    private var avatarTopConstraint: NSLayoutConstraint!
    private var headerHeightConstraint: NSLayoutConstraint!
    private var bodyTopConstraint: NSLayoutConstraint!
    private var mediaTopConstraint: NSLayoutConstraint!
    private var mediaHeightConstraint: NSLayoutConstraint!
    private var embedTopConstraint: NSLayoutConstraint!
    private var embedZeroHeightConstraint: NSLayoutConstraint!
    private var embedImageHeightConstraint: NSLayoutConstraint!
    private var pollTopConstraint: NSLayoutConstraint!
    private var pollZeroHeightConstraint: NSLayoutConstraint!
    private var reactionsTopConstraint: NSLayoutConstraint!
    private var reactionsHeightConstraint: NSLayoutConstraint!
    private var bottomConstraint: NSLayoutConstraint!
    private var avatarMinBottomConstraint: NSLayoutConstraint!

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupUI() {
        selectionStyle = .none
        backgroundColor = .clear
        contentView.backgroundColor = .clear

        mentionBar.backgroundColor = UIColor(hex: 0xF0B232)
        mentionBar.isHidden = true
        mentionBar.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(mentionBar)

        replyBar.font = UIFont.systemFont(ofSize: 12)
        replyBar.numberOfLines = 1
        replyBar.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(replyBar)

        avatarView.translatesAutoresizingMaskIntoConstraints = false
        avatarView.showsStatusDot = false
        avatarView.isUserInteractionEnabled = true
        avatarView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(authorTapped)))
        contentView.addSubview(avatarView)

        nameLabel.baseFontSize = 15
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.isUserInteractionEnabled = true
        nameLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(authorTapped)))
        contentView.addSubview(nameLabel)

        timeLabel.font = UIFont.systemFont(ofSize: 11)
        timeLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(timeLabel)

        bodyLabel.font = UIFont.systemFont(ofSize: 15)
        bodyLabel.numberOfLines = 0
        bodyLabel.isUserInteractionEnabled = true
        bodyLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(bodyTapped)))
        bodyLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(bodyLabel)

        mediaContainer.layer.cornerRadius = 8
        mediaContainer.clipsToBounds = true
        mediaContainer.isUserInteractionEnabled = true
        mediaContainer.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(mediaTapped)))
        mediaContainer.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(mediaContainer)

        mediaImageView.contentMode = .scaleAspectFit
        mediaImageView.clipsToBounds = true
        mediaImageView.frame = mediaContainer.bounds
        mediaImageView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        mediaContainer.addSubview(mediaImageView)

        videoPlayBadge.image = DiscordIcons.image(.play, size: 28, color: .white, template: false)
        videoPlayBadge.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        videoPlayBadge.contentMode = .center
        videoPlayBadge.layer.cornerRadius = 26
        videoPlayBadge.clipsToBounds = true
        videoPlayBadge.isHidden = true
        videoPlayBadge.translatesAutoresizingMaskIntoConstraints = false
        mediaContainer.addSubview(videoPlayBadge)

        gifBadge.text = "GIF"
        gifBadge.font = UIFont.systemFont(ofSize: 10, weight: .heavy)
        gifBadge.textColor = .white
        gifBadge.backgroundColor = UIColor.black.withAlphaComponent(0.72)
        gifBadge.textAlignment = .center
        gifBadge.layer.cornerRadius = 4
        gifBadge.clipsToBounds = true
        gifBadge.isHidden = true
        gifBadge.translatesAutoresizingMaskIntoConstraints = false
        mediaContainer.addSubview(gifBadge)

        embedCard.layer.cornerRadius = 6
        embedCard.clipsToBounds = true
        embedCard.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(embedCard)

        embedAccentBar.translatesAutoresizingMaskIntoConstraints = false
        embedCard.addSubview(embedAccentBar)

        embedTitleLabel.font = UIFont.systemFont(ofSize: 14, weight: .bold)
        embedTitleLabel.numberOfLines = 2
        embedTitleLabel.translatesAutoresizingMaskIntoConstraints = false
        embedCard.addSubview(embedTitleLabel)

        embedDescLabel.font = UIFont.systemFont(ofSize: 13)
        embedDescLabel.numberOfLines = 6
        embedDescLabel.translatesAutoresizingMaskIntoConstraints = false
        embedCard.addSubview(embedDescLabel)

        embedImageView.contentMode = .scaleAspectFill
        embedImageView.layer.cornerRadius = 6
        embedImageView.clipsToBounds = true
        embedImageView.isUserInteractionEnabled = true
        embedImageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(embedImageTapped)))
        embedImageView.translatesAutoresizingMaskIntoConstraints = false
        embedCard.addSubview(embedImageView)

        pollCard.layer.cornerRadius = 8
        pollCard.clipsToBounds = true
        pollCard.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(pollCard)

        pollStack.axis = .vertical
        pollStack.spacing = 6
        pollStack.translatesAutoresizingMaskIntoConstraints = false
        pollCard.addSubview(pollStack)

        reactionsScroll.showsHorizontalScrollIndicator = false
        reactionsScroll.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(reactionsScroll)

        reactionsStack.axis = .horizontal
        reactionsStack.spacing = 6
        reactionsStack.translatesAutoresizingMaskIntoConstraints = false
        reactionsScroll.addSubview(reactionsStack)

        replyTopConstraint = replyBar.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 0)
        replyHeightConstraint = replyBar.heightAnchor.constraint(equalToConstant: 0)
        avatarTopConstraint = avatarView.topAnchor.constraint(equalTo: replyBar.bottomAnchor, constant: 10)
        headerHeightConstraint = nameLabel.heightAnchor.constraint(equalToConstant: 20)
        bodyTopConstraint = bodyLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 2)
        mediaTopConstraint = mediaContainer.topAnchor.constraint(equalTo: bodyLabel.bottomAnchor, constant: 0)
        mediaHeightConstraint = mediaContainer.heightAnchor.constraint(equalToConstant: 0)
        embedTopConstraint = embedCard.topAnchor.constraint(equalTo: mediaContainer.bottomAnchor, constant: 0)
        embedZeroHeightConstraint = embedCard.heightAnchor.constraint(equalToConstant: 0)
        embedZeroHeightConstraint.priority = .defaultHigh
        embedImageHeightConstraint = embedImageView.heightAnchor.constraint(equalToConstant: 0)
        pollTopConstraint = pollCard.topAnchor.constraint(equalTo: embedCard.bottomAnchor, constant: 0)
        pollZeroHeightConstraint = pollCard.heightAnchor.constraint(equalToConstant: 0)
        pollZeroHeightConstraint.priority = .defaultHigh
        reactionsTopConstraint = reactionsScroll.topAnchor.constraint(equalTo: pollCard.bottomAnchor, constant: 0)
        reactionsHeightConstraint = reactionsScroll.heightAnchor.constraint(equalToConstant: 0)
        bottomConstraint = reactionsScroll.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -4)
        avatarMinBottomConstraint = contentView.bottomAnchor.constraint(greaterThanOrEqualTo: avatarView.bottomAnchor, constant: 6)
        avatarMinBottomConstraint.priority = .defaultHigh

        let embedTitleTop = embedTitleLabel.topAnchor.constraint(equalTo: embedCard.topAnchor, constant: 8)
        embedTitleTop.priority = .defaultLow
        let embedImgBottom = embedImageView.bottomAnchor.constraint(equalTo: embedCard.bottomAnchor, constant: -8)
        embedImgBottom.priority = .defaultLow
        let pollTop = pollStack.topAnchor.constraint(equalTo: pollCard.topAnchor, constant: 10)
        pollTop.priority = .defaultLow
        let pollBottom = pollStack.bottomAnchor.constraint(equalTo: pollCard.bottomAnchor, constant: -10)
        pollBottom.priority = .defaultLow

        NSLayoutConstraint.activate([
            mentionBar.topAnchor.constraint(equalTo: contentView.topAnchor),
            mentionBar.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            mentionBar.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            mentionBar.widthAnchor.constraint(equalToConstant: 3),

            avatarMinBottomConstraint,
            replyTopConstraint,
            replyBar.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 62),
            replyBar.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -12),
            replyHeightConstraint,

            avatarTopConstraint,
            avatarView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 12),
            avatarView.widthAnchor.constraint(equalToConstant: 40),
            avatarView.heightAnchor.constraint(equalToConstant: 40),

            nameLabel.topAnchor.constraint(equalTo: avatarView.topAnchor),
            nameLabel.leadingAnchor.constraint(equalTo: avatarView.trailingAnchor, constant: 10),
            headerHeightConstraint,

            timeLabel.centerYAnchor.constraint(equalTo: nameLabel.centerYAnchor),
            timeLabel.leadingAnchor.constraint(equalTo: nameLabel.trailingAnchor, constant: 6),
            timeLabel.trailingAnchor.constraint(lessThanOrEqualTo: contentView.trailingAnchor, constant: -12),

            bodyTopConstraint,
            bodyLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            bodyLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -12),

            mediaTopConstraint,
            mediaContainer.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            mediaContainer.widthAnchor.constraint(equalToConstant: 240),
            mediaHeightConstraint,

            videoPlayBadge.centerXAnchor.constraint(equalTo: mediaContainer.centerXAnchor),
            videoPlayBadge.centerYAnchor.constraint(equalTo: mediaContainer.centerYAnchor),
            videoPlayBadge.widthAnchor.constraint(equalToConstant: 52),
            videoPlayBadge.heightAnchor.constraint(equalToConstant: 52),

            gifBadge.topAnchor.constraint(equalTo: mediaContainer.topAnchor, constant: 8),
            gifBadge.leadingAnchor.constraint(equalTo: mediaContainer.leadingAnchor, constant: 8),
            gifBadge.widthAnchor.constraint(equalToConstant: 30),
            gifBadge.heightAnchor.constraint(equalToConstant: 18),

            embedTopConstraint,
            embedCard.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            embedCard.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            embedZeroHeightConstraint,

            embedAccentBar.topAnchor.constraint(equalTo: embedCard.topAnchor),
            embedAccentBar.bottomAnchor.constraint(equalTo: embedCard.bottomAnchor),
            embedAccentBar.leadingAnchor.constraint(equalTo: embedCard.leadingAnchor),
            embedAccentBar.widthAnchor.constraint(equalToConstant: 4),

            embedTitleTop,
            embedTitleLabel.leadingAnchor.constraint(equalTo: embedAccentBar.trailingAnchor, constant: 10),
            embedTitleLabel.trailingAnchor.constraint(equalTo: embedCard.trailingAnchor, constant: -10),

            embedDescLabel.topAnchor.constraint(equalTo: embedTitleLabel.bottomAnchor, constant: 4),
            embedDescLabel.leadingAnchor.constraint(equalTo: embedTitleLabel.leadingAnchor),
            embedDescLabel.trailingAnchor.constraint(equalTo: embedTitleLabel.trailingAnchor),

            embedImageView.topAnchor.constraint(equalTo: embedDescLabel.bottomAnchor, constant: 6),
            embedImageView.leadingAnchor.constraint(equalTo: embedTitleLabel.leadingAnchor),
            embedImageView.trailingAnchor.constraint(equalTo: embedTitleLabel.trailingAnchor),
            embedImageHeightConstraint,
            embedImgBottom,

            pollTopConstraint,
            pollCard.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            pollCard.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            pollZeroHeightConstraint,

            pollTop,
            pollBottom,
            pollStack.leadingAnchor.constraint(equalTo: pollCard.leadingAnchor, constant: 10),
            pollStack.trailingAnchor.constraint(equalTo: pollCard.trailingAnchor, constant: -10),

            reactionsTopConstraint,
            reactionsScroll.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            reactionsScroll.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -12),
            reactionsHeightConstraint,
            bottomConstraint,

            reactionsStack.topAnchor.constraint(equalTo: reactionsScroll.topAnchor),
            reactionsStack.bottomAnchor.constraint(equalTo: reactionsScroll.bottomAnchor),
            reactionsStack.leadingAnchor.constraint(equalTo: reactionsScroll.leadingAnchor),
            reactionsStack.trailingAnchor.constraint(equalTo: reactionsScroll.trailingAnchor),
            reactionsStack.heightAnchor.constraint(equalTo: reactionsScroll.heightAnchor)
        ])
    }

    func configure(with msg: DiscordMessage, grouped: Bool) {
        self.message = msg
        let t = ThemeManager.shared.current

        avatarView.isHidden = grouped
        nameLabel.isHidden = grouped
        timeLabel.isHidden = grouped
        avatarMinBottomConstraint.isActive = !grouped
        headerHeightConstraint.constant = grouped ? 0 : 20
        bodyTopConstraint.constant = grouped ? 0 : 2
        bottomConstraint.constant = grouped ? -2 : -4

        let myId = DiscordStore.shared.currentUser?.id
        let isPing = (msg.mentionEveryone == true)
            || (myId != nil && msg.mentions?.contains(where: { $0.id == myId }) == true)
            || (myId != nil && (msg.content.contains("<@\(myId!)>") || msg.content.contains("<@!\(myId!)>")))
        mentionBar.isHidden = !isPing
        contentView.backgroundColor = isPing ? UIColor(hex: 0xF0B232).withAlphaComponent(0.10) : .clear

        if let ref = msg.referencedMessage?.message {
            replyBar.textColor = t.textSecondary
            replyBar.text = "@\(ref.author.effectiveDisplayName): \(ref.content)"
            replyTopConstraint.constant = 6
            replyHeightConstraint.constant = 16
            avatarTopConstraint.constant = grouped ? 2 : 4
        } else {
            replyBar.text = nil
            replyTopConstraint.constant = 0
            replyHeightConstraint.constant = 0
            avatarTopConstraint.constant = grouped ? 2 : 10
        }

        if !grouped {
            avatarView.configure(user: msg.author, status: nil, pixelSize: 64)
            nameLabel.defaultColor = t.textPrimary
            nameLabel.style = msg.author.displayNameStyles
            nameLabel.text = msg.author.effectiveDisplayName
            timeLabel.textColor = t.textMuted
            let ts = MessageCell.formatTimestamp(msg.timestamp)
            timeLabel.text = (msg.editedTimestamp != nil) ? "\(ts) (edited)" : ts
        }

        // Media detection (attachments, gifv embeds, stickers, direct image/gif URLs)
        videoPlayBadge.isHidden = true
        gifBadge.isHidden = true
        let trimmed = msg.content.trimmingCharacters(in: .whitespacesAndNewlines)
        let lowerTrimmed = trimmed.lowercased()
        let isDirectImageOrGifURL = trimmed.hasPrefix("https://") && !trimmed.contains(" ") && (
            lowerTrimmed.contains(".gif") || lowerTrimmed.contains(".png") || lowerTrimmed.contains(".jpg") ||
            lowerTrimmed.contains(".jpeg") || lowerTrimmed.contains("media.tenor.com") ||
            lowerTrimmed.contains("i.giphy.com") || trimmed.contains("cdn.discordapp.com/emojis/")
        )

        let effectiveAtt = msg.attachments?.first(where: { $0.isImage || $0.isVideo })
            ?? msg.messageSnapshots?.first?.message?.attachments?.first(where: { $0.isImage || $0.isVideo })

        let effectiveGifEmbed = msg.embeds?.first(where: {
            $0.type == "gifv" || $0.type == "image" || ($0.image?.url?.lowercased().contains(".gif") == true) || ($0.thumbnail?.url?.lowercased().contains(".gif") == true)
        }) ?? msg.messageSnapshots?.first?.message?.embeds?.first(where: { $0.type == "gifv" || $0.type == "image" })

        if let att = effectiveAtt {
            let rawURL = att.proxyUrl ?? att.url
            let url = MessageCell.ios12SafeImageURL(rawURL)
            mediaTopConstraint.constant = 6
            mediaHeightConstraint.constant = 165
            mediaContainer.backgroundColor = t.surfaceCard
            if att.isVideo {
                videoPlayBadge.isHidden = false
                mediaImageView.image = nil
            } else {
                gifBadge.isHidden = !att.isGIF
                loadMediaImage(url)
            }
        } else if let gifEmbed = effectiveGifEmbed,
                  let rawURL = gifEmbed.thumbnail?.proxyUrl ?? gifEmbed.thumbnail?.url ?? gifEmbed.image?.proxyUrl ?? gifEmbed.image?.url {
            let url = MessageCell.ios12SafeImageURL(rawURL)
            mediaTopConstraint.constant = 6
            mediaHeightConstraint.constant = 165
            mediaContainer.backgroundColor = .clear
            gifBadge.isHidden = !(gifEmbed.type == "gifv" || url.lowercased().contains(".gif"))
            loadMediaImage(url)
        } else if let sticker = msg.stickerItems?.first {
            mediaTopConstraint.constant = 6
            mediaHeightConstraint.constant = 120
            mediaContainer.backgroundColor = .clear
            loadMediaImage(sticker.imageURL)
        } else if isDirectImageOrGifURL {
            mediaTopConstraint.constant = 4
            mediaHeightConstraint.constant = trimmed.contains("cdn.discordapp.com/emojis/") ? 48 : 165
            mediaContainer.backgroundColor = .clear
            gifBadge.isHidden = !lowerTrimmed.contains(".gif")
            loadMediaImage(MessageCell.ios12SafeImageURL(trimmed))
        } else {
            currentMediaURL = nil
            mediaImageView.image = nil
            mediaTopConstraint.constant = 0
            mediaHeightConstraint.constant = 0
        }

        let displayContent = MessageCell.effectiveBodyText(for: msg)
        if isDirectImageOrGifURL && mediaHeightConstraint.constant > 0 {
            bodyLabel.attributedText = nil
            bodyLabel.text = nil
        } else if displayContent.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            bodyLabel.attributedText = nil
            bodyLabel.text = nil
            bodyTopConstraint.constant = 0
        } else {
            let messageId = msg.id
            bodyLabel.attributedText = MessageCell.renderMarkdown(displayContent, theme: t) { [weak self] in
                guard let self = self, self.message?.id == messageId else { return }
                self.bodyLabel.attributedText = MessageCell.renderMarkdown(displayContent, theme: t, onEmojiLoaded: nil)
                self.delegate?.messageCellNeedsRelayout(self)
            }
        }

        if let embed = msg.embeds?.first(where: { $0.type != "gifv" && ($0.title != nil || $0.description != nil) }) {
            embedTopConstraint.constant = 6
            embedZeroHeightConstraint.isActive = false
            embedCard.isHidden = false
            embedCard.backgroundColor = t.surfaceCard
            embedAccentBar.backgroundColor = embed.color.map { UIColor(hex: $0) } ?? t.accent
            embedTitleLabel.textColor = t.textPrimary
            embedTitleLabel.text = embed.title ?? embed.author?.name
            embedDescLabel.textColor = t.textSecondary
            embedDescLabel.text = embed.description
            if let imgURL = embed.image?.url ?? embed.thumbnail?.url {
                embedImageHeightConstraint.constant = 130
                ImageLoader.shared.load(urlString: imgURL, maxPixelSize: 256, animated: true) { [weak self] img in
                    self?.embedImageView.image = img
                }
            } else {
                embedImageView.image = nil
                embedImageHeightConstraint.constant = 0
            }
        } else {
            embedTopConstraint.constant = 0
            embedCard.isHidden = true
            embedZeroHeightConstraint.isActive = true
            embedTitleLabel.text = nil
            embedDescLabel.text = nil
            embedImageView.image = nil
            embedImageHeightConstraint.constant = 0
        }

        pollStack.arrangedSubviews.forEach { $0.removeFromSuperview() }
        if let poll = msg.poll {
            pollTopConstraint.constant = 6
            pollZeroHeightConstraint.isActive = false
            pollCard.isHidden = false
            pollCard.backgroundColor = t.surfaceCard
            let qLabel = UILabel()
            qLabel.text = poll.question.text ?? "Poll"
            qLabel.font = UIFont.systemFont(ofSize: 14, weight: .bold)
            qLabel.textColor = t.textPrimary
            qLabel.numberOfLines = 0
            pollStack.addArrangedSubview(qLabel)

            let totalVotes = max(1, poll.results?.answerCounts?.reduce(0) { $0 + $1.count } ?? 0)
            for ans in poll.answers {
                let countObj = poll.results?.answerCounts?.first(where: { $0.id == ans.answerId })
                let count = countObj?.count ?? 0
                let meVoted = countObj?.meVoted ?? false
                let pct = Int((Double(count) / Double(totalVotes)) * 100)

                let btn = UIButton(type: .system)
                btn.tag = ans.answerId
                btn.setTitle("\(ans.pollMedia.text ?? "")  (\(count) • \(pct)%)", for: .normal)
                btn.setTitleColor(meVoted ? .white : t.textPrimary, for: .normal)
                btn.backgroundColor = meVoted ? t.accent : t.backgroundSecondary
                btn.layer.cornerRadius = 8
                btn.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
                btn.contentHorizontalAlignment = .left
                btn.contentEdgeInsets = UIEdgeInsets(top: 8, left: 10, bottom: 8, right: 10)
                btn.addTarget(self, action: #selector(pollAnswerTapped(_:)), for: .touchUpInside)
                pollStack.addArrangedSubview(btn)
            }
        } else {
            pollTopConstraint.constant = 0
            pollCard.isHidden = true
            pollZeroHeightConstraint.isActive = true
        }

        reactionsStack.arrangedSubviews.forEach { $0.removeFromSuperview() }
        if let reactions = msg.reactions, !reactions.isEmpty {
            reactionsTopConstraint.constant = 6
            reactionsHeightConstraint.constant = 28
            for (idx, r) in reactions.prefix(10).enumerated() {
                let btn = UIButton(type: .system)
                btn.tag = idx
                btn.titleLabel?.font = UIFont.systemFont(ofSize: 12, weight: .semibold)
                btn.setTitleColor(r.me ? .white : t.textSecondary, for: .normal)
                btn.backgroundColor = r.me ? t.accent.withAlphaComponent(0.35) : t.surfaceCard
                btn.layer.cornerRadius = 12
                btn.layer.borderWidth = 1
                btn.layer.borderColor = (r.me ? t.accent : t.separator).cgColor
                btn.contentEdgeInsets = UIEdgeInsets(top: 4, left: 8, bottom: 4, right: 8)
                if let imgURL = r.emoji.staticPNGURL ?? r.emoji.imageURL {
                    btn.setTitle(" \(r.count)", for: .normal)
                    ImageLoader.shared.load(urlString: imgURL, maxPixelSize: 32, animated: false) { img in
                        btn.setImage(img?.withRenderingMode(.alwaysOriginal), for: .normal)
                    }
                } else {
                    btn.setTitle("\(r.emoji.displayText) \(r.count)", for: .normal)
                }
                btn.addTarget(self, action: #selector(reactionPillTapped(_:)), for: .touchUpInside)
                reactionsStack.addArrangedSubview(btn)
            }
            let addBtn = UIButton(type: .system)
            addBtn.setImage(DiscordIcons.image(.smile, size: 15), for: .normal)
            addBtn.tintColor = t.textMuted
            addBtn.backgroundColor = t.surfaceCard
            addBtn.layer.cornerRadius = 12
            addBtn.contentEdgeInsets = UIEdgeInsets(top: 4, left: 8, bottom: 4, right: 8)
            addBtn.addTarget(self, action: #selector(addReactionTapped), for: .touchUpInside)
            reactionsStack.addArrangedSubview(addBtn)
        } else {
            reactionsTopConstraint.constant = 0
            reactionsHeightConstraint.constant = 0
        }
    }

    private func loadMediaImage(_ url: String) {
        if currentMediaURL != url {
            currentMediaURL = url
            mediaImageView.image = nil
            ImageLoader.shared.load(urlString: url, maxPixelSize: 256, animated: true) { [weak self] img in
                if self?.currentMediaURL == url {
                    self?.mediaImageView.image = img
                }
            }
        }
    }

    @objc private func authorTapped() {
        guard let author = message?.author else { return }
        delegate?.messageCell(self, didTapAuthor: author)
    }

    @objc private func bodyTapped() {
        guard let text = message?.content else { return }
        let detector = try? NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue)
        let matches = detector?.matches(in: text, range: NSRange(location: 0, length: (text as NSString).length))
        if let url = matches?.first?.url {
            let s = url.absoluteString
            if s.contains("discord.gg/") || s.contains("discord.com/invite/") {
                delegate?.messageCell(self, didTapInviteCode: DiscordRESTClient.extractInviteCode(from: s))
            } else {
                delegate?.messageCell(self, didTapLinkURL: url)
            }
        }
    }

    @objc private func mediaTapped() {
        guard let msg = message else { return }
        if let att = msg.attachments?.first(where: { $0.isVideo }) {
            delegate?.messageCell(self, didTapVideoURL: att.url)
            return
        }
        if let att = msg.attachments?.first(where: { $0.isImage }) {
            delegate?.messageCell(self, didTapImageURL: att.proxyUrl ?? att.url, isGif: att.isGIF)
            return
        }
        if let gifEmbed = msg.embeds?.first(where: { $0.type == "gifv" || ($0.image?.url?.lowercased().contains(".gif") == true) }) {
            if let vid = gifEmbed.video?.proxyUrl ?? gifEmbed.video?.url { delegate?.messageCell(self, didTapVideoURL: vid); return }
            let url = gifEmbed.thumbnail?.proxyUrl ?? gifEmbed.thumbnail?.url ?? gifEmbed.image?.proxyUrl ?? gifEmbed.image?.url ?? ""
            if !url.isEmpty {
                delegate?.messageCell(self, didTapImageURL: url, isGif: true)
                return
            }
        }
        if let url = currentMediaURL {
            delegate?.messageCell(self, didTapImageURL: url, isGif: url.lowercased().contains(".gif"))
        }
    }

    @objc private func embedImageTapped() {
        if let url = message?.embeds?.first?.image?.url ?? message?.embeds?.first?.thumbnail?.url {
            delegate?.messageCell(self, didTapImageURL: url, isGif: url.lowercased().contains(".gif"))
        }
    }

    @objc private func reactionPillTapped(_ sender: UIButton) {
        guard let msg = message, let reactions = msg.reactions, sender.tag < reactions.count else { return }
        delegate?.messageCell(self, didToggleReaction: reactions[sender.tag], message: msg)
    }

    @objc private func addReactionTapped() {
        guard let msg = message else { return }
        delegate?.messageCell(self, didTapAddReaction: msg)
    }

    @objc private func pollAnswerTapped(_ sender: UIButton) {
        guard let msg = message else { return }
        delegate?.messageCell(self, didVotePoll: sender.tag, message: msg)
    }


    static func ios12SafeImageURL(_ url: String) -> String {
        var out = url.replacingOccurrences(of: "format=webp", with: "format=png")
        out = out.replacingOccurrences(of: "format=WEBP", with: "format=png")
        return out
    }

    static func effectiveBodyText(for msg: DiscordMessage) -> String {
        if !msg.content.isEmpty { return msg.content }
        if let snap = msg.messageSnapshots?.first?.message?.content, !snap.isEmpty {
            return "Forwarded: \(snap)"
        }
        if let t = msg.type, t != 0 && t != 19 {
            switch t {
            case 1: return "Added someone to the group."
            case 2: return "Removed someone from the group."
            case 3: return "Started a call."
            case 4: return "Changed the channel name."
            case 5: return "Changed the channel icon."
            case 6: return "Pinned a message."
            case 7: return "Joined the server."
            case 8, 9, 10, 11: return "Boosted the server."
            default: return ""
            }
        }
        return ""
    }

    static func renderMarkdown(_ text: String, theme: CordTheme, onEmojiLoaded: (() -> Void)?) -> NSAttributedString {
        let baseFont = UIFont.systemFont(ofSize: 15)
        let boldFont = UIFont.systemFont(ofSize: 15, weight: .bold)
        let codeFont = UIFont(name: "Menlo-Regular", size: 13) ?? UIFont.systemFont(ofSize: 13)

        var resolvedText = text
        if let userMentionRegex = try? NSRegularExpression(pattern: "<@!?([0-9]+)>") {
            let ns = resolvedText as NSString
            for match in userMentionRegex.matches(in: resolvedText, range: NSRange(location: 0, length: ns.length)).reversed() {
                let uid = ns.substring(with: match.range(at: 1))
                let name = DiscordStore.shared.usersById[uid]?.effectiveDisplayName ?? "user"
                resolvedText = (resolvedText as NSString).replacingCharacters(in: match.range, with: "@\(name)")
            }
        }
        if let roleRegex = try? NSRegularExpression(pattern: "<@&([0-9]+)>") {
            resolvedText = roleRegex.stringByReplacingMatches(in: resolvedText, range: NSRange(location: 0, length: (resolvedText as NSString).length), withTemplate: "@role")
        }
        if let chanMentionRegex = try? NSRegularExpression(pattern: "<#([0-9]+)>") {
            let ns = resolvedText as NSString
            for match in chanMentionRegex.matches(in: resolvedText, range: NSRange(location: 0, length: ns.length)).reversed() {
                let cid = ns.substring(with: match.range(at: 1))
                let chName = DiscordStore.shared.channelsByGuild.values.flatMap { $0 }.first(where: { $0.id == cid })?.displayName ?? "channel"
                resolvedText = (resolvedText as NSString).replacingCharacters(in: match.range, with: "#\(chName)")
            }
        }

        let result = NSMutableAttributedString(string: resolvedText, attributes: [
            .font: baseFont,
            .foregroundColor: theme.textPrimary
        ])

        // Replace Discord custom emojis <:name:id> / <a:name:id> with inline NSTextAttachment images
        if let emojiRegex = try? NSRegularExpression(pattern: "<(a?):([A-Za-z0-9_]+):([0-9]+)>") {
            let fullRange = NSRange(location: 0, length: (resolvedText as NSString).length)
            let matches = emojiRegex.matches(in: resolvedText, range: fullRange)
            let strippedNonEmoji = emojiRegex.stringByReplacingMatches(in: resolvedText, range: fullRange, withTemplate: "").trimmingCharacters(in: .whitespacesAndNewlines)
            let isJumbo = strippedNonEmoji.isEmpty && matches.count >= 1 && matches.count <= 3
            let emojiDim: CGFloat = isJumbo ? 36 : 20
            let yOffset: CGFloat = isJumbo ? -4 : -4

            for match in matches.reversed() {
                let ns = resolvedText as NSString
                let id = ns.substring(with: match.range(at: 3))
                let url = "https://cdn.discordapp.com/emojis/\(id).png?size=64"

                let attachment = NSTextAttachment()
                attachment.bounds = CGRect(x: 0, y: yOffset, width: emojiDim, height: emojiDim)
                if let cached = ImageLoader.shared.cachedImage(urlString: url, maxPixelSize: 64, animated: false) {
                    attachment.image = cached
                } else if let onEmojiLoaded = onEmojiLoaded {
                    ImageLoader.shared.load(urlString: url, maxPixelSize: 64, animated: false) { img in
                        if img != nil { onEmojiLoaded() }
                    }
                }
                result.replaceCharacters(in: match.range, with: NSAttributedString(attachment: attachment))
            }
        }

        let currentStr = result.string
        let mentionPattern = "(@[A-Za-z0-9_\\.]+|#[A-Za-z0-9\\-_]+|https?://\\S+)"
        if let regex = try? NSRegularExpression(pattern: mentionPattern) {
            let range = NSRange(location: 0, length: (currentStr as NSString).length)
            for match in regex.matches(in: currentStr, range: range) {
                result.addAttributes([
                    .foregroundColor: theme.accent,
                    .font: boldFont
                ], range: match.range)
            }
        }

        if let codeRegex = try? NSRegularExpression(pattern: "`([^`]+)`") {
            let range = NSRange(location: 0, length: (currentStr as NSString).length)
            for match in codeRegex.matches(in: currentStr, range: range) {
                result.addAttributes([
                    .font: codeFont,
                    .backgroundColor: theme.backgroundTertiary
                ], range: match.range)
            }
        }
        return result
    }

    private static let isoFormatter: ISO8601DateFormatter = {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return f
    }()

    private static let isoFallbackFormatter: ISO8601DateFormatter = {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime]
        return f
    }()

    private static let timeFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateStyle = .none
        f.timeStyle = .short
        return f
    }()

    private static let sameYearFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "MMM d, h:mm a"
        return f
    }()

    private static let fullDateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "MMM d, yyyy, h:mm a"
        return f
    }()

    static func parseDate(_ iso: String) -> Date? {
        return isoFormatter.date(from: iso) ?? isoFallbackFormatter.date(from: iso)
    }

    private static func formatTimestamp(_ iso: String) -> String {
        guard let date = parseDate(iso) else { return "" }
        let cal = Calendar.current
        if cal.isDateInToday(date) {
            return timeFormatter.string(from: date)
        }
        if cal.isDateInYesterday(date) {
            return "Yesterday at \(timeFormatter.string(from: date))"
        }
        let nowYear = cal.component(.year, from: Date())
        let msgYear = cal.component(.year, from: date)
        if nowYear == msgYear {
            return sameYearFormatter.string(from: date)
        }
        return fullDateFormatter.string(from: date)
    }
}
