import UIKit

protocol MessageActionsSheetDelegate: AnyObject {
    func messageActions(_ sheet: MessageActionsSheetViewController, didReact emoji: String, to message: DiscordMessage)
    func messageActionsDidTapMoreEmojis(_ sheet: MessageActionsSheetViewController, for message: DiscordMessage)
    func messageActionsDidTapReply(_ sheet: MessageActionsSheetViewController, for message: DiscordMessage)
    func messageActionsDidTapCopyText(_ sheet: MessageActionsSheetViewController, for message: DiscordMessage)
    func messageActionsDidTapCopyLink(_ sheet: MessageActionsSheetViewController, for message: DiscordMessage)
    func messageActionsDidTapCopyID(_ sheet: MessageActionsSheetViewController, for message: DiscordMessage)
    func messageActionsDidTapEdit(_ sheet: MessageActionsSheetViewController, for message: DiscordMessage)
    func messageActionsDidTapDelete(_ sheet: MessageActionsSheetViewController, for message: DiscordMessage)
}

/// Discord-style dark bottom sheet for message reactions and actions.
final class MessageActionsSheetViewController: UIViewController {
    weak var delegate: MessageActionsSheetDelegate?
    private let message: DiscordMessage
    private let isOwnMessage: Bool

    private let backdrop = UIView()
    private let sheetView = UIView()
    private var sheetBottomConstraint: NSLayoutConstraint!

    private let quickEmojis = ["✅", "💀", "🥺", "❤️", "😂", "🔥"]

    init(message: DiscordMessage, isOwnMessage: Bool) {
        self.message = message
        self.isOwnMessage = isOwnMessage
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .overFullScreen
        modalTransitionStyle = .crossDissolve
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        sheetBottomConstraint.constant = 0
        UIView.animate(withDuration: 0.24, delay: 0, options: .curveEaseOut, animations: {
            self.backdrop.alpha = 1.0
            self.view.layoutIfNeeded()
        })
    }

    private func setupUI() {
        let t = ThemeManager.shared.current
        view.backgroundColor = .clear

        backdrop.backgroundColor = UIColor.black.withAlphaComponent(0.55)
        backdrop.alpha = 0
        backdrop.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(dismissSheet)))
        backdrop.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(backdrop)

        sheetView.backgroundColor = t.backgroundSecondary
        sheetView.layer.cornerRadius = 18
        if #available(iOS 11.0, *) {
            sheetView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        }
        sheetView.clipsToBounds = true
        sheetView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(sheetView)

        sheetBottomConstraint = sheetView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 420)
        NSLayoutConstraint.activate([
            backdrop.topAnchor.constraint(equalTo: view.topAnchor),
            backdrop.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            backdrop.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            backdrop.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            sheetView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            sheetView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            sheetBottomConstraint
        ])

        let grabber = UIView()
        grabber.backgroundColor = t.textMuted.withAlphaComponent(0.5)
        grabber.layer.cornerRadius = 2
        grabber.translatesAutoresizingMaskIntoConstraints = false
        sheetView.addSubview(grabber)

        // Quick reaction row
        let reactRow = UIStackView()
        reactRow.axis = .horizontal
        reactRow.distribution = .fillEqually
        reactRow.spacing = 8
        reactRow.translatesAutoresizingMaskIntoConstraints = false
        sheetView.addSubview(reactRow)

        for (idx, emoji) in quickEmojis.enumerated() {
            let btn = UIButton(type: .system)
            btn.tag = idx
            btn.setTitle(emoji, for: .normal)
            btn.titleLabel?.font = UIFont.systemFont(ofSize: 22)
            btn.backgroundColor = t.surfaceCard
            btn.layer.cornerRadius = 12
            btn.addTarget(self, action: #selector(quickReactTapped(_:)), for: .touchUpInside)
            reactRow.addArrangedSubview(btn)
        }

        let moreBtn = UIButton(type: .system)
        moreBtn.setImage(DiscordIcons.image(.smile, size: 22), for: .normal)
        moreBtn.tintColor = t.textSecondary
        moreBtn.backgroundColor = t.surfaceCard
        moreBtn.layer.cornerRadius = 12
        moreBtn.addTarget(self, action: #selector(moreEmojisTapped), for: .touchUpInside)
        reactRow.addArrangedSubview(moreBtn)

        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 12
        stack.translatesAutoresizingMaskIntoConstraints = false
        sheetView.addSubview(stack)

        var rows: [(DiscordIcons.Kind, String, UIColor, Selector)] = []
        if isOwnMessage {
            rows.append((.edit, "Edit Message", t.textPrimary, #selector(editTapped)))
        }
        rows.append((.reply, "Reply", t.textPrimary, #selector(replyTapped)))
        rows.append((.share, "Copy Text", t.textPrimary, #selector(copyTextTapped)))
        stack.addArrangedSubview(makeCard(rows: rows, theme: t))

        if isOwnMessage {
            let deleteCard = makeCard(rows: [(.close, "Delete Message", UIColor(hex: 0xF23F43), #selector(deleteTapped))], theme: t)
            stack.addArrangedSubview(deleteCard)
        }

        let bottomPad: CGFloat
        if #available(iOS 11.0, *) {
            bottomPad = max(18, UIApplication.shared.keyWindow?.safeAreaInsets.bottom ?? 18)
        } else {
            bottomPad = 18
        }

        NSLayoutConstraint.activate([
            grabber.topAnchor.constraint(equalTo: sheetView.topAnchor, constant: 10),
            grabber.centerXAnchor.constraint(equalTo: sheetView.centerXAnchor),
            grabber.widthAnchor.constraint(equalToConstant: 36),
            grabber.heightAnchor.constraint(equalToConstant: 4),

            reactRow.topAnchor.constraint(equalTo: grabber.bottomAnchor, constant: 14),
            reactRow.leadingAnchor.constraint(equalTo: sheetView.leadingAnchor, constant: 14),
            reactRow.trailingAnchor.constraint(equalTo: sheetView.trailingAnchor, constant: -14),
            reactRow.heightAnchor.constraint(equalToConstant: 44),

            stack.topAnchor.constraint(equalTo: reactRow.bottomAnchor, constant: 14),
            stack.leadingAnchor.constraint(equalTo: sheetView.leadingAnchor, constant: 14),
            stack.trailingAnchor.constraint(equalTo: sheetView.trailingAnchor, constant: -14),
            stack.bottomAnchor.constraint(equalTo: sheetView.bottomAnchor, constant: -bottomPad)
        ])
    }

    private func makeCard(rows: [(DiscordIcons.Kind, String, UIColor, Selector)], theme: CordTheme) -> UIView {
        let card = UIView()
        card.backgroundColor = theme.surfaceCard
        card.layer.cornerRadius = 14
        card.clipsToBounds = true

        let inner = UIStackView()
        inner.axis = .vertical
        inner.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(inner)
        NSLayoutConstraint.activate([
            inner.topAnchor.constraint(equalTo: card.topAnchor),
            inner.bottomAnchor.constraint(equalTo: card.bottomAnchor),
            inner.leadingAnchor.constraint(equalTo: card.leadingAnchor),
            inner.trailingAnchor.constraint(equalTo: card.trailingAnchor)
        ])

        for (idx, row) in rows.enumerated() {
            let btn = UIButton(type: .system)
            btn.heightAnchor.constraint(equalToConstant: 46).isActive = true
            btn.setImage(DiscordIcons.image(row.0, size: 18), for: .normal)
            btn.setTitle("   \(row.1)", for: .normal)
            btn.tintColor = row.2
            btn.setTitleColor(row.2, for: .normal)
            btn.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
            btn.contentHorizontalAlignment = .left
            btn.contentEdgeInsets = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16)
            btn.addTarget(self, action: row.3, for: .touchUpInside)
            inner.addArrangedSubview(btn)

            if idx < rows.count - 1 {
                let sep = UIView()
                sep.backgroundColor = theme.separator
                sep.heightAnchor.constraint(equalToConstant: 0.5).isActive = true
                inner.addArrangedSubview(sep)
            }
        }
        return card
    }

    @objc private func dismissSheet() {
        closeWithCompletion(nil)
    }

    private func closeWithCompletion(_ completion: (() -> Void)?) {
        sheetBottomConstraint.constant = 420
        UIView.animate(withDuration: 0.18, animations: {
            self.backdrop.alpha = 0
            self.view.layoutIfNeeded()
        }, completion: { _ in
            self.dismiss(animated: false, completion: completion)
        })
    }

    @objc private func quickReactTapped(_ sender: UIButton) {
        let emoji = quickEmojis[sender.tag]
        closeWithCompletion { [weak self] in
            guard let self = self else { return }
            self.delegate?.messageActions(self, didReact: emoji, to: self.message)
        }
    }

    @objc private func moreEmojisTapped() {
        closeWithCompletion { [weak self] in
            guard let self = self else { return }
            self.delegate?.messageActionsDidTapMoreEmojis(self, for: self.message)
        }
    }

    @objc private func editTapped() {
        closeWithCompletion { [weak self] in
            guard let self = self else { return }
            self.delegate?.messageActionsDidTapEdit(self, for: self.message)
        }
    }

    @objc private func replyTapped() {
        closeWithCompletion { [weak self] in
            guard let self = self else { return }
            self.delegate?.messageActionsDidTapReply(self, for: self.message)
        }
    }

    @objc private func copyTextTapped() {
        closeWithCompletion { [weak self] in
            guard let self = self else { return }
            self.delegate?.messageActionsDidTapCopyText(self, for: self.message)
        }
    }

    @objc private func copyLinkTapped() {
        closeWithCompletion { [weak self] in
            guard let self = self else { return }
            self.delegate?.messageActionsDidTapCopyLink(self, for: self.message)
        }
    }

    @objc private func copyIDTapped() {
        closeWithCompletion { [weak self] in
            guard let self = self else { return }
            self.delegate?.messageActionsDidTapCopyID(self, for: self.message)
        }
    }

    @objc private func deleteTapped() {
        closeWithCompletion { [weak self] in
            guard let self = self else { return }
            self.delegate?.messageActionsDidTapDelete(self, for: self.message)
        }
    }
}
