import UIKit
import AVKit
import SafariServices

protocol ChatViewControllerDelegate: AnyObject {
    func chatViewControllerDidTapMenu(_ vc: ChatViewController)
}

final class ChatViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, MessageCellDelegate, GifPickerDelegate, EmojiPickerDelegate, MessageActionsSheetDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    weak var delegate: ChatViewControllerDelegate?

    private let tableView = UITableView(frame: .zero, style: .plain)
    private let refreshControl = UIRefreshControl()
    private let mentionTableView = UITableView(frame: .zero, style: .plain)
    private let typingLabel = UILabel()
    private let composerContainer = UIView()
    private let replyPreviewBar = UIView()
    private let replyLabel = UILabel()
    private let replyCloseButton = UIButton(type: .system)
    private let attachButton = UIButton(type: .system)
    private let emojiButton = UIButton(type: .system)
    private let inputField = UITextField()
    private let sendButton = UIButton(type: .system)
    private var composerBottomConstraint: NSLayoutConstraint!
    private var replyHeightConstraint: NSLayoutConstraint!
    private var typingHeightConstraint: NSLayoutConstraint!
    private var mentionHeightConstraint: NSLayoutConstraint!
    private var sendWidthConstraint: NSLayoutConstraint!

    private var membersItem: UIBarButtonItem!
    private var callItem: UIBarButtonItem!
    private var pinsItem: UIBarButtonItem!

    private var currentChannel: DiscordChannel?
    private var messages: [DiscordMessage] = []
    private var replyingTo: DiscordMessage?
    private var typingClearTimer: Timer?
    private var fallbackSyncTimer: Timer?
    private var reactionTargetMessage: DiscordMessage?

    // Pagination
    private var isLoadingOlder = false
    private var hasMoreMessages = true

    // @Mention autocomplete
    private var mentionCandidates: [DiscordUser] = []
    private var filteredMentions: [DiscordUser] = []
    private var pendingMentions: [String: String] = [:] // "@username" -> userId

    override func viewDidLoad() {
        super.viewDidLoad()
        setupNav()
        setupUI()
        applyTheme()

        NotificationCenter.default.addObserver(self, selector: #selector(onMessageCreate(_:)), name: .cordStoreDidReceiveMessage, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(onMessageUpdate(_:)), name: .cordStoreDidUpdateMessage, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(onMessageDelete(_:)), name: .cordStoreDidDeleteMessage, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(onTyping(_:)), name: .cordStoreDidReceiveTyping, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(onThemeChanged), name: .cordThemeDidChange, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillChange(_:)), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        ThemeManager.shared.applyGradientIfNeeded(to: view)
    }

    func loadChannel(_ channel: DiscordChannel) {
        self.currentChannel = channel
        self.replyingTo = nil
        self.isLoadingOlder = false
        self.hasMoreMessages = true
        self.pendingMentions.removeAll()
        self.filteredMentions.removeAll()
        self.mentionHeightConstraint.constant = 0
        updateReplyBar()
        typingHeightConstraint.constant = 0
        title = (channel.type == 1 || channel.type == 3) ? "@ \(channel.displayName)" : "# \(channel.displayName)"
        navigationItem.rightBarButtonItems = (channel.guildId != nil) ? [membersItem, pinsItem] : [callItem, pinsItem]
        applyTheme()
        loadMentionCandidates(for: channel)

        DiscordStore.shared.loadMessages(channelId: channel.id) { [weak self] msgs in
            guard let self = self, self.currentChannel?.id == channel.id else { return }
            self.messages = msgs
            self.hasMoreMessages = msgs.count >= 40
            self.tableView.reloadData()
            self.scrollToBottom(animated: false)
        }

        fallbackSyncTimer?.invalidate()
        fallbackSyncTimer = Timer.scheduledTimer(withTimeInterval: 3.5, repeats: true) { [weak self] _ in
            guard let self = self, let ch = self.currentChannel, !DiscordStore.shared.isGatewayConnected else { return }
            DiscordStore.shared.loadMessages(channelId: ch.id) { msgs in
                guard self.currentChannel?.id == ch.id, msgs.count != self.messages.count || msgs.last?.id != self.messages.last?.id else { return }
                self.messages = msgs
                self.tableView.reloadData()
                self.scrollToBottom(animated: true)
            }
        }
    }

    private func loadMentionCandidates(for channel: DiscordChannel) {
        if let gid = channel.guildId {
            mentionCandidates = Array(DiscordStore.shared.usersById.values)
            DiscordRESTClient.shared.fetchGuildMembers(guildId: gid, limit: 100) { [weak self] res in
                guard let self = self, self.currentChannel?.id == channel.id else { return }
                if case .success(let members) = res {
                    var seen = Set<String>()
                    var list: [DiscordUser] = []
                    for m in members {
                        if let u = m.user, !seen.contains(u.id) {
                            seen.insert(u.id)
                            DiscordStore.shared.usersById[u.id] = u
                            list.append(u)
                        }
                    }
                    self.mentionCandidates = list
                }
            }
        } else {
            mentionCandidates = channel.resolvedRecipients
        }
    }

    private func setupNav() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            image: DiscordIcons.image(.menu, size: 22),
            style: .plain,
            target: self,
            action: #selector(menuTapped)
        )
        membersItem = UIBarButtonItem(
            image: DiscordIcons.image(.members, size: 20),
            style: .plain,
            target: self,
            action: #selector(membersTapped)
        )
        callItem = UIBarButtonItem(
            image: DiscordIcons.image(.speaker, size: 19),
            style: .plain,
            target: self,
            action: #selector(dmCallTapped)
        )
        pinsItem = UIBarButtonItem(
            image: DiscordIcons.image(.badge, size: 19),
            style: .plain,
            target: self,
            action: #selector(pinsSearchTapped)
        )
        navigationItem.rightBarButtonItems = [pinsItem]
    }

    private func setupUI() {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.separatorStyle = .none
        tableView.backgroundColor = .clear
        tableView.estimatedRowHeight = 56
        tableView.rowHeight = UITableView.automaticDimension
        tableView.keyboardDismissMode = .interactive
        tableView.contentInset = UIEdgeInsets(top: 6, left: 0, bottom: 8, right: 0)
        tableView.register(MessageCell.self, forCellReuseIdentifier: MessageCell.reuseID)
        refreshControl.addTarget(self, action: #selector(pullToLoadOlder), for: .valueChanged)
        tableView.refreshControl = refreshControl
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)

        tableView.addGestureRecognizer(UILongPressGestureRecognizer(target: self, action: #selector(handleMessageLongPress(_:))))

        mentionTableView.dataSource = self
        mentionTableView.delegate = self
        mentionTableView.layer.cornerRadius = 10
        mentionTableView.clipsToBounds = true
        mentionTableView.rowHeight = 42
        mentionTableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(mentionTableView)
        mentionHeightConstraint = mentionTableView.heightAnchor.constraint(equalToConstant: 0)

        typingLabel.font = UIFont.systemFont(ofSize: 11, weight: .medium)
        typingLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(typingLabel)
        typingHeightConstraint = typingLabel.heightAnchor.constraint(equalToConstant: 0)

        replyPreviewBar.clipsToBounds = true
        replyPreviewBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(replyPreviewBar)
        replyHeightConstraint = replyPreviewBar.heightAnchor.constraint(equalToConstant: 0)

        replyLabel.font = UIFont.systemFont(ofSize: 12, weight: .medium)
        replyLabel.translatesAutoresizingMaskIntoConstraints = false
        replyPreviewBar.addSubview(replyLabel)

        replyCloseButton.setImage(DiscordIcons.image(.close, size: 14), for: .normal)
        replyCloseButton.addTarget(self, action: #selector(cancelReply), for: .touchUpInside)
        replyCloseButton.translatesAutoresizingMaskIntoConstraints = false
        replyPreviewBar.addSubview(replyCloseButton)

        composerContainer.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(composerContainer)

        attachButton.setImage(DiscordIcons.image(.plus, size: 20), for: .normal)
        attachButton.layer.cornerRadius = 17
        attachButton.addTarget(self, action: #selector(attachTapped), for: .touchUpInside)
        attachButton.translatesAutoresizingMaskIntoConstraints = false
        composerContainer.addSubview(attachButton)

        emojiButton.setImage(DiscordIcons.image(.smile, size: 20), for: .normal)
        emojiButton.addTarget(self, action: #selector(emojiTapped), for: .touchUpInside)
        emojiButton.translatesAutoresizingMaskIntoConstraints = false
        composerContainer.addSubview(emojiButton)

        inputField.placeholder = "Message..."
        inputField.font = UIFont.systemFont(ofSize: 15)
        inputField.layer.cornerRadius = 18
        inputField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 12, height: 1))
        inputField.leftViewMode = .always
        inputField.returnKeyType = .send
        inputField.delegate = self
        inputField.addTarget(self, action: #selector(inputEditingChanged), for: .editingChanged)
        inputField.translatesAutoresizingMaskIntoConstraints = false
        composerContainer.addSubview(inputField)

        sendButton.setImage(DiscordIcons.image(.send, size: 17), for: .normal)
        sendButton.layer.cornerRadius = 17
        sendButton.isHidden = true
        sendButton.addTarget(self, action: #selector(sendTapped), for: .touchUpInside)
        sendButton.translatesAutoresizingMaskIntoConstraints = false
        composerContainer.addSubview(sendButton)
        sendWidthConstraint = sendButton.widthAnchor.constraint(equalToConstant: 0)

        if #available(iOS 11.0, *) {
            composerBottomConstraint = composerContainer.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        } else {
            composerBottomConstraint = composerContainer.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        }

        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: typingLabel.topAnchor),

            mentionTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            mentionTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
            mentionTableView.bottomAnchor.constraint(equalTo: replyPreviewBar.topAnchor, constant: -4),
            mentionHeightConstraint,

            typingLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 14),
            typingLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -14),
            typingLabel.bottomAnchor.constraint(equalTo: replyPreviewBar.topAnchor),
            typingHeightConstraint,

            replyPreviewBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            replyPreviewBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            replyPreviewBar.bottomAnchor.constraint(equalTo: composerContainer.topAnchor),
            replyHeightConstraint,

            replyLabel.leadingAnchor.constraint(equalTo: replyPreviewBar.leadingAnchor, constant: 14),
            replyLabel.centerYAnchor.constraint(equalTo: replyPreviewBar.centerYAnchor),
            replyLabel.trailingAnchor.constraint(equalTo: replyCloseButton.leadingAnchor, constant: -8),

            replyCloseButton.trailingAnchor.constraint(equalTo: replyPreviewBar.trailingAnchor, constant: -12),
            replyCloseButton.centerYAnchor.constraint(equalTo: replyPreviewBar.centerYAnchor),
            replyCloseButton.widthAnchor.constraint(equalToConstant: 24),
            replyCloseButton.heightAnchor.constraint(equalToConstant: 24),

            composerContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            composerContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            composerBottomConstraint,
            composerContainer.heightAnchor.constraint(equalToConstant: 54),

            attachButton.leadingAnchor.constraint(equalTo: composerContainer.leadingAnchor, constant: 10),
            attachButton.centerYAnchor.constraint(equalTo: composerContainer.centerYAnchor),
            attachButton.widthAnchor.constraint(equalToConstant: 34),
            attachButton.heightAnchor.constraint(equalToConstant: 34),

            inputField.leadingAnchor.constraint(equalTo: attachButton.trailingAnchor, constant: 8),
            inputField.centerYAnchor.constraint(equalTo: composerContainer.centerYAnchor),
            inputField.heightAnchor.constraint(equalToConstant: 36),
            inputField.trailingAnchor.constraint(equalTo: emojiButton.leadingAnchor, constant: -6),

            emojiButton.trailingAnchor.constraint(equalTo: sendButton.leadingAnchor, constant: -6),
            emojiButton.centerYAnchor.constraint(equalTo: composerContainer.centerYAnchor),
            emojiButton.widthAnchor.constraint(equalToConstant: 32),
            emojiButton.heightAnchor.constraint(equalToConstant: 32),

            sendButton.trailingAnchor.constraint(equalTo: composerContainer.trailingAnchor, constant: -10),
            sendButton.centerYAnchor.constraint(equalTo: composerContainer.centerYAnchor),
            sendWidthConstraint,
            sendButton.heightAnchor.constraint(equalToConstant: 34)
        ])
    }

    @objc private func onThemeChanged() {
        applyTheme()
        tableView.reloadData()
    }

    private func applyTheme() {
        let t = ThemeManager.shared.current
        view.backgroundColor = t.backgroundPrimary
        ThemeManager.shared.applyGradientIfNeeded(to: view)
        navigationController?.navigationBar.barStyle = t.isDark ? .black : .default
        navigationController?.navigationBar.barTintColor = t.backgroundPrimary
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.tintColor = t.textPrimary
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: t.textPrimary]
        mentionTableView.backgroundColor = t.backgroundSecondary
        mentionTableView.separatorColor = t.separator
        refreshControl.tintColor = t.textMuted
        typingLabel.textColor = t.textMuted
        composerContainer.backgroundColor = t.backgroundPrimary
        attachButton.backgroundColor = t.surfaceCard
        attachButton.tintColor = t.textSecondary
        emojiButton.tintColor = t.textSecondary
        replyPreviewBar.backgroundColor = t.backgroundSecondary
        replyLabel.textColor = t.textSecondary
        replyCloseButton.tintColor = t.textSecondary
        inputField.backgroundColor = t.surfaceCard
        inputField.textColor = t.textPrimary
        inputField.attributedPlaceholder = NSAttributedString(
            string: currentChannel.map { "Message \(($0.type == 1 || $0.type == 3) ? "@" : "#")\($0.displayName)" } ?? "Message...",
            attributes: [.foregroundColor: t.textMuted]
        )
        updateSendButtonState()
    }

    private func updateSendButtonState() {
        let t = ThemeManager.shared.current
        let hasText = !(inputField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        sendButton.isHidden = !hasText
        sendWidthConstraint.constant = hasText ? 34 : 0
        sendButton.backgroundColor = t.accent
        sendButton.tintColor = .white
    }

    @objc private func pullToLoadOlder() {
        loadOlderMessages()
    }

    private func loadOlderMessages() {
        guard !isLoadingOlder, hasMoreMessages,
              let ch = currentChannel,
              let oldestId = messages.first?.id else {
            refreshControl.endRefreshing()
            return
        }
        isLoadingOlder = true
        let prevCount = messages.count
        DiscordStore.shared.loadMessages(channelId: ch.id, before: oldestId) { [weak self] updated in
            guard let self = self, self.currentChannel?.id == ch.id else { return }
            self.isLoadingOlder = false
            self.refreshControl.endRefreshing()
            let added = updated.count - prevCount
            if added <= 0 {
                self.hasMoreMessages = false
                return
            }
            let oldHeight = self.tableView.contentSize.height
            let oldOffset = self.tableView.contentOffset.y
            self.messages = updated
            UIView.performWithoutAnimation {
                self.tableView.reloadData()
                self.tableView.layoutIfNeeded()
                let newHeight = self.tableView.contentSize.height
                self.tableView.contentOffset = CGPoint(x: 0, y: oldOffset + (newHeight - oldHeight))
            }
        }
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if scrollView === tableView && scrollView.contentOffset.y < 60 && !messages.isEmpty {
            loadOlderMessages()
        }
    }

    @objc private func menuTapped() {
        delegate?.chatViewControllerDidTapMenu(self)
    }

    @objc private func dmCallTapped() {
        guard let ch = currentChannel else { return }
        if DiscordVoiceClient.shared.channelId != ch.id {
            DiscordStore.shared.joinVoiceChannel(ch)
        }
        let vc = VoiceCallViewController(channel: ch)
        present(UINavigationController(rootViewController: vc), animated: true)
    }

    @objc private func membersTapped() {
        guard let gid = currentChannel?.guildId else { return }
        let vc = MemberListViewController(guildId: gid)
        present(UINavigationController(rootViewController: vc), animated: true)
    }

    @objc private func pinsSearchTapped() {
        guard let ch = currentChannel else { return }
        let vc = PinsAndSearchViewController(channel: ch)
        present(UINavigationController(rootViewController: vc), animated: true)
    }

    @objc private func attachTapped() {
        guard currentChannel != nil else { return }
        let sheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        sheet.addAction(UIAlertAction(title: "Photo or Video", style: .default) { [weak self] _ in
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = .photoLibrary
            picker.mediaTypes = ["public.image", "public.movie"]
            self?.present(picker, animated: true)
        })
        sheet.addAction(UIAlertAction(title: "Send GIF", style: .default) { [weak self] _ in
            guard let self = self else { return }
            let picker = GifPickerViewController()
            picker.delegate = self
            self.present(UINavigationController(rootViewController: picker), animated: true)
        })
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(sheet, animated: true)
    }

    @objc private func emojiTapped() {
        reactionTargetMessage = nil
        let picker = EmojiPickerViewController(currentGuildId: currentChannel?.guildId)
        picker.delegate = self
        present(UINavigationController(rootViewController: picker), animated: true)
    }

    @objc private func inputEditingChanged() {
        updateSendButtonState()
        updateMentionAutocomplete()
        if let cid = currentChannel?.id, !(inputField.text ?? "").isEmpty {
            DiscordRESTClient.shared.triggerTyping(channelId: cid)
        }
    }

    private func updateMentionAutocomplete() {
        let text = inputField.text ?? ""
        guard let atIdx = text.lastIndex(of: "@") else {
            filteredMentions = []
            mentionHeightConstraint.constant = 0
            return
        }
        let afterAt = String(text[text.index(after: atIdx)...])
        if afterAt.contains(" ") {
            filteredMentions = []
            mentionHeightConstraint.constant = 0
            return
        }
        let q = afterAt.lowercased()
        filteredMentions = mentionCandidates.filter { u in
            q.isEmpty || u.username.lowercased().contains(q) || u.effectiveDisplayName.lowercased().contains(q)
        }.prefix(5).map { $0 }

        mentionHeightConstraint.constant = CGFloat(min(filteredMentions.count, 5) * 42)
        mentionTableView.reloadData()
    }

    @objc private func cancelReply() {
        replyingTo = nil
        updateReplyBar()
    }

    private func updateReplyBar() {
        if let r = replyingTo {
            replyLabel.text = "Replying to @\(r.author.effectiveDisplayName)"
            replyHeightConstraint.constant = 30
        } else {
            replyHeightConstraint.constant = 0
        }
    }

    private func formatOutgoingContent(_ raw: String) -> String {
        var result = raw

        // 1. Convert @username mentions to Discord <@userId> tags
        for (tag, uid) in pendingMentions {
            result = result.replacingOccurrences(of: tag, with: "<@\(uid)>")
        }
        if let atRegex = try? NSRegularExpression(pattern: "(?<!<)@([A-Za-z0-9_\\.]+)") {
            let ns = result as NSString
            for match in atRegex.matches(in: result, range: NSRange(location: 0, length: ns.length)).reversed() {
                let name = ns.substring(with: match.range(at: 1)).lowercased()
                if let user = mentionCandidates.first(where: { $0.username.lowercased() == name || $0.effectiveDisplayName.lowercased() == name }) {
                    result = (result as NSString).replacingCharacters(in: match.range, with: "<@\(user.id)>")
                }
            }
        }

        // 2. Convert :emoji_name: into Discord's <:name:id> / <a:name:id> format
        if let regex = try? NSRegularExpression(pattern: "(?<!<a)(?<!<):([A-Za-z0-9_]+):(?!\\d+>)") {
            let guildEmojis: [DiscordEmoji]
            if let gid = currentChannel?.guildId, let local = DiscordStore.shared.emojisByGuild[gid] {
                guildEmojis = local + DiscordStore.shared.allCustomEmojis()
            } else {
                guildEmojis = DiscordStore.shared.allCustomEmojis()
            }
            let ns = result as NSString
            for m in regex.matches(in: result, range: NSRange(location: 0, length: ns.length)).reversed() {
                let name = ns.substring(with: m.range(at: 1))
                if let found = guildEmojis.first(where: { ($0.name ?? "").lowercased() == name.lowercased() }) {
                    result = (result as NSString).replacingCharacters(in: m.range, with: found.asDiscordTag)
                }
            }
        }
        return result
    }

    @objc private func sendTapped() {
        guard let channel = currentChannel else { return }
        let raw = (inputField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return }
        let text = formatOutgoingContent(raw)
        inputField.text = ""
        pendingMentions.removeAll()
        filteredMentions.removeAll()
        mentionHeightConstraint.constant = 0
        updateSendButtonState()
        let refId = replyingTo?.id
        replyingTo = nil
        updateReplyBar()

        DiscordRESTClient.shared.sendMessage(channelId: channel.id, content: text, replyToMessageId: refId) { [weak self] res in
            if case .success(let sent) = res {
                DiscordStore.shared.gatewayDidReceiveMessageCreate(sent)
            }
            _ = self
        }
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        sendTapped()
        return false
    }

    @objc private func keyboardWillChange(_ note: Notification) {
        guard let frame = note.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect,
              let duration = note.userInfo?[UIResponder.keyboardAnimationDurationUserInfoKey] as? TimeInterval else { return }
        let converted = view.convert(frame, from: nil)
        let overlap = max(0, view.bounds.height - converted.origin.y - view.safeAreaInsets.bottom)
        composerBottomConstraint.constant = -overlap
        UIView.animate(withDuration: duration) {
            self.view.layoutIfNeeded()
        }
    }

    @objc private func handleMessageLongPress(_ gr: UILongPressGestureRecognizer) {
        guard gr.state == .began else { return }
        let pt = gr.location(in: tableView)
        guard let ip = tableView.indexPathForRow(at: pt) else { return }
        presentMessageActions(for: messages[ip.row])
    }

    private func presentMessageActions(for msg: DiscordMessage) {
        let isOwn = (msg.author.id == DiscordStore.shared.currentUser?.id)
        let sheet = MessageActionsSheetViewController(message: msg, isOwnMessage: isOwn)
        sheet.delegate = self
        present(sheet, animated: false)
    }

    func messageActions(_ sheet: MessageActionsSheetViewController, didReact emoji: String, to message: DiscordMessage) {
        DiscordRESTClient.shared.addReaction(channelId: message.channelId, messageId: message.id, emoji: emoji)
    }

    func messageActionsDidTapMoreEmojis(_ sheet: MessageActionsSheetViewController, for message: DiscordMessage) {
        reactionTargetMessage = message
        let picker = EmojiPickerViewController(currentGuildId: currentChannel?.guildId)
        picker.delegate = self
        present(UINavigationController(rootViewController: picker), animated: true)
    }

    func messageActionsDidTapReply(_ sheet: MessageActionsSheetViewController, for message: DiscordMessage) {
        replyingTo = message
        updateReplyBar()
        inputField.becomeFirstResponder()
    }

    func messageActionsDidTapCopyText(_ sheet: MessageActionsSheetViewController, for message: DiscordMessage) {
        UIPasteboard.general.string = message.content
    }

    func messageActionsDidTapCopyLink(_ sheet: MessageActionsSheetViewController, for message: DiscordMessage) {
        let gid = message.guildId ?? currentChannel?.guildId ?? "@me"
        UIPasteboard.general.string = "https://discord.com/channels/\(gid)/\(message.channelId)/\(message.id)"
    }

    func messageActionsDidTapCopyID(_ sheet: MessageActionsSheetViewController, for message: DiscordMessage) {
        UIPasteboard.general.string = message.id
    }

    func messageActionsDidTapEdit(_ sheet: MessageActionsSheetViewController, for message: DiscordMessage) {
        promptEditMessage(message)
    }

    func messageActionsDidTapDelete(_ sheet: MessageActionsSheetViewController, for message: DiscordMessage) {
        DiscordRESTClient.shared.deleteMessage(channelId: message.channelId, messageId: message.id) { err in
            if err == nil {
                DiscordStore.shared.gatewayDidReceiveMessageDelete(channelId: message.channelId, messageId: message.id)
            }
        }
    }

    private func promptEditMessage(_ msg: DiscordMessage) {
        let alert = UIAlertController(title: "Edit Message", message: nil, preferredStyle: .alert)
        alert.addTextField { tf in tf.text = msg.content }
        alert.addAction(UIAlertAction(title: "Save", style: .default) { _ in
            let text = alert.textFields?.first?.text ?? ""
            DiscordRESTClient.shared.editMessage(channelId: msg.channelId, messageId: msg.id, content: text) { res in
                if case .success(let updated) = res {
                    DiscordStore.shared.gatewayDidReceiveMessageUpdate(updated)
                }
            }
        })
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    @objc private func onMessageCreate(_ note: Notification) {
        guard let msg = note.object as? DiscordMessage, msg.channelId == currentChannel?.id else { return }
        messages = DiscordStore.shared.messagesByChannel[msg.channelId] ?? messages
        tableView.reloadData()
        scrollToBottom(animated: true)
    }

    @objc private func onMessageUpdate(_ note: Notification) {
        guard let msg = note.object as? DiscordMessage, msg.channelId == currentChannel?.id else { return }
        messages = DiscordStore.shared.messagesByChannel[msg.channelId] ?? messages
        tableView.reloadData()
    }

    @objc private func onMessageDelete(_ note: Notification) {
        guard let info = note.object as? [String: String], info["channelId"] == currentChannel?.id else { return }
        messages = DiscordStore.shared.messagesByChannel[currentChannel?.id ?? ""] ?? messages
        tableView.reloadData()
    }

    @objc private func onTyping(_ note: Notification) {
        guard let info = note.object as? [String: String],
              info["channelId"] == currentChannel?.id,
              let uid = info["userId"] else { return }
        let name = DiscordStore.shared.usersById[uid]?.effectiveDisplayName ?? "Someone"
        typingLabel.text = "\(name) is typing..."
        typingHeightConstraint.constant = 16
        typingClearTimer?.invalidate()
        typingClearTimer = Timer.scheduledTimer(withTimeInterval: 5.0, repeats: false) { [weak self] _ in
            self?.typingHeightConstraint.constant = 0
            self?.typingLabel.text = nil
        }
    }

    private func scrollToBottom(animated: Bool) {
        guard !messages.isEmpty else { return }
        DispatchQueue.main.async { [weak self] in
            guard let self = self, !self.messages.isEmpty else { return }
            self.tableView.layoutIfNeeded()
            let last = IndexPath(row: self.messages.count - 1, section: 0)
            self.tableView.scrollToRow(at: last, at: .bottom, animated: animated)
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView === mentionTableView { return filteredMentions.count }
        return messages.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView === mentionTableView {
            let t = ThemeManager.shared.current
            let cell = tableView.dequeueReusableCell(withIdentifier: "MentionCell") ?? UITableViewCell(style: .default, reuseIdentifier: "MentionCell")
            cell.backgroundColor = .clear
            cell.contentView.subviews.forEach { $0.removeFromSuperview() }
            let u = filteredMentions[indexPath.row]
            let av = AvatarWithDecorationView(frame: CGRect(x: 10, y: 7, width: 28, height: 28))
            av.showsStatusDot = false
            av.configure(user: u, status: nil, pixelSize: 64)
            cell.contentView.addSubview(av)
            let lbl = UILabel(frame: CGRect(x: 46, y: 10, width: tableView.bounds.width - 56, height: 22))
            lbl.text = "\(u.effectiveDisplayName)  @\(u.username)"
            lbl.font = UIFont.systemFont(ofSize: 14, weight: .medium)
            lbl.textColor = t.textPrimary
            cell.contentView.addSubview(lbl)
            return cell
        }

        let cell = tableView.dequeueReusableCell(withIdentifier: MessageCell.reuseID, for: indexPath) as! MessageCell
        cell.delegate = self
        let msg = messages[indexPath.row]
        let prev = indexPath.row > 0 ? messages[indexPath.row - 1] : nil
        var grouped = false
        if let prev = prev, prev.author.id == msg.author.id, msg.referencedMessage?.message == nil {
            if let d1 = MessageCell.parseDate(prev.timestamp), let d2 = MessageCell.parseDate(msg.timestamp) {
                grouped = d2.timeIntervalSince(d1) < 420
            } else {
                grouped = true
            }
        }
        cell.configure(with: msg, grouped: grouped)
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView === mentionTableView {
            let u = filteredMentions[indexPath.row]
            let text = inputField.text ?? ""
            if let atIdx = text.lastIndex(of: "@") {
                let prefix = String(text[..<atIdx])
                let tag = "@\(u.username)"
                pendingMentions[tag] = u.id
                inputField.text = prefix + tag + " "
                updateSendButtonState()
            }
            filteredMentions = []
            mentionHeightConstraint.constant = 0
            return
        }

        replyingTo = messages[indexPath.row]
        updateReplyBar()
        inputField.becomeFirstResponder()
    }

    func messageCellNeedsRelayout(_ cell: MessageCell) {
        UIView.performWithoutAnimation {
            tableView.beginUpdates()
            tableView.endUpdates()
        }
    }

    func messageCell(_ cell: MessageCell, didTapAuthor user: DiscordUser) {
        let profileVC = UserProfileViewController(userId: user.id, guildId: currentChannel?.guildId, initialUser: user)
        present(UINavigationController(rootViewController: profileVC), animated: true)
    }

    func messageCell(_ cell: MessageCell, didTapImageURL url: String, isGif: Bool) {
        let preview = MediaPreviewViewController(urlString: url, isGif: isGif)
        present(UINavigationController(rootViewController: preview), animated: true)
    }

    func messageCell(_ cell: MessageCell, didTapVideoURL url: String) {
        guard let videoURL = URL(string: url) else { return }
        let playerVC = AVPlayerViewController()
        playerVC.player = AVPlayer(url: videoURL)
        present(playerVC, animated: true) { playerVC.player?.play() }
    }


    func messageCell(_ cell: MessageCell, didTapInviteCode code: String) {
        DiscordRESTClient.shared.fetchInvite(code: code) { [weak self] res in
            guard let self = self else { return }
            let serverName: String
            let memberInfo: String
            if case .success(let info) = res {
                serverName = info.guild?.name ?? "Discord Server"
                memberInfo = info.approximateMemberCount.map { "\($0) members" } ?? "Invite: \(code)"
            } else {
                serverName = "Discord Server"
                memberInfo = "Invite code: \(code)"
            }
            let alert = UIAlertController(title: "Join \(serverName)?", message: memberInfo, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Join Server", style: .default) { _ in
                self.performJoinInvite(code: code)

            })
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            self.present(alert, animated: true)
        }
    }

    func messageCell(_ cell: MessageCell, didTapLinkURL url: URL) {
        present(SFSafariViewController(url: url), animated: true)
    }

    func messageCell(_ cell: MessageCell, didToggleReaction reaction: DiscordReaction, message: DiscordMessage) {
        let emoji = reaction.emoji.apiIdentifier
        if reaction.me {
            DiscordRESTClient.shared.removeReaction(channelId: message.channelId, messageId: message.id, emoji: emoji)
        } else {
            DiscordRESTClient.shared.addReaction(channelId: message.channelId, messageId: message.id, emoji: emoji)
        }
    }

    func messageCell(_ cell: MessageCell, didTapAddReaction message: DiscordMessage) {
        presentMessageActions(for: message)
    }

    func messageCell(_ cell: MessageCell, didVotePoll answerId: Int, message: DiscordMessage) {
        DiscordRESTClient.shared.votePoll(channelId: message.channelId, messageId: message.id, answerId: answerId)
    }

    func gifPicker(_ picker: GifPickerViewController, didSelectGifURL url: String) {
        guard let channel = currentChannel else { return }
        DiscordRESTClient.shared.sendMessage(channelId: channel.id, content: url, replyToMessageId: replyingTo?.id) { res in
            if case .success(let sent) = res {
                DiscordStore.shared.gatewayDidReceiveMessageCreate(sent)
            }
        }
        replyingTo = nil
        updateReplyBar()
    }

    func emojiPicker(_ picker: EmojiPickerViewController, didSelectEmojiText text: String, apiIdentifier: String) {
        if let target = reactionTargetMessage {
            DiscordRESTClient.shared.addReaction(channelId: target.channelId, messageId: target.id, emoji: apiIdentifier)
            reactionTargetMessage = nil
        } else {
            let existing = inputField.text ?? ""
            let sep = (!existing.isEmpty && !existing.hasSuffix(" ")) ? " " : ""
            inputField.text = existing + sep + text + " "
            updateSendButtonState()
        }
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        picker.dismiss(animated: true)
        guard let cid = currentChannel?.id else { return }
        if let img = info[.originalImage] as? UIImage,
           let data = img.jpegData(compressionQuality: 0.82) {
            DiscordRESTClient.shared.uploadFile(channelId: cid, data: data, filename: "photo.jpg", mimeType: "image/jpeg") { res in
                if case .success(let sent) = res {
                    DiscordStore.shared.gatewayDidReceiveMessageCreate(sent)
                }
            }
        } else if let mediaURL = info[.mediaURL] as? URL,
                  let data = try? Data(contentsOf: mediaURL) {
            DiscordRESTClient.shared.uploadFile(channelId: cid, data: data, filename: mediaURL.lastPathComponent, mimeType: "video/mp4") { res in
                if case .success(let sent) = res {
                    DiscordStore.shared.gatewayDidReceiveMessageCreate(sent)
                }
            }
        }
    }

    private func performJoinInvite(code: String, captchaKey: String? = nil, captchaRqtoken: String? = nil) {
        DiscordRESTClient.shared.acceptInvite(code: code, captchaKey: captchaKey, captchaRqtoken: captchaRqtoken) { [weak self] res in
            guard let self = self else { return }
            switch res {
            case .success:
                DiscordStore.shared.refreshGuilds()
            case .failure(let err):
                if case RESTError.captchaRequired(let challenge) = err {
                    let cap = CaptchaViewController(challenge: challenge) { key, rqt in
                        if let key = key {
                            self.performJoinInvite(code: code, captchaKey: key, captchaRqtoken: rqt)
                        }
                    }
                    self.present(UINavigationController(rootViewController: cap), animated: true)
                } else {
                    let errAlert = UIAlertController(title: "Could Not Join", message: err.localizedDescription, preferredStyle: .alert)
                    errAlert.addAction(UIAlertAction(title: "OK", style: .default))
                    self.present(errAlert, animated: true)
                }
            }
        }
    }

}
