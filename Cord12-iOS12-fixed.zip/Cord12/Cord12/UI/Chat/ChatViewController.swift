import UIKit
import AVKit
import SafariServices

protocol ChatViewControllerDelegate: AnyObject {
    func chatViewControllerDidTapMenu(_ vc: ChatViewController)
}

final class ChatViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, MessageCellDelegate, GifPickerDelegate, EmojiPickerDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    weak var delegate: ChatViewControllerDelegate?

    private let tableView = UITableView(frame: .zero, style: .plain)
    private let typingLabel = UILabel()
    private let composerContainer = UIView()
    private let replyPreviewBar = UIView()
    private let replyLabel = UILabel()
    private let replyCloseButton = UIButton(type: .system)
    private let attachButton = UIButton(type: .system)
    private let gifButton = UIButton(type: .system)
    private let emojiButton = UIButton(type: .system)
    private let inputField = UITextField()
    private let sendButton = UIButton(type: .system)
    private var composerBottomConstraint: NSLayoutConstraint!
    private var replyHeightConstraint: NSLayoutConstraint!
    private var typingHeightConstraint: NSLayoutConstraint!

    private var membersItem: UIBarButtonItem!
    private var pinsItem: UIBarButtonItem!

    private var currentChannel: DiscordChannel?
    private var messages: [DiscordMessage] = []
    private var replyingTo: DiscordMessage?
    private var typingClearTimer: Timer?
    private var fallbackSyncTimer: Timer?
    private var reactionTargetMessage: DiscordMessage?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupNav()
        setupUI()
        applyTheme()

        NotificationCenter.default.addObserver(self, selector: #selector(onMessageCreate(_:)), name: .cordStoreDidReceiveMessage, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(onMessageUpdate(_:)), name: .cordStoreDidUpdateMessage, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(onMessageDelete(_:)), name: .cordStoreDidDeleteMessage, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(onTyping(_:)), name: .cordStoreDidReceiveTyping, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(onThemeChanged), name: .cordThemeDidChange, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillChange(_:)), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        ThemeManager.shared.applyGradientIfNeeded(to: view)
    }

    func loadChannel(_ channel: DiscordChannel) {
        self.currentChannel = channel
        self.replyingTo = nil
        updateReplyBar()
        typingHeightConstraint.constant = 0
        title = (channel.type == 1 || channel.type == 3) ? "@ \(channel.displayName)" : "# \(channel.displayName)"
        navigationItem.rightBarButtonItems = (channel.guildId != nil) ? [membersItem, pinsItem] : [pinsItem]
        applyTheme()

        DiscordStore.shared.loadMessages(channelId: channel.id) { [weak self] msgs in
            guard let self = self, self.currentChannel?.id == channel.id else { return }
            self.messages = msgs
            self.tableView.reloadData()
            self.scrollToBottom(animated: false)
        }

        // Realtime safety net if Gateway drops on iOS 12
        fallbackSyncTimer?.invalidate()
        fallbackSyncTimer = Timer.scheduledTimer(withTimeInterval: 3.5, repeats: true) { [weak self] _ in
            guard let self = self, let ch = self.currentChannel, !DiscordStore.shared.isGatewayConnected else { return }
            DiscordStore.shared.loadMessages(channelId: ch.id) { msgs in
                guard self.currentChannel?.id == ch.id, msgs.count != self.messages.count || msgs.last?.id != self.messages.last?.id else { return }
                self.messages = msgs
                self.tableView.reloadData()
                self.scrollToBottom(animated: true)
            }
        }
    }

    private func setupNav() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            image: DiscordIcons.image(.menu, size: 22),
            style: .plain,
            target: self,
            action: #selector(menuTapped)
        )
        membersItem = UIBarButtonItem(
            image: DiscordIcons.image(.members, size: 20),
            style: .plain,
            target: self,
            action: #selector(membersTapped)
        )
        pinsItem = UIBarButtonItem(
            image: DiscordIcons.image(.badge, size: 19),
            style: .plain,
            target: self,
            action: #selector(pinsSearchTapped)
        )
        navigationItem.rightBarButtonItems = [pinsItem]
    }

    private func setupUI() {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.separatorStyle = .none
        tableView.backgroundColor = .clear
        tableView.estimatedRowHeight = 56
        tableView.rowHeight = UITableView.automaticDimension
        tableView.keyboardDismissMode = .interactive
        tableView.contentInset = UIEdgeInsets(top: 6, left: 0, bottom: 8, right: 0)
        tableView.register(MessageCell.self, forCellReuseIdentifier: MessageCell.reuseID)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)

        tableView.addGestureRecognizer(UILongPressGestureRecognizer(target: self, action: #selector(handleMessageLongPress(_:))))

        typingLabel.font = UIFont.systemFont(ofSize: 11, weight: .medium)
        typingLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(typingLabel)
        typingHeightConstraint = typingLabel.heightAnchor.constraint(equalToConstant: 0)

        replyPreviewBar.clipsToBounds = true
        replyPreviewBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(replyPreviewBar)
        replyHeightConstraint = replyPreviewBar.heightAnchor.constraint(equalToConstant: 0)

        replyLabel.font = UIFont.systemFont(ofSize: 12, weight: .medium)
        replyLabel.translatesAutoresizingMaskIntoConstraints = false
        replyPreviewBar.addSubview(replyLabel)

        replyCloseButton.setImage(DiscordIcons.image(.close, size: 14), for: .normal)
        replyCloseButton.addTarget(self, action: #selector(cancelReply), for: .touchUpInside)
        replyCloseButton.translatesAutoresizingMaskIntoConstraints = false
        replyPreviewBar.addSubview(replyCloseButton)

        composerContainer.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(composerContainer)

        attachButton.setImage(DiscordIcons.image(.plus, size: 20), for: .normal)
        attachButton.layer.cornerRadius = 16
        attachButton.addTarget(self, action: #selector(attachTapped), for: .touchUpInside)
        attachButton.translatesAutoresizingMaskIntoConstraints = false
        composerContainer.addSubview(attachButton)

        gifButton.setImage(DiscordIcons.image(.gif, size: 20), for: .normal)
        gifButton.addTarget(self, action: #selector(gifTapped), for: .touchUpInside)
        gifButton.translatesAutoresizingMaskIntoConstraints = false
        composerContainer.addSubview(gifButton)

        emojiButton.setImage(DiscordIcons.image(.smile, size: 20), for: .normal)
        emojiButton.addTarget(self, action: #selector(emojiTapped), for: .touchUpInside)
        emojiButton.translatesAutoresizingMaskIntoConstraints = false
        composerContainer.addSubview(emojiButton)

        inputField.placeholder = "Message..."
        inputField.font = UIFont.systemFont(ofSize: 15)
        inputField.layer.cornerRadius = 18
        inputField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 12, height: 1))
        inputField.leftViewMode = .always
        inputField.returnKeyType = .send
        inputField.delegate = self
        inputField.addTarget(self, action: #selector(inputEditingChanged), for: .editingChanged)
        inputField.translatesAutoresizingMaskIntoConstraints = false
        composerContainer.addSubview(inputField)

        sendButton.setImage(DiscordIcons.image(.send, size: 17), for: .normal)
        sendButton.layer.cornerRadius = 17
        sendButton.addTarget(self, action: #selector(sendTapped), for: .touchUpInside)
        sendButton.translatesAutoresizingMaskIntoConstraints = false
        composerContainer.addSubview(sendButton)

        if #available(iOS 11.0, *) {
            composerBottomConstraint = composerContainer.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        } else {
            composerBottomConstraint = composerContainer.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        }

        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: typingLabel.topAnchor),

            typingLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 14),
            typingLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -14),
            typingLabel.bottomAnchor.constraint(equalTo: replyPreviewBar.topAnchor),
            typingHeightConstraint,

            replyPreviewBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            replyPreviewBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            replyPreviewBar.bottomAnchor.constraint(equalTo: composerContainer.topAnchor),
            replyHeightConstraint,

            replyLabel.leadingAnchor.constraint(equalTo: replyPreviewBar.leadingAnchor, constant: 14),
            replyLabel.centerYAnchor.constraint(equalTo: replyPreviewBar.centerYAnchor),
            replyLabel.trailingAnchor.constraint(equalTo: replyCloseButton.leadingAnchor, constant: -8),

            replyCloseButton.trailingAnchor.constraint(equalTo: replyPreviewBar.trailingAnchor, constant: -12),
            replyCloseButton.centerYAnchor.constraint(equalTo: replyPreviewBar.centerYAnchor),
            replyCloseButton.widthAnchor.constraint(equalToConstant: 24),
            replyCloseButton.heightAnchor.constraint(equalToConstant: 24),

            composerContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            composerContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            composerBottomConstraint,
            composerContainer.heightAnchor.constraint(equalToConstant: 54),

            attachButton.leadingAnchor.constraint(equalTo: composerContainer.leadingAnchor, constant: 8),
            attachButton.centerYAnchor.constraint(equalTo: composerContainer.centerYAnchor),
            attachButton.widthAnchor.constraint(equalToConstant: 32),
            attachButton.heightAnchor.constraint(equalToConstant: 32),

            gifButton.leadingAnchor.constraint(equalTo: attachButton.trailingAnchor, constant: 4),
            gifButton.centerYAnchor.constraint(equalTo: composerContainer.centerYAnchor),
            gifButton.widthAnchor.constraint(equalToConstant: 32),
            gifButton.heightAnchor.constraint(equalToConstant: 32),

            inputField.leadingAnchor.constraint(equalTo: gifButton.trailingAnchor, constant: 6),
            inputField.centerYAnchor.constraint(equalTo: composerContainer.centerYAnchor),
            inputField.heightAnchor.constraint(equalToConstant: 36),
            inputField.trailingAnchor.constraint(equalTo: emojiButton.leadingAnchor, constant: -4),

            emojiButton.trailingAnchor.constraint(equalTo: sendButton.leadingAnchor, constant: -6),
            emojiButton.centerYAnchor.constraint(equalTo: composerContainer.centerYAnchor),
            emojiButton.widthAnchor.constraint(equalToConstant: 32),
            emojiButton.heightAnchor.constraint(equalToConstant: 32),

            sendButton.trailingAnchor.constraint(equalTo: composerContainer.trailingAnchor, constant: -10),
            sendButton.centerYAnchor.constraint(equalTo: composerContainer.centerYAnchor),
            sendButton.widthAnchor.constraint(equalToConstant: 34),
            sendButton.heightAnchor.constraint(equalToConstant: 34)
        ])
    }

    @objc private func onThemeChanged() {
        applyTheme()
        tableView.reloadData()
    }

    private func applyTheme() {
        let t = ThemeManager.shared.current
        view.backgroundColor = t.backgroundPrimary
        ThemeManager.shared.applyGradientIfNeeded(to: view)
        navigationController?.navigationBar.barTintColor = t.backgroundPrimary
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.tintColor = t.textPrimary
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: t.textPrimary]
        typingLabel.textColor = t.textMuted
        composerContainer.backgroundColor = t.backgroundPrimary
        attachButton.backgroundColor = t.surfaceCard
        attachButton.tintColor = t.textSecondary
        gifButton.tintColor = t.textSecondary
        emojiButton.tintColor = t.textSecondary
        replyPreviewBar.backgroundColor = t.backgroundSecondary
        replyLabel.textColor = t.textSecondary
        replyCloseButton.tintColor = t.textSecondary
        inputField.backgroundColor = t.surfaceCard
        inputField.textColor = t.textPrimary
        inputField.attributedPlaceholder = NSAttributedString(
            string: currentChannel.map { "Message \(($0.type == 1 || $0.type == 3) ? "@" : "#")\($0.displayName)" } ?? "Message...",
            attributes: [.foregroundColor: t.textMuted]
        )
        updateSendButtonState()
    }

    private func updateSendButtonState() {
        let t = ThemeManager.shared.current
        let hasText = !(inputField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        sendButton.backgroundColor = hasText ? t.accent : t.surfaceCard
        sendButton.tintColor = hasText ? .white : t.textMuted
    }

    @objc private func menuTapped() {
        delegate?.chatViewControllerDidTapMenu(self)
    }

    @objc private func membersTapped() {
        guard let gid = currentChannel?.guildId else { return }
        let vc = MemberListViewController(guildId: gid)
        present(UINavigationController(rootViewController: vc), animated: true)
    }

    @objc private func pinsSearchTapped() {
        guard let ch = currentChannel else { return }
        let vc = PinsAndSearchViewController(channel: ch)
        present(UINavigationController(rootViewController: vc), animated: true)
    }

    @objc private func attachTapped() {
        guard currentChannel != nil else { return }
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        picker.mediaTypes = ["public.image", "public.movie"]
        present(picker, animated: true)
    }

    @objc private func gifTapped() {
        let picker = GifPickerViewController()
        picker.delegate = self
        present(UINavigationController(rootViewController: picker), animated: true)
    }

    @objc private func emojiTapped() {
        reactionTargetMessage = nil
        let picker = EmojiPickerViewController(currentGuildId: currentChannel?.guildId)
        picker.delegate = self
        present(UINavigationController(rootViewController: picker), animated: true)
    }

    @objc private func inputEditingChanged() {
        updateSendButtonState()
        if let cid = currentChannel?.id, !(inputField.text ?? "").isEmpty {
            DiscordRESTClient.shared.triggerTyping(channelId: cid)
        }
    }

    @objc private func cancelReply() {
        replyingTo = nil
        updateReplyBar()
    }

    private func updateReplyBar() {
        if let r = replyingTo {
            replyLabel.text = "Replying to @\(r.author.effectiveDisplayName)"
            replyHeightConstraint.constant = 30
        } else {
            replyHeightConstraint.constant = 0
        }
    }

    private func formatOutgoingEmojis(_ raw: String) -> String {
        var result = raw
        // Convert typed :emoji_name: into Discord's <:name:id> format when matching an available emoji
        guard let regex = try? NSRegularExpression(pattern: "(?<!<a)(?<!<):([A-Za-z0-9_]+):(?!\\d+>)") else {
            return result
        }
        let guildEmojis: [DiscordEmoji]
        if let gid = currentChannel?.guildId, let local = DiscordStore.shared.emojisByGuild[gid] {
            guildEmojis = local + DiscordStore.shared.allCustomEmojis()
        } else {
            guildEmojis = DiscordStore.shared.allCustomEmojis()
        }
        let hasNitro = (DiscordStore.shared.currentUser?.premiumType ?? 0) > 0
        let currentGuildSet = Set((currentChannel?.guildId.flatMap { DiscordStore.shared.emojisByGuild[$0] } ?? []).compactMap { $0.id })

        let ns = result as NSString
        let matches = regex.matches(in: result, range: NSRange(location: 0, length: ns.length))
        for m in matches.reversed() {
            let name = ns.substring(with: m.range(at: 1))
            if let found = guildEmojis.first(where: { ($0.name ?? "").lowercased() == name.lowercased() }), let eid = found.id {
                let inCurrentGuild = currentGuildSet.contains(eid) && found.animated != true
                if hasNitro || inCurrentGuild {
                    result = (result as NSString).replacingCharacters(in: m.range, with: found.asDiscordTag)
                }
            }
        }
        return result
    }

    @objc private func sendTapped() {
        guard let channel = currentChannel else { return }
        let raw = (inputField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return }
        let text = formatOutgoingEmojis(raw)
        inputField.text = ""
        updateSendButtonState()
        let refId = replyingTo?.id
        replyingTo = nil
        updateReplyBar()

        DiscordRESTClient.shared.sendMessage(channelId: channel.id, content: text, replyToMessageId: refId) { [weak self] res in
            if case .success(let sent) = res {
                DiscordStore.shared.gatewayDidReceiveMessageCreate(sent)
            }
            _ = self
        }
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        sendTapped()
        return false
    }

    @objc private func keyboardWillChange(_ note: Notification) {
        guard let frame = note.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect,
              let duration = note.userInfo?[UIResponder.keyboardAnimationDurationUserInfoKey] as? TimeInterval else { return }
        let converted = view.convert(frame, from: nil)
        let overlap = max(0, view.bounds.height - converted.origin.y - view.safeAreaInsets.bottom)
        composerBottomConstraint.constant = -overlap
        UIView.animate(withDuration: duration) {
            self.view.layoutIfNeeded()
        }
    }

    @objc private func handleMessageLongPress(_ gr: UILongPressGestureRecognizer) {
        guard gr.state == .began else { return }
        let pt = gr.location(in: tableView)
        guard let ip = tableView.indexPathForRow(at: pt) else { return }
        presentMessageActions(for: messages[ip.row])
    }

    private func presentMessageActions(for msg: DiscordMessage) {
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        for emoji in ["👍", "❤️", "😂", "🔥", "💀", "✨"] {
            alert.addAction(UIAlertAction(title: "React \(emoji)", style: .default) { _ in
                DiscordRESTClient.shared.addReaction(channelId: msg.channelId, messageId: msg.id, emoji: emoji)
            })
        }
        alert.addAction(UIAlertAction(title: "More Emojis...", style: .default) { [weak self] _ in
            self?.reactionTargetMessage = msg
            let picker = EmojiPickerViewController(currentGuildId: self?.currentChannel?.guildId)
            picker.delegate = self
            self?.present(UINavigationController(rootViewController: picker), animated: true)
        })
        alert.addAction(UIAlertAction(title: "Reply", style: .default) { [weak self] _ in
            self?.replyingTo = msg
            self?.updateReplyBar()
            self?.inputField.becomeFirstResponder()
        })
        alert.addAction(UIAlertAction(title: "Copy Text", style: .default) { _ in
            UIPasteboard.general.string = msg.content
        })
        if msg.author.id == DiscordStore.shared.currentUser?.id {
            alert.addAction(UIAlertAction(title: "Edit Message", style: .default) { [weak self] _ in
                self?.promptEditMessage(msg)
            })
            alert.addAction(UIAlertAction(title: "Delete Message", style: .destructive) { _ in
                DiscordRESTClient.shared.deleteMessage(channelId: msg.channelId, messageId: msg.id) { err in
                    if err == nil {
                        DiscordStore.shared.gatewayDidReceiveMessageDelete(channelId: msg.channelId, messageId: msg.id)
                    }
                }
            })
        }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    private func promptEditMessage(_ msg: DiscordMessage) {
        let alert = UIAlertController(title: "Edit Message", message: nil, preferredStyle: .alert)
        alert.addTextField { tf in tf.text = msg.content }
        alert.addAction(UIAlertAction(title: "Save", style: .default) { _ in
            let text = alert.textFields?.first?.text ?? ""
            DiscordRESTClient.shared.editMessage(channelId: msg.channelId, messageId: msg.id, content: text) { res in
                if case .success(let updated) = res {
                    DiscordStore.shared.gatewayDidReceiveMessageUpdate(updated)
                }
            }
        })
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    @objc private func onMessageCreate(_ note: Notification) {
        guard let msg = note.object as? DiscordMessage, msg.channelId == currentChannel?.id else { return }
        messages = DiscordStore.shared.messagesByChannel[msg.channelId] ?? messages
        tableView.reloadData()
        scrollToBottom(animated: true)
    }

    @objc private func onMessageUpdate(_ note: Notification) {
        guard let msg = note.object as? DiscordMessage, msg.channelId == currentChannel?.id else { return }
        messages = DiscordStore.shared.messagesByChannel[msg.channelId] ?? messages
        tableView.reloadData()
    }

    @objc private func onMessageDelete(_ note: Notification) {
        guard let info = note.object as? [String: String], info["channelId"] == currentChannel?.id else { return }
        messages = DiscordStore.shared.messagesByChannel[currentChannel?.id ?? ""] ?? messages
        tableView.reloadData()
    }

    @objc private func onTyping(_ note: Notification) {
        guard let info = note.object as? [String: String],
              info["channelId"] == currentChannel?.id,
              let uid = info["userId"] else { return }
        let name = DiscordStore.shared.usersById[uid]?.effectiveDisplayName ?? "Someone"
        typingLabel.text = "\(name) is typing..."
        typingHeightConstraint.constant = 16
        typingClearTimer?.invalidate()
        typingClearTimer = Timer.scheduledTimer(withTimeInterval: 5.0, repeats: false) { [weak self] _ in
            self?.typingHeightConstraint.constant = 0
            self?.typingLabel.text = nil
        }
    }

    private func scrollToBottom(animated: Bool) {
        guard !messages.isEmpty else { return }
        DispatchQueue.main.async { [weak self] in
            guard let self = self, !self.messages.isEmpty else { return }
            self.tableView.layoutIfNeeded()
            let last = IndexPath(row: self.messages.count - 1, section: 0)
            self.tableView.scrollToRow(at: last, at: .bottom, animated: animated)
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MessageCell.reuseID, for: indexPath) as! MessageCell
        cell.delegate = self
        let msg = messages[indexPath.row]
        let prev = indexPath.row > 0 ? messages[indexPath.row - 1] : nil
        var grouped = false
        if let prev = prev, prev.author.id == msg.author.id, msg.referencedMessage?.message == nil {
            if let d1 = MessageCell.parseDate(prev.timestamp), let d2 = MessageCell.parseDate(msg.timestamp) {
                grouped = d2.timeIntervalSince(d1) < 420
            } else {
                grouped = true
            }
        }
        cell.configure(with: msg, grouped: grouped)
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        replyingTo = messages[indexPath.row]
        updateReplyBar()
        inputField.becomeFirstResponder()
    }

    func messageCellNeedsRelayout(_ cell: MessageCell) {
        UIView.performWithoutAnimation {
            tableView.beginUpdates()
            tableView.endUpdates()
        }
    }

    func messageCell(_ cell: MessageCell, didTapAuthor user: DiscordUser) {
        let profileVC = UserProfileViewController(userId: user.id, guildId: currentChannel?.guildId, initialUser: user)
        present(UINavigationController(rootViewController: profileVC), animated: true)
    }

    func messageCell(_ cell: MessageCell, didTapImageURL url: String, isGif: Bool) {
        let preview = MediaPreviewViewController(urlString: url, isGif: isGif)
        present(UINavigationController(rootViewController: preview), animated: true)
    }

    func messageCell(_ cell: MessageCell, didTapVideoURL url: String) {
        guard let videoURL = URL(string: url) else { return }
        let playerVC = AVPlayerViewController()
        playerVC.player = AVPlayer(url: videoURL)
        present(playerVC, animated: true) { playerVC.player?.play() }
    }

    func messageCell(_ cell: MessageCell, didTapLinkURL url: URL) {
        present(SFSafariViewController(url: url), animated: true)
    }

    func messageCell(_ cell: MessageCell, didToggleReaction reaction: DiscordReaction, message: DiscordMessage) {
        let emoji = reaction.emoji.apiIdentifier
        if reaction.me {
            DiscordRESTClient.shared.removeReaction(channelId: message.channelId, messageId: message.id, emoji: emoji)
        } else {
            DiscordRESTClient.shared.addReaction(channelId: message.channelId, messageId: message.id, emoji: emoji)
        }
    }

    func messageCell(_ cell: MessageCell, didTapAddReaction message: DiscordMessage) {
        presentMessageActions(for: message)
    }

    func messageCell(_ cell: MessageCell, didVotePoll answerId: Int, message: DiscordMessage) {
        DiscordRESTClient.shared.votePoll(channelId: message.channelId, messageId: message.id, answerId: answerId)
    }

    func gifPicker(_ picker: GifPickerViewController, didSelectGifURL url: String) {
        guard let channel = currentChannel else { return }
        DiscordRESTClient.shared.sendMessage(channelId: channel.id, content: url, replyToMessageId: replyingTo?.id) { res in
            if case .success(let sent) = res {
                DiscordStore.shared.gatewayDidReceiveMessageCreate(sent)
            }
        }
        replyingTo = nil
        updateReplyBar()
    }

    func emojiPicker(_ picker: EmojiPickerViewController, didSelectEmojiText text: String, apiIdentifier: String) {
        if let target = reactionTargetMessage {
            DiscordRESTClient.shared.addReaction(channelId: target.channelId, messageId: target.id, emoji: apiIdentifier)
            reactionTargetMessage = nil
        } else {
            let existing = inputField.text ?? ""
            let sep = (!existing.isEmpty && !existing.hasSuffix(" ")) ? " " : ""
            inputField.text = existing + sep + text + " "
            updateSendButtonState()
        }
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        picker.dismiss(animated: true)
        guard let cid = currentChannel?.id else { return }
        if let img = info[.originalImage] as? UIImage,
           let data = img.jpegData(compressionQuality: 0.82) {
            DiscordRESTClient.shared.uploadFile(channelId: cid, data: data, filename: "photo.jpg", mimeType: "image/jpeg") { res in
                if case .success(let sent) = res {
                    DiscordStore.shared.gatewayDidReceiveMessageCreate(sent)
                }
            }
        } else if let mediaURL = info[.mediaURL] as? URL,
                  let data = try? Data(contentsOf: mediaURL) {
            DiscordRESTClient.shared.uploadFile(channelId: cid, data: data, filename: mediaURL.lastPathComponent, mimeType: "video/mp4") { res in
                if case .success(let sent) = res {
                    DiscordStore.shared.gatewayDidReceiveMessageCreate(sent)
                }
            }
        }
    }
}
