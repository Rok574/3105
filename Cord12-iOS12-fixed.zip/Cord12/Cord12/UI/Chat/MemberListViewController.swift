import UIKit

final class MemberListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private let guildId: String
    private let tableView = UITableView(frame: .zero, style: .plain)
    private var members: [GuildMember] = []

    init(guildId: String) {
        self.guildId = guildId
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Members"
        let t = ThemeManager.shared.current
        view.backgroundColor = t.backgroundPrimary
        navigationController?.navigationBar.barTintColor = t.backgroundSecondary
        navigationController?.navigationBar.tintColor = t.textPrimary
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: t.textPrimary]

        navigationItem.leftBarButtonItem = UIBarButtonItem(
            image: DiscordIcons.image(.close, size: 18),
            style: .plain,
            target: self,
            action: #selector(closeTapped)
        )

        tableView.dataSource = self
        tableView.delegate = self
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.rowHeight = 58
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        DiscordRESTClient.shared.fetchGuildMembers(guildId: guildId) { [weak self] res in
            if case .success(let list) = res {
                self?.members = list
                self?.tableView.reloadData()
            }
        }
    }

    @objc private func closeTapped() {
        dismiss(animated: true)
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return members.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MemberCell") ?? UITableViewCell(style: .default, reuseIdentifier: "MemberCell")
        cell.backgroundColor = .clear
        cell.contentView.subviews.forEach { $0.removeFromSuperview() }

        let m = members[indexPath.row]
        guard let user = m.user else { return cell }

        let nameplate = NameplateBannerView(frame: CGRect(x: 10, y: 4, width: tableView.bounds.width - 20, height: 50))
        nameplate.configure(nameplate: user.collectibles?.nameplate)
        cell.contentView.addSubview(nameplate)

        let avatar = AvatarWithDecorationView(frame: CGRect(x: 16, y: 10, width: 38, height: 38))
        let status = DiscordStore.shared.presencesByUserId[user.id]
        avatar.configure(user: user, status: status, pixelSize: 64)
        cell.contentView.addSubview(avatar)

        let name = StyledNameLabel(frame: CGRect(x: 64, y: 16, width: tableView.bounds.width - 84, height: 24))
        name.baseFontSize = 15
        name.defaultColor = ThemeManager.shared.current.textPrimary
        name.style = user.displayNameStyles
        name.text = m.nick ?? user.effectiveDisplayName
        cell.contentView.addSubview(name)

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard let user = members[indexPath.row].user else { return }
        let profileVC = UserProfileViewController(userId: user.id, guildId: guildId, initialUser: user)
        navigationController?.pushViewController(profileVC, animated: true)
    }
}
