import UIKit

final class PinsAndSearchViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {
    private let channel: DiscordChannel
    private let segment = UISegmentedControl(items: ["Pinned Messages", "Search Channel"])
    private let searchBar = UISearchBar()
    private let tableView = UITableView(frame: .zero, style: .plain)

    private var pins: [DiscordMessage] = []
    private var searchResults: [DiscordMessage] = []

    private var displayed: [DiscordMessage] {
        return segment.selectedSegmentIndex == 0 ? pins : searchResults
    }

    init(channel: DiscordChannel) {
        self.channel = channel
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "#\(channel.displayName)"
        let t = ThemeManager.shared.current
        view.backgroundColor = t.backgroundPrimary
        navigationController?.navigationBar.barTintColor = t.backgroundSecondary
        navigationController?.navigationBar.tintColor = t.textPrimary
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: t.textPrimary]

        navigationItem.leftBarButtonItem = UIBarButtonItem(
            image: DiscordIcons.image(.close, size: 18),
            style: .plain,
            target: self,
            action: #selector(closeTapped)
        )

        segment.selectedSegmentIndex = 0
        segment.tintColor = t.accent
        segment.addTarget(self, action: #selector(segmentChanged), for: .valueChanged)
        segment.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(segment)

        searchBar.placeholder = "Search messages in #\(channel.displayName)"
        searchBar.searchBarStyle = .minimal
        searchBar.delegate = self
        searchBar.isHidden = true
        searchBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(searchBar)

        tableView.dataSource = self
        tableView.delegate = self
        tableView.backgroundColor = .clear
        tableView.separatorColor = t.separator
        tableView.estimatedRowHeight = 64
        tableView.rowHeight = UITableView.automaticDimension
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)

        let topRef: NSLayoutYAxisAnchor
        if #available(iOS 11.0, *) {
            topRef = view.safeAreaLayoutGuide.topAnchor
        } else {
            topRef = view.topAnchor
        }

        NSLayoutConstraint.activate([
            segment.topAnchor.constraint(equalTo: topRef, constant: 10),
            segment.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 14),
            segment.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -14),

            searchBar.topAnchor.constraint(equalTo: segment.bottomAnchor, constant: 4),
            searchBar.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 6),
            searchBar.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -6),

            tableView.topAnchor.constraint(equalTo: searchBar.bottomAnchor, constant: 4),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        DiscordRESTClient.shared.fetchPinnedMessages(channelId: channel.id) { [weak self] res in
            if case .success(let list) = res {
                self?.pins = list
                self?.tableView.reloadData()
            }
        }
    }

    @objc private func segmentChanged() {
        searchBar.isHidden = (segment.selectedSegmentIndex == 0)
        tableView.reloadData()
    }

    @objc private func closeTapped() {
        dismiss(animated: true)
    }

    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        let q = (searchBar.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return }
        DiscordRESTClient.shared.searchChannelMessages(guildId: channel.guildId, channelId: channel.id, query: q) { [weak self] res in
            if case .success(let msgs) = res {
                self?.searchResults = msgs
                self?.tableView.reloadData()
            }
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return displayed.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let t = ThemeManager.shared.current
        let cell = tableView.dequeueReusableCell(withIdentifier: "PinCell") ?? UITableViewCell(style: .subtitle, reuseIdentifier: "PinCell")
        cell.backgroundColor = .clear
        let m = displayed[indexPath.row]
        cell.textLabel?.text = m.author.effectiveDisplayName
        cell.textLabel?.textColor = t.accent
        cell.textLabel?.font = UIFont.systemFont(ofSize: 13, weight: .bold)
        cell.detailTextLabel?.text = m.content.isEmpty ? "[Attachment / Embed]" : m.content
        cell.detailTextLabel?.textColor = t.textPrimary
        cell.detailTextLabel?.numberOfLines = 0
        cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 14)
        return cell
    }
}
