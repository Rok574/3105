import UIKit
import WebKit

struct DiscordCaptchaChallenge {
    let siteKey: String
    let service: String
    let rqdata: String?
    let rqtoken: String?

    init?(json: [String: Any]) {
        guard let siteKey = json["captcha_sitekey"] as? String, !siteKey.isEmpty else { return nil }
        self.siteKey = siteKey
        self.service = (json["captcha_service"] as? String) ?? "recaptcha"
        self.rqdata = json["captcha_rqdata"] as? String
        self.rqtoken = json["captcha_rqtoken"] as? String
    }
}

/// Presents Discord's mobile captcha challenge inside a WKWebView using the `reCaptcha` message handler.
final class CaptchaViewController: UIViewController, WKScriptMessageHandler {
    private let challenge: DiscordCaptchaChallenge
    private let completion: (String?, String?) -> Void
    private var webView: WKWebView!
    private let spinner = UIActivityIndicatorView(style: .whiteLarge)
    private var didComplete = false

    init(challenge: DiscordCaptchaChallenge, completion: @escaping (String?, String?) -> Void) {
        self.challenge = challenge
        self.completion = completion
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Verify Human"
        let t = ThemeManager.shared.current
        view.backgroundColor = t.backgroundPrimary
        navigationController?.navigationBar.barStyle = t.isDark ? .black : .default
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.barTintColor = t.backgroundSecondary
        navigationController?.navigationBar.tintColor = t.textPrimary
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: t.textPrimary]

        navigationItem.leftBarButtonItem = UIBarButtonItem(
            image: DiscordIcons.image(.close, size: 18),
            style: .plain,
            target: self,
            action: #selector(cancelTapped)
        )

        let ucc = WKUserContentController()
        ucc.add(self, name: "reCaptcha")
        let cfg = WKWebViewConfiguration()
        cfg.userContentController = ucc

        webView = WKWebView(frame: .zero, configuration: cfg)
        webView.isOpaque = false
        webView.backgroundColor = t.isDark ? UIColor(hex: 0x222222) : .white
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)

        spinner.translatesAutoresizingMaskIntoConstraints = false
        spinner.startAnimating()
        view.addSubview(spinner)

        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            spinner.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            spinner.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])

        loadCaptchaHTML()
    }

    deinit {
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "reCaptcha")
    }

    private func loadCaptchaHTML() {
        let theme = ThemeManager.shared.current.isDark ? "dark" : "light"
        let escapedKey = challenge.siteKey.replacingOccurrences(of: "'", with: "")
        let isHCaptcha = challenge.service.lowercased().contains("hcaptcha")
        let scriptSrc = isHCaptcha
            ? "https://js.hcaptcha.com/1/api.js?onload=documentReady&render=explicit"
            : "https://www.google.com/recaptcha/api.js?onload=documentReady&render=explicit"
        let globalObj = isHCaptcha ? "hcaptcha" : "grecaptcha"

        let rqdataJS: String
        if let rqd = challenge.rqdata, !rqd.isEmpty {
            let safe = rqd.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "'", with: "\\'")
            rqdataJS = ", rqdata: '\(safe)'"
        } else {
            rqdataJS = ""
        }

        let html = """
        <!DOCTYPE html>
        <html>
        <head>
          <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
          <style>
            html, body { margin: 0; padding: 0; height: 100%; display: flex; align-items: center; justify-content: center; }
          </style>
          <script>
            var RECAPTCHA_SITE_KEY = '\(escapedKey)';
            var RECAPTCHA_THEME = '\(theme)';
            function documentReady() {
              var PAGE_BG_COLOR = RECAPTCHA_THEME == 'dark' ? '#222' : '#fff';
              document.body.style.backgroundColor = PAGE_BG_COLOR;
              showCaptcha(document.body.firstElementChild);
            }
            function showCaptcha(el) {
              try {
                \(globalObj).render(el, {
                  sitekey: RECAPTCHA_SITE_KEY,
                  theme: RECAPTCHA_THEME,
                  callback: captchaSolved,
                  'expired-callback': captchaExpired\(rqdataJS)
                });
                window.webkit.messageHandlers.reCaptcha.postMessage(['didLoad']);
              } catch (_) {
                window.setTimeout(function() { showCaptcha(el); }, 50);
              }
            }
            function captchaSolved(response) {
              window.webkit.messageHandlers.reCaptcha.postMessage(['didSolve', response]);
            }
            function captchaExpired() {
              window.webkit.messageHandlers.reCaptcha.postMessage(['didExpire']);
            }
          </script>
          <script src="\(scriptSrc)" async defer></script>
        </head>
        <body><div></div></body>
        </html>
        """
        webView.loadHTMLString(html, baseURL: URL(string: "https://discord.com"))
    }

    @objc private func cancelTapped() {
        guard !didComplete else { return }
        didComplete = true
        dismiss(animated: true) {
            self.completion(nil, nil)
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let arr = message.body as? [Any], let event = arr.first as? String else { return }
        switch event {
        case "didLoad":
            spinner.stopAnimating()
        case "didSolve":
            guard !didComplete, arr.count > 1, let token = arr[1] as? String else { return }
            didComplete = true
            let rqt = challenge.rqtoken
            dismiss(animated: true) {
                self.completion(token, rqt)
            }
        case "didExpire":
            spinner.startAnimating()
        default:
            break
        }
    }
}
