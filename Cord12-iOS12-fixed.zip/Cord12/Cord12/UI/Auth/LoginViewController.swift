import UIKit
import CoreImage

protocol LoginViewControllerDelegate: AnyObject {
    func loginViewControllerDidAuthenticate(token: String)
}

/// Two-Device QR Remote Auth Login + Direct Token Fallback for iOS 12.
final class LoginViewController: UIViewController, RemoteAuthClientDelegate {
    weak var delegate: LoginViewControllerDelegate?

    private let remoteAuth = RemoteAuthClient()
    private let scrollView = UIScrollView()
    private let titleLabel = UILabel()
    private let subtitleLabel = UILabel()
    private let segmentedControl = UISegmentedControl(items: ["2-Device QR Login", "Token"])

    // QR Container
    private let qrCard = UIView()
    private let qrImageView = UIImageView()
    private let statusLabel = UILabel()
    private let refreshButton = UIButton(type: .system)
    private let scannedAvatar = UIImageView()

    // Token Container
    private let tokenCard = UIView()
    private let tokenField = UITextField()
    private let tokenLoginButton = UIButton(type: .system)

    private var countdownTimer: Timer?
    private var secondsRemaining = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        remoteAuth.delegate = self
        setupUI()
        applyTheme()
        startQRSession()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        countdownTimer?.invalidate()
        remoteAuth.stop()
    }

    private func setupUI() {
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 16
        stack.alignment = .fill
        stack.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: scrollView.topAnchor, constant: 48),
            stack.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor, constant: -32),
            stack.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor, constant: 20),
            stack.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor, constant: -20),
            stack.widthAnchor.constraint(equalTo: scrollView.widthAnchor, constant: -40)
        ])

        titleLabel.text = "Cord12"
        titleLabel.font = UIFont.systemFont(ofSize: 30, weight: .bold)
        titleLabel.textAlignment = .center
        stack.addArrangedSubview(titleLabel)

        subtitleLabel.text = "Scan with Discord on your second device to log in securely on iOS 12."
        subtitleLabel.font = UIFont.systemFont(ofSize: 14)
        subtitleLabel.numberOfLines = 0
        subtitleLabel.textAlignment = .center
        stack.addArrangedSubview(subtitleLabel)

        segmentedControl.selectedSegmentIndex = 0
        segmentedControl.addTarget(self, action: #selector(segmentChanged), for: .valueChanged)
        stack.addArrangedSubview(segmentedControl)

        // QR Card
        qrCard.layer.cornerRadius = 16
        qrCard.translatesAutoresizingMaskIntoConstraints = false
        stack.addArrangedSubview(qrCard)

        let qrInner = UIStackView()
        qrInner.axis = .vertical
        qrInner.spacing = 14
        qrInner.alignment = .center
        qrInner.translatesAutoresizingMaskIntoConstraints = false
        qrCard.addSubview(qrInner)
        NSLayoutConstraint.activate([
            qrInner.topAnchor.constraint(equalTo: qrCard.topAnchor, constant: 20),
            qrInner.bottomAnchor.constraint(equalTo: qrCard.bottomAnchor, constant: -20),
            qrInner.leadingAnchor.constraint(equalTo: qrCard.leadingAnchor, constant: 16),
            qrInner.trailingAnchor.constraint(equalTo: qrCard.trailingAnchor, constant: -16)
        ])

        qrImageView.backgroundColor = .white
        qrImageView.layer.cornerRadius = 12
        qrImageView.clipsToBounds = true
        qrImageView.contentMode = .scaleAspectFit
        qrImageView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            qrImageView.widthAnchor.constraint(equalToConstant: 210),
            qrImageView.heightAnchor.constraint(equalToConstant: 210)
        ])
        qrInner.addArrangedSubview(qrImageView)

        scannedAvatar.layer.cornerRadius = 32
        scannedAvatar.clipsToBounds = true
        scannedAvatar.isHidden = true
        scannedAvatar.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            scannedAvatar.widthAnchor.constraint(equalToConstant: 64),
            scannedAvatar.heightAnchor.constraint(equalToConstant: 64)
        ])
        qrInner.addArrangedSubview(scannedAvatar)

        statusLabel.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        statusLabel.numberOfLines = 0
        statusLabel.textAlignment = .center
        statusLabel.text = "Connecting to Discord Remote Auth..."
        qrInner.addArrangedSubview(statusLabel)

        refreshButton.setTitle("Generate New QR Code", for: .normal)
        refreshButton.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
        refreshButton.addTarget(self, action: #selector(startQRSession), for: .touchUpInside)
        qrInner.addArrangedSubview(refreshButton)

        // Token Card
        tokenCard.layer.cornerRadius = 16
        tokenCard.isHidden = true
        stack.addArrangedSubview(tokenCard)

        let tokenInner = UIStackView()
        tokenInner.axis = .vertical
        tokenInner.spacing = 12
        tokenInner.translatesAutoresizingMaskIntoConstraints = false
        tokenCard.addSubview(tokenInner)
        NSLayoutConstraint.activate([
            tokenInner.topAnchor.constraint(equalTo: tokenCard.topAnchor, constant: 20),
            tokenInner.bottomAnchor.constraint(equalTo: tokenCard.bottomAnchor, constant: -20),
            tokenInner.leadingAnchor.constraint(equalTo: tokenCard.leadingAnchor, constant: 16),
            tokenInner.trailingAnchor.constraint(equalTo: tokenCard.trailingAnchor, constant: -16)
        ])

        tokenField.placeholder = "Paste Discord user token"
        tokenField.borderStyle = .roundedRect
        tokenField.isSecureTextEntry = true
        tokenField.autocapitalizationType = .none
        tokenField.autocorrectionType = .no
        tokenInner.addArrangedSubview(tokenField)

        tokenLoginButton.setTitle("Sign In with Token", for: .normal)
        tokenLoginButton.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        tokenLoginButton.layer.cornerRadius = 10
        tokenLoginButton.contentEdgeInsets = UIEdgeInsets(top: 12, left: 16, bottom: 12, right: 16)
        tokenLoginButton.addTarget(self, action: #selector(signInWithToken), for: .touchUpInside)
        tokenInner.addArrangedSubview(tokenLoginButton)
    }

    private func applyTheme() {
        let t = ThemeManager.shared.current
        view.backgroundColor = t.backgroundPrimary
        titleLabel.textColor = t.textPrimary
        subtitleLabel.textColor = t.textSecondary
        segmentedControl.tintColor = t.accent
        qrCard.backgroundColor = t.surfaceCard
        statusLabel.textColor = t.textSecondary
        refreshButton.setTitleColor(t.accent, for: .normal)
        tokenCard.backgroundColor = t.surfaceCard
        tokenField.backgroundColor = t.backgroundSecondary
        tokenField.textColor = t.textPrimary
        tokenLoginButton.backgroundColor = t.accent
        tokenLoginButton.setTitleColor(.white, for: .normal)
    }

    @objc private func segmentChanged() {
        let isQR = segmentedControl.selectedSegmentIndex == 0
        qrCard.isHidden = !isQR
        tokenCard.isHidden = isQR
    }

    @objc private func startQRSession() {
        scannedAvatar.isHidden = true
        qrImageView.isHidden = false
        qrImageView.image = nil
        statusLabel.text = "Generating 2-device QR code..."
        remoteAuth.start()
    }

    @objc private func signInWithToken() {
        let token = (tokenField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        guard !token.isEmpty else { return }
        KeychainStore.shared.saveToken(token)
        delegate?.loginViewControllerDidAuthenticate(token: token)
    }

    // MARK: - RemoteAuthClientDelegate

    func remoteAuthDidGenerateQR(urlString: String, timeoutSeconds: Int) {
        qrImageView.image = makeQRCode(from: urlString)
        self.secondsRemaining = timeoutSeconds
        countdownTimer?.invalidate()
        countdownTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            self.secondsRemaining -= 1
            if self.secondsRemaining <= 0 {
                self.countdownTimer?.invalidate()
                self.statusLabel.text = "QR code expired. Tap below to refresh."
            } else {
                self.statusLabel.text = "Open Discord on your other device → Scan QR Code (\(self.secondsRemaining)s)"
            }
        }
        statusLabel.text = "Open Discord on your other device → Scan QR Code (\(timeoutSeconds)s)"
    }

    func remoteAuthDidScan(username: String, discriminator: String, userId: String, avatarHash: String) {
        countdownTimer?.invalidate()
        qrImageView.isHidden = true
        scannedAvatar.isHidden = false
        statusLabel.text = "Scanned as @\(username)!\nTap \"Yes, log me in\" on your other device."
        if avatarHash != "0" && !avatarHash.isEmpty {
            let ext = avatarHash.hasPrefix("a_") ? "gif" : "png"
            let url = "https://cdn.discordapp.com/avatars/\(userId)/\(avatarHash).\(ext)?size=128"
            ImageLoader.shared.load(urlString: url, maxPixelSize: 128) { [weak self] img in
                self?.scannedAvatar.image = img
            }
        }
    }

    func remoteAuthDidComplete(token: String) {
        countdownTimer?.invalidate()
        KeychainStore.shared.saveToken(token)
        delegate?.loginViewControllerDidAuthenticate(token: token)
    }

    func remoteAuthDidCancelOrFail(message: String) {
        countdownTimer?.invalidate()
        statusLabel.text = message
    }

    private func makeQRCode(from string: String) -> UIImage? {
        guard let data = string.data(using: .ascii),
              let filter = CIFilter(name: "CIQRCodeGenerator") else { return nil }
        filter.setValue(data, forKey: "inputMessage")
        filter.setValue("M", forKey: "inputCorrectionLevel")
        guard let output = filter.outputImage else { return nil }
        let transform = CGAffineTransform(scaleX: 10, y: 10)
        let scaled = output.transformed(by: transform)
        return UIImage(ciImage: scaled)
    }
}
