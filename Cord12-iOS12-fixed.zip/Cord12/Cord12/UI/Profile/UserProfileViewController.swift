import UIKit

final class UserProfileViewController: UIViewController {
    private var targetUserId: String?
    private let guildId: String?
    private var user: DiscordUser?
    private var profile: UserProfileResponse?

    private let scrollView = UIScrollView()
    private let contentStack = UIStackView()
    private let themeGradientLayer = CAGradientLayer()

    private let bannerImageView = UIImageView()
    private let nameplateView = NameplateBannerView()
    private let avatarView = AvatarWithDecorationView()
    private let headerCard = UIView()
    private let displayNameLabel = StyledNameLabel()
    private let usernameLabel = UILabel()
    private let guildTagPill = UILabel()
    private let badgesCard = UIView()
    private let badgesStack = UIStackView()
    private let bioCard = UIView()
    private let bioLabel = UILabel()
    private let metaCard = UIView()
    private let metaLabel = UILabel()
    private let editButton = UIButton(type: .system)

    init(userId: String?, guildId: String?, initialUser: DiscordUser?) {
        self.targetUserId = userId
        self.guildId = guildId
        self.user = initialUser
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupNav()
        setupUI()
        applyTheme()
        loadProfile()

        NotificationCenter.default.addObserver(self, selector: #selector(onCurrentUserUpdated), name: .cordStoreDidUpdateCurrentUser, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(onThemeChanged), name: .cordThemeDidChange, object: nil)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        themeGradientLayer.frame = view.bounds
    }

    private var isSelfProfile: Bool {
        if targetUserId == nil { return true }
        return targetUserId == DiscordStore.shared.currentUser?.id
    }

    private func setupNav() {
        title = isSelfProfile ? "You" : "Profile"
        if presentingViewController != nil {
            navigationItem.leftBarButtonItem = UIBarButtonItem(
                image: DiscordIcons.image(.close, size: 18),
                style: .plain,
                target: self,
                action: #selector(closeTapped)
            )
        }
        if isSelfProfile {
            navigationItem.rightBarButtonItem = UIBarButtonItem(
                image: DiscordIcons.image(.gear, size: 20),
                style: .plain,
                target: self,
                action: #selector(settingsTapped)
            )
        }
    }

    private func setupUI() {
        themeGradientLayer.startPoint = CGPoint(x: 0.2, y: 0)
        themeGradientLayer.endPoint = CGPoint(x: 0.8, y: 1)
        view.layer.insertSublayer(themeGradientLayer, at: 0)

        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        bannerImageView.contentMode = .scaleAspectFill
        bannerImageView.clipsToBounds = true
        bannerImageView.isUserInteractionEnabled = true
        bannerImageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(bannerTapped)))
        bannerImageView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(bannerImageView)

        avatarView.isUserInteractionEnabled = true
        avatarView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(avatarTapped)))
        avatarView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(avatarView)

        contentStack.axis = .vertical
        contentStack.spacing = 12
        contentStack.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(contentStack)

        NSLayoutConstraint.activate([
            bannerImageView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            bannerImageView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            bannerImageView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            bannerImageView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),
            bannerImageView.heightAnchor.constraint(equalToConstant: 145),

            avatarView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor, constant: 16),
            avatarView.centerYAnchor.constraint(equalTo: bannerImageView.bottomAnchor),
            avatarView.widthAnchor.constraint(equalToConstant: 86),
            avatarView.heightAnchor.constraint(equalToConstant: 86),

            contentStack.topAnchor.constraint(equalTo: avatarView.bottomAnchor, constant: 12),
            contentStack.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor, constant: 14),
            contentStack.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor, constant: -14),
            contentStack.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor, constant: -28)
        ])

        nameplateView.translatesAutoresizingMaskIntoConstraints = false
        nameplateView.heightAnchor.constraint(equalToConstant: 52).isActive = true
        contentStack.addArrangedSubview(nameplateView)

        headerCard.layer.cornerRadius = 14
        let headerInner = UIStackView()
        headerInner.axis = .vertical
        headerInner.spacing = 4
        headerInner.translatesAutoresizingMaskIntoConstraints = false
        headerCard.addSubview(headerInner)
        NSLayoutConstraint.activate([
            headerInner.topAnchor.constraint(equalTo: headerCard.topAnchor, constant: 12),
            headerInner.bottomAnchor.constraint(equalTo: headerCard.bottomAnchor, constant: -12),
            headerInner.leadingAnchor.constraint(equalTo: headerCard.leadingAnchor, constant: 14),
            headerInner.trailingAnchor.constraint(equalTo: headerCard.trailingAnchor, constant: -14)
        ])

        displayNameLabel.baseFontSize = 22
        displayNameLabel.heightAnchor.constraint(equalToConstant: 28).isActive = true
        headerInner.addArrangedSubview(displayNameLabel)

        usernameLabel.font = UIFont.systemFont(ofSize: 14)
        usernameLabel.numberOfLines = 0
        headerInner.addArrangedSubview(usernameLabel)

        guildTagPill.font = UIFont.systemFont(ofSize: 12, weight: .bold)
        guildTagPill.layer.cornerRadius = 6
        guildTagPill.clipsToBounds = true
        guildTagPill.isHidden = true
        let tagRow = UIStackView(arrangedSubviews: [guildTagPill, UIView()])
        tagRow.axis = .horizontal
        headerInner.addArrangedSubview(tagRow)

        contentStack.addArrangedSubview(headerCard)

        badgesCard.layer.cornerRadius = 12
        badgesStack.axis = .horizontal
        badgesStack.spacing = 8
        badgesStack.alignment = .center
        badgesStack.translatesAutoresizingMaskIntoConstraints = false
        badgesCard.addSubview(badgesStack)
        NSLayoutConstraint.activate([
            badgesStack.topAnchor.constraint(equalTo: badgesCard.topAnchor, constant: 8),
            badgesStack.bottomAnchor.constraint(equalTo: badgesCard.bottomAnchor, constant: -8),
            badgesStack.leadingAnchor.constraint(equalTo: badgesCard.leadingAnchor, constant: 12),
            badgesStack.heightAnchor.constraint(equalToConstant: 26)
        ])
        contentStack.addArrangedSubview(badgesCard)

        bioCard.layer.cornerRadius = 12
        bioLabel.font = UIFont.systemFont(ofSize: 14)
        bioLabel.numberOfLines = 0
        bioLabel.translatesAutoresizingMaskIntoConstraints = false
        bioCard.addSubview(bioLabel)
        NSLayoutConstraint.activate([
            bioLabel.topAnchor.constraint(equalTo: bioCard.topAnchor, constant: 12),
            bioLabel.bottomAnchor.constraint(equalTo: bioCard.bottomAnchor, constant: -12),
            bioLabel.leadingAnchor.constraint(equalTo: bioCard.leadingAnchor, constant: 14),
            bioLabel.trailingAnchor.constraint(equalTo: bioCard.trailingAnchor, constant: -14)
        ])
        contentStack.addArrangedSubview(bioCard)

        metaCard.layer.cornerRadius = 12
        metaLabel.font = UIFont.systemFont(ofSize: 13)
        metaLabel.numberOfLines = 0
        metaLabel.translatesAutoresizingMaskIntoConstraints = false
        metaCard.addSubview(metaLabel)
        NSLayoutConstraint.activate([
            metaLabel.topAnchor.constraint(equalTo: metaCard.topAnchor, constant: 12),
            metaLabel.bottomAnchor.constraint(equalTo: metaCard.bottomAnchor, constant: -12),
            metaLabel.leadingAnchor.constraint(equalTo: metaCard.leadingAnchor, constant: 14),
            metaLabel.trailingAnchor.constraint(equalTo: metaCard.trailingAnchor, constant: -14)
        ])
        contentStack.addArrangedSubview(metaCard)

        editButton.setTitle("Edit Profile", for: .normal)
        editButton.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        editButton.layer.cornerRadius = 12
        editButton.contentEdgeInsets = UIEdgeInsets(top: 12, left: 16, bottom: 12, right: 16)
        editButton.addTarget(self, action: #selector(editProfileTapped), for: .touchUpInside)
        editButton.isHidden = !isSelfProfile
        contentStack.addArrangedSubview(editButton)

        renderData()
    }

    @objc private func onCurrentUserUpdated() {
        guard isSelfProfile else { return }
        self.user = DiscordStore.shared.currentUser
        self.profile = DiscordStore.shared.currentUserProfile
        renderData()
    }

    @objc private func onThemeChanged() {
        applyTheme()
        renderData()
    }

    private func applyTheme() {
        let t = ThemeManager.shared.current
        view.backgroundColor = t.backgroundPrimary
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.barStyle = t.isDark ? .black : .default
        navigationController?.navigationBar.barTintColor = t.backgroundSecondary
        navigationController?.navigationBar.tintColor = t.textPrimary
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: t.textPrimary]
        usernameLabel.textColor = t.textSecondary
        headerCard.backgroundColor = t.surfaceCard.withAlphaComponent(0.78)
        badgesCard.backgroundColor = t.surfaceCard.withAlphaComponent(0.78)
        bioCard.backgroundColor = t.surfaceCard.withAlphaComponent(0.78)
        bioLabel.textColor = t.textPrimary
        metaCard.backgroundColor = t.surfaceCard.withAlphaComponent(0.78)
        metaLabel.textColor = t.textSecondary
        editButton.backgroundColor = t.accent
        editButton.setTitleColor(.white, for: .normal)
    }

    private func loadProfile() {
        let uid = targetUserId ?? DiscordStore.shared.currentUser?.id
        guard let uid = uid else { return }
        if isSelfProfile, let cached = DiscordStore.shared.currentUserProfile {
            self.profile = cached
            self.user = cached.user
            renderData()
        }
        DiscordRESTClient.shared.fetchUserProfile(userId: uid, guildId: guildId) { [weak self] res in
            guard let self = self else { return }
            if case .success(let prof) = res {
                self.profile = prof
                self.user = prof.user
                self.renderData()
            }
        }
    }

    private func renderData() {
        let t = ThemeManager.shared.current
        let u = user ?? (isSelfProfile ? DiscordStore.shared.currentUser : nil)
        let meta = profile?.userProfile

        // Vivid Nitro color profile theme (theme_colors)
        if let tc = meta?.themeColors, tc.count >= 2 {
            let c1 = UIColor(hex: tc[0])
            let c2 = UIColor(hex: tc[1])
            themeGradientLayer.colors = [
                c1.withAlphaComponent(0.92).cgColor,
                c2.withAlphaComponent(0.85).cgColor
            ]
        } else {
            themeGradientLayer.colors = nil
        }

        // Animated GIF / Static Banner
        if let bannerURL = u?.bannerURL(size: 512) {
            ImageLoader.shared.load(urlString: bannerURL, maxPixelSize: 400, animated: true) { [weak self] img in
                self?.bannerImageView.image = img
            }
        } else {
            bannerImageView.image = nil
            let hex = meta?.accentColor ?? u?.accentColor ?? t.accent.hexInt
            bannerImageView.backgroundColor = UIColor(hex: hex)
        }

        // Animated GIF / Static Avatar + Frame
        let status = u.flatMap { DiscordStore.shared.presencesByUserId[$0.id] } ?? (isSelfProfile ? "online" : nil)
        avatarView.configure(user: u, status: status, pixelSize: 256)

        // Nameplate
        nameplateView.configure(nameplate: u?.collectibles?.nameplate)

        // Styled Name Font + Effects
        displayNameLabel.defaultColor = t.textPrimary
        displayNameLabel.style = u?.displayNameStyles
        displayNameLabel.text = u?.effectiveDisplayName ?? "Discord User"

        let handle = u.map { "@\($0.username)" } ?? ""
        let pronouns = meta?.pronouns ?? u?.pronouns ?? ""
        usernameLabel.text = pronouns.isEmpty ? handle : "\(handle)  •  \(pronouns)"

        if let tag = u?.primaryGuild?.tag, !tag.isEmpty {
            guildTagPill.isHidden = false
            guildTagPill.text = "  \(tag)  "
            guildTagPill.textColor = t.textPrimary
            guildTagPill.backgroundColor = t.backgroundSecondary
        } else {
            guildTagPill.isHidden = true
        }

        // Badges
        badgesStack.arrangedSubviews.forEach { $0.removeFromSuperview() }
        let badges = profile?.badges ?? []
        if badges.isEmpty {
            badgesCard.isHidden = true
        } else {
            badgesCard.isHidden = false
            for b in badges.prefix(10) {
                let iv = UIImageView()
                iv.contentMode = .scaleAspectFit
                iv.translatesAutoresizingMaskIntoConstraints = false
                iv.widthAnchor.constraint(equalToConstant: 24).isActive = true
                iv.heightAnchor.constraint(equalToConstant: 24).isActive = true
                ImageLoader.shared.load(urlString: b.iconURL, maxPixelSize: 48) { img in
                    iv.image = img
                }
                badgesStack.addArrangedSubview(iv)
            }
        }

        // Bio (render Discord <:name:id> custom emojis inline)
        let bioText = meta?.bio ?? u?.bio ?? ""
        bioCard.isHidden = bioText.isEmpty
        if !bioText.isEmpty {
            bioLabel.attributedText = MessageCell.renderMarkdown(bioText, theme: t) { [weak self] in
                guard let self = self else { return }
                self.bioLabel.attributedText = MessageCell.renderMarkdown(bioText, theme: ThemeManager.shared.current, onEmojiLoaded: nil)
            }
        } else {
            bioLabel.attributedText = nil
        }

        // Connections & Mutuals
        var metaLines: [String] = []
        if let mg = profile?.mutualGuilds, !mg.isEmpty {
            metaLines.append("Mutual Servers: \(mg.count)")
        }
        if let mf = profile?.mutualFriendsCount, mf > 0 {
            metaLines.append("Mutual Friends: \(mf)")
        }
        if let conns = profile?.connectedAccounts, !conns.isEmpty {
            let list = conns.map { "\($0.type.capitalized): \($0.name)" }.joined(separator: "  •  ")
            metaLines.append(list)
        }
        metaCard.isHidden = metaLines.isEmpty
        metaLabel.text = metaLines.joined(separator: "\n")
    }

    @objc private func avatarTapped() {
        guard let u = user else { return }
        let url = u.avatarURL(size: 512)
        let preview = MediaPreviewViewController(urlString: url, title: u.effectiveDisplayName, isGif: u.avatar?.hasPrefix("a_") == true)
        present(UINavigationController(rootViewController: preview), animated: true)
    }

    @objc private func bannerTapped() {
        guard let url = user?.bannerURL(size: 1024) else { return }
        let preview = MediaPreviewViewController(urlString: url, title: "\(user?.effectiveDisplayName ?? "") Banner", isGif: user?.banner?.hasPrefix("a_") == true)
        present(UINavigationController(rootViewController: preview), animated: true)
    }

    @objc private func closeTapped() {
        dismiss(animated: true)
    }

    @objc private func settingsTapped() {
        let vc = SettingsViewController()
        navigationController?.pushViewController(vc, animated: true)
    }

    @objc private func editProfileTapped() {
        let vc = EditProfileViewController()
        navigationController?.pushViewController(vc, animated: true)
    }
}
