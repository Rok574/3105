import UIKit

/// Live-preview editor for Avatar, Banner, Global Name, Bio, Pronouns, Nitro theme_colors,
/// Display Name Styles, and Avatar Decoration Frames.
final class EditProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    private let scrollView = UIScrollView()
    private let stack = UIStackView()

    // Live Preview
    private let previewCard = UIView()
    private let previewGradient = CAGradientLayer()
    private let previewNameplate = NameplateBannerView()
    private let previewAvatar = AvatarWithDecorationView()
    private let previewNameLabel = StyledNameLabel()

    // Photo buttons
    private let changeAvatarBtn = UIButton(type: .system)
    private let changeBannerBtn = UIButton(type: .system)

    // Fields
    private let globalNameField = UITextField()
    private let pronounsField = UITextField()
    private let bioTextView = UITextView()
    private let saveButton = UIButton(type: .system)

    // State
    private var selectedFontId: Int = 11
    private var selectedEffectId: Int = 1
    private var selectedNameColors: [Int] = [0xFFFFFF, 0x5865F2]
    private var selectedThemeColors: [Int]? = nil
    private var selectedDecoSkuId: String?
    private var didChangeDeco = false
    private var pendingAvatarDataURI: String?
    private var pendingBannerDataURI: String?
    private var pickingForBanner = false

    private var themeButtons: [UIButton] = []
    private var decoButtons: [UIButton] = []

    private let nitroThemePresets: [(String, [Int])] = [
        ("Blurple Pink", [0x5865F2, 0xEB459E]),
        ("Aurora Teal", [0x1ABC9C, 0x3498DB]),
        ("Sunset Gold", [0xFF6B6B, 0xFECA57]),
        ("Crimson Night", [0x991B1B, 0x1F1F23]),
        ("Cotton Candy", [0xFF85C0, 0x85D7FF])
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Edit Profile"
        loadInitialValues()
        setupUI()
        applyTheme()
        updateLivePreview()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewGradient.frame = previewCard.bounds
    }

    private func loadInitialValues() {
        let user = DiscordStore.shared.currentUser
        let meta = DiscordStore.shared.currentUserProfile?.userProfile
        globalNameField.text = user?.globalName ?? user?.username
        pronounsField.text = meta?.pronouns ?? user?.pronouns
        bioTextView.text = meta?.bio ?? user?.bio
        if let dns = user?.displayNameStyles {
            selectedFontId = dns.fontId
            selectedEffectId = dns.effectId
            if !dns.colors.isEmpty { selectedNameColors = dns.colors }
        }
        if let tc = meta?.themeColors, tc.count >= 2 {
            selectedThemeColors = tc
        }
        selectedDecoSkuId = user?.avatarDecorationData?.skuId
    }

    private func setupUI() {
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        stack.axis = .vertical
        stack.spacing = 14
        stack.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: scrollView.topAnchor, constant: 16),
            stack.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor, constant: -32),
            stack.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor, constant: 16),
            stack.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor, constant: -16),
            stack.widthAnchor.constraint(equalTo: scrollView.widthAnchor, constant: -32)
        ])

        // Live Preview Card
        previewCard.layer.cornerRadius = 12
        previewCard.clipsToBounds = true
        previewGradient.startPoint = CGPoint(x: 0, y: 0)
        previewGradient.endPoint = CGPoint(x: 1, y: 1)
        previewCard.layer.insertSublayer(previewGradient, at: 0)
        previewCard.heightAnchor.constraint(equalToConstant: 112).isActive = true

        previewNameplate.translatesAutoresizingMaskIntoConstraints = false
        previewCard.addSubview(previewNameplate)
        previewAvatar.translatesAutoresizingMaskIntoConstraints = false
        previewCard.addSubview(previewAvatar)
        previewNameLabel.baseFontSize = 20
        previewNameLabel.translatesAutoresizingMaskIntoConstraints = false
        previewCard.addSubview(previewNameLabel)

        NSLayoutConstraint.activate([
            previewNameplate.topAnchor.constraint(equalTo: previewCard.topAnchor, constant: 10),
            previewNameplate.leadingAnchor.constraint(equalTo: previewCard.leadingAnchor, constant: 10),
            previewNameplate.trailingAnchor.constraint(equalTo: previewCard.trailingAnchor, constant: -10),
            previewNameplate.bottomAnchor.constraint(equalTo: previewCard.bottomAnchor, constant: -10),

            previewAvatar.leadingAnchor.constraint(equalTo: previewCard.leadingAnchor, constant: 18),
            previewAvatar.centerYAnchor.constraint(equalTo: previewCard.centerYAnchor),
            previewAvatar.widthAnchor.constraint(equalToConstant: 64),
            previewAvatar.heightAnchor.constraint(equalToConstant: 64),

            previewNameLabel.leadingAnchor.constraint(equalTo: previewAvatar.trailingAnchor, constant: 14),
            previewNameLabel.trailingAnchor.constraint(equalTo: previewCard.trailingAnchor, constant: -16),
            previewNameLabel.centerYAnchor.constraint(equalTo: previewCard.centerYAnchor),
            previewNameLabel.heightAnchor.constraint(equalToConstant: 28)
        ])
        stack.addArrangedSubview(previewCard)

        // Avatar & Banner Upload Buttons
        let mediaRow = UIStackView(arrangedSubviews: [changeAvatarBtn, changeBannerBtn])
        mediaRow.axis = .horizontal
        mediaRow.spacing = 10
        mediaRow.distribution = .fillEqually
        changeAvatarBtn.setTitle("Change Avatar", for: .normal)
        changeAvatarBtn.layer.cornerRadius = 8
        changeAvatarBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .semibold)
        changeAvatarBtn.contentEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        changeAvatarBtn.addTarget(self, action: #selector(pickAvatar), for: .touchUpInside)

        changeBannerBtn.setTitle("Change Banner", for: .normal)
        changeBannerBtn.layer.cornerRadius = 8
        changeBannerBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .semibold)
        changeBannerBtn.contentEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        changeBannerBtn.addTarget(self, action: #selector(pickBanner), for: .touchUpInside)
        stack.addArrangedSubview(mediaRow)

        stack.addArrangedSubview(sectionHeader("Display Name"))
        styleTextField(globalNameField, placeholder: "Display Name")
        globalNameField.addTarget(self, action: #selector(textChanged), for: .editingChanged)
        stack.addArrangedSubview(globalNameField)

        stack.addArrangedSubview(sectionHeader("Pronouns"))
        styleTextField(pronounsField, placeholder: "e.g. they/them")
        stack.addArrangedSubview(pronounsField)

        stack.addArrangedSubview(sectionHeader("About Me"))
        bioTextView.font = UIFont.systemFont(ofSize: 15)
        bioTextView.layer.cornerRadius = 8
        bioTextView.heightAnchor.constraint(equalToConstant: 90).isActive = true
        stack.addArrangedSubview(bioTextView)

        stack.addArrangedSubview(sectionHeader("Nitro Profile Theme"))
        let (themeScroll, tBtns) = makeChipRow(items: nitroThemePresets.map { $0.0 }, action: #selector(themeChipTapped(_:)))
        themeButtons = tBtns
        stack.addArrangedSubview(themeScroll)

        let ownedDecos = DiscordStore.shared.ownedCollectibles.filter { $0.type == 0 }
        if !ownedDecos.isEmpty {
            stack.addArrangedSubview(sectionHeader("Avatar Decorations"))
            let titles = ["None"] + ownedDecos.map { $0.name }
            let (decoScroll, dBtns) = makeChipRow(items: titles, action: #selector(decoChipTapped(_:)))
            decoButtons = dBtns
            stack.addArrangedSubview(decoScroll)
        }

        saveButton.setTitle("Save", for: .normal)
        saveButton.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        saveButton.layer.cornerRadius = 8
        saveButton.contentEdgeInsets = UIEdgeInsets(top: 14, left: 16, bottom: 14, right: 16)
        saveButton.addTarget(self, action: #selector(saveTapped), for: .touchUpInside)
        stack.addArrangedSubview(saveButton)
    }

    private func sectionHeader(_ title: String) -> UILabel {
        let lbl = UILabel()
        lbl.text = title.uppercased()
        lbl.font = UIFont.systemFont(ofSize: 12, weight: .bold)
        lbl.textColor = ThemeManager.shared.current.textMuted
        return lbl
    }

    private func styleTextField(_ tf: UITextField, placeholder: String) {
        tf.placeholder = placeholder
        tf.font = UIFont.systemFont(ofSize: 15)
        tf.layer.cornerRadius = 8
        tf.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 12, height: 1))
        tf.leftViewMode = .always
        tf.heightAnchor.constraint(equalToConstant: 42).isActive = true
    }

    private func makeChipRow(items: [String], action: Selector) -> (UIScrollView, [UIButton]) {
        let sc = UIScrollView()
        sc.showsHorizontalScrollIndicator = false
        sc.heightAnchor.constraint(equalToConstant: 38).isActive = true

        let row = UIStackView()
        row.axis = .horizontal
        row.spacing = 8
        row.translatesAutoresizingMaskIntoConstraints = false
        sc.addSubview(row)
        NSLayoutConstraint.activate([
            row.topAnchor.constraint(equalTo: sc.topAnchor),
            row.bottomAnchor.constraint(equalTo: sc.bottomAnchor),
            row.leadingAnchor.constraint(equalTo: sc.leadingAnchor),
            row.trailingAnchor.constraint(equalTo: sc.trailingAnchor),
            row.heightAnchor.constraint(equalTo: sc.heightAnchor)
        ])

        var buttons: [UIButton] = []
        let t = ThemeManager.shared.current
        for (idx, title) in items.enumerated() {
            let btn = UIButton(type: .system)
            btn.tag = idx
            btn.setTitle(title, for: .normal)
            btn.setTitleColor(t.textPrimary, for: .normal)
            btn.backgroundColor = t.surfaceCard
            btn.layer.cornerRadius = 16
            btn.layer.borderWidth = 1.5
            btn.layer.borderColor = UIColor.clear.cgColor
            btn.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: .medium)
            btn.contentEdgeInsets = UIEdgeInsets(top: 6, left: 12, bottom: 6, right: 12)
            btn.addTarget(self, action: action, for: .touchUpInside)
            row.addArrangedSubview(btn)
            buttons.append(btn)
        }
        return (sc, buttons)
    }

    private func applyTheme() {
        let t = ThemeManager.shared.current
        view.backgroundColor = t.backgroundPrimary
        previewCard.backgroundColor = t.backgroundSecondary
        changeAvatarBtn.backgroundColor = t.surfaceCard
        changeAvatarBtn.setTitleColor(t.textPrimary, for: .normal)
        changeBannerBtn.backgroundColor = t.surfaceCard
        changeBannerBtn.setTitleColor(t.textPrimary, for: .normal)
        globalNameField.backgroundColor = t.surfaceCard
        globalNameField.textColor = t.textPrimary
        pronounsField.backgroundColor = t.surfaceCard
        pronounsField.textColor = t.textPrimary
        bioTextView.backgroundColor = t.surfaceCard
        bioTextView.textColor = t.textPrimary
        saveButton.backgroundColor = t.accent
        saveButton.setTitleColor(.white, for: .normal)
    }

    private func updateLivePreview() {
        let t = ThemeManager.shared.current
        if let tc = selectedThemeColors, tc.count >= 2 {
            previewGradient.colors = tc.map { UIColor(hex: $0).cgColor }
        } else {
            previewGradient.colors = nil
        }
        previewAvatar.configure(user: DiscordStore.shared.currentUser, status: "online", pixelSize: 128)
        previewNameplate.configure(nameplate: DiscordStore.shared.currentUser?.collectibles?.nameplate)
        previewNameLabel.style = DisplayNameStyle(fontId: selectedFontId, effectId: selectedEffectId, colors: selectedNameColors)
        let name = (globalNameField.text ?? "").isEmpty ? (DiscordStore.shared.currentUser?.username ?? "You") : (globalNameField.text ?? "")
        previewNameLabel.text = name

        for (idx, btn) in themeButtons.enumerated() {
            let isSel = selectedThemeColors == nitroThemePresets[idx].1
            btn.layer.borderColor = isSel ? t.accent.cgColor : UIColor.clear.cgColor
        }
    }

    @objc private func pickAvatar() {
        pickingForBanner = false
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true)
    }

    @objc private func pickBanner() {
        pickingForBanner = true
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true)
    }

    private func resizeImage(_ image: UIImage, maxDimension: CGFloat) -> UIImage {
        let size = image.size
        let maxSide = max(size.width, size.height)
        guard maxSide > maxDimension else { return image }
        let scale = maxDimension / maxSide
        let target = CGSize(width: size.width * scale, height: size.height * scale)
        let renderer = UIGraphicsImageRenderer(size: target)
        return renderer.image { _ in
            image.draw(in: CGRect(origin: .zero, size: target))
        }
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        picker.dismiss(animated: true)
        guard let rawImg = info[.originalImage] as? UIImage else { return }
        let resized = resizeImage(rawImg, maxDimension: pickingForBanner ? 960 : 512)
        guard let jpeg = resized.jpegData(compressionQuality: 0.82) else { return }
        let dataURI = "data:image/jpeg;base64,\(jpeg.base64EncodedString())"
        if pickingForBanner {
            pendingBannerDataURI = dataURI
            changeBannerBtn.setTitle("Banner Selected", for: .normal)
        } else {
            pendingAvatarDataURI = dataURI
            changeAvatarBtn.setTitle("Avatar Selected", for: .normal)
        }
    }

    @objc private func textChanged() {
        updateLivePreview()
    }

    @objc private func themeChipTapped(_ sender: UIButton) {
        selectedThemeColors = nitroThemePresets[sender.tag].1
        updateLivePreview()
    }

    @objc private func decoChipTapped(_ sender: UIButton) {
        let ownedDecos = DiscordStore.shared.ownedCollectibles.filter { $0.type == 0 }
        selectedDecoSkuId = sender.tag == 0 ? nil : ownedDecos[sender.tag - 1].skuId
        didChangeDeco = true
        let t = ThemeManager.shared.current
        for (idx, btn) in decoButtons.enumerated() {
            btn.layer.borderColor = (idx == sender.tag) ? t.accent.cgColor : UIColor.clear.cgColor
        }
    }

    @objc private func saveTapped() {
        saveButton.isEnabled = false
        saveButton.setTitle("Saving...", for: .normal)

        let group = DispatchGroup()
        var lastError: Error?

        group.enter()
        DiscordRESTClient.shared.patchCurrentUser(
            globalName: globalNameField.text,
            avatarBase64: pendingAvatarDataURI,
            avatarDecorationSkuId: didChangeDeco ? .some(selectedDecoSkuId) : nil
        ) { res in
            switch res {
            case .success(let updatedUser):
                DiscordStore.shared.applyUpdatedCurrentUser(updatedUser)
            case .failure(let err):
                lastError = err
            }
            group.leave()
        }

        group.enter()
        DiscordRESTClient.shared.patchUserProfile(
            bio: bioTextView.text,
            pronouns: pronounsField.text,
            themeColors: selectedThemeColors.map { .some($0) },
            bannerBase64: pendingBannerDataURI.map { .some($0) }
        ) { res in
            if case .failure(let err) = res { lastError = err }
            group.leave()
        }

        group.notify(queue: .main) { [weak self] in
            guard let self = self else { return }
            self.saveButton.isEnabled = true
            self.saveButton.setTitle("Save", for: .normal)
            DiscordStore.shared.refreshCurrentUserProfile()
            if let err = lastError {
                let alert = UIAlertController(title: "Could Not Save All Changes", message: err.localizedDescription, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                self.present(alert, animated: true)
            } else {
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
}
