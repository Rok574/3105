import UIKit

final class SettingsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private let tableView = UITableView(frame: .zero, style: .grouped)
    private let statuses: [(String, String)] = [
        ("online", "Online"),
        ("idle", "Idle"),
        ("dnd", "Do Not Disturb"),
        ("invisible", "Invisible")
    ]
    private var selectedStatus = "online"

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Settings & Nitro Themes"
        if let uid = DiscordStore.shared.currentUser?.id,
           let current = DiscordStore.shared.presencesByUserId[uid] {
            selectedStatus = current
        }

        tableView.dataSource = self
        tableView.delegate = self
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
        applyTheme()
        NotificationCenter.default.addObserver(self, selector: #selector(applyTheme), name: .cordThemeDidChange, object: nil)
    }

    @objc private func applyTheme() {
        let t = ThemeManager.shared.current
        view.backgroundColor = t.backgroundPrimary
        tableView.backgroundColor = t.backgroundPrimary
        tableView.separatorColor = t.separator
        tableView.reloadData()
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0: return statuses.count + 1
        case 1: return CordThemeID.allCases.count
        default: return 1
        }
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0: return "Presence & Custom Status"
        case 1: return "App & Nitro Client Themes"
        default: return "Account"
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let t = ThemeManager.shared.current
        let cell = tableView.dequeueReusableCell(withIdentifier: "SetCell") ?? UITableViewCell(style: .default, reuseIdentifier: "SetCell")
        cell.backgroundColor = t.surfaceCard

        if indexPath.section == 0 {
            if indexPath.row < statuses.count {
                let st = statuses[indexPath.row]
                cell.textLabel?.text = st.1
                cell.textLabel?.textColor = t.textPrimary
                cell.accessoryType = (st.0 == selectedStatus) ? .checkmark : .none
                cell.tintColor = t.accent
            } else {
                cell.textLabel?.text = "Set Custom Status..."
                cell.textLabel?.textColor = t.accent
                cell.accessoryType = .disclosureIndicator
            }
        } else if indexPath.section == 1 {
            let themeID = CordThemeID.allCases[indexPath.row]
            cell.textLabel?.text = themeID.displayName
            cell.textLabel?.textColor = t.textPrimary
            cell.accessoryType = (themeID == t.id) ? .checkmark : .none
            cell.tintColor = t.accent
        } else {
            cell.textLabel?.text = "Log Out"
            cell.textLabel?.textColor = UIColor(hex: 0xED4245)
            cell.accessoryType = .none
        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.section == 0 {
            if indexPath.row < statuses.count {
                selectedStatus = statuses[indexPath.row].0
                DiscordStore.shared.updatePresence(status: selectedStatus, customText: nil)
                tableView.reloadData()
            } else {
                promptCustomStatus()
            }
        } else if indexPath.section == 1 {
            let chosen = CordThemeID.allCases[indexPath.row]
            ThemeManager.shared.setTheme(chosen)
        } else {
            DiscordStore.shared.logout()
            if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
                appDelegate.showLogin()
            }
        }
    }

    private func promptCustomStatus() {
        let alert = UIAlertController(title: "Custom Status", message: "What are you up to?", preferredStyle: .alert)
        alert.addTextField { tf in tf.placeholder = "Playing on iPhone 6..." }
        alert.addAction(UIAlertAction(title: "Save", style: .default) { [weak self] _ in
            guard let self = self else { return }
            let text = alert.textFields?.first?.text
            DiscordStore.shared.updatePresence(status: self.selectedStatus, customText: text)
        })
        alert.addAction(UIAlertAction(title: "Clear", style: .destructive) { [weak self] _ in
            guard let self = self else { return }
            DiscordStore.shared.updatePresence(status: self.selectedStatus, customText: nil)
        })
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }
}
