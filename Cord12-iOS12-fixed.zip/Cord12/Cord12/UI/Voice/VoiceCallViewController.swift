import UIKit

final class VoiceCallViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private let channel: DiscordChannel
    private let headerCard = UIView()
    private let statusLabel = UILabel()
    private let subtitleLabel = UILabel()
    private let tableView = UITableView(frame: .zero, style: .plain)
    private let controlsBar = UIView()
    private let muteButton = UIButton(type: .system)
    private let deafenButton = UIButton(type: .system)
    private let speakerButton = UIButton(type: .system)
    private let disconnectButton = UIButton(type: .system)

    private var participants: [VoiceState] = []

    init(channel: DiscordChannel) {
        self.channel = channel
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = channel.displayName
        setupNav()
        setupUI()
        applyTheme()
        refreshState()

        NotificationCenter.default.addObserver(self, selector: #selector(refreshState), name: .cordVoiceStateDidChange, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(refreshState), name: .cordVoiceSpeakingDidChange, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(refreshState), name: .cordStoreDidUpdateVoiceStates, object: nil)
    }

    private func setupNav() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            image: DiscordIcons.image(.chevronDown, size: 18),
            style: .plain,
            target: self,
            action: #selector(closeTapped)
        )
    }

    private func setupUI() {
        headerCard.layer.cornerRadius = 10
        headerCard.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headerCard)

        statusLabel.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        headerCard.addSubview(statusLabel)

        subtitleLabel.font = UIFont.systemFont(ofSize: 12)
        subtitleLabel.numberOfLines = 0
        subtitleLabel.translatesAutoresizingMaskIntoConstraints = false
        headerCard.addSubview(subtitleLabel)

        tableView.dataSource = self
        tableView.delegate = self
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.rowHeight = 56
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)

        controlsBar.layer.cornerRadius = 16
        controlsBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(controlsBar)

        let stack = UIStackView(arrangedSubviews: [muteButton, deafenButton, speakerButton, disconnectButton])
        stack.axis = .horizontal
        stack.distribution = .equalSpacing
        stack.alignment = .center
        stack.translatesAutoresizingMaskIntoConstraints = false
        controlsBar.addSubview(stack)

        for btn in [muteButton, deafenButton, speakerButton, disconnectButton] {
            btn.layer.cornerRadius = 26
            btn.translatesAutoresizingMaskIntoConstraints = false
            btn.widthAnchor.constraint(equalToConstant: 52).isActive = true
            btn.heightAnchor.constraint(equalToConstant: 52).isActive = true
        }

        muteButton.addTarget(self, action: #selector(muteTapped), for: .touchUpInside)
        deafenButton.addTarget(self, action: #selector(deafenTapped), for: .touchUpInside)
        speakerButton.addTarget(self, action: #selector(speakerTapped), for: .touchUpInside)
        disconnectButton.setImage(DiscordIcons.image(.phoneOff, size: 22), for: .normal)
        disconnectButton.backgroundColor = UIColor(hex: 0xDA373C)
        disconnectButton.tintColor = .white
        disconnectButton.addTarget(self, action: #selector(disconnectTapped), for: .touchUpInside)

        let topRef: NSLayoutYAxisAnchor
        let bottomRef: NSLayoutYAxisAnchor
        if #available(iOS 11.0, *) {
            topRef = view.safeAreaLayoutGuide.topAnchor
            bottomRef = view.safeAreaLayoutGuide.bottomAnchor
        } else {
            topRef = view.topAnchor
            bottomRef = view.bottomAnchor
        }

        NSLayoutConstraint.activate([
            headerCard.topAnchor.constraint(equalTo: topRef, constant: 12),
            headerCard.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 14),
            headerCard.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -14),

            statusLabel.topAnchor.constraint(equalTo: headerCard.topAnchor, constant: 12),
            statusLabel.leadingAnchor.constraint(equalTo: headerCard.leadingAnchor, constant: 14),
            statusLabel.trailingAnchor.constraint(equalTo: headerCard.trailingAnchor, constant: -14),

            subtitleLabel.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 4),
            subtitleLabel.leadingAnchor.constraint(equalTo: headerCard.leadingAnchor, constant: 14),
            subtitleLabel.trailingAnchor.constraint(equalTo: headerCard.trailingAnchor, constant: -14),
            subtitleLabel.bottomAnchor.constraint(equalTo: headerCard.bottomAnchor, constant: -12),

            tableView.topAnchor.constraint(equalTo: headerCard.bottomAnchor, constant: 10),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: controlsBar.topAnchor, constant: -12),

            controlsBar.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            controlsBar.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            controlsBar.bottomAnchor.constraint(equalTo: bottomRef, constant: -14),
            controlsBar.heightAnchor.constraint(equalToConstant: 76),

            stack.leadingAnchor.constraint(equalTo: controlsBar.leadingAnchor, constant: 18),
            stack.trailingAnchor.constraint(equalTo: controlsBar.trailingAnchor, constant: -18),
            stack.centerYAnchor.constraint(equalTo: controlsBar.centerYAnchor)
        ])
    }

    private func applyTheme() {
        let t = ThemeManager.shared.current
        view.backgroundColor = t.backgroundPrimary
        navigationController?.navigationBar.barTintColor = t.backgroundSecondary
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.tintColor = t.textPrimary
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: t.textPrimary]
        headerCard.backgroundColor = t.backgroundSecondary
        controlsBar.backgroundColor = t.backgroundSecondary
        subtitleLabel.textColor = t.textMuted
    }

    @objc private func refreshState() {
        let t = ThemeManager.shared.current
        let vc = DiscordVoiceClient.shared
        statusLabel.text = vc.phase.rawValue
        statusLabel.textColor = (vc.phase == .connected) ? UIColor(hex: 0x23A55A) : t.textPrimary

        if let ip = vc.localExternalIP, let port = vc.localExternalPort {
            subtitleLabel.text = "Voice Gateway v4 • UDP \(ip):\(port)"
        } else {
            subtitleLabel.text = "Channel #\(channel.displayName)"
        }

        muteButton.setImage(DiscordIcons.image(vc.isMuted ? .micOff : .mic, size: 22), for: .normal)
        muteButton.backgroundColor = vc.isMuted ? .white : t.surfaceCard
        muteButton.tintColor = vc.isMuted ? .black : t.textPrimary

        deafenButton.setImage(DiscordIcons.image(vc.isDeafened ? .headsetOff : .headset, size: 22), for: .normal)
        deafenButton.backgroundColor = vc.isDeafened ? .white : t.surfaceCard
        deafenButton.tintColor = vc.isDeafened ? .black : t.textPrimary

        speakerButton.setImage(DiscordIcons.image(.speaker, size: 22), for: .normal)
        speakerButton.backgroundColor = vc.isSpeakerOn ? t.accent : t.surfaceCard
        speakerButton.tintColor = .white

        participants = DiscordStore.shared.voiceStatesByChannel[channel.id] ?? []
        tableView.reloadData()
    }

    @objc private func closeTapped() {
        dismiss(animated: true)
    }

    @objc private func muteTapped() {
        DiscordVoiceClient.shared.setMuted(!DiscordVoiceClient.shared.isMuted)
        DiscordStore.shared.syncLocalVoiceMuteDeaf()
    }

    @objc private func deafenTapped() {
        DiscordVoiceClient.shared.setDeafened(!DiscordVoiceClient.shared.isDeafened)
        DiscordStore.shared.syncLocalVoiceMuteDeaf()
    }

    @objc private func speakerTapped() {
        DiscordVoiceClient.shared.setSpeakerphone(!DiscordVoiceClient.shared.isSpeakerOn)
    }

    @objc private func disconnectTapped() {
        DiscordStore.shared.leaveVoiceChannel()
        dismiss(animated: true)
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return participants.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let t = ThemeManager.shared.current
        let cell = tableView.dequeueReusableCell(withIdentifier: "VCMemberCell") ?? UITableViewCell(style: .default, reuseIdentifier: "VCMemberCell")
        cell.backgroundColor = .clear
        cell.selectionStyle = .none
        cell.contentView.subviews.forEach { $0.removeFromSuperview() }

        let vs = participants[indexPath.row]
        let user = DiscordStore.shared.usersById[vs.userId]
        let isSpeaking = DiscordVoiceClient.shared.speakingUserIds.contains(vs.userId)

        let av = AvatarWithDecorationView(frame: CGRect(x: 16, y: 10, width: 36, height: 36))
        av.showsStatusDot = false
        av.configure(user: user, status: nil, pixelSize: 64)
        if isSpeaking {
            av.layer.cornerRadius = 18
            av.layer.borderWidth = 2
            av.layer.borderColor = UIColor(hex: 0x23A55A).cgColor
        }
        cell.contentView.addSubview(av)

        let nameLbl = UILabel(frame: CGRect(x: 62, y: 16, width: tableView.bounds.width - 130, height: 24))
        nameLbl.text = user?.effectiveDisplayName ?? "User \(vs.userId)"
        nameLbl.font = UIFont.systemFont(ofSize: 15, weight: .medium)
        nameLbl.textColor = t.textPrimary
        cell.contentView.addSubview(nameLbl)

        if vs.selfDeaf == true || vs.deaf == true {
            let icon = UIImageView(frame: CGRect(x: tableView.bounds.width - 38, y: 18, width: 18, height: 18))
            icon.image = DiscordIcons.image(.headsetOff, size: 18)
            icon.tintColor = UIColor(hex: 0xDA373C)
            cell.contentView.addSubview(icon)
        } else if vs.selfMute == true || vs.mute == true {
            let icon = UIImageView(frame: CGRect(x: tableView.bounds.width - 38, y: 18, width: 18, height: 18))
            icon.image = DiscordIcons.image(.micOff, size: 18)
            icon.tintColor = UIColor(hex: 0xDA373C)
            cell.contentView.addSubview(icon)
        }

        return cell
    }
}
