import UIKit

/// Circular user avatar with optional Avatar Decoration frame overlay and presence badge.
final class AvatarWithDecorationView: UIView {
    private let avatarImageView = UIImageView()
    private let decorationImageView = UIImageView()
    private let statusDot = UIView()
    private var currentAvatarURL: String?
    private var currentDecoURL: String?

    var showsStatusDot: Bool = true {
        didSet { statusDot.isHidden = !showsStatusDot }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }

    private func setup() {
        avatarImageView.contentMode = .scaleAspectFill
        avatarImageView.clipsToBounds = true
        avatarImageView.backgroundColor = ThemeManager.shared.current.surfaceCard
        addSubview(avatarImageView)

        decorationImageView.contentMode = .scaleAspectFit
        decorationImageView.clipsToBounds = false
        addSubview(decorationImageView)

        statusDot.layer.borderWidth = 2.5
        statusDot.layer.borderColor = ThemeManager.shared.current.backgroundPrimary.cgColor
        statusDot.isHidden = true
        addSubview(statusDot)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        let size = min(bounds.width, bounds.height)
        avatarImageView.frame = CGRect(x: (bounds.width - size) / 2, y: (bounds.height - size) / 2, width: size, height: size)
        avatarImageView.layer.cornerRadius = size / 2

        let decoInset = -size * 0.12
        decorationImageView.frame = avatarImageView.frame.insetBy(dx: decoInset, dy: decoInset)

        let dotSize = max(10, size * 0.28)
        statusDot.frame = CGRect(
            x: avatarImageView.frame.maxX - dotSize * 0.9,
            y: avatarImageView.frame.maxY - dotSize * 0.9,
            width: dotSize,
            height: dotSize
        )
        statusDot.layer.cornerRadius = dotSize / 2
    }

    func configure(user: DiscordUser?, status: String? = nil, pixelSize: CGFloat = 128) {
        guard let user = user else {
            avatarImageView.image = nil
            decorationImageView.image = nil
            statusDot.isHidden = true
            return
        }

        let avURL = user.avatarURL(size: Int(pixelSize))
        if currentAvatarURL != avURL {
            currentAvatarURL = avURL
            avatarImageView.image = nil
            ImageLoader.shared.load(urlString: avURL, maxPixelSize: pixelSize) { [weak self] img in
                if self?.currentAvatarURL == avURL {
                    self?.avatarImageView.image = img
                }
            }
        }

        if let deco = user.avatarDecorationData {
            let decURL = deco.imageURL
            if currentDecoURL != decURL {
                currentDecoURL = decURL
                decorationImageView.image = nil
                ImageLoader.shared.load(urlString: decURL, maxPixelSize: pixelSize * 1.3) { [weak self] img in
                    if self?.currentDecoURL == decURL {
                        self?.decorationImageView.image = img
                    }
                }
            }
        } else {
            currentDecoURL = nil
            decorationImageView.image = nil
        }

        if showsStatusDot, let status = status {
            statusDot.isHidden = false
            statusDot.layer.borderColor = ThemeManager.shared.current.backgroundPrimary.cgColor
            switch status {
            case "online": statusDot.backgroundColor = UIColor(hex: 0x23A55A)
            case "idle": statusDot.backgroundColor = UIColor(hex: 0xF0B232)
            case "dnd": statusDot.backgroundColor = UIColor(hex: 0xF23F43)
            default: statusDot.backgroundColor = UIColor(hex: 0x80848E)
            }
        } else {
            statusDot.isHidden = true
        }
    }
}
