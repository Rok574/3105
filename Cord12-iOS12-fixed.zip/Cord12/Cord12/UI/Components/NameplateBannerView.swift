import UIKit

/// Renders a Discord collectible Nameplate with its palette gradient and static asset overlay.
final class NameplateBannerView: UIView {
    private let gradientLayer = CAGradientLayer()
    private let imageView = UIImageView()
    private var currentURL: String?

    override init(frame: CGRect) {
        super.init(frame: frame)
        layer.cornerRadius = 10
        clipsToBounds = true
        gradientLayer.startPoint = CGPoint(x: 0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1, y: 0.5)
        layer.insertSublayer(gradientLayer, at: 0)

        imageView.contentMode = .scaleAspectFill
        imageView.alpha = 0.85
        addSubview(imageView)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        gradientLayer.frame = bounds
        imageView.frame = bounds
    }

    func configure(nameplate: NameplateData?) {
        guard let np = nameplate else {
            isHidden = true
            return
        }
        isHidden = false
        let colors = NameplateBannerView.paletteColors(np.palette)
        gradientLayer.colors = colors.map { $0.cgColor }

        let url = np.staticImageURL
        if currentURL != url {
            currentURL = url
            imageView.image = nil
            ImageLoader.shared.load(urlString: url, maxPixelSize: 320) { [weak self] img in
                if self?.currentURL == url {
                    self?.imageView.image = img
                }
            }
        }
    }

    static func paletteColors(_ palette: String?) -> [UIColor] {
        switch palette?.lowercased() {
        case "crimson": return [UIColor(hex: 0x5C101B), UIColor(hex: 0xB82538)]
        case "berry": return [UIColor(hex: 0x4E1B4E), UIColor(hex: 0xA83882)]
        case "bubble_gum": return [UIColor(hex: 0x6B245B), UIColor(hex: 0xE664B5)]
        case "sky": return [UIColor(hex: 0x15436B), UIColor(hex: 0x3A99E0)]
        case "teal": return [UIColor(hex: 0x0E4A47), UIColor(hex: 0x26B5AA)]
        case "forest": return [UIColor(hex: 0x144524), UIColor(hex: 0x2E994B)]
        case "clover": return [UIColor(hex: 0x1A5226), UIColor(hex: 0x48C25B)]
        case "cobalt": return [UIColor(hex: 0x142A66), UIColor(hex: 0x3B66E0)]
        case "violet": return [UIColor(hex: 0x331B66), UIColor(hex: 0x7A4CE0)]
        case "lemon": return [UIColor(hex: 0x5E4B10), UIColor(hex: 0xD6B029)]
        case "white": return [UIColor(hex: 0x3D4047), UIColor(hex: 0x7A7E87)]
        default: return [UIColor(hex: 0x2B2D31), UIColor(hex: 0x40444B)]
        }
    }
}
