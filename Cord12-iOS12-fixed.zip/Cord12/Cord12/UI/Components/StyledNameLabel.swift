import UIKit

/// Renders Discord Display Name Styles (font_id, effect_id, colors) safely in UIKit for iOS 12+.
final class StyledNameLabel: UIView {
    private let label = UILabel()

    var baseFontSize: CGFloat = 15 {
        didSet { updateAppearance() }
    }

    var text: String = "" {
        didSet { updateAppearance() }
    }

    var defaultColor: UIColor = ThemeManager.shared.current.textPrimary {
        didSet { updateAppearance() }
    }

    var style: DisplayNameStyle? {
        didSet { updateAppearance() }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }

    private func setup() {
        backgroundColor = .clear
        label.numberOfLines = 1
        label.lineBreakMode = .byTruncatingTail
        addSubview(label)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        label.frame = bounds
        if let style = style, !style.colors.isEmpty,
           [2, 6, 7, 8].contains(style.effectId), bounds.width > 4, bounds.height > 4 {
            applyGradientTextColor(colors: style.colors.map { UIColor(hex: $0) })
        }
    }

    override var intrinsicContentSize: CGSize {
        return label.intrinsicContentSize
    }

    static func fontName(for fontId: Int) -> String {
        switch fontId {
        case 3: return "ChalkboardSE-Bold"
        case 4: return "MarkerFelt-Wide"
        case 6: return "Futura-Bold"
        case 7: return "Papyrus"
        case 8: return "Courier-Bold"
        case 10: return "Copperplate-Bold"
        case 12: return "Rockwell-Bold"
        case 13: return "AvenirNext-Heavy"
        case 14: return "Menlo-Bold"
        case 15: return "Georgia-BoldItalic"
        case 16: return "Noteworthy-Bold"
        default: return ".SFUIText-Semibold"
        }
    }

    static func displayTitle(for fontId: Int) -> String {
        switch fontId {
        case 11: return "Default (gg Sans)"
        case 3: return "Sakura"
        case 4: return "Jellybean"
        case 6: return "Modern"
        case 7: return "Medieval"
        case 8: return "8-Bit"
        case 10: return "Vampyre"
        case 12: return "Tempo"
        case 13: return "Monkey Bars"
        case 14: return "Mainframe"
        case 15: return "Headbang"
        case 16: return "Journal"
        default: return "Default"
        }
    }

    static func effectTitle(for effectId: Int) -> String {
        switch effectId {
        case 1: return "Solid"
        case 2: return "Gradient"
        case 3: return "Neon"
        case 4: return "Toon"
        case 5: return "Pop"
        case 6: return "Glow"
        case 7: return "Prism"
        case 8: return "Gummy"
        default: return "Solid"
        }
    }

    private func applyGradientTextColor(colors: [UIColor]) {
        let gradColors = colors.count >= 2 ? colors : [colors[0], colors[0].withAlphaComponent(0.7)]
        let size = CGSize(width: max(10, bounds.width), height: max(10, bounds.height))
        let renderer = UIGraphicsImageRenderer(size: size)
        let img = renderer.image { ctx in
            let cgColors = gradColors.map { $0.cgColor } as CFArray
            guard let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: cgColors, locations: nil) else { return }
            ctx.cgContext.drawLinearGradient(
                gradient,
                start: CGPoint(x: 0, y: size.height / 2),
                end: CGPoint(x: size.width, y: size.height / 2),
                options: [.drawsBeforeStartLocation, .drawsAfterEndLocation]
            )
        }
        label.textColor = UIColor(patternImage: img)
    }

    private func updateAppearance() {
        label.layer.shadowOpacity = 0
        label.layer.shadowRadius = 0

        let font: UIFont
        if let style = style, style.fontId != 11,
           let custom = UIFont(name: StyledNameLabel.fontName(for: style.fontId), size: baseFontSize) {
            font = custom
        } else {
            font = UIFont.systemFont(ofSize: baseFontSize, weight: .semibold)
        }
        label.font = font

        guard let style = style, !style.colors.isEmpty else {
            label.attributedText = nil
            label.text = text
            label.textColor = defaultColor
            invalidateIntrinsicContentSize()
            return
        }

        let colors = style.colors.map { UIColor(hex: $0) }
        let primary = colors[0]

        switch style.effectId {
        case 2, 6, 7, 8:
            label.attributedText = nil
            label.text = text
            if bounds.width > 4 && bounds.height > 4 {
                applyGradientTextColor(colors: colors)
            } else {
                label.textColor = primary
            }
            if style.effectId == 6 {
                label.layer.shadowColor = primary.cgColor
                label.layer.shadowRadius = 5
                label.layer.shadowOpacity = 0.75
                label.layer.shadowOffset = .zero
            }

        case 3:
            label.attributedText = nil
            label.text = text
            label.textColor = .white
            label.layer.shadowColor = primary.cgColor
            label.layer.shadowRadius = 6
            label.layer.shadowOpacity = 0.9
            label.layer.shadowOffset = .zero

        case 4:
            let attrs: [NSAttributedString.Key: Any] = [
                .font: font,
                .foregroundColor: primary,
                .strokeColor: UIColor.black,
                .strokeWidth: -3.0
            ]
            label.attributedText = NSAttributedString(string: text, attributes: attrs)

        case 5:
            label.attributedText = nil
            label.text = text
            label.textColor = primary
            label.layer.shadowColor = UIColor.black.cgColor
            label.layer.shadowRadius = 0
            label.layer.shadowOpacity = 0.85
            label.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)

        default:
            label.attributedText = nil
            label.text = text
            label.textColor = primary
        }

        invalidateIntrinsicContentSize()
    }
}
