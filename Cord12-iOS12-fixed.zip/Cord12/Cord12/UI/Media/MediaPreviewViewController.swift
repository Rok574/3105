import UIKit

/// Full-screen pinch-to-zoom Image & GIF lightbox with Share and Favorite GIF toggle.
final class MediaPreviewViewController: UIViewController, UIScrollViewDelegate {
    private let mediaURL: String
    private let mediaTitle: String?
    private let isGif: Bool

    private let scrollView = UIScrollView()
    private let imageView = UIImageView()
    private let favoriteButton = UIButton(type: .system)

    init(urlString: String, title: String? = nil, isGif: Bool = false) {
        self.mediaURL = urlString
        self.mediaTitle = title
        self.isGif = isGif || urlString.lowercased().contains(".gif") || urlString.lowercased().contains("tenor.com") || urlString.lowercased().contains("giphy.com")
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        setupNav()
        setupScroll()
        loadMedia()
    }

    private func setupNav() {
        navigationController?.navigationBar.barTintColor = UIColor(hex: 0x121214)
        navigationController?.navigationBar.tintColor = .white
        navigationController?.navigationBar.isTranslucent = false

        navigationItem.leftBarButtonItem = UIBarButtonItem(
            image: DiscordIcons.image(.close, size: 20),
            style: .plain,
            target: self,
            action: #selector(closeTapped)
        )

        let shareItem = UIBarButtonItem(
            image: DiscordIcons.image(.share, size: 20),
            style: .plain,
            target: self,
            action: #selector(shareTapped)
        )

        updateFavoriteIcon()
        favoriteButton.tintColor = GifFavoritesStore.shared.isFavorite(url: mediaURL) ? UIColor(hex: 0xF0B232) : .white
        favoriteButton.frame = CGRect(x: 0, y: 0, width: 34, height: 34)
        favoriteButton.addTarget(self, action: #selector(favoriteTapped), for: .touchUpInside)
        let favItem = UIBarButtonItem(customView: favoriteButton)

        navigationItem.rightBarButtonItems = [shareItem, favItem]
    }

    private func updateFavoriteIcon() {
        let isFav = GifFavoritesStore.shared.isFavorite(url: mediaURL)
        favoriteButton.setImage(DiscordIcons.image(isFav ? .starFilled : .star, size: 22), for: .normal)
        favoriteButton.tintColor = isFav ? UIColor(hex: 0xF0B232) : .white
    }

    private func setupScroll() {
        scrollView.delegate = self
        scrollView.minimumZoomScale = 1.0
        scrollView.maximumZoomScale = 4.0
        scrollView.showsVerticalScrollIndicator = false
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)

        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(imageView)

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            imageView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            imageView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            imageView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            imageView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),
            imageView.heightAnchor.constraint(equalTo: scrollView.heightAnchor)
        ])

        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap))
        doubleTap.numberOfTapsRequired = 2
        scrollView.addGestureRecognizer(doubleTap)
    }

    private func loadMedia() {
        ImageLoader.shared.load(urlString: mediaURL, maxPixelSize: 600, animated: true) { [weak self] img in
            self?.imageView.image = img
        }
    }

    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return imageView
    }

    @objc private func handleDoubleTap() {
        let nextScale: CGFloat = scrollView.zoomScale > 1.2 ? 1.0 : 2.5
        scrollView.setZoomScale(nextScale, animated: true)
    }

    @objc private func favoriteTapped() {
        _ = GifFavoritesStore.shared.toggleFavorite(url: mediaURL, title: mediaTitle)
        updateFavoriteIcon()
    }

    @objc private func shareTapped() {
        var items: [Any] = []
        if let img = imageView.image { items.append(img) }
        if let url = URL(string: mediaURL) { items.append(url) }
        let vc = UIActivityViewController(activityItems: items, applicationActivities: nil)
        vc.popoverPresentationController?.barButtonItem = navigationItem.rightBarButtonItems?.first
        present(vc, animated: true)
    }

    @objc private func closeTapped() {
        dismiss(animated: true)
    }
}
