import UIKit

protocol EmojiPickerDelegate: AnyObject {
    func emojiPicker(_ picker: EmojiPickerViewController, didSelectEmojiText text: String, apiIdentifier: String)
}

/// Custom Guild Emoji + Standard Emoji Picker using Discord's <:name:id> / <a:name:id> format.
final class EmojiPickerViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    weak var delegate: EmojiPickerDelegate?

    private let currentGuildId: String?
    private let segment = UISegmentedControl(items: ["Standard", "Server Emojis"])
    private var collectionView: UICollectionView!

    private let standardEmojis = [
        "👍", "❤️", "😂", "🔥", "💀", "✨", "😭", "🙏",
        "👀", "🎉", "💯", "🤔", "😎", "🥳", "😡", "🤯",
        "👏", "💜", "💙", "🖤", "🤍", "⭐", "⚡", "🚀"
    ]
    private var customEmojis: [DiscordEmoji] = []
    private var currentGuildEmojiIds: Set<String> = []

    init(currentGuildId: String? = nil) {
        self.currentGuildId = currentGuildId
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Emojis"
        if let gid = currentGuildId, let local = DiscordStore.shared.emojisByGuild[gid] {
            currentGuildEmojiIds = Set(local.compactMap { $0.id })
            let others = DiscordStore.shared.allCustomEmojis().filter { !currentGuildEmojiIds.contains($0.id ?? "") }
            customEmojis = local + others
        } else {
            customEmojis = DiscordStore.shared.allCustomEmojis()
        }

        let t = ThemeManager.shared.current
        view.backgroundColor = t.backgroundPrimary
        navigationController?.navigationBar.barTintColor = t.backgroundSecondary
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.tintColor = t.textPrimary
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: t.textPrimary]

        navigationItem.leftBarButtonItem = UIBarButtonItem(
            image: DiscordIcons.image(.close, size: 18),
            style: .plain,
            target: self,
            action: #selector(closeTapped)
        )

        segment.selectedSegmentIndex = customEmojis.isEmpty ? 0 : 1
        segment.tintColor = t.accent
        segment.addTarget(self, action: #selector(segmentChanged), for: .valueChanged)
        segment.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(segment)

        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: 48, height: 48)
        layout.minimumInteritemSpacing = 8
        layout.minimumLineSpacing = 8
        layout.sectionInset = UIEdgeInsets(top: 12, left: 12, bottom: 20, right: 12)
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(EmojiGridCell.self, forCellWithReuseIdentifier: EmojiGridCell.reuseID)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(collectionView)

        let topRef: NSLayoutYAxisAnchor
        if #available(iOS 11.0, *) {
            topRef = view.safeAreaLayoutGuide.topAnchor
        } else {
            topRef = view.topAnchor
        }

        NSLayoutConstraint.activate([
            segment.topAnchor.constraint(equalTo: topRef, constant: 10),
            segment.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 14),
            segment.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -14),

            collectionView.topAnchor.constraint(equalTo: segment.bottomAnchor, constant: 8),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    @objc private func segmentChanged() {
        collectionView.reloadData()
    }

    @objc private func closeTapped() {
        dismiss(animated: true)
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return segment.selectedSegmentIndex == 0 ? standardEmojis.count : customEmojis.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: EmojiGridCell.reuseID, for: indexPath) as! EmojiGridCell
        if segment.selectedSegmentIndex == 0 {
            cell.configure(unicode: standardEmojis[indexPath.item])
        } else {
            cell.configure(custom: customEmojis[indexPath.item])
        }
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if segment.selectedSegmentIndex == 0 {
            let e = standardEmojis[indexPath.item]
            delegate?.emojiPicker(self, didSelectEmojiText: e, apiIdentifier: e)
        } else {
            let e = customEmojis[indexPath.item]
            let hasNitro = (DiscordStore.shared.currentUser?.premiumType ?? 0) > 0
            let isLocalStatic = (e.id.map { currentGuildEmojiIds.contains($0) } ?? false) && (e.animated != true)
            let insertText: String
            if hasNitro || isLocalStatic {
                insertText = e.asDiscordTag
            } else {
                // External or animated emoji without Nitro: Fake Nitro CDN fallback
                insertText = e.imageURL ?? e.asDiscordTag
            }
            delegate?.emojiPicker(self, didSelectEmojiText: insertText, apiIdentifier: e.apiIdentifier)
        }
        dismiss(animated: true)
    }
}

private final class EmojiGridCell: UICollectionViewCell {
    static let reuseID = "EmojiGridCell"
    private let label = UILabel()
    private let imageView = UIImageView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.layer.cornerRadius = 10
        contentView.backgroundColor = ThemeManager.shared.current.surfaceCard
        label.font = UIFont.systemFont(ofSize: 28)
        label.textAlignment = .center
        label.frame = contentView.bounds
        label.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        contentView.addSubview(label)

        imageView.contentMode = .scaleAspectFit
        imageView.frame = contentView.bounds.insetBy(dx: 6, dy: 6)
        imageView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        contentView.addSubview(imageView)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func configure(unicode: String) {
        imageView.isHidden = true
        label.isHidden = false
        label.text = unicode
    }

    func configure(custom: DiscordEmoji) {
        label.isHidden = true
        imageView.isHidden = false
        imageView.image = nil
        ImageLoader.shared.load(urlString: custom.staticPNGURL ?? custom.imageURL, maxPixelSize: 64, animated: false) { [weak self] img in
            self?.imageView.image = img
        }
    }
}
