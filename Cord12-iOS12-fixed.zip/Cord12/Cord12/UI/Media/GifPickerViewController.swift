import UIKit

protocol GifPickerDelegate: AnyObject {
    func gifPicker(_ picker: GifPickerViewController, didSelectGifURL url: String)
}

final class GifPickerViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UISearchBarDelegate {
    weak var delegate: GifPickerDelegate?

    private let segment = UISegmentedControl(items: ["Favorites", "Trending / Search"])
    private let searchBar = UISearchBar()
    private var collectionView: UICollectionView!
    private let emptyLabel = UILabel()

    private var searchResults: [DiscordGifItem] = []

    private var displayedItems: [DiscordGifItem] {
        return segment.selectedSegmentIndex == 0 ? GifFavoritesStore.shared.favorites : searchResults
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "GIFs"
        setupNav()
        setupUI()
        applyTheme()
        NotificationCenter.default.addObserver(self, selector: #selector(reloadGrid), name: .cordGifFavoritesDidChange, object: nil)
        GifFavoritesStore.shared.syncFromDiscord()
        loadTrending()
    }

    private func setupNav() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            image: DiscordIcons.image(.close, size: 18),
            style: .plain,
            target: self,
            action: #selector(closeTapped)
        )
    }

    private func setupUI() {
        segment.selectedSegmentIndex = GifFavoritesStore.shared.favorites.isEmpty ? 1 : 0
        segment.addTarget(self, action: #selector(segmentChanged), for: .valueChanged)
        segment.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(segment)

        searchBar.placeholder = "Search Tenor / Discord GIFs"
        searchBar.searchBarStyle = .minimal
        searchBar.delegate = self
        searchBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(searchBar)

        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 8
        layout.minimumLineSpacing = 8
        layout.sectionInset = UIEdgeInsets(top: 8, left: 10, bottom: 16, right: 10)
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(GifGridCell.self, forCellWithReuseIdentifier: GifGridCell.reuseID)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(collectionView)

        emptyLabel.text = "No favorite GIFs yet.\nTap any GIF in chat and press ★ to save it!"
        emptyLabel.numberOfLines = 0
        emptyLabel.textAlignment = .center
        emptyLabel.font = UIFont.systemFont(ofSize: 14)
        emptyLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(emptyLabel)

        let topRef: NSLayoutYAxisAnchor
        if #available(iOS 11.0, *) {
            topRef = view.safeAreaLayoutGuide.topAnchor
        } else {
            topRef = view.topAnchor
        }

        NSLayoutConstraint.activate([
            segment.topAnchor.constraint(equalTo: topRef, constant: 10),
            segment.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 14),
            segment.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -14),

            searchBar.topAnchor.constraint(equalTo: segment.bottomAnchor, constant: 6),
            searchBar.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 6),
            searchBar.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -6),

            collectionView.topAnchor.constraint(equalTo: searchBar.bottomAnchor, constant: 4),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            emptyLabel.centerXAnchor.constraint(equalTo: collectionView.centerXAnchor),
            emptyLabel.centerYAnchor.constraint(equalTo: collectionView.centerYAnchor),
            emptyLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 32),
            emptyLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -32)
        ])
    }

    private func applyTheme() {
        let t = ThemeManager.shared.current
        view.backgroundColor = t.backgroundPrimary
        navigationController?.navigationBar.barTintColor = t.backgroundSecondary
        navigationController?.navigationBar.tintColor = t.textPrimary
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: t.textPrimary]
        segment.tintColor = t.accent
        collectionView.backgroundColor = t.backgroundPrimary
        emptyLabel.textColor = t.textMuted
        if let tf = searchBar.value(forKey: "searchField") as? UITextField {
            tf.textColor = t.textPrimary
        }
    }

    private func loadTrending() {
        DiscordRESTClient.shared.fetchTrendingGifs { [weak self] res in
            if case .success(let items) = res {
                self?.searchResults = items
                self?.reloadGrid()
            }
        }
    }

    @objc private func segmentChanged() {
        searchBar.isHidden = (segment.selectedSegmentIndex == 0)
        reloadGrid()
    }

    @objc private func reloadGrid() {
        emptyLabel.isHidden = !displayedItems.isEmpty
        collectionView.reloadData()
    }

    @objc private func closeTapped() {
        dismiss(animated: true)
    }

    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        let q = (searchBar.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else {
            GifFavoritesStore.shared.syncFromDiscord()
        loadTrending()
            return
        }
        segment.selectedSegmentIndex = 1
        DiscordRESTClient.shared.searchGifs(query: q) { [weak self] res in
            if case .success(let items) = res {
                self?.searchResults = items
                self?.reloadGrid()
            }
        }
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return displayedItems.count
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let w = (collectionView.bounds.width - 28) / 2
        return CGSize(width: w, height: w * 0.72)
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: GifGridCell.reuseID, for: indexPath) as! GifGridCell
        let item = displayedItems[indexPath.item]
        cell.configure(with: item)
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let item = displayedItems[indexPath.item]
        delegate?.gifPicker(self, didSelectGifURL: item.effectiveGifURL)
        dismiss(animated: true)
    }
}

private final class GifGridCell: UICollectionViewCell {
    static let reuseID = "GifGridCell"
    private let imageView = UIImageView()
    private let starBadge = UIImageView()
    private var currentURL: String?

    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.layer.cornerRadius = 10
        contentView.clipsToBounds = true
        contentView.backgroundColor = ThemeManager.shared.current.surfaceCard

        imageView.contentMode = .scaleAspectFill
        imageView.frame = contentView.bounds
        imageView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        contentView.addSubview(imageView)

        starBadge.frame = CGRect(x: frame.width - 26, y: 6, width: 20, height: 20)
        starBadge.autoresizingMask = [.flexibleLeftMargin, .flexibleBottomMargin]
        starBadge.image = DiscordIcons.image(.starFilled, size: 16, color: UIColor(hex: 0xF0B232), template: false)
        contentView.addSubview(starBadge)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func configure(with item: DiscordGifItem) {
        let url = item.preview ?? item.effectiveGifURL
        starBadge.isHidden = !GifFavoritesStore.shared.isFavorite(url: item.effectiveGifURL)
        if currentURL != url {
            currentURL = url
            imageView.image = nil
            ImageLoader.shared.load(urlString: url, maxPixelSize: 180, animated: true) { [weak self] img in
                if self?.currentURL == url {
                    self?.imageView.image = img
                }
            }
        }
    }
}
