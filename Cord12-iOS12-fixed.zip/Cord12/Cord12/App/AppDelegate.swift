import UIKit
import UserNotifications

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, LoginViewControllerDelegate, UNUserNotificationCenterDelegate {
    var window: UIWindow?
    private var bgTask: UIBackgroundTaskIdentifier = .invalid

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        let win = UIWindow(frame: UIScreen.main.bounds)
        win.backgroundColor = ThemeManager.shared.current.backgroundPrimary
        self.window = win

        let center = UNUserNotificationCenter.current()
        center.delegate = self
        center.requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
        application.setMinimumBackgroundFetchInterval(UIApplication.backgroundFetchIntervalMinimum)

        if let token = KeychainStore.shared.loadToken(), !token.isEmpty {
            showMain(token: token)
        } else {
            showLogin()
        }

        win.makeKeyAndVisible()
        NotificationCenter.default.addObserver(self, selector: #selector(handleAuthInvalid), name: .cordAuthInvalid, object: nil)
        return true
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        bgTask = application.beginBackgroundTask(withName: "Cord12Gateway") { [weak self] in
            if let task = self?.bgTask, task != .invalid {
                application.endBackgroundTask(task)
                self?.bgTask = .invalid
            }
        }
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        if bgTask != .invalid {
            application.endBackgroundTask(bgTask)
            bgTask = .invalid
        }
        application.applicationIconBadgeNumber = 0
    }

    func application(_ application: UIApplication, performFetchWithCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        guard DiscordRESTClient.shared.token != nil else {
            completionHandler(.noData)
            return
        }
        DiscordStore.shared.pollBackgroundNotifications { hasNew in
            completionHandler(hasNew ? .newData : .noData)
        }
    }

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        completionHandler([.alert, .sound])
    }

    @objc private func handleAuthInvalid() {
        guard !(window?.rootViewController is LoginViewController) else { return }
        DiscordStore.shared.logout()
        showLogin()
    }

    func showLogin() {
        let loginVC = LoginViewController()
        loginVC.delegate = self
        window?.rootViewController = loginVC
    }

    func showMain(token: String) {
        DiscordStore.shared.startSession(token: token)
        window?.rootViewController = MainContainerViewController()
    }

    func loginViewControllerDidAuthenticate(token: String) {
        showMain(token: token)
    }
}
