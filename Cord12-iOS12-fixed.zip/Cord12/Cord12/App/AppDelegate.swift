import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, LoginViewControllerDelegate {
    var window: UIWindow?

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        let win = UIWindow(frame: UIScreen.main.bounds)
        win.backgroundColor = UIColor(red: 0.102, green: 0.102, blue: 0.118, alpha: 1)
        self.window = win

        if let token = KeychainStore.shared.loadToken(), !token.isEmpty {
            showMain(token: token)
        } else {
            showLogin()
        }

        win.makeKeyAndVisible()
        NotificationCenter.default.addObserver(self, selector: #selector(handleAuthInvalid), name: .cordAuthInvalid, object: nil)
        return true
    }

    @objc private func handleAuthInvalid() {
        guard !(window?.rootViewController is LoginViewController) else { return }
        DiscordStore.shared.logout()
        showLogin()
    }

    func showLogin() {
        let loginVC = LoginViewController()
        loginVC.delegate = self
        window?.rootViewController = loginVC
    }

    func showMain(token: String) {
        DiscordStore.shared.startSession(token: token)
        window?.rootViewController = MainContainerViewController()
    }

    func loginViewControllerDidAuthenticate(token: String) {
        showMain(token: token)
    }
}
