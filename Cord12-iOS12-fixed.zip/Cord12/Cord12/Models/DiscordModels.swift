import Foundation

/// Discord CDN strictly requires power-of-two `?size=` parameters (16..4096).
func discordCDNSize(_ requested: Int) -> Int {
    let valid = [16, 32, 64, 128, 256, 512, 1024, 2048, 4096]
    return valid.first(where: { $0 >= requested }) ?? 1024
}

struct DiscordUser: Codable {
    let id: String
    var username: String
    var discriminator: String?
    var globalName: String?
    var avatar: String?
    var banner: String?
    var accentColor: Int?
    var bio: String?
    var pronouns: String?
    var publicFlags: Int?
    var premiumType: Int?
    var avatarDecorationData: AvatarDecorationData?
    var collectibles: UserCollectibles?
    var displayNameStyles: DisplayNameStyle?
    var primaryGuild: PrimaryGuild?
    var bot: Bool?

    enum CodingKeys: String, CodingKey {
        case id, username, discriminator, avatar, banner, bio, pronouns, collectibles, bot
        case globalName = "global_name"
        case accentColor = "accent_color"
        case publicFlags = "public_flags"
        case premiumType = "premium_type"
        case avatarDecorationData = "avatar_decoration_data"
        case displayNameStyles = "display_name_styles"
        case primaryGuild = "primary_guild"
    }

    var effectiveDisplayName: String {
        if let g = globalName, !g.isEmpty { return g }
        return username
    }

    func avatarURL(size: Int = 128) -> String {
        let s = discordCDNSize(size)
        if let avatar = avatar, !avatar.isEmpty {
            let ext = avatar.hasPrefix("a_") ? "gif" : "png"
            return "https://cdn.discordapp.com/avatars/\(id)/\(avatar).\(ext)?size=\(s)"
        }
        let index: Int
        if let disc = discriminator, disc != "0", let d = Int(disc) {
            index = d % 5
        } else if let uid = UInt64(id) {
            index = Int((uid >> 22) % 6)
        } else {
            index = 0
        }
        return "https://cdn.discordapp.com/embed/avatars/\(index).png"
    }

    func bannerURL(size: Int = 512) -> String? {
        guard let banner = banner, !banner.isEmpty else { return nil }
        let s = discordCDNSize(size)
        let ext = banner.hasPrefix("a_") ? "gif" : "png"
        return "https://cdn.discordapp.com/banners/\(id)/\(banner).\(ext)?size=\(s)"
    }
}

struct AvatarDecorationData: Codable {
    let asset: String
    let skuId: String?
    let expiresAt: Int?

    enum CodingKeys: String, CodingKey {
        case asset
        case skuId = "sku_id"
        case expiresAt = "expires_at"
    }

    var imageURL: String {
        return "https://cdn.discordapp.com/avatar-decoration-presets/\(asset).png?size=256&passthrough=false"
    }
}

struct UserCollectibles: Codable {
    let nameplate: NameplateData?
}

struct NameplateData: Codable {
    let asset: String
    let skuId: String?
    let label: String?
    let palette: String?

    enum CodingKeys: String, CodingKey {
        case asset, label, palette
        case skuId = "sku_id"
    }

    var staticImageURL: String {
        let clean = asset.hasSuffix("/") ? asset : "\(asset)/"
        return "https://cdn.discordapp.com/assets/collectibles/\(clean)static.png"
    }
}

struct DisplayNameStyle: Codable {
    var fontId: Int
    var effectId: Int
    var colors: [Int]

    enum CodingKeys: String, CodingKey {
        case fontId = "font_id"
        case effectId = "effect_id"
        case colors
    }
}

struct PrimaryGuild: Codable {
    let identityGuildId: String?
    let identityEnabled: Bool?
    let tag: String?
    let badge: String?

    enum CodingKeys: String, CodingKey {
        case tag, badge
        case identityGuildId = "identity_guild_id"
        case identityEnabled = "identity_enabled"
    }
}

struct ProfileBadge: Codable {
    let id: String
    let description: String
    let icon: String
    let link: String?

    var iconURL: String {
        return "https://cdn.discordapp.com/badge-icons/\(icon).png"
    }
}

struct ProfileEffectRef: Codable {
    let id: String
    let expiresAt: Int?

    enum CodingKeys: String, CodingKey {
        case id
        case expiresAt = "expires_at"
    }
}

struct ProfileMetadata: Codable {
    let guildId: String?
    var pronouns: String?
    var bio: String?
    var banner: String?
    var accentColor: Int?
    var themeColors: [Int]?
    var profileEffect: ProfileEffectRef?

    enum CodingKeys: String, CodingKey {
        case pronouns, bio, banner
        case guildId = "guild_id"
        case accentColor = "accent_color"
        case themeColors = "theme_colors"
        case profileEffect = "profile_effect"
    }
}

struct ConnectedAccount: Codable {
    let type: String
    let id: String
    let name: String
    let verified: Bool?
}

struct MutualGuild: Codable {
    let id: String
    let nick: String?
}

struct UserProfileResponse: Codable {
    let user: DiscordUser
    let userProfile: ProfileMetadata?
    let badges: [ProfileBadge]?
    let mutualGuilds: [MutualGuild]?
    let mutualFriendsCount: Int?
    let connectedAccounts: [ConnectedAccount]?
    let premiumType: Int?
    let premiumSince: String?
    let premiumGuildSince: String?

    enum CodingKeys: String, CodingKey {
        case user, badges
        case userProfile = "user_profile"
        case mutualGuilds = "mutual_guilds"
        case mutualFriendsCount = "mutual_friends_count"
        case connectedAccounts = "connected_accounts"
        case premiumType = "premium_type"
        case premiumSince = "premium_since"
        case premiumGuildSince = "premium_guild_since"
    }
}

struct CollectibleProduct: Codable {
    let skuId: String
    let type: Int
    let name: String
    let items: [CollectibleItem]?

    enum CodingKeys: String, CodingKey {
        case type, name, items
        case skuId = "sku_id"
    }
}

struct CollectibleItem: Codable {
    let type: Int
    let skuId: String?
    let asset: String?
    let palette: String?
    let label: String?

    enum CodingKeys: String, CodingKey {
        case type, asset, palette, label
        case skuId = "sku_id"
    }
}

struct DiscordGuild: Codable {
    let id: String
    var name: String
    var icon: String?
    var banner: String?
    var ownerId: String?
    var roles: [DiscordRole]?
    var channels: [DiscordChannel]?
    var emojis: [DiscordEmoji]?

    enum CodingKeys: String, CodingKey {
        case id, name, icon, banner, roles, channels, emojis
        case ownerId = "owner_id"
    }

    func iconURL(size: Int = 128) -> String? {
        guard let icon = icon, !icon.isEmpty else { return nil }
        let s = discordCDNSize(size)
        let ext = icon.hasPrefix("a_") ? "gif" : "png"
        return "https://cdn.discordapp.com/icons/\(id)/\(icon).\(ext)?size=\(s)"
    }
}

struct GuildFolder: Codable {
    let id: Int?
    let name: String?
    let color: Int?
    let guildIds: [String]

    enum CodingKeys: String, CodingKey {
        case id, name, color
        case guildIds = "guild_ids"
    }

    var folderKey: String {
        if let id = id { return "folder_\(id)" }
        return "folder_\(guildIds.joined(separator: "_"))"
    }
}

struct DiscordUserSettings: Codable {
    let guildFolders: [GuildFolder]?
    let guildPositions: [String]?
    let status: String?

    enum CodingKeys: String, CodingKey {
        case status
        case guildFolders = "guild_folders"
        case guildPositions = "guild_positions"
    }
}

struct DiscordRole: Codable {
    let id: String
    let name: String
    let color: Int
    let permissions: String
    let position: Int
}

struct PermissionOverwrite: Codable {
    let id: String
    let type: Int
    let allow: String
    let deny: String
}

struct DiscordChannel: Codable {
    let id: String
    let type: Int
    var guildId: String?
    var name: String?
    var icon: String?
    var topic: String?
    var position: Int?
    var parentId: String?
    var lastMessageId: String?
    var recipients: [DiscordUser]?
    var recipientIds: [String]?
    var permissionOverwrites: [PermissionOverwrite]?

    enum CodingKeys: String, CodingKey {
        case id, type, name, icon, topic, position, recipients
        case guildId = "guild_id"
        case parentId = "parent_id"
        case lastMessageId = "last_message_id"
        case recipientIds = "recipient_ids"
        case permissionOverwrites = "permission_overwrites"
    }

    var lastMessageSnowflake: UInt64 {
        return UInt64(lastMessageId ?? "0") ?? 0
    }

    var resolvedRecipients: [DiscordUser] {
        if let recs = recipients, !recs.isEmpty { return recs }
        if let ids = recipientIds {
            return ids.compactMap { DiscordStore.shared.usersById[$0] }
        }
        return []
    }

    var displayName: String {
        if let name = name, !name.isEmpty { return name }
        let recs = resolvedRecipients
        if !recs.isEmpty {
            return recs.map { $0.effectiveDisplayName }.joined(separator: ", ")
        }
        return "Direct Message"
    }

    var isLockedForEveryone: Bool {
        guard let gid = guildId, let overwrites = permissionOverwrites else { return false }
        if let everyone = overwrites.first(where: { $0.id == gid }),
           let denyVal = UInt64(everyone.deny) {
            return (denyVal & (1 << 10)) != 0
        }
        return false
    }
}

struct DiscordAttachment: Codable {
    let id: String
    let filename: String
    let size: Int
    let url: String
    let proxyUrl: String?
    let width: Int?
    let height: Int?
    let contentType: String?

    enum CodingKeys: String, CodingKey {
        case id, filename, size, url, width, height
        case proxyUrl = "proxy_url"
        case contentType = "content_type"
    }

    var isImage: Bool {
        if let ct = contentType, ct.hasPrefix("image/") { return true }
        let lower = filename.lowercased()
        return lower.hasSuffix(".png") || lower.hasSuffix(".jpg") || lower.hasSuffix(".jpeg") || lower.hasSuffix(".gif") || lower.hasSuffix(".webp")
    }

    var isVideo: Bool {
        if let ct = contentType, ct.hasPrefix("video/") { return true }
        let lower = filename.lowercased()
        return lower.hasSuffix(".mp4") || lower.hasSuffix(".mov") || lower.hasSuffix(".webm") || lower.hasSuffix(".m4v")
    }

    var isGIF: Bool {
        let lower = filename.lowercased()
        return lower.hasSuffix(".gif") || contentType == "image/gif"
    }
}

struct EmbedMedia: Codable {
    let url: String?
    let proxyUrl: String?
    let width: Int?
    let height: Int?

    enum CodingKeys: String, CodingKey {
        case url, width, height
        case proxyUrl = "proxy_url"
    }
}

struct EmbedAuthor: Codable {
    let name: String?
    let url: String?
    let iconUrl: String?

    enum CodingKeys: String, CodingKey {
        case name, url
        case iconUrl = "icon_url"
    }
}

struct EmbedFooter: Codable {
    let text: String?
    let iconUrl: String?

    enum CodingKeys: String, CodingKey {
        case text
        case iconUrl = "icon_url"
    }
}

struct EmbedField: Codable {
    let name: String
    let value: String
    let inline: Bool?
}

struct DiscordEmbed: Codable {
    let title: String?
    let type: String?
    let description: String?
    let url: String?
    let color: Int?
    let author: EmbedAuthor?
    let footer: EmbedFooter?
    let image: EmbedMedia?
    let thumbnail: EmbedMedia?
    let video: EmbedMedia?
    let fields: [EmbedField]?
}

struct DiscordEmoji: Codable {
    let id: String?
    let name: String?
    let animated: Bool?

    var apiIdentifier: String {
        if let id = id, let name = name {
            return "\(name):\(id)"
        }
        return name ?? "👍"
    }

    var asDiscordTag: String {
        guard let id = id else { return name ?? "👍" }
        let prefix = (animated == true) ? "<a" : "<"
        return "\(prefix):\(name ?? "emoji"):\(id)>"
    }

    var displayText: String {
        return name ?? "👍"
    }

    var imageURL: String? {
        guard let id = id else { return nil }
        let ext = (animated == true) ? "gif" : "png"
        return "https://cdn.discordapp.com/emojis/\(id).\(ext)?size=64"
    }

    var staticPNGURL: String? {
        guard let id = id else { return nil }
        return "https://cdn.discordapp.com/emojis/\(id).png?size=64"
    }
}

struct DiscordReaction: Codable {
    var count: Int
    var me: Bool
    let emoji: DiscordEmoji
}

struct PollMedia: Codable {
    let text: String?
    let emoji: DiscordEmoji?
}

struct PollAnswer: Codable {
    let answerId: Int
    let pollMedia: PollMedia

    enum CodingKeys: String, CodingKey {
        case answerId = "answer_id"
        case pollMedia = "poll_media"
    }
}

struct PollAnswerCount: Codable {
    let id: Int
    let count: Int
    let meVoted: Bool?

    enum CodingKeys: String, CodingKey {
        case id, count
        case meVoted = "me_voted"
    }
}

struct PollResults: Codable {
    let isFinalized: Bool?
    let answerCounts: [PollAnswerCount]?

    enum CodingKeys: String, CodingKey {
        case isFinalized = "is_finalized"
        case answerCounts = "answer_counts"
    }
}

struct DiscordPoll: Codable {
    let question: PollMedia
    let answers: [PollAnswer]
    let expiry: String?
    let allowMultiselect: Bool?
    let results: PollResults?

    enum CodingKeys: String, CodingKey {
        case question, answers, expiry, results
        case allowMultiselect = "allow_multiselect"
    }
}

final class ReferencedMessageBox: Codable {
    let message: DiscordMessage?
    init(_ message: DiscordMessage?) { self.message = message }
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        self.message = try? container.decode(DiscordMessage.self)
    }
    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encode(message)
    }
}

struct DiscordMessage: Codable {
    let id: String
    let channelId: String
    let guildId: String?
    let author: DiscordUser
    var content: String
    let timestamp: String
    var editedTimestamp: String?
    var attachments: [DiscordAttachment]?
    var embeds: [DiscordEmbed]?
    var reactions: [DiscordReaction]?
    var poll: DiscordPoll?
    var referencedMessage: ReferencedMessageBox?

    enum CodingKeys: String, CodingKey {
        case id, author, content, timestamp, attachments, embeds, reactions, poll
        case channelId = "channel_id"
        case guildId = "guild_id"
        case editedTimestamp = "edited_timestamp"
        case referencedMessage = "referenced_message"
    }
}

struct GuildMember: Codable {
    let user: DiscordUser?
    let nick: String?
    let roles: [String]
}

struct DiscordRelationship: Codable {
    let id: String
    let type: Int
    let user: DiscordUser
}

struct VoiceState: Codable {
    let userId: String
    let channelId: String?
    let guildId: String?
    let sessionId: String?
    let selfMute: Bool?
    let selfDeaf: Bool?
    let mute: Bool?
    let deaf: Bool?

    enum CodingKeys: String, CodingKey {
        case userId = "user_id"
        case channelId = "channel_id"
        case guildId = "guild_id"
        case sessionId = "session_id"
        case selfMute = "self_mute"
        case selfDeaf = "self_deaf"
        case mute, deaf
    }
}

struct VoiceServerUpdate: Codable {
    let token: String
    let guildId: String?
    let channelId: String?
    let endpoint: String?

    enum CodingKeys: String, CodingKey {
        case token, endpoint
        case guildId = "guild_id"
        case channelId = "channel_id"
    }
}

struct DiscordGifItem: Codable, Equatable {
    let id: String
    let title: String?
    let url: String
    let gifSrc: String?
    let preview: String?
    let width: Int?
    let height: Int?

    enum CodingKeys: String, CodingKey {
        case id, title, url, preview, width, height
        case gifSrc = "gif_src"
    }

    var effectiveGifURL: String {
        return gifSrc ?? url
    }
}
