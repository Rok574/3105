import Foundation
import AVFoundation
import Network

extension Notification.Name {
    static let cordVoiceStateDidChange = Notification.Name("cordVoiceStateDidChange")
    static let cordVoiceSpeakingDidChange = Notification.Name("cordVoiceSpeakingDidChange")
}

/// Discord Voice Gateway v8 client for iOS 12+ using RFC6455WebSocket, NWConnection UDP,
/// AES-256-GCM (`aead_aes256_gcm_rtpsize`), DAVE MLS E2EE (`libdave`), AVAudioEngine (48kHz), and `libopus`.
final class DiscordVoiceClient: RFC6455WebSocketDelegate {
    static let shared = DiscordVoiceClient()

    enum ConnectionPhase: String {
        case disconnected = "Disconnected"
        case connecting = "Connecting..."
        case signaling = "Voice Signaling (v8)..."
        case discoveringIP = "Discovering UDP..."
        case connected = "Voice Connected"
    }

    private(set) var phase: ConnectionPhase = .disconnected
    private(set) var guildId: String?
    private(set) var channelId: String?
    private(set) var channelName: String = ""
    private(set) var isMuted: Bool = false
    private(set) var isDeafened: Bool = false
    private(set) var isSpeakerOn: Bool = true
    private(set) var speakingUserIds: Set<String> = []
    private(set) var localExternalIP: String?
    private(set) var localExternalPort: UInt16?
    private(set) var daveProtocolVersion: Int = 0

    private var socket: RFC6455WebSocket?
    private var udpConnection: NWConnection?
    private var heartbeatTimer: Timer?
    private var seqAck: Int = -1
    private var serverId: String = ""
    private var userId: String = ""
    private var sessionId: String = ""
    private var voiceToken: String = ""
    private var ssrc: UInt32 = 0
    private var remoteHost: String = ""
    private var remotePort: UInt16 = 0
    private var selectedMode: String = "aead_aes256_gcm_rtpsize"
    private var secretKey: [UInt8] = []

    // DAVE MLS state
    private var daveSession: UnsafeMutableRawPointer?
    private var daveEncryptor: UnsafeMutableRawPointer?
    private var daveDecryptorsByUser: [String: UnsafeMutableRawPointer] = [:]
    private var recognizedUserIds: Set<String> = []
    private var ssrcToUserId: [UInt32: String] = [:]
    private var pendingTransitions: [Int: Int] = [:]

    // RTP & Audio Engine
    private let audioQueue = DispatchQueue(label: "com.rok574.cord12.voiceaudio", qos: .userInteractive)
    private var audioEngine: AVAudioEngine?
    private var playerNode: AVAudioPlayerNode?
    private var playbackFormat: AVAudioFormat?
    private var opusEncoder: UnsafeMutableRawPointer?
    private var opusDecoder: UnsafeMutableRawPointer?
    private var rtpSequence: UInt16 = 0
    private var rtpTimestamp: UInt32 = 0
    private var txNonceCounter: UInt32 = 1
    private var pcmAccumulator: [Int16] = []

    private init() {}

    func beginJoining(guildId: String?, channelId: String, channelName: String, userId: String) {
        disconnect(notifyGateway: false)
        self.guildId = guildId
        self.channelId = channelId
        self.channelName = channelName
        self.userId = userId
        self.seqAck = -1
        self.recognizedUserIds = [userId]
        self.phase = .connecting
        configureAudioSession()
        NotificationCenter.default.post(name: .cordVoiceStateDidChange, object: nil)
    }

    func updateSessionId(_ sid: String) {
        self.sessionId = sid
        tryConnectVoiceGatewayIfReady()
    }

    func updateVoiceServer(endpoint: String, token: String, serverId: String) {
        self.voiceToken = token
        self.serverId = serverId
        let cleanHost = endpoint.replacingOccurrences(of: ":80", with: "").replacingOccurrences(of: ":443", with: "")
        self.remoteHost = cleanHost
        tryConnectVoiceGatewayIfReady()
    }

    private func tryConnectVoiceGatewayIfReady() {
        guard !sessionId.isEmpty, !voiceToken.isEmpty, !remoteHost.isEmpty, socket == nil else { return }
        guard let url = URL(string: "wss://\(remoteHost)/?v=8") else { return }
        phase = .signaling
        NotificationCenter.default.post(name: .cordVoiceStateDidChange, object: nil)

        if cord_dave_is_available() {
            daveSession = cord_dave_session_create(sessionId)
            daveEncryptor = cord_dave_encryptor_create()
            cord_dave_encryptor_set_passthrough(daveEncryptor, true)
        }

        let ws = RFC6455WebSocket(url: url, headers: [
            "Origin": "https://discord.com",
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 12_5_8 like Mac OS X) AppleWebKit/605.1.15"
        ])
        ws.delegate = self
        self.socket = ws
        ws.connect()
    }

    func setMuted(_ muted: Bool) {
        self.isMuted = muted
        sendSpeaking(speaking: !muted && !isDeafened)
        NotificationCenter.default.post(name: .cordVoiceStateDidChange, object: nil)
    }

    func setDeafened(_ deafened: Bool) {
        self.isDeafened = deafened
        if deafened { self.isMuted = true }
        sendSpeaking(speaking: !isMuted && !isDeafened)
        NotificationCenter.default.post(name: .cordVoiceStateDidChange, object: nil)
    }

    func setSpeakerphone(_ enabled: Bool) {
        self.isSpeakerOn = enabled
        let session = AVAudioSession.sharedInstance()
        try? session.overrideOutputAudioPort(enabled ? .speaker : .none)
        NotificationCenter.default.post(name: .cordVoiceStateDidChange, object: nil)
    }

    func disconnect(notifyGateway: Bool = true) {
        heartbeatTimer?.invalidate()
        heartbeatTimer = nil
        stopAudioPipeline()
        udpConnection?.cancel()
        udpConnection = nil
        socket?.delegate = nil
        socket?.close()
        socket = nil

        if let enc = daveEncryptor { cord_dave_encryptor_destroy(enc); daveEncryptor = nil }
        for (_, dec) in daveDecryptorsByUser { cord_dave_decryptor_destroy(dec) }
        daveDecryptorsByUser.removeAll()
        if let sess = daveSession { cord_dave_session_destroy(sess); daveSession = nil }

        daveProtocolVersion = 0
        recognizedUserIds.removeAll()
        ssrcToUserId.removeAll()
        pendingTransitions.removeAll()
        sessionId = ""
        voiceToken = ""
        remoteHost = ""
        secretKey = []
        speakingUserIds.removeAll()
        phase = .disconnected
        channelId = nil
        guildId = nil
        channelName = ""
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        NotificationCenter.default.post(name: .cordVoiceStateDidChange, object: nil)
        _ = notifyGateway
    }

    private func configureAudioSession() {
        let session = AVAudioSession.sharedInstance()
        session.requestRecordPermission { _ in }
        try? session.setCategory(.playAndRecord, mode: .voiceChat, options: [.allowBluetooth, .defaultToSpeaker])
        try? session.setPreferredSampleRate(48000)
        try? session.setPreferredIOBufferDuration(0.02)
        try? session.setActive(true)
        if isSpeakerOn {
            try? session.overrideOutputAudioPort(.speaker)
        }
    }

    // MARK: - RFC6455WebSocketDelegate

    func webSocketDidConnect(_ socket: RFC6455WebSocket) {
        guard socket === self.socket else { return }
        let identify: [String: Any] = [
            "op": 0,
            "d": [
                "server_id": serverId,
                "user_id": userId,
                "session_id": sessionId,
                "token": voiceToken,
                "max_dave_protocol_version": Int(cord_dave_max_version())
            ]
        ]
        sendJSON(identify)
    }

    func webSocket(_ socket: RFC6455WebSocket, didDisconnectWithCode code: Int, reason: String?) {
        guard socket === self.socket else { return }
        heartbeatTimer?.invalidate()
        heartbeatTimer = nil
        stopAudioPipeline()
        if phase != .disconnected {
            phase = .disconnected
            NotificationCenter.default.post(name: .cordVoiceStateDidChange, object: nil)
        }
    }

    func webSocket(_ socket: RFC6455WebSocket, didReceiveText text: String) {
        guard socket === self.socket,
              let data = text.data(using: .utf8),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let op = json["op"] as? Int else { return }

        if let seq = json["seq"] as? Int {
            self.seqAck = seq
        }
        let d = json["d"] as? [String: Any]

        switch op {
        case 8: // Hello
            if let intervalMs = d?["heartbeat_interval"] as? Double {
                startHeartbeat(interval: intervalMs / 1000.0)
            }

        case 2: // Ready
            if let ssrc = d?["ssrc"] as? UInt32,
               let ip = d?["ip"] as? String,
               let port = d?["port"] as? Int {
                self.ssrc = ssrc
                self.remoteHost = ip
                self.remotePort = UInt16(port)
                if let enc = daveEncryptor {
                    cord_dave_encryptor_assign_opus(enc, ssrc)
                }
                if let modes = d?["modes"] as? [String] {
                    self.selectedMode = modes.first(where: { $0 == "aead_aes256_gcm_rtpsize" }) ?? modes.first ?? "aead_aes256_gcm_rtpsize"
                }
                performUDPDiscovery(host: ip, port: UInt16(port), ssrc: ssrc)
            }

        case 4: // Session Description
            if let key = d?["secret_key"] as? [Int] {
                self.secretKey = key.map { UInt8(clamping: $0) }
                if let m = d?["mode"] as? String { self.selectedMode = m }
                let daveVer = (d?["dave_protocol_version"] as? Int) ?? 0
                handleDaveProtocolInit(version: daveVer)
                phase = .connected
                NotificationCenter.default.post(name: .cordVoiceStateDidChange, object: nil)
                startAudioPipeline()
                sendSpeaking(speaking: !isMuted && !isDeafened)
            }

        case 5: // Speaking
            if let uid = d?["user_id"] as? String {
                recognizedUserIds.insert(uid)
                if let spkSsrc = d?["ssrc"] as? UInt32 {
                    ssrcToUserId[spkSsrc] = uid
                }
                let speakingInt = (d?["speaking"] as? Int) ?? 0
                if speakingInt > 0 {
                    speakingUserIds.insert(uid)
                } else {
                    speakingUserIds.remove(uid)
                }
                NotificationCenter.default.post(name: .cordVoiceSpeakingDidChange, object: uid)
            }

        case 11: // Clients Connect
            if let uids = d?["user_ids"] as? [String] {
                for uid in uids { recognizedUserIds.insert(uid) }
            }

        case 13: // Client Disconnect
            if let uid = d?["user_id"] as? String {
                recognizedUserIds.remove(uid)
                if let dec = daveDecryptorsByUser.removeValue(forKey: uid) {
                    cord_dave_decryptor_destroy(dec)
                }
            }

        case 21: // DAVE Prepare Transition
            if let tid = d?["transition_id"] as? Int,
               let ver = d?["protocol_version"] as? Int {
                pendingTransitions[tid] = ver
                prepareDaveRatchets(version: ver)
                sendJSON(["op": 23, "d": ["transition_id": tid]])
            }

        case 22: // DAVE Execute Transition
            if let tid = d?["transition_id"] as? Int,
               let ver = pendingTransitions.removeValue(forKey: tid) {
                executeDaveTransition(version: ver)
            }

        case 24: // DAVE Prepare Epoch
            if let epoch = d?["epoch"] as? Int,
               let ver = d?["protocol_version"] as? Int,
               epoch == 1 {
                handleDaveProtocolInit(version: ver)
            }

        default:
            break
        }
    }

    func webSocket(_ socket: RFC6455WebSocket, didReceiveData data: Data) {
        guard socket === self.socket, data.count >= 3 else { return }
        let seq = Int(UInt16(data[0]) << 8 | UInt16(data[1]))
        self.seqAck = seq
        let op = data[2]
        let payload = data.subdata(in: 3..<data.count)

        switch op {
        case 25: // External Sender Package
            if let sess = daveSession {
                payload.withUnsafeBytes { ptr in
                    guard let base = ptr.bindMemory(to: UInt8.self).baseAddress else { return }
                    cord_dave_session_set_external_sender(sess, base, payload.count)
                }
            }

        case 27: // MLS Proposals
            guard let sess = daveSession else { return }
            let uids = Array(recognizedUserIds)
            withCStringArray(uids) { cUids, count in
                payload.withUnsafeBytes { ptr in
                    guard let base = ptr.bindMemory(to: UInt8.self).baseAddress else { return }
                    var outLen: Int = 0
                    if let cw = cord_dave_session_process_proposals(sess, base, payload.count, cUids, count, &outLen), outLen > 0 {
                        var frame = Data([28])
                        frame.append(cw, count: outLen)
                        cord_dave_free(cw)
                        socket.send(data: frame)
                    }
                }
            }

        case 29: // Announce Commit Transition
            guard payload.count >= 2, let sess = daveSession else { return }
            let tid = Int(UInt16(payload[0]) << 8 | UInt16(payload[1]))
            let commitData = payload.subdata(in: 2..<payload.count)
            let rc = commitData.withUnsafeBytes { ptr -> Int32 in
                guard let base = ptr.bindMemory(to: UInt8.self).baseAddress else { return -1 }
                return cord_dave_session_process_commit(sess, base, commitData.count)
            }
            if rc >= 0 {
                pendingTransitions[tid] = max(1, daveProtocolVersion)
                prepareDaveRatchets(version: max(1, daveProtocolVersion))
                sendJSON(["op": 23, "d": ["transition_id": tid]])
            } else {
                sendJSON(["op": 31, "d": ["transition_id": tid]])
                cord_dave_session_reset(sess)
                sendMLSKeyPackage()
            }

        case 30: // MLS Welcome
            guard payload.count >= 2, let sess = daveSession else { return }
            let tid = Int(UInt16(payload[0]) << 8 | UInt16(payload[1]))
            let welcomeData = payload.subdata(in: 2..<payload.count)
            let uids = Array(recognizedUserIds)
            let ok = withCStringArray(uids) { cUids, count -> Bool in
                welcomeData.withUnsafeBytes { ptr in
                    guard let base = ptr.bindMemory(to: UInt8.self).baseAddress else { return false }
                    return cord_dave_session_process_welcome(sess, base, welcomeData.count, cUids, count)
                }
            }
            if ok {
                pendingTransitions[tid] = max(1, daveProtocolVersion)
                prepareDaveRatchets(version: max(1, daveProtocolVersion))
                sendJSON(["op": 23, "d": ["transition_id": tid]])
            } else {
                sendJSON(["op": 31, "d": ["transition_id": tid]])
                cord_dave_session_reset(sess)
                sendMLSKeyPackage()
            }

        default:
            break
        }
    }

    // MARK: - DAVE Helpers

    private func handleDaveProtocolInit(version: Int) {
        daveProtocolVersion = version
        guard version > 0, let sess = daveSession, let gid = UInt64(channelId ?? serverId) else {
            cord_dave_encryptor_set_passthrough(daveEncryptor, true)
            return
        }
        userId.withCString { cUid in
            cord_dave_session_init(sess, UInt16(version), gid, cUid)
        }
        sendMLSKeyPackage()
    }

    private func sendMLSKeyPackage() {
        guard let sess = daveSession else { return }
        var len: Int = 0
        guard let kp = cord_dave_session_get_key_package(sess, &len), len > 0 else { return }
        var frame = Data([26])
        frame.append(kp, count: len)
        cord_dave_free(kp)
        socket?.send(data: frame)
    }

    private func prepareDaveRatchets(version: Int) {
        guard let sess = daveSession else { return }
        if version > 0 {
            if let enc = daveEncryptor {
                userId.withCString { cUid in
                    cord_dave_encryptor_set_key_ratchet(enc, sess, cUid)
                }
            }
            for uid in recognizedUserIds where uid != userId {
                let dec = daveDecryptorsByUser[uid] ?? {
                    let d = cord_dave_decryptor_create()
                    if let d = d { daveDecryptorsByUser[uid] = d }
                    return d
                }()
                if let dec = dec {
                    uid.withCString { cUid in
                        cord_dave_decryptor_transition_key_ratchet(dec, sess, cUid)
                    }
                }
            }
        }
    }

    private func executeDaveTransition(version: Int) {
        daveProtocolVersion = version
        let passthrough = (version == 0)
        cord_dave_encryptor_set_passthrough(daveEncryptor, passthrough)
        for (_, dec) in daveDecryptorsByUser {
            cord_dave_decryptor_set_passthrough(dec, passthrough)
        }
    }

    private func withCStringArray<R>(_ strings: [String], body: (UnsafeMutablePointer<UnsafePointer<Int8>?>?, Int) -> R) -> R {
        let cStrings = strings.map { strdup($0) }
        defer { cStrings.forEach { free($0) } }
        var ptrs = cStrings.map { UnsafePointer($0) }
        return ptrs.withUnsafeMutableBufferPointer { buf in
            body(buf.baseAddress, buf.count)
        }
    }

    // MARK: - UDP Discovery & Audio Pipeline

    private func performUDPDiscovery(host: String, port: UInt16, ssrc: UInt32) {
        phase = .discoveringIP
        NotificationCenter.default.post(name: .cordVoiceStateDidChange, object: nil)

        guard let nwPort = NWEndpoint.Port(rawValue: port) else { return }
        let conn = NWConnection(host: NWEndpoint.Host(host), port: nwPort, using: .udp)
        self.udpConnection = conn
        conn.stateUpdateHandler = { [weak self] state in
            guard let self = self else { return }
            if case .ready = state {
                var packet = Data(count: 74)
                packet[0] = 0x00; packet[1] = 0x01 // Request
                packet[2] = 0x00; packet[3] = 0x46 // Length 70
                var bigSSRC = ssrc.bigEndian
                withUnsafeBytes(of: &bigSSRC) { buf in
                    packet.replaceSubrange(4..<8, with: buf)
                }
                conn.send(content: packet, completion: .contentProcessed { _ in })
                conn.receiveMessage { data, _, _, _ in
                    guard let data = data, data.count >= 74 else { return }
                    let ipData = data.subdata(in: 8..<72)
                    let ipStr = String(data: ipData, encoding: .ascii)?.trimmingCharacters(in: CharacterSet(charactersIn: "\0")) ?? ""
                    let portVal = (UInt16(data[72]) << 8) | UInt16(data[73])
                    DispatchQueue.main.async {
                        self.localExternalIP = ipStr
                        self.localExternalPort = portVal
                        self.sendSelectProtocol(ip: ipStr, port: portVal)
                    }
                }
            }
        }
        conn.start(queue: audioQueue)
    }

    private func startAudioPipeline() {
        guard cord_opus_is_available(), secretKey.count == 32 else { return }
        audioQueue.async { [weak self] in
            guard let self = self else { return }
            self.opusEncoder = cord_opus_encoder_create(48000, 2)
            self.opusDecoder = cord_opus_decoder_create(48000, 2)
            self.pcmAccumulator.removeAll()
            self.txNonceCounter = 1

            let engine = AVAudioEngine()
            let player = AVAudioPlayerNode()
            let format = AVAudioFormat(commonFormat: .pcmFormatInt16, sampleRate: 48000, channels: 2, interleaved: true)!
            self.playbackFormat = format

            engine.attach(player)
            engine.connect(player, to: engine.mainMixerNode, format: format)

            let input = engine.inputNode
            let inputFormat = input.outputFormat(forBus: 0)
            let converter = AVAudioConverter(from: inputFormat, to: format)

            input.installTap(onBus: 0, bufferSize: 960, format: inputFormat) { [weak self] buffer, _ in
                guard let self = self, !self.isMuted, !self.isDeafened else { return }
                self.processCapturedAudio(buffer: buffer, converter: converter, targetFormat: format)
            }

            try? engine.start()
            player.play()
            self.audioEngine = engine
            self.playerNode = player
            self.startReceivingUDP()
        }
    }

    private func stopAudioPipeline() {
        audioQueue.async { [weak self] in
            guard let self = self else { return }
            self.audioEngine?.inputNode.removeTap(onBus: 0)
            self.playerNode?.stop()
            self.audioEngine?.stop()
            self.audioEngine = nil
            self.playerNode = nil
            if let enc = self.opusEncoder { cord_opus_encoder_destroy(enc); self.opusEncoder = nil }
            if let dec = self.opusDecoder { cord_opus_decoder_destroy(dec); self.opusDecoder = nil }
            self.pcmAccumulator.removeAll()
        }
    }

    private func processCapturedAudio(buffer: AVAudioPCMBuffer, converter: AVAudioConverter?, targetFormat: AVAudioFormat) {
        guard let converter = converter, let enc = opusEncoder else { return }
        let ratio = targetFormat.sampleRate / buffer.format.sampleRate
        let outCap = AVAudioFrameCount(Double(buffer.frameLength) * ratio) + 64
        guard let outBuf = AVAudioPCMBuffer(pcmFormat: targetFormat, frameCapacity: outCap) else { return }

        var err: NSError?
        var consumed = false
        converter.convert(to: outBuf, error: &err) { _, outStatus in
            if consumed {
                outStatus.pointee = .noDataNow
                return nil
            }
            consumed = true
            outStatus.pointee = .haveData
            return buffer
        }

        guard let int16Ptr = outBuf.int16ChannelData?[0] else { return }
        let sampleCount = Int(outBuf.frameLength) * 2
        pcmAccumulator.append(contentsOf: UnsafeBufferPointer(start: int16Ptr, count: sampleCount))

        let frameSamples = 960 * 2
        while pcmAccumulator.count >= frameSamples {
            let frame = Array(pcmAccumulator.prefix(frameSamples))
            pcmAccumulator.removeFirst(frameSamples)

            var opusOut = [UInt8](repeating: 0, count: 1275)
            let encodedLen = frame.withUnsafeBufferPointer { pcmPtr -> Int32 in
                return cord_opus_encode(enc, pcmPtr.baseAddress, 960, &opusOut, 1275)
            }
            if encodedLen > 0 {
                var payload = Array(opusOut.prefix(Int(encodedLen)))
                if daveProtocolVersion > 0, let dEnc = daveEncryptor {
                    var daveOut = [UInt8](repeating: 0, count: payload.count + 128)
                    let written = payload.withUnsafeBufferPointer { inPtr in
                        return cord_dave_encrypt_audio(dEnc, ssrc, inPtr.baseAddress, payload.count, &daveOut, daveOut.count)
                    }
                    if written > 0 {
                        payload = Array(daveOut.prefix(Int(written)))
                    }
                }
                sendEncryptedRTP(opusFrame: payload)
            }
        }
    }

    private func sendEncryptedRTP(opusFrame: [UInt8]) {
        guard let conn = udpConnection, secretKey.count == 32 else { return }
        rtpSequence &+= 1
        rtpTimestamp &+= 960
        txNonceCounter &+= 1

        var rtpHeader = [UInt8](repeating: 0, count: 12)
        rtpHeader[0] = 0x80
        rtpHeader[1] = 0x78
        rtpHeader[2] = UInt8((rtpSequence >> 8) & 0xFF)
        rtpHeader[3] = UInt8(rtpSequence & 0xFF)
        rtpHeader[4] = UInt8((rtpTimestamp >> 24) & 0xFF)
        rtpHeader[5] = UInt8((rtpTimestamp >> 16) & 0xFF)
        rtpHeader[6] = UInt8((rtpTimestamp >> 8) & 0xFF)
        rtpHeader[7] = UInt8(rtpTimestamp & 0xFF)
        rtpHeader[8] = UInt8((ssrc >> 24) & 0xFF)
        rtpHeader[9] = UInt8((ssrc >> 16) & 0xFF)
        rtpHeader[10] = UInt8((ssrc >> 8) & 0xFF)
        rtpHeader[11] = UInt8(ssrc & 0xFF)

        var nonce12 = [UInt8](repeating: 0, count: 12)
        nonce12[0] = UInt8(txNonceCounter & 0xFF)
        nonce12[1] = UInt8((txNonceCounter >> 8) & 0xFF)
        nonce12[2] = UInt8((txNonceCounter >> 16) & 0xFF)
        nonce12[3] = UInt8((txNonceCounter >> 24) & 0xFF)

        guard let sealed = AES256GCM.seal(key: secretKey, nonce12: nonce12, plaintext: opusFrame, aad: rtpHeader) else { return }
        var packet = Data(rtpHeader)
        packet.append(contentsOf: sealed.ciphertext)
        packet.append(contentsOf: sealed.tag)
        packet.append(contentsOf: nonce12.prefix(4))
        conn.send(content: packet, completion: .contentProcessed { _ in })
    }

    private func startReceivingUDP() {
        udpConnection?.receiveMessage { [weak self] data, _, _, error in
            guard let self = self, error == nil else { return }
            if let data = data {
                self.handleIncomingUDP(data)
            }
            if self.phase == .connected {
                self.startReceivingUDP()
            }
        }
    }

    private func handleIncomingUDP(_ data: Data) {
        guard !isDeafened, data.count > 32, let dec = opusDecoder, secretKey.count == 32 else { return }
        let bytes = [UInt8](data)
        let payloadType = bytes[1] & 0x7F
        guard payloadType == 120 else { return }

        let senderSSRC = (UInt32(bytes[8]) << 24) | (UInt32(bytes[9]) << 16) | (UInt32(bytes[10]) << 8) | UInt32(bytes[11])
        let cc = Int(bytes[0] & 0x0F)
        let hasExt = (bytes[0] & 0x10) != 0
        var headerLen = 12 + cc * 4
        if hasExt && bytes.count >= headerLen + 4 {
            headerLen += 4
        }
        guard bytes.count > headerLen + 20 else { return }

        let aad = Array(bytes[0..<headerLen])
        let nonce4 = Array(bytes[(bytes.count - 4)..<bytes.count])
        let nonce12 = nonce4 + [UInt8](repeating: 0, count: 8)
        let tag = Array(bytes[(bytes.count - 20)..<(bytes.count - 4)])
        let ciphertext = Array(bytes[headerLen..<(bytes.count - 20)])

        guard var plain = AES256GCM.open(key: secretKey, nonce12: nonce12, ciphertext: ciphertext, tag: tag, aad: aad) else { return }
        if hasExt && bytes.count >= 12 + cc * 4 + 4 {
            let extWords = (Int(bytes[12 + cc * 4 + 2]) << 8) | Int(bytes[12 + cc * 4 + 3])
            let extBytes = extWords * 4
            if plain.count > extBytes { plain.removeFirst(extBytes) }
        }

        // DAVE frame decryption (skip 3-byte SFU silence packet 0xF8 0xFF 0xFE)
        let isSilence = (plain.count == 3 && plain[0] == 0xF8 && plain[1] == 0xFF && plain[2] == 0xFE)
        if daveProtocolVersion > 0, !isSilence,
           let uid = ssrcToUserId[senderSSRC],
           let dDec = daveDecryptorsByUser[uid] {
            var davePlain = [UInt8](repeating: 0, count: plain.count + 64)
            let written = plain.withUnsafeBufferPointer { inPtr in
                return cord_dave_decrypt_audio(dDec, inPtr.baseAddress, plain.count, &davePlain, davePlain.count)
            }
            if written > 0 {
                plain = Array(davePlain.prefix(Int(written)))
            }
        }

        var pcmOut = [Int16](repeating: 0, count: 960 * 2)
        let decodedSamples = plain.withUnsafeBufferPointer { ptr -> Int32 in
            return cord_opus_decode(dec, ptr.baseAddress, Int32(plain.count), &pcmOut, 960)
        }
        guard decodedSamples > 0, let fmt = playbackFormat, let player = playerNode else { return }
        guard let buf = AVAudioPCMBuffer(pcmFormat: fmt, frameCapacity: AVAudioFrameCount(decodedSamples)) else { return }
        buf.frameLength = AVAudioFrameCount(decodedSamples)
        if let dst = buf.int16ChannelData?[0] {
            pcmOut.withUnsafeBufferPointer { src in
                dst.update(from: src.baseAddress!, count: Int(decodedSamples) * 2)
            }
            player.scheduleBuffer(buf, completionHandler: nil)
        }
    }

    private func sendSelectProtocol(ip: String, port: UInt16) {
        let payload: [String: Any] = [
            "op": 1,
            "d": [
                "protocol": "udp",
                "data": [
                    "address": ip,
                    "port": Int(port),
                    "mode": selectedMode
                ]
            ]
        ]
        sendJSON(payload)
    }

    private func sendSpeaking(speaking: Bool) {
        let payload: [String: Any] = [
            "op": 5,
            "d": [
                "speaking": speaking ? 1 : 0,
                "delay": 0,
                "ssrc": ssrc
            ]
        ]
        sendJSON(payload)
    }

    private func startHeartbeat(interval: TimeInterval) {
        heartbeatTimer?.invalidate()
        let timer = Timer(timeInterval: interval, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            self.sendJSON([
                "op": 3,
                "d": [
                    "t": Int(Date().timeIntervalSince1970 * 1000),
                    "seq_ack": self.seqAck
                ]
            ])
        }
        RunLoop.main.add(timer, forMode: .common)
        heartbeatTimer = timer
    }

    private func sendJSON(_ dict: [String: Any]) {
        guard let data = try? JSONSerialization.data(withJSONObject: dict),
              let str = String(data: data, encoding: .utf8) else { return }
        socket?.send(text: str)
    }
}
