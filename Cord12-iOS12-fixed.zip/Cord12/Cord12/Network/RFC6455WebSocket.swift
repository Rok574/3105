import Foundation
import Network
import CommonCrypto

protocol RFC6455WebSocketDelegate: AnyObject {
    func webSocketDidConnect(_ socket: RFC6455WebSocket)
    func webSocket(_ socket: RFC6455WebSocket, didReceiveText text: String)
    func webSocket(_ socket: RFC6455WebSocket, didReceiveData data: Data)
    func webSocket(_ socket: RFC6455WebSocket, didDisconnectWithCode code: Int, reason: String?)
}

extension RFC6455WebSocketDelegate {
    func webSocket(_ socket: RFC6455WebSocket, didReceiveData data: Data) {}
}

/// Pure Swift RFC 6455 WebSocket built on Network.framework (iOS 12.0+),
/// because URLSessionWebSocketTask requires iOS 13+.
final class RFC6455WebSocket {
    weak var delegate: RFC6455WebSocketDelegate?

    private let url: URL
    private let headers: [String: String]
    private var connection: NWConnection?
    private let queue = DispatchQueue(label: "com.rok574.cord12.ws", qos: .userInitiated)
    private var buffer = Data()
    private var didUpgrade = false
    private var isClosed = false

    private var fragmentedOpcode: UInt8 = 0
    private var fragmentedData = Data()

    init(url: URL, headers: [String: String] = [:]) {
        self.url = url
        self.headers = headers
    }

    func connect() {
        guard let host = url.host else { return }
        let isTLS = (url.scheme == "wss" || url.scheme == "https")
        let portValue = UInt16(url.port ?? (isTLS ? 443 : 80))
        guard let port = NWEndpoint.Port(rawValue: portValue) else { return }

        let params: NWParameters = isTLS ? .tls : .tcp
        let conn = NWConnection(host: NWEndpoint.Host(host), port: port, using: params)
        self.connection = conn

        conn.stateUpdateHandler = { [weak self] state in
            guard let self = self else { return }
            switch state {
            case .ready:
                self.sendHandshake()
                self.receiveLoop()
            case .failed(let err):
                self.finish(code: 1006, reason: err.localizedDescription)
            case .cancelled:
                self.finish(code: 1000, reason: "Cancelled")
            default:
                break
            }
        }
        conn.start(queue: queue)
    }

    func send(text: String) {
        guard let data = text.data(using: .utf8) else { return }
        sendFrame(opcode: 0x01, payload: data)
    }

    func send(data: Data) {
        sendFrame(opcode: 0x02, payload: data)
    }

    func close(code: UInt16 = 1000) {
        var payload = Data()
        var be = code.bigEndian
        payload.append(Data(bytes: &be, count: 2))
        sendFrame(opcode: 0x08, payload: payload)
        finish(code: Int(code), reason: nil)
    }

    private func sendHandshake() {
        let hostHeader = url.port != nil ? "\(url.host ?? ""):\(url.port!)" : (url.host ?? "")
        var path = url.path.isEmpty ? "/" : url.path
        if let query = url.query, !query.isEmpty {
            path += "?\(query)"
        }

        var randomBytes = [UInt8](repeating: 0, count: 16)
        _ = SecRandomCopyBytes(kSecRandomDefault, 16, &randomBytes)
        let secKey = Data(randomBytes).base64EncodedString()

        var req = "GET \(path) HTTP/1.1\r\n"
        req += "Host: \(hostHeader)\r\n"
        req += "Upgrade: websocket\r\n"
        req += "Connection: Upgrade\r\n"
        req += "Sec-WebSocket-Key: \(secKey)\r\n"
        req += "Sec-WebSocket-Version: 13\r\n"
        for (k, v) in headers {
            req += "\(k): \(v)\r\n"
        }
        req += "\r\n"

        guard let data = req.data(using: .utf8) else { return }
        connection?.send(content: data, completion: .contentProcessed { _ in })
    }

    private func receiveLoop() {
        connection?.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] data, _, isComplete, error in
            guard let self = self else { return }
            if let data = data, !data.isEmpty {
                self.buffer.append(data)
                self.processBuffer()
            }
            if isComplete || error != nil {
                self.finish(code: 1006, reason: error?.localizedDescription)
                return
            }
            if !self.isClosed {
                self.receiveLoop()
            }
        }
    }

    private func processBuffer() {
        if !didUpgrade {
            let delimiter = Data([0x0D, 0x0A, 0x0D, 0x0A])
            guard let range = buffer.range(of: delimiter) else { return }
            let headerData = buffer.subdata(in: 0..<range.lowerBound)
            buffer.removeSubrange(0..<range.upperBound)
            let headerStr = String(data: headerData, encoding: .utf8) ?? ""
            guard headerStr.contains("101") else {
                finish(code: 1002, reason: "WebSocket HTTP upgrade failed")
                return
            }
            didUpgrade = true
            DispatchQueue.main.async {
                self.delegate?.webSocketDidConnect(self)
            }
        }

        while parseNextFrame() {}
    }

    private func parseNextFrame() -> Bool {
        guard buffer.count >= 2 else { return false }
        let b0 = buffer[0]
        let b1 = buffer[1]
        let fin = (b0 & 0x80) != 0
        let opcode = b0 & 0x0F
        let masked = (b1 & 0x80) != 0
        var payloadLen = UInt64(b1 & 0x7F)
        var offset = 2

        if payloadLen == 126 {
            guard buffer.count >= offset + 2 else { return false }
            payloadLen = UInt64(buffer[offset]) << 8 | UInt64(buffer[offset + 1])
            offset += 2
        } else if payloadLen == 127 {
            guard buffer.count >= offset + 8 else { return false }
            payloadLen = 0
            for i in 0..<8 {
                payloadLen = (payloadLen << 8) | UInt64(buffer[offset + i])
            }
            offset += 8
        }

        var maskKey: [UInt8] = []
        if masked {
            guard buffer.count >= offset + 4 else { return false }
            maskKey = Array(buffer[offset..<(offset + 4)])
            offset += 4
        }

        guard payloadLen <= 64 * 1024 * 1024 else {
            finish(code: 1009, reason: "Frame too large")
            return false
        }

        let intLen = Int(payloadLen)
        guard buffer.count >= offset + intLen else { return false }

        var payload = buffer.subdata(in: offset..<(offset + intLen))
        buffer.removeSubrange(0..<(offset + intLen))

        if masked {
            payload.withUnsafeMutableBytes { ptr in
                guard let base = ptr.bindMemory(to: UInt8.self).baseAddress else { return }
                for i in 0..<intLen {
                    base[i] ^= maskKey[i % 4]
                }
            }
        }

        handleFrame(fin: fin, opcode: opcode, payload: payload)
        return true
    }

    private func handleFrame(fin: Bool, opcode: UInt8, payload: Data) {
        switch opcode {
        case 0x00: // Continuation
            fragmentedData.append(payload)
            if fin {
                let complete = fragmentedData
                let orig = fragmentedOpcode
                fragmentedData.removeAll(keepingCapacity: false)
                if orig == 0x01, let text = String(data: complete, encoding: .utf8) {
                    DispatchQueue.main.async { self.delegate?.webSocket(self, didReceiveText: text) }
                } else if orig == 0x02 {
                    DispatchQueue.main.async { self.delegate?.webSocket(self, didReceiveData: complete) }
                }
            }
        case 0x01: // Text
            if fin {
                if let text = String(data: payload, encoding: .utf8) {
                    DispatchQueue.main.async { self.delegate?.webSocket(self, didReceiveText: text) }
                }
            } else {
                fragmentedOpcode = 0x01
                fragmentedData = payload
            }
        case 0x02: // Binary
            if fin {
                DispatchQueue.main.async { self.delegate?.webSocket(self, didReceiveData: payload) }
            } else {
                fragmentedOpcode = 0x02
                fragmentedData = payload
            }
        case 0x08: // Close
            var code = 1000
            var reason: String?
            if payload.count >= 2 {
                code = Int(UInt16(payload[0]) << 8 | UInt16(payload[1]))
                if payload.count > 2 {
                    reason = String(data: payload.subdata(in: 2..<payload.count), encoding: .utf8)
                }
            }
            finish(code: code, reason: reason)
        case 0x09: // Ping -> Pong
            sendFrame(opcode: 0x0A, payload: payload)
        case 0x0A: // Pong
            break
        default:
            break
        }
    }

    private func sendFrame(opcode: UInt8, payload: Data) {
        queue.async { [weak self] in
            guard let self = self, !self.isClosed else { return }
            var frame = Data()
            frame.append(0x80 | opcode)

            let len = payload.count
            if len < 126 {
                frame.append(0x80 | UInt8(len))
            } else if len <= 65535 {
                frame.append(0x80 | 126)
                frame.append(UInt8((len >> 8) & 0xFF))
                frame.append(UInt8(len & 0xFF))
            } else {
                frame.append(0x80 | 127)
                let u64 = UInt64(len)
                for shift in stride(from: 56, through: 0, by: -8) {
                    frame.append(UInt8((u64 >> shift) & 0xFF))
                }
            }

            var mask = [UInt8](repeating: 0, count: 4)
            _ = SecRandomCopyBytes(kSecRandomDefault, 4, &mask)
            frame.append(contentsOf: mask)

            var maskedPayload = [UInt8](repeating: 0, count: len)
            payload.withUnsafeBytes { raw in
                let bytes = raw.bindMemory(to: UInt8.self)
                for i in 0..<len {
                    maskedPayload[i] = bytes[i] ^ mask[i % 4]
                }
            }
            frame.append(contentsOf: maskedPayload)
            self.connection?.send(content: frame, completion: .contentProcessed { _ in })
        }
    }

    private func finish(code: Int, reason: String?) {
        queue.async { [weak self] in
            guard let self = self, !self.isClosed else { return }
            self.isClosed = true
            self.connection?.cancel()
            self.connection = nil
            DispatchQueue.main.async {
                self.delegate?.webSocket(self, didDisconnectWithCode: code, reason: reason)
            }
        }
    }
}
