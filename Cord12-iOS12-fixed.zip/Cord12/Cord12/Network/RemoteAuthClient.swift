import Foundation

protocol RemoteAuthClientDelegate: AnyObject {
    func remoteAuthDidGenerateQR(urlString: String, timeoutSeconds: Int)
    func remoteAuthDidScan(username: String, discriminator: String, userId: String, avatarHash: String)
    func remoteAuthDidComplete(token: String)
    func remoteAuthDidCancelOrFail(message: String)
}

/// Implements Discord Remote Authentication (Desktop v2) for two-device QR login on iOS 12.
final class RemoteAuthClient: RFC6455WebSocketDelegate {
    weak var delegate: RemoteAuthClientDelegate?

    private var socket: RFC6455WebSocket?
    private var rsaHelper: RSAOAEPHelper?
    private var heartbeatTimer: Timer?
    private var timeoutSeconds: Int = 120

    private static let userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    private static let superPropertiesBase64: String = {
        let props: [String: Any] = [
            "os": "Mac OS X",
            "browser": "Chrome",
            "device": "",
            "system_locale": "en-US",
            "browser_user_agent": userAgent,
            "browser_version": "131.0.0.0",
            "os_version": "10.15.7",
            "referrer": "",
            "referring_domain": "",
            "referrer_current": "",
            "referring_domain_current": "",
            "release_channel": "stable",
            "client_build_number": 345678,
            "client_event_source": NSNull()
        ]
        guard let data = try? JSONSerialization.data(withJSONObject: props) else { return "" }
        return data.base64EncodedString()
    }()

    func start() {
        stop()
        guard let rsa = RSAOAEPHelper() else {
            delegate?.remoteAuthDidCancelOrFail(message: "Failed to generate RSA-2048 keypair.")
            return
        }
        self.rsaHelper = rsa
        guard let url = URL(string: "wss://remote-auth-gateway.discord.gg/?v=2") else { return }
        let ws = RFC6455WebSocket(url: url, headers: [
            "Origin": "https://discord.com",
            "User-Agent": RemoteAuthClient.userAgent
        ])
        ws.delegate = self
        self.socket = ws
        ws.connect()
    }

    func stop() {
        heartbeatTimer?.invalidate()
        heartbeatTimer = nil
        socket?.delegate = nil
        socket?.close()
        socket = nil
    }

    func webSocketDidConnect(_ socket: RFC6455WebSocket) {}

    func webSocket(_ socket: RFC6455WebSocket, didDisconnectWithCode code: Int, reason: String?) {
        guard socket === self.socket else { return }
        heartbeatTimer?.invalidate()
        heartbeatTimer = nil
        if code != 1000 {
            delegate?.remoteAuthDidCancelOrFail(message: reason ?? "Remote Auth disconnected (\(code))")
        }
    }

    func webSocket(_ socket: RFC6455WebSocket, didReceiveText text: String) {
        guard socket === self.socket,
              let data = text.data(using: .utf8),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let op = json["op"] as? String else { return }

        switch op {
        case "hello":
            let intervalMs = json["heartbeat_interval"] as? Int ?? 41250
            let timeoutMs = json["timeout_ms"] as? Int ?? 120000
            self.timeoutSeconds = max(30, timeoutMs / 1000)
            startHeartbeat(interval: TimeInterval(intervalMs) / 1000.0)
            if let spki = rsaHelper?.spkiBase64 {
                sendJSON(["op": "init", "encoded_public_key": spki])
            }

        case "nonce_proof":
            if let encryptedNonce = json["encrypted_nonce"] as? String,
               let decrypted = rsaHelper?.decrypt(base64String: encryptedNonce) {
                let proof = RSAOAEPHelper.base64URLEncode(decrypted)
                sendJSON(["op": "nonce_proof", "nonce": proof])
            }

        case "pending_remote_init":
            if let fingerprint = json["fingerprint"] as? String {
                guard fingerprint == rsaHelper?.fingerprintBase64URL else {
                    stop()
                    delegate?.remoteAuthDidCancelOrFail(message: "Fingerprint verification failed.")
                    return
                }
                let qrURL = "https://discord.com/ra/\(fingerprint)"
                delegate?.remoteAuthDidGenerateQR(urlString: qrURL, timeoutSeconds: timeoutSeconds)
            }

        case "pending_ticket":
            if let encryptedPayload = json["encrypted_user_payload"] as? String,
               let plainData = rsaHelper?.decrypt(base64String: encryptedPayload),
               let payloadStr = String(data: plainData, encoding: .utf8) {
                let parts = payloadStr.components(separatedBy: ":")
                if parts.count >= 4 {
                    let userId = parts[0]
                    let disc = parts[1]
                    let avatar = parts[2]
                    let username = parts[3...].joined(separator: ":")
                    delegate?.remoteAuthDidScan(username: username, discriminator: disc, userId: userId, avatarHash: avatar)
                }
            }

        case "pending_login":
            if let ticket = json["ticket"] as? String {
                exchangeTicket(ticket)
            }

        case "cancel":
            stop()
            delegate?.remoteAuthDidCancelOrFail(message: "Login was canceled on the other device.")

        default:
            break
        }
    }

    private func startHeartbeat(interval: TimeInterval) {
        heartbeatTimer?.invalidate()
        heartbeatTimer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { [weak self] _ in
            self?.sendJSON(["op": "heartbeat"])
        }
    }

    private func sendJSON(_ dict: [String: Any]) {
        guard let data = try? JSONSerialization.data(withJSONObject: dict),
              let str = String(data: data, encoding: .utf8) else { return }
        socket?.send(text: str)
    }

    private func exchangeTicket(_ ticket: String) {
        guard let url = URL(string: "https://discord.com/api/v9/users/@me/remote-auth/login") else { return }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("https://discord.com", forHTTPHeaderField: "Origin")
        req.setValue("https://discord.com/login", forHTTPHeaderField: "Referer")
        req.setValue(RemoteAuthClient.userAgent, forHTTPHeaderField: "User-Agent")
        req.setValue(RemoteAuthClient.superPropertiesBase64, forHTTPHeaderField: "X-Super-Properties")
        req.setValue("en-US", forHTTPHeaderField: "X-Discord-Locale")
        req.httpBody = try? JSONSerialization.data(withJSONObject: ["ticket": ticket])

        URLSession.shared.dataTask(with: req) { [weak self] data, response, error in
            DispatchQueue.main.async {
                guard let self = self else { return }
                if let error = error {
                    self.delegate?.remoteAuthDidCancelOrFail(message: error.localizedDescription)
                    return
                }
                let status = (response as? HTTPURLResponse)?.statusCode ?? 0
                guard let data = data,
                      let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                    self.delegate?.remoteAuthDidCancelOrFail(message: "Remote auth failed (HTTP \(status)).")
                    return
                }
                guard let encryptedToken = json["encrypted_token"] as? String else {
                    if json["captcha_key"] != nil {
                        self.delegate?.remoteAuthDidCancelOrFail(message: "Discord requested a captcha for QR login. Use the Token tab instead.")
                    } else if let msg = json["message"] as? String {
                        self.delegate?.remoteAuthDidCancelOrFail(message: "\(msg) (HTTP \(status))")
                    } else {
                        self.delegate?.remoteAuthDidCancelOrFail(message: "Remote auth rejected (HTTP \(status)).")
                    }
                    return
                }
                guard let tokenData = self.rsaHelper?.decrypt(base64String: encryptedToken),
                      let token = String(data: tokenData, encoding: .utf8) else {
                    self.delegate?.remoteAuthDidCancelOrFail(message: "Could not decrypt login token.")
                    return
                }
                self.stop()
                self.delegate?.remoteAuthDidComplete(token: token)
            }
        }.resume()
    }
}
