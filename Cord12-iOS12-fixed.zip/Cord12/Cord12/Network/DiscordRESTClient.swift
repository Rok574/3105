import Foundation

enum RESTError: Error, LocalizedError {
    case invalidURL
    case httpError(Int, String)
    case decodingError

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "Invalid Discord API URL"
        case .httpError(let code, let msg): return "HTTP \(code): \(msg)"
        case .decodingError: return "Failed to parse Discord response"
        }
    }
}

final class DiscordRESTClient {
    static let shared = DiscordRESTClient()
    private let baseURL = "https://discord.com/api/v9"
    private let session: URLSession

    var token: String?

    private static let userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    private static let superPropertiesBase64: String = {
        let props: [String: Any] = [
            "os": "Mac OS X",
            "browser": "Chrome",
            "device": "",
            "system_locale": "en-US",
            "browser_user_agent": userAgent,
            "browser_version": "131.0.0.0",
            "os_version": "10.15.7",
            "referrer": "",
            "referring_domain": "",
            "referrer_current": "",
            "referring_domain_current": "",
            "release_channel": "stable",
            "client_build_number": 345678,
            "client_event_source": NSNull()
        ]
        guard let data = try? JSONSerialization.data(withJSONObject: props) else { return "" }
        return data.base64EncodedString()
    }()


    private init() {
        let cfg = URLSessionConfiguration.default
        cfg.timeoutIntervalForRequest = 25
        self.session = URLSession(configuration: cfg)
    }

    private func makeRequest(path: String, method: String = "GET", body: Any? = nil) -> URLRequest? {
        guard let url = URL(string: baseURL + path) else { return nil }
        var req = URLRequest(url: url)
        req.httpMethod = method
        if let token = token {
            req.setValue(token, forHTTPHeaderField: "Authorization")
        }
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("https://discord.com", forHTTPHeaderField: "Origin")
        req.setValue(DiscordRESTClient.userAgent, forHTTPHeaderField: "User-Agent")
        req.setValue(DiscordRESTClient.superPropertiesBase64, forHTTPHeaderField: "X-Super-Properties")
        req.setValue("en-US", forHTTPHeaderField: "X-Discord-Locale")
        if let body = body {
            req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        }
        return req
    }

    func requestData(path: String, method: String = "GET", body: Any? = nil, completion: @escaping (Result<Data, Error>) -> Void) {
        guard let req = makeRequest(path: path, method: method, body: body) else {
            completion(.failure(RESTError.invalidURL))
            return
        }
        session.dataTask(with: req) { data, response, error in
            if let error = error {
                DispatchQueue.main.async { completion(.failure(error)) }
                return
            }
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            let raw = data ?? Data()
            if status >= 200 && status < 300 {
                DispatchQueue.main.async { completion(.success(raw)) }
            } else {
                let msg = String(data: raw, encoding: .utf8) ?? "Unknown error"
                DispatchQueue.main.async {
                    if status == 401 { NotificationCenter.default.post(name: .cordAuthInvalid, object: nil) }
                    completion(.failure(RESTError.httpError(status, msg)))
                }
            }
        }.resume()
    }

    func requestDecodable<T: Decodable>(path: String, method: String = "GET", body: Any? = nil, completion: @escaping (Result<T, Error>) -> Void) {
        requestData(path: path, method: method, body: body) { result in
            switch result {
            case .success(let data):
                do {
                    let decoded = try JSONDecoder().decode(T.self, from: data)
                    completion(.success(decoded))
                } catch {
                    completion(.failure(RESTError.decodingError))
                }
            case .failure(let err):
                completion(.failure(err))
            }
        }
    }

    // MARK: - Users, Settings & Profiles

    func fetchCurrentUser(completion: @escaping (Result<DiscordUser, Error>) -> Void) {
        requestDecodable(path: "/users/@me", completion: completion)
    }

    func fetchUserSettings(completion: @escaping (Result<DiscordUserSettings, Error>) -> Void) {
        requestDecodable(path: "/users/@me/settings", completion: completion)
    }

    func fetchUserProfile(userId: String, guildId: String? = nil, completion: @escaping (Result<UserProfileResponse, Error>) -> Void) {
        var path = "/users/\(userId)/profile?with_mutual_guilds=true&with_mutual_friends_count=true"
        if let gid = guildId {
            path += "&guild_id=\(gid)"
        }
        requestDecodable(path: path, completion: completion)
    }

    func fetchOwnedCollectibles(completion: @escaping (Result<[CollectibleProduct], Error>) -> Void) {
        requestDecodable(path: "/users/@me/collectibles-purchases?variants_return_style=1", completion: completion)
    }

    func patchCurrentUser(
        globalName: String? = nil,
        avatarBase64: String? = nil,
        avatarDecorationSkuId: String?? = nil,
        completion: @escaping (Result<DiscordUser, Error>) -> Void
    ) {
        var body: [String: Any] = [:]
        if let g = globalName { body["global_name"] = g.isEmpty ? NSNull() : g }
        if let av = avatarBase64 { body["avatar"] = av }
        if let dec = avatarDecorationSkuId { body["avatar_decoration_id"] = dec ?? NSNull() }
        guard !body.isEmpty else {
            fetchCurrentUser(completion: completion)
            return
        }
        requestDecodable(path: "/users/@me", method: "PATCH", body: body, completion: completion)
    }

    func patchUserProfile(
        bio: String? = nil,
        pronouns: String? = nil,
        accentColor: Int?? = nil,
        themeColors: [Int]?? = nil,
        bannerBase64: String?? = nil,
        completion: @escaping (Result<ProfileMetadata, Error>) -> Void
    ) {
        var body: [String: Any] = [:]
        if let bio = bio { body["bio"] = bio }
        if let pronouns = pronouns { body["pronouns"] = pronouns }
        if let ac = accentColor { body["accent_color"] = ac ?? NSNull() }
        if let tc = themeColors { body["theme_colors"] = tc ?? NSNull() }
        if let ban = bannerBase64 { body["banner"] = ban ?? NSNull() }
        requestDecodable(path: "/users/@me/profile", method: "PATCH", body: body) { [weak self] (res: Result<ProfileMetadata, Error>) in
            if case .failure = res, themeColors != nil {
                // Non-Nitro accounts reject theme_colors; retry with core profile fields
                var fallback: [String: Any] = [:]
                if let bio = bio { fallback["bio"] = bio }
                if let pronouns = pronouns { fallback["pronouns"] = pronouns }
                if let ac = accentColor { fallback["accent_color"] = ac ?? NSNull() }
                if let ban = bannerBase64 { fallback["banner"] = ban ?? NSNull() }
                if !fallback.isEmpty {
                    self?.requestDecodable(path: "/users/@me/profile", method: "PATCH", body: fallback, completion: completion)
                    return
                }
            }
            completion(res)
        }
    }

    // MARK: - Guilds, Channels, Friends & Messages

    func fetchGuilds(completion: @escaping (Result<[DiscordGuild], Error>) -> Void) {
        requestDecodable(path: "/users/@me/guilds", completion: completion)
    }

    func fetchDMChannels(completion: @escaping (Result<[DiscordChannel], Error>) -> Void) {
        requestDecodable(path: "/users/@me/channels", completion: completion)
    }

    func createDM(recipientId: String, completion: @escaping (Result<DiscordChannel, Error>) -> Void) {
        requestDecodable(path: "/users/@me/channels", method: "POST", body: ["recipient_id": recipientId], completion: completion)
    }

    func fetchRelationships(completion: @escaping (Result<[DiscordRelationship], Error>) -> Void) {
        requestDecodable(path: "/users/@me/relationships", completion: completion)
    }

    func sendFriendRequest(username: String, completion: ((Error?) -> Void)? = nil) {
        requestData(path: "/users/@me/relationships", method: "POST", body: ["username": username]) { res in
            switch res {
            case .success: completion?(nil)
            case .failure(let err): completion?(err)
            }
        }
    }

    func fetchGuildChannels(guildId: String, completion: @escaping (Result<[DiscordChannel], Error>) -> Void) {
        requestDecodable(path: "/guilds/\(guildId)/channels", completion: completion)
    }

    func fetchGuildMembers(guildId: String, limit: Int = 50, completion: @escaping (Result<[GuildMember], Error>) -> Void) {
        requestDecodable(path: "/guilds/\(guildId)/members?limit=\(limit)", completion: completion)
    }

    func fetchMessages(channelId: String, before: String? = nil, limit: Int = 40, completion: @escaping (Result<[DiscordMessage], Error>) -> Void) {
        var path = "/channels/\(channelId)/messages?limit=\(limit)"
        if let before = before {
            path += "&before=\(before)"
        }
        requestDecodable(path: path, completion: completion)
    }

    func fetchPinnedMessages(channelId: String, completion: @escaping (Result<[DiscordMessage], Error>) -> Void) {
        requestDecodable(path: "/channels/\(channelId)/pins", completion: completion)
    }

    func searchChannelMessages(guildId: String?, channelId: String, query: String, completion: @escaping (Result<[DiscordMessage], Error>) -> Void) {
        let q = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let path: String
        if let gid = guildId {
            path = "/guilds/\(gid)/messages/search?channel_id=\(channelId)&content=\(q)"
        } else {
            path = "/channels/\(channelId)/messages/search?content=\(q)"
        }
        requestData(path: path) { res in
            switch res {
            case .success(let data):
                if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let groups = json["messages"] as? [[[String: Any]]] {
                    let flat = groups.compactMap { $0.first }
                    if let arrData = try? JSONSerialization.data(withJSONObject: flat),
                       let decoded = try? JSONDecoder().decode([DiscordMessage].self, from: arrData) {
                        completion(.success(decoded))
                        return
                    }
                }
                completion(.success([]))
            case .failure(let err):
                completion(.failure(err))
            }
        }
    }

    func sendMessage(channelId: String, content: String, replyToMessageId: String? = nil, completion: @escaping (Result<DiscordMessage, Error>) -> Void) {
        var body: [String: Any] = [
            "content": content,
            "nonce": String(Int64(Date().timeIntervalSince1970 * 1000)) + String(Int.random(in: 100...999)),
            "tts": false
        ]
        if let refId = replyToMessageId {
            body["message_reference"] = ["message_id": refId]
        }
        requestDecodable(path: "/channels/\(channelId)/messages", method: "POST", body: body, completion: completion)
    }

    func editMessage(channelId: String, messageId: String, content: String, completion: @escaping (Result<DiscordMessage, Error>) -> Void) {
        requestDecodable(path: "/channels/\(channelId)/messages/\(messageId)", method: "PATCH", body: ["content": content], completion: completion)
    }

    func deleteMessage(channelId: String, messageId: String, completion: ((Error?) -> Void)? = nil) {
        requestData(path: "/channels/\(channelId)/messages/\(messageId)", method: "DELETE") { res in
            switch res {
            case .success: completion?(nil)
            case .failure(let err): completion?(err)
            }
        }
    }

    /// Uploads a file directly to Discord, with automatic Catbox.moe fallback if oversized or rejected.
    func uploadFile(channelId: String, data: Data, filename: String, mimeType: String, caption: String = "", completion: @escaping (Result<DiscordMessage, Error>) -> Void) {
        if data.count > 24 * 1024 * 1024 {
            uploadToCatbox(data: data, filename: filename, mimeType: mimeType) { [weak self] urlStr in
                if let urlStr = urlStr {
                    let msg = caption.isEmpty ? urlStr : "\(caption)\n\(urlStr)"
                    self?.sendMessage(channelId: channelId, content: msg, completion: completion)
                } else {
                    completion(.failure(RESTError.httpError(413, "File too large for Discord and Catbox upload failed.")))
                }
            }
            return
        }

        guard let url = URL(string: baseURL + "/channels/\(channelId)/messages") else {
            completion(.failure(RESTError.invalidURL))
            return
        }
        let boundary = "Boundary-\(UUID().uuidString)"
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        if let token = token { req.setValue(token, forHTTPHeaderField: "Authorization") }
        req.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        req.setValue("https://discord.com", forHTTPHeaderField: "Origin")

        var body = Data()
        let payloadJSON = "{\"content\":\"\(caption.replacingOccurrences(of: "\"", with: "\\\""))\"}"
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"payload_json\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: application/json\r\n\r\n".data(using: .utf8)!)
        body.append(payloadJSON.data(using: .utf8)!)
        body.append("\r\n".data(using: .utf8)!)

        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"files[0]\"; filename=\"\(filename)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: \(mimeType)\r\n\r\n".data(using: .utf8)!)
        body.append(data)
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)
        req.httpBody = body

        session.dataTask(with: req) { [weak self] respData, response, error in
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            if status >= 200 && status < 300, let respData = respData,
               let msg = try? JSONDecoder().decode(DiscordMessage.self, from: respData) {
                DispatchQueue.main.async { completion(.success(msg)) }
            } else {
                // Automatic Catbox fallback
                self?.uploadToCatbox(data: data, filename: filename, mimeType: mimeType) { catboxURL in
                    if let catboxURL = catboxURL {
                        let msgText = caption.isEmpty ? catboxURL : "\(caption)\n\(catboxURL)"
                        self?.sendMessage(channelId: channelId, content: msgText, completion: completion)
                    } else {
                        DispatchQueue.main.async {
                            completion(.failure(error ?? RESTError.httpError(status, "Upload failed")))
                        }
                    }
                }
            }
        }.resume()
    }

    private func uploadToCatbox(data: Data, filename: String, mimeType: String, completion: @escaping (String?) -> Void) {
        guard let url = URL(string: "https://catbox.moe/user/api.php") else { completion(nil); return }
        let boundary = "Catbox-\(UUID().uuidString)"
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        var body = Data()
        body.append("--\(boundary)\r\nContent-Disposition: form-data; name=\"reqtype\"\r\n\r\nfileupload\r\n".data(using: .utf8)!)
        body.append("--\(boundary)\r\nContent-Disposition: form-data; name=\"fileToUpload\"; filename=\"\(filename)\"\r\nContent-Type: \(mimeType)\r\n\r\n".data(using: .utf8)!)
        body.append(data)
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)
        req.httpBody = body

        session.dataTask(with: req) { respData, _, _ in
            let str = respData.flatMap { String(data: $0, encoding: .utf8) }?.trimmingCharacters(in: .whitespacesAndNewlines)
            DispatchQueue.main.async {
                if let s = str, s.hasPrefix("https://") {
                    completion(s)
                } else {
                    completion(nil)
                }
            }
        }.resume()
    }

    func triggerTyping(channelId: String) {
        requestData(path: "/channels/\(channelId)/typing", method: "POST") { _ in }
    }

    // MARK: - Reactions & Polls

    func addReaction(channelId: String, messageId: String, emoji: String, completion: ((Error?) -> Void)? = nil) {
        let encoded = emoji.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? emoji
        requestData(path: "/channels/\(channelId)/messages/\(messageId)/reactions/\(encoded)/@me", method: "PUT") { res in
            switch res {
            case .success: completion?(nil)
            case .failure(let err): completion?(err)
            }
        }
    }

    func removeReaction(channelId: String, messageId: String, emoji: String, completion: ((Error?) -> Void)? = nil) {
        let encoded = emoji.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? emoji
        requestData(path: "/channels/\(channelId)/messages/\(messageId)/reactions/\(encoded)/@me", method: "DELETE") { res in
            switch res {
            case .success: completion?(nil)
            case .failure(let err): completion?(err)
            }
        }
    }

    func votePoll(channelId: String, messageId: String, answerId: Int, completion: ((Error?) -> Void)? = nil) {
        requestData(
            path: "/channels/\(channelId)/polls/\(messageId)/answers/\(answerId)",
            method: "PUT"
        ) { res in
            switch res {
            case .success: completion?(nil)
            case .failure(let err): completion?(err)
            }
        }
    }

    // MARK: - GIFs

    func searchGifs(query: String, completion: @escaping (Result<[DiscordGifItem], Error>) -> Void) {
        let q = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        requestDecodable(path: "/gifs/search?q=\(q)&media_format=gif&limit=30", completion: completion)
    }

    func fetchTrendingGifs(completion: @escaping (Result<[DiscordGifItem], Error>) -> Void) {
        requestDecodable(path: "/gifs/trending?media_format=gif&limit=30", completion: completion)
    }
}

extension Notification.Name {
    /// Posted when Discord rejects the stored token (HTTP 401) so the app can return to login.
    static let cordAuthInvalid = Notification.Name("cordAuthInvalid")
}
