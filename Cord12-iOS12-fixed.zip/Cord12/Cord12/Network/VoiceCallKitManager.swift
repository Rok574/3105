import Foundation
import CallKit
import AVFoundation

protocol VoiceCallKitDelegate: AnyObject {
    func callKitDidActivateAudioSession(_ session: AVAudioSession)
    func callKitDidDeactivateAudioSession(_ session: AVAudioSession)
    func callKitDidRequestMute(_ muted: Bool)
    func callKitDidRequestEndCall()
}

/// Manages iOS CallKit VoIP call lifecycle and AVAudioSession activation for Cord12 voice channels.
final class VoiceCallKitManager: NSObject, CXProviderDelegate {
    static let shared = VoiceCallKitManager()

    weak var delegate: VoiceCallKitDelegate?

    private let provider: CXProvider
    private let callController = CXCallController()
    private var activeCallUUID: UUID?

    private override init() {
        let config = CXProviderConfiguration(localizedName: "Cord12")
        config.supportsVideo = false
        config.maximumCallsPerCallGroup = 1
        config.supportedHandleTypes = [.generic]
        config.includesCallsInRecents = false
        self.provider = CXProvider(configuration: config)
        super.init()
        self.provider.setDelegate(self, queue: .main)
    }

    func startOutgoingCall(channelName: String) {
        if let existing = activeCallUUID {
            endCall(uuid: existing)
        }
        let uuid = UUID()
        activeCallUUID = uuid
        let handle = CXHandle(type: .generic, value: channelName)
        let startAction = CXStartCallAction(call: uuid, handle: handle)
        startAction.isVideo = false
        let transaction = CXTransaction(action: startAction)
        callController.request(transaction) { [weak self] error in
            if error != nil {
                // Fallback if CallKit transaction fails (e.g. simulator or restricted entitlement)
                self?.configureFallbackAudioSession()
            } else {
                self?.provider.reportOutgoingCall(with: uuid, startedConnectingAt: Date())
            }
        }
    }

    func reportConnected() {
        guard let uuid = activeCallUUID else { return }
        provider.reportOutgoingCall(with: uuid, connectedAt: Date())
    }

    func reportMute(_ muted: Bool) {
        guard let uuid = activeCallUUID else { return }
        let action = CXSetMutedCallAction(call: uuid, muted: muted)
        callController.request(CXTransaction(action: action)) { _ in }
    }

    func endCall(uuid: UUID? = nil) {
        let target = uuid ?? activeCallUUID
        guard let id = target else { return }
        if id == activeCallUUID { activeCallUUID = nil }
        let endAction = CXEndCallAction(call: id)
        callController.request(CXTransaction(action: endAction)) { [weak self] _ in
            self?.provider.reportCall(with: id, endedAt: Date(), reason: .remoteEnded)
        }
    }

    private func configureFallbackAudioSession() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playAndRecord, mode: .voiceChat, options: [.allowBluetooth, .defaultToSpeaker])
        try? session.setPreferredSampleRate(48000)
        try? session.setPreferredIOBufferDuration(0.02)
        try? session.setActive(true)
        delegate?.callKitDidActivateAudioSession(session)
    }

    // MARK: - CXProviderDelegate

    func providerDidReset(_ provider: CXProvider) {
        activeCallUUID = nil
        delegate?.callKitDidRequestEndCall()
    }

    func provider(_ provider: CXProvider, perform action: CXStartCallAction) {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playAndRecord, mode: .voiceChat, options: [.allowBluetooth, .defaultToSpeaker])
        try? session.setPreferredSampleRate(48000)
        try? session.setPreferredIOBufferDuration(0.02)
        action.fulfill()
    }

    func provider(_ provider: CXProvider, perform action: CXEndCallAction) {
        if action.callUUID == activeCallUUID {
            activeCallUUID = nil
            delegate?.callKitDidRequestEndCall()
        }
        action.fulfill()
    }

    func provider(_ provider: CXProvider, perform action: CXSetMutedCallAction) {
        delegate?.callKitDidRequestMute(action.isMuted)
        action.fulfill()
    }

    func provider(_ provider: CXProvider, didActivate audioSession: AVAudioSession) {
        delegate?.callKitDidActivateAudioSession(audioSession)
    }

    func provider(_ provider: CXProvider, didDeactivate audioSession: AVAudioSession) {
        delegate?.callKitDidDeactivateAudioSession(audioSession)
    }
}
