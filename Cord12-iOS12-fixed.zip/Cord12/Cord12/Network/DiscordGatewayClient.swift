import Foundation

protocol DiscordGatewayDelegate: AnyObject {
    func gatewayDidReceiveReady(payload: [String: Any])
    func gatewayDidReceiveMessageCreate(_ message: DiscordMessage)
    func gatewayDidReceiveMessageUpdate(_ message: DiscordMessage)
    func gatewayDidReceiveMessageDelete(channelId: String, messageId: String)
    func gatewayDidReceiveReactionAdd(channelId: String, messageId: String, userId: String, emoji: DiscordEmoji)
    func gatewayDidReceiveReactionRemove(channelId: String, messageId: String, userId: String, emoji: DiscordEmoji)
    func gatewayDidReceiveUserUpdate(_ user: DiscordUser)
    func gatewayDidReceivePresenceUpdate(userId: String, status: String)
    func gatewayDidReceiveTypingStart(channelId: String, userId: String)
    func gatewayDidReceiveUserSettingsUpdate(_ settings: DiscordUserSettings)
    func gatewayDidReceiveVoiceStateUpdate(_ state: VoiceState)
    func gatewayDidReceiveVoiceServerUpdate(_ server: VoiceServerUpdate)
    func gatewayDidChangeState(connected: Bool)
}

final class DiscordGatewayClient: RFC6455WebSocketDelegate {
    weak var delegate: DiscordGatewayDelegate?

    private var socket: RFC6455WebSocket?
    private var token: String = ""
    private var heartbeatTimer: Timer?
    private var sequence: Int?
    private var sessionId: String?
    private var resumeGatewayURL: String?
    private var shouldReconnect = false
    private let parseQueue = DispatchQueue(label: "com.sky.cord12.gwparse", qos: .userInitiated)

    func connect(token: String) {
        self.token = token
        self.shouldReconnect = true
        openSocket(urlString: resumeGatewayURL ?? "wss://gateway.discord.gg/?v=10&encoding=json")
    }

    func disconnect() {
        shouldReconnect = false
        heartbeatTimer?.invalidate()
        heartbeatTimer = nil
        socket?.delegate = nil
        socket?.close()
        socket = nil
        sessionId = nil
        sequence = nil
        resumeGatewayURL = nil
        delegate?.gatewayDidChangeState(connected: false)
    }

    func updatePresence(status: String, customText: String?) {
        var activities: [[String: Any]] = []
        if let text = customText, !text.isEmpty {
            activities.append([
                "name": "Custom Status",
                "type": 4,
                "state": text
            ])
        }
        let payload: [String: Any] = [
            "op": 3,
            "d": [
                "since": status == "idle" ? Int(Date().timeIntervalSince1970 * 1000) : 0,
                "activities": activities,
                "status": status,
                "afk": status == "idle"
            ]
        ]
        sendJSON(payload)
    }

    func sendVoiceStateUpdate(guildId: String?, channelId: String?, selfMute: Bool, selfDeaf: Bool) {
        let payload: [String: Any] = [
            "op": 4,
            "d": [
                "guild_id": guildId.map { $0 as Any } ?? NSNull(),
                "channel_id": channelId.map { $0 as Any } ?? NSNull(),
                "self_mute": selfMute,
                "self_deaf": selfDeaf
            ]
        ]
        sendJSON(payload)
    }

    private func openSocket(urlString: String) {
        let old = socket
        socket = nil
        old?.delegate = nil
        old?.close()
        guard let url = URL(string: urlString) else { return }
        let ws = RFC6455WebSocket(url: url, headers: [
            "Origin": "https://discord.com",
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 12_5_8 like Mac OS X) AppleWebKit/605.1.15"
        ])
        ws.delegate = self
        self.socket = ws
        ws.connect()
    }

    func webSocketDidConnect(_ socket: RFC6455WebSocket) {
        guard socket === self.socket else { return }
        delegate?.gatewayDidChangeState(connected: true)
    }

    func webSocket(_ socket: RFC6455WebSocket, didDisconnectWithCode code: Int, reason: String?) {
        guard socket === self.socket else { return }
        heartbeatTimer?.invalidate()
        heartbeatTimer = nil
        delegate?.gatewayDidChangeState(connected: false)
        // 4004 = auth failed, 4010-4014 = fatal config errors: do not retry
        let fatal: Set<Int> = [4004, 4010, 4011, 4012, 4013, 4014]
        if code == 4007 || code == 4009 { sessionId = nil; sequence = nil }
        if shouldReconnect && !fatal.contains(code) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { [weak self] in
                guard let self = self, self.shouldReconnect else { return }
                self.openSocket(urlString: self.resumeGatewayURL ?? "wss://gateway.discord.gg/?v=10&encoding=json")
            }
        }
    }

    func webSocket(_ socket: RFC6455WebSocket, didReceiveText text: String) {
        parseQueue.async { [weak self] in
            guard let self = self,
                  let data = text.data(using: .utf8),
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let op = json["op"] as? Int else { return }

            let s = json["s"] as? Int
            DispatchQueue.main.async {
                guard socket === self.socket else { return }
                if let s = s { self.sequence = s }
                switch op {
                case 10: // Hello
                    if let d = json["d"] as? [String: Any],
                       let intervalMs = d["heartbeat_interval"] as? Int {
                        self.startHeartbeat(interval: TimeInterval(intervalMs) / 1000.0)
                        if let sessionId = self.sessionId, let seq = self.sequence {
                            self.sendResume(sessionId: sessionId, seq: seq)
                        } else {
                            self.sendIdentify()
                        }
                    }

                case 0: // Dispatch
                    guard let t = json["t"] as? String,
                          let d = json["d"] as? [String: Any] else { return }
                    self.handleDispatch(event: t, data: d)

                case 7: // Reconnect
                    socket.close(code: 4000)

                case 9: // Invalid Session
                    let resumable = (json["d"] as? Bool) ?? false
                    if !resumable {
                        self.sessionId = nil
                        self.sequence = nil
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [weak self] in
                        guard let self = self, self.shouldReconnect else { return }
                        self.sendIdentify()
                    }

                default:
                    break
                }
            }
        }
    }


    private func handleDispatch(event: String, data: [String: Any]) {
        switch event {
        case "READY":
            sessionId = data["session_id"] as? String
            if let url = data["resume_gateway_url"] as? String {
                resumeGatewayURL = url + "/?v=10&encoding=json"
            }
            delegate?.gatewayDidReceiveReady(payload: data)

        case "MESSAGE_CREATE":
            if let msgData = try? JSONSerialization.data(withJSONObject: data),
               let msg = try? JSONDecoder().decode(DiscordMessage.self, from: msgData) {
                delegate?.gatewayDidReceiveMessageCreate(msg)
            }

        case "MESSAGE_UPDATE":
            if let msgData = try? JSONSerialization.data(withJSONObject: data),
               let msg = try? JSONDecoder().decode(DiscordMessage.self, from: msgData) {
                delegate?.gatewayDidReceiveMessageUpdate(msg)
            }

        case "MESSAGE_DELETE":
            if let cid = data["channel_id"] as? String, let mid = data["id"] as? String {
                delegate?.gatewayDidReceiveMessageDelete(channelId: cid, messageId: mid)
            }

        case "MESSAGE_REACTION_ADD", "MESSAGE_REACTION_REMOVE":
            if let cid = data["channel_id"] as? String,
               let mid = data["message_id"] as? String,
               let uid = data["user_id"] as? String,
               let emojiDict = data["emoji"] as? [String: Any],
               let emojiData = try? JSONSerialization.data(withJSONObject: emojiDict),
               let emoji = try? JSONDecoder().decode(DiscordEmoji.self, from: emojiData) {
                if event == "MESSAGE_REACTION_ADD" {
                    delegate?.gatewayDidReceiveReactionAdd(channelId: cid, messageId: mid, userId: uid, emoji: emoji)
                } else {
                    delegate?.gatewayDidReceiveReactionRemove(channelId: cid, messageId: mid, userId: uid, emoji: emoji)
                }
            }

        case "USER_UPDATE":
            if let userData = try? JSONSerialization.data(withJSONObject: data),
               let user = try? JSONDecoder().decode(DiscordUser.self, from: userData) {
                delegate?.gatewayDidReceiveUserUpdate(user)
            }

        case "USER_SETTINGS_UPDATE":
            if let sData = try? JSONSerialization.data(withJSONObject: data),
               let settings = try? JSONDecoder().decode(DiscordUserSettings.self, from: sData) {
                delegate?.gatewayDidReceiveUserSettingsUpdate(settings)
            }

        case "PRESENCE_UPDATE":
            if let u = data["user"] as? [String: Any], let uid = u["id"] as? String,
               let status = data["status"] as? String {
                delegate?.gatewayDidReceivePresenceUpdate(userId: uid, status: status)
            }

        case "TYPING_START":
            if let cid = data["channel_id"] as? String, let uid = data["user_id"] as? String {
                delegate?.gatewayDidReceiveTypingStart(channelId: cid, userId: uid)
            }

        case "VOICE_STATE_UPDATE":
            if let vData = try? JSONSerialization.data(withJSONObject: data),
               let state = try? JSONDecoder().decode(VoiceState.self, from: vData) {
                delegate?.gatewayDidReceiveVoiceStateUpdate(state)
            }

        case "VOICE_SERVER_UPDATE":
            if let sData = try? JSONSerialization.data(withJSONObject: data),
               let server = try? JSONDecoder().decode(VoiceServerUpdate.self, from: sData) {
                delegate?.gatewayDidReceiveVoiceServerUpdate(server)
            }

        default:
            break
        }
    }

    private func startHeartbeat(interval: TimeInterval) {
        heartbeatTimer?.invalidate()
        let timer = Timer(timeInterval: interval, repeats: true) { [weak self] _ in
            self?.sendHeartbeat()
        }
        // .common so heartbeats keep firing while the user scrolls (UITrackingRunLoopMode)
        RunLoop.main.add(timer, forMode: .common)
        heartbeatTimer = timer
        DispatchQueue.main.asyncAfter(deadline: .now() + interval * Double.random(in: 0.05...0.9)) { [weak self] in
            self?.sendHeartbeat()
        }
    }

    private func sendHeartbeat() {
        let payload: [String: Any] = ["op": 1, "d": sequence ?? NSNull()]
        sendJSON(payload)
    }

    private func sendIdentify() {
        let payload: [String: Any] = [
            "op": 2,
            "d": [
                "token": token,
                "capabilities": 16381,
                "properties": [
                    "os": "iOS",
                    "browser": "Discord iOS",
                    "device": "iPhone7,2",
                    "system_locale": Locale.current.identifier,
                    "client_version": "240.0",
                    "os_version": "12.5.8"
                ],
                "presence": [
                    "status": "online",
                    "since": 0,
                    "activities": [],
                    "afk": false
                ],
                "compress": false
            ]
        ]
        sendJSON(payload)
    }

    private func sendResume(sessionId: String, seq: Int) {
        let payload: [String: Any] = [
            "op": 6,
            "d": [
                "token": token,
                "session_id": sessionId,
                "seq": seq
            ]
        ]
        sendJSON(payload)
    }

    private func sendJSON(_ dict: [String: Any]) {
        guard let data = try? JSONSerialization.data(withJSONObject: dict),
              let str = String(data: data, encoding: .utf8) else { return }
        socket?.send(text: str)
    }
}
