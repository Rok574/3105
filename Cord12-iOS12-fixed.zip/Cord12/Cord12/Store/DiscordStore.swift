import Foundation
import UserNotifications

extension Notification.Name {
    static let cordStoreDidUpdateGuilds = Notification.Name("cordStoreDidUpdateGuilds")
    static let cordStoreDidUpdateCurrentUser = Notification.Name("cordStoreDidUpdateCurrentUser")
    static let cordStoreDidReceiveMessage = Notification.Name("cordStoreDidReceiveMessage")
    static let cordStoreDidUpdateMessage = Notification.Name("cordStoreDidUpdateMessage")
    static let cordStoreDidDeleteMessage = Notification.Name("cordStoreDidDeleteMessage")
    static let cordStoreDidReceiveTyping = Notification.Name("cordStoreDidReceiveTyping")
    static let cordStoreConnectionChanged = Notification.Name("cordStoreConnectionChanged")
    static let cordStoreDidUpdateVoiceStates = Notification.Name("cordStoreDidUpdateVoiceStates")
}

enum ServerRailItem {
    case folder(GuildFolder, [DiscordGuild])
    case guild(DiscordGuild)
}

final class DiscordStore: DiscordGatewayDelegate {
    static let shared = DiscordStore()

    private let gateway = DiscordGatewayClient()
    private let rest = DiscordRESTClient.shared

    private(set) var currentUser: DiscordUser?
    private(set) var currentUserProfile: UserProfileResponse?
    private(set) var guilds: [DiscordGuild] = []
    private(set) var guildFolders: [GuildFolder] = []
    private(set) var guildPositions: [String] = []
    private(set) var dmChannels: [DiscordChannel] = []
    private(set) var channelsByGuild: [String: [DiscordChannel]] = [:]
    private(set) var emojisByGuild: [String: [DiscordEmoji]] = [:]
    private(set) var messagesByChannel: [String: [DiscordMessage]] = [:]
    var usersById: [String: DiscordUser] = [:]
    private(set) var presencesByUserId: [String: String] = [:]
    private(set) var ownedCollectibles: [CollectibleProduct] = []
    private(set) var recentPings: [DiscordMessage] = []
    private(set) var voiceStatesByChannel: [String: [VoiceState]] = [:]
    private(set) var isGatewayConnected = false

    private init() {
        gateway.delegate = self
    }

    var orderedServerItems: [ServerRailItem] {
        var guildMap: [String: DiscordGuild] = [:]
        for g in guilds { guildMap[g.id] = g }

        var items: [ServerRailItem] = []
        var placedIds = Set<String>()

        if !guildFolders.isEmpty {
            for folder in guildFolders {
                let resolved = folder.guildIds.compactMap { guildMap[$0] }
                guard !resolved.isEmpty else { continue }
                resolved.forEach { placedIds.insert($0.id) }
                if folder.id != nil || resolved.count > 1 || (folder.name != nil && !(folder.name ?? "").isEmpty) {
                    items.append(.folder(folder, resolved))
                } else {
                    items.append(.guild(resolved[0]))
                }
            }
        } else if !guildPositions.isEmpty {
            for gid in guildPositions {
                if let g = guildMap[gid] {
                    placedIds.insert(g.id)
                    items.append(.guild(g))
                }
            }
        }

        // Append any remaining guilds not in folders/positions
        for g in guilds where !placedIds.contains(g.id) {
            items.append(.guild(g))
        }
        return items
    }

    func startSession(token: String) {
        rest.token = token
        gateway.connect(token: token)

        rest.fetchCurrentUser { [weak self] res in
            if case .success(let user) = res {
                self?.currentUser = user
                self?.usersById[user.id] = user
                NotificationCenter.default.post(name: .cordStoreDidUpdateCurrentUser, object: nil)
                self?.refreshCurrentUserProfile()
            }
        }
        rest.fetchUserSettings { [weak self] res in
            if case .success(let settings) = res {
                if let folders = settings.guildFolders, !folders.isEmpty {
                    self?.guildFolders = folders
                }
                if let positions = settings.guildPositions, !positions.isEmpty {
                    self?.guildPositions = positions
                }
                NotificationCenter.default.post(name: .cordStoreDidUpdateGuilds, object: nil)
            }
        }
        rest.fetchGuilds { [weak self] res in
            if case .success(let guilds) = res, self?.guilds.isEmpty == true {
                self?.guilds = guilds
                NotificationCenter.default.post(name: .cordStoreDidUpdateGuilds, object: nil)
            }
        }
        rest.fetchDMChannels { [weak self] res in
            if case .success(let dms) = res {
                for dm in dms {
                    for u in dm.recipients ?? [] {
                        self?.usersById[u.id] = u
                    }
                }
                self?.dmChannels = dms.sorted { $0.lastMessageSnowflake > $1.lastMessageSnowflake }
                NotificationCenter.default.post(name: .cordStoreDidUpdateGuilds, object: nil)
            }
        }
        GifFavoritesStore.shared.syncFromDiscord()
        rest.fetchOwnedCollectibles { [weak self] res in
            if case .success(let items) = res {
                self?.ownedCollectibles = items
            }
        }
    }

    func updatePresence(status: String, customText: String?) {
        gateway.updatePresence(status: status, customText: customText)
        if let uid = currentUser?.id {
            presencesByUserId[uid] = status
        }
    }

    func applyUpdatedCurrentUser(_ user: DiscordUser) {
        self.currentUser = user
        self.usersById[user.id] = user
        NotificationCenter.default.post(name: .cordStoreDidUpdateCurrentUser, object: nil)
    }


    func refreshGuilds() {
        rest.fetchGuilds { [weak self] res in
            if case .success(let guilds) = res {
                self?.guilds = guilds
                NotificationCenter.default.post(name: .cordStoreDidUpdateGuilds, object: nil)
            }
        }
    }

    func refreshCurrentUserProfile() {
        guard let uid = currentUser?.id else { return }
        rest.fetchUserProfile(userId: uid) { [weak self] res in
            if case .success(let prof) = res {
                self?.currentUserProfile = prof
                self?.currentUser = prof.user
                self?.usersById[prof.user.id] = prof.user
                NotificationCenter.default.post(name: .cordStoreDidUpdateCurrentUser, object: nil)
            }
        }
    }

    // MARK: - Voice Channel Controls

    func joinVoiceChannel(_ channel: DiscordChannel) {
        guard let uid = currentUser?.id else { return }
        DiscordVoiceClient.shared.beginJoining(
            guildId: channel.guildId,
            channelId: channel.id,
            channelName: channel.displayName,
            userId: uid
        )
        gateway.sendVoiceStateUpdate(
            guildId: channel.guildId,
            channelId: channel.id,
            selfMute: DiscordVoiceClient.shared.isMuted,
            selfDeaf: DiscordVoiceClient.shared.isDeafened
        )
    }

    func leaveVoiceChannel() {
        let gid = DiscordVoiceClient.shared.guildId
        DiscordVoiceClient.shared.disconnect(notifyGateway: false)
        gateway.sendVoiceStateUpdate(guildId: gid, channelId: nil, selfMute: false, selfDeaf: false)
    }

    func syncLocalVoiceMuteDeaf() {
        guard let cid = DiscordVoiceClient.shared.channelId else { return }
        gateway.sendVoiceStateUpdate(
            guildId: DiscordVoiceClient.shared.guildId,
            channelId: cid,
            selfMute: DiscordVoiceClient.shared.isMuted,
            selfDeaf: DiscordVoiceClient.shared.isDeafened
        )
    }

    func logout() {
        DiscordVoiceClient.shared.disconnect(notifyGateway: false)
        gateway.disconnect()
        rest.token = nil
        KeychainStore.shared.clearToken()
        currentUser = nil
        currentUserProfile = nil
        guilds = []
        guildFolders = []
        guildPositions = []
        dmChannels = []
        channelsByGuild = [:]
        emojisByGuild = [:]
        messagesByChannel = [:]
        usersById = [:]
        presencesByUserId = [:]
        ownedCollectibles = []
        voiceStatesByChannel = [:]
    }

    func allCustomEmojis() -> [DiscordEmoji] {
        return emojisByGuild.values.flatMap { $0 }
    }

    func loadChannelsIfNeeded(guildId: String, completion: @escaping ([DiscordChannel]) -> Void) {
        if let existing = channelsByGuild[guildId], !existing.isEmpty {
            completion(existing)
            return
        }
        rest.fetchGuildChannels(guildId: guildId) { [weak self] res in
            if case .success(let channels) = res {
                let sorted = channels.sorted { ($0.position ?? 0) < ($1.position ?? 0) }
                self?.channelsByGuild[guildId] = sorted
                completion(sorted)
            } else {
                completion([])
            }
        }
    }

    func loadMessages(channelId: String, before: String? = nil, completion: @escaping ([DiscordMessage]) -> Void) {
        rest.fetchMessages(channelId: channelId, before: before) { [weak self] res in
            guard let self = self else { return }
            if case .success(let msgs) = res {
                let ordered = msgs.reversed()
                for m in ordered {
                    self.usersById[m.author.id] = m.author
                }
                if before == nil {
                    self.messagesByChannel[channelId] = Array(ordered)
                } else {
                    let existing = self.messagesByChannel[channelId] ?? []
                    self.messagesByChannel[channelId] = Array(ordered) + existing
                }
                completion(self.messagesByChannel[channelId] ?? [])
            } else {
                completion(self.messagesByChannel[channelId] ?? [])
            }
        }
    }

    // MARK: - DiscordGatewayDelegate

    func gatewayDidReceiveReady(payload: [String: Any]) {
        applyReady(payload: payload)
    }

    private func applyReady(payload: [String: Any]) {
        if let userDict = payload["user"] as? [String: Any],
           let data = try? JSONSerialization.data(withJSONObject: userDict),
           let user = try? JSONDecoder().decode(DiscordUser.self, from: data) {
            currentUser = user
            usersById[user.id] = user
            refreshCurrentUserProfile()
        }

        if let usersArr = payload["users"] as? [[String: Any]],
           let data = try? JSONSerialization.data(withJSONObject: usersArr),
           let users = try? JSONDecoder().decode([DiscordUser].self, from: data) {
            for u in users { usersById[u.id] = u }
        }

        voiceStatesByChannel.removeAll()
        if let guildsArr = payload["guilds"] as? [[String: Any]] {
            var parsedGuilds: [DiscordGuild] = []
            for gDict in guildsArr {
                let props = (gDict["properties"] as? [String: Any]) ?? gDict
                let id = (gDict["id"] as? String) ?? (props["id"] as? String) ?? ""
                let name = (props["name"] as? String) ?? "Server"
                let icon = props["icon"] as? String
                let banner = props["banner"] as? String
                let ownerId = props["owner_id"] as? String
                var guild = DiscordGuild(id: id, name: name, icon: icon, banner: banner, ownerId: ownerId, roles: nil, channels: nil, emojis: nil)

                if let chArr = gDict["channels"] as? [[String: Any]],
                   let chData = try? JSONSerialization.data(withJSONObject: chArr),
                   var chs = try? JSONDecoder().decode([DiscordChannel].self, from: chData) {
                    for i in chs.indices { chs[i].guildId = id }
                    chs.sort { ($0.position ?? 0) < ($1.position ?? 0) }
                    channelsByGuild[id] = chs
                    guild.channels = chs
                }
                if let emArr = gDict["emojis"] as? [[String: Any]],
                   let emData = try? JSONSerialization.data(withJSONObject: emArr),
                   let emojis = try? JSONDecoder().decode([DiscordEmoji].self, from: emData) {
                    emojisByGuild[id] = emojis
                    guild.emojis = emojis
                }
                if let vsArr = gDict["voice_states"] as? [[String: Any]],
                   let vsData = try? JSONSerialization.data(withJSONObject: vsArr),
                   let vstates = try? JSONDecoder().decode([VoiceState].self, from: vsData) {
                    for vs in vstates {
                        if let cid = vs.channelId {
                            voiceStatesByChannel[cid, default: []].append(vs)
                        }
                    }
                }
                parsedGuilds.append(guild)
            }
            if !parsedGuilds.isEmpty {
                self.guilds = parsedGuilds
            }
        }

        if let privArr = payload["private_channels"] as? [[String: Any]],
           let data = try? JSONSerialization.data(withJSONObject: privArr),
           let dms = try? JSONDecoder().decode([DiscordChannel].self, from: data) {
            for dm in dms {
                for u in dm.recipients ?? [] { usersById[u.id] = u }
            }
            self.dmChannels = dms.sorted { $0.lastMessageSnowflake > $1.lastMessageSnowflake }
        }

        if let userSettings = payload["user_settings"] as? [String: Any] {
            if let foldersArr = userSettings["guild_folders"] as? [[String: Any]],
               let data = try? JSONSerialization.data(withJSONObject: foldersArr),
               let folders = try? JSONDecoder().decode([GuildFolder].self, from: data) {
                self.guildFolders = folders
            }
            if let pos = userSettings["guild_positions"] as? [String] {
                self.guildPositions = pos
            }
        }

        if let presences = payload["presences"] as? [[String: Any]] {
            for p in presences {
                if let u = p["user"] as? [String: Any], let uid = u["id"] as? String,
                   let status = p["status"] as? String {
                    presencesByUserId[uid] = status
                }
            }
        }

        NotificationCenter.default.post(name: .cordStoreDidUpdateGuilds, object: nil)
        NotificationCenter.default.post(name: .cordStoreDidUpdateCurrentUser, object: nil)
        NotificationCenter.default.post(name: .cordStoreDidUpdateVoiceStates, object: nil)
    }

    func gatewayDidReceiveMessageCreate(_ message: DiscordMessage) {
        usersById[message.author.id] = message.author
        for m in message.mentions ?? [] { usersById[m.id] = m }
        var list = messagesByChannel[message.channelId] ?? []
        if !list.contains(where: { $0.id == message.id }) {
            list.append(message)
            if list.count > 120 { list.removeFirst(list.count - 120) }
            messagesByChannel[message.channelId] = list
            NotificationCenter.default.post(name: .cordStoreDidReceiveMessage, object: message)
            notifyIfPingOrDM(message)
        }
    }


    func pollBackgroundNotifications(completion: @escaping (Bool) -> Void) {
        let lastKey = "cord12_last_bg_mention_id"
        let lastId = UserDefaults.standard.string(forKey: lastKey) ?? "0"
        rest.requestDecodable(path: "/users/@me/mentions?limit=5") { [weak self] (res: Result<[DiscordMessage], Error>) in
            guard let self = self else { completion(false); return }
            if case .success(let msgs) = res, let newest = msgs.first, (UInt64(newest.id) ?? 0) > (UInt64(lastId) ?? 0) {
                UserDefaults.standard.set(newest.id, forKey: lastKey)
                self.notifyIfPingOrDM(newest)
                completion(true)
            } else {
                completion(false)
            }
        }
    }

    private func notifyIfPingOrDM(_ message: DiscordMessage) {
        guard let myId = currentUser?.id, message.author.id != myId else { return }
        let isDM = (message.guildId == nil)
        let isMentioned = (message.mentionEveryone == true)
            || (message.mentions?.contains(where: { $0.id == myId }) == true)
            || message.content.contains("<@\(myId)>")
            || message.content.contains("<@!\(myId)>")
        guard isDM || isMentioned else { return }

        recentPings.insert(message, at: 0)
        if recentPings.count > 40 { recentPings.removeLast(recentPings.count - 40) }

        let content = UNMutableNotificationContent()
        if isDM {
            content.title = message.author.effectiveDisplayName
        } else {
            let gName = guilds.first(where: { $0.id == message.guildId })?.name ?? "Server"
            content.title = "\(message.author.effectiveDisplayName) in \(gName)"
        }
        content.body = message.content.isEmpty ? "Sent an attachment" : message.content
        content.sound = .default
        let req = UNNotificationRequest(identifier: "cord12_msg_\(message.id)", content: content, trigger: nil)
        UNUserNotificationCenter.current().add(req, withCompletionHandler: nil)
    }

    func gatewayDidReceiveMessageUpdate(_ message: DiscordMessage) {
        guard var list = messagesByChannel[message.channelId],
              let idx = list.firstIndex(where: { $0.id == message.id }) else { return }
        list[idx] = message
        messagesByChannel[message.channelId] = list
        NotificationCenter.default.post(name: .cordStoreDidUpdateMessage, object: message)
    }

    func gatewayDidReceiveMessageDelete(channelId: String, messageId: String) {
        guard var list = messagesByChannel[channelId] else { return }
        list.removeAll { $0.id == messageId }
        messagesByChannel[channelId] = list
        NotificationCenter.default.post(name: .cordStoreDidDeleteMessage, object: ["channelId": channelId, "messageId": messageId])
    }

    func gatewayDidReceiveReactionAdd(channelId: String, messageId: String, userId: String, emoji: DiscordEmoji) {
        guard var list = messagesByChannel[channelId],
              let idx = list.firstIndex(where: { $0.id == messageId }) else { return }
        var msg = list[idx]
        var reactions = msg.reactions ?? []
        let isMe = (userId == currentUser?.id)
        if let rIdx = reactions.firstIndex(where: { $0.emoji.apiIdentifier == emoji.apiIdentifier }) {
            reactions[rIdx].count += 1
            if isMe { reactions[rIdx].me = true }
        } else {
            reactions.append(DiscordReaction(count: 1, me: isMe, emoji: emoji))
        }
        msg.reactions = reactions
        list[idx] = msg
        messagesByChannel[channelId] = list
        NotificationCenter.default.post(name: .cordStoreDidUpdateMessage, object: msg)
    }

    func gatewayDidReceiveReactionRemove(channelId: String, messageId: String, userId: String, emoji: DiscordEmoji) {
        guard var list = messagesByChannel[channelId],
              let idx = list.firstIndex(where: { $0.id == messageId }) else { return }
        var msg = list[idx]
        var reactions = msg.reactions ?? []
        let isMe = (userId == currentUser?.id)
        if let rIdx = reactions.firstIndex(where: { $0.emoji.apiIdentifier == emoji.apiIdentifier }) {
            reactions[rIdx].count -= 1
            if isMe { reactions[rIdx].me = false }
            if reactions[rIdx].count <= 0 {
                reactions.remove(at: rIdx)
            }
        }
        msg.reactions = reactions
        list[idx] = msg
        messagesByChannel[channelId] = list
        NotificationCenter.default.post(name: .cordStoreDidUpdateMessage, object: msg)
    }

    func gatewayDidReceiveUserUpdate(_ user: DiscordUser) {
        currentUser = user
        usersById[user.id] = user
        NotificationCenter.default.post(name: .cordStoreDidUpdateCurrentUser, object: nil)
    }

    func gatewayDidReceiveUserSettingsUpdate(_ settings: DiscordUserSettings) {
        if let folders = settings.guildFolders { self.guildFolders = folders }
        if let pos = settings.guildPositions { self.guildPositions = pos }
        NotificationCenter.default.post(name: .cordStoreDidUpdateGuilds, object: nil)
    }

    func gatewayDidReceivePresenceUpdate(userId: String, status: String) {
        presencesByUserId[userId] = status
    }

    func gatewayDidReceiveTypingStart(channelId: String, userId: String) {
        guard userId != currentUser?.id else { return }
        NotificationCenter.default.post(name: .cordStoreDidReceiveTyping, object: ["channelId": channelId, "userId": userId])
    }

    func gatewayDidReceiveVoiceStateUpdate(_ state: VoiceState) {
        for (cid, var list) in voiceStatesByChannel {
            list.removeAll { $0.userId == state.userId }
            voiceStatesByChannel[cid] = list
        }
        if let cid = state.channelId {
            voiceStatesByChannel[cid, default: []].append(state)
        }
        if state.userId == currentUser?.id, let sid = state.sessionId {
            DiscordVoiceClient.shared.updateSessionId(sid)
        }
        NotificationCenter.default.post(name: .cordStoreDidUpdateVoiceStates, object: nil)
    }

    func gatewayDidReceiveVoiceServerUpdate(_ server: VoiceServerUpdate) {
        guard let endpoint = server.endpoint else { return }
        let sid = server.guildId ?? server.channelId ?? ""
        DiscordVoiceClient.shared.updateVoiceServer(endpoint: endpoint, token: server.token, serverId: sid)
    }

    func gatewayDidChangeState(connected: Bool) {
        isGatewayConnected = connected
        NotificationCenter.default.post(name: .cordStoreConnectionChanged, object: connected)
    }
}
