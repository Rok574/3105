import Foundation
import SwiftUI
import WebKit

struct AJWebViewContainer: UIViewRepresentable {
    @Binding var session: AJSession?
    @ObservedObject var coordinator: WebViewCoordinator

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let proxy = ProxyHandler()
        config.setURLSchemeHandler(proxy, forURLScheme: "ajproxy")

        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        config.defaultWebpagePreferences = prefs

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        
        coordinator.webView = webView

        // Load via HTTPS baseURL string instead of file:// to satisfy Ruffle's secure protocol checks
        let html = HTMLTemplate.playerHTML
        webView.loadHTMLString(html, baseURL: URL(string: "https://www.animaljam.com"))

        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, WKNavigationDelegate {
        var parent: AJWebViewContainer
        init(_ parent: AJWebViewContainer) { self.parent = parent }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            print("AJ Classic Ruffle wrapper loaded.")
        }
    }
}

struct HTMLTemplate {
    static let playerHTML = """
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <style>
            html, body { width: 100%; height: 100%; margin: 0; padding: 0; background-color: #1a1a1a; overflow: hidden; }
            #player-container { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; }
        </style>
        <script src="https://unpkg.com/@ruffle-rs/ruffle"></script>
    </head>
    <body>
        <div id="player-container"></div>
        <script>
            window.aj = window.aj || {
                ready: function() { console.log("AJ ExternalInterface: ready"); },
                login: function() {},
                logout: function() { console.log("AJ ExternalInterface: logout"); },
                reload: function() { location.reload(); },
                openExternalUrl: function(url) { console.log("External URL:", url); },
                getDF: function() { return window.__ajFlashvars ? window.__ajFlashvars.df : ""; }
            };

            window.startAJWithSession = function(flashvars, swfUrl, baseContentUrl, socketProxies) {
                window.__ajFlashvars = flashvars;
                const ruffle = window.RufflePlayer.newest();
                const container = document.getElementById("player-container");
                container.innerHTML = "";

                const player = ruffle.createPlayer();
                player.style.width = "100%";
                player.style.height = "100%";
                container.appendChild(player);

                player.load({
                    url: swfUrl,
                    base: baseContentUrl,
                    parameters: flashvars,
                    allowScriptAccess: "always",
                    allowNetworking: "all",
                    wmode: "direct",
                    letterbox: "on",
                    upgradeToHttps: false,
                    socketProxy: socketProxies || []
                });
            };
        </script>
    </body>
    </html>
    """
}
