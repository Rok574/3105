import SwiftUI

struct LoginControlBar: View {
    @State private var username: String = UserDefaults.standard.string(forKey: "aj_saved_user") ?? ""
    @State private var password: String = ""
    @State private var otp: String = ""
    @State private var needsOTP: Bool = false
    @State private var isLoading: Bool = false
    @State private var statusMessage: String = "Enter AJ Classic login"
    @Binding var useTLSSocket: Bool

    var onAuthenticated: (AJSession) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 8) {
                Text(statusMessage)
                    .font(.caption2)
                    .foregroundColor(.white.opacity(0.9))
                    .lineLimit(1)

                Spacer()

                Button(action: performLogin) {
                    if isLoading {
                        ProgressView().tint(.white).scaleEffect(0.8)
                    } else {
                        Text(needsOTP ? "Verify" : "Start")
                            .font(.caption)
                            .fontWeight(.bold)
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 5)
                .background(Color.green)
                .foregroundColor(.white)
                .clipShape(RoundedRectangle(cornerRadius: 6))
                .disabled(isLoading || username.isEmpty || password.isEmpty)
            }

            HStack(spacing: 6) {
                TextField("Username", text: $username)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .textFieldStyle(.roundedBorder)
                    .font(.caption)

                SecureField("Password", text: $password)
                    .textFieldStyle(.roundedBorder)
                    .font(.caption)

                if needsOTP {
                    TextField("2FA", text: $otp)
                        .keyboardType(.numberPad)
                        .frame(width: 64)
                        .textFieldStyle(.roundedBorder)
                        .font(.caption)
                }
            }
        }
        .padding(10)
        .background(Color.black.opacity(0.85))
    }

    private func performLogin() {
        isLoading = true
        statusMessage = "Authenticating..."

    Task {
            do {
                let session = try await AJAuthenticator.shared.login(
                    username: username,
                    password: password,
                    otp: needsOTP ? otp : nil
                )
                await MainActor.run {
                    UserDefaults.standard.set(username, forKey: "aj_saved_user")
                    needsOTP = false
                    otp = ""
                    isLoading = false
                    statusMessage = "Logged in: \(session.username)"
                    onAuthenticated(session)
                }
            } catch AJAuthError.otpRequired {
                await MainActor.run {
                    needsOTP = true
                    isLoading = false
                    statusMessage = "Enter 2FA code"
                }
            } catch {
                await MainActor.run {
                    isLoading = false
                    statusMessage = error.localizedDescription
                }
            }
        }
    }
}
