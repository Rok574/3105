import Foundation

/// Identity the AJ Classic client expects from its host app.
///
/// The SWF reads navigator.userAgent through ExternalInterface, extracts `AJClassic/x.y.z` and
/// compares it to a hard-coded minimum of 1.5.3 (Utility.isElectronVersionIncompatible). That
/// comparison splits both versions on "." and compares each part as a *string*, returning
/// "incompatible" if ANY part is lexicographically smaller. So the version must satisfy, per part:
///   major >= "1",  minor >= "5" (single digit 5-9),  patch >= "3" (single digit 3-9).
/// e.g. 1.6.4 passes, but 2.0.0 (minor "0" < "5"), 1.10.0 and 3.0.0 all trigger the
/// "The AJ Classic app needs to be updated!" popup. Keep this at a real, passing version.
/// Only `AJClassic/x.y.z` is parsed by the client; the Electron/Chrome numbers are cosmetic.
///
/// This is the single source of truth for every UA the app sends (page, proxy, auth).
enum AJEnv {
    static let appVersion = "1.6.4"
    static let electronVersion = "11.5.0"
    static let chromeVersion = "87.0.4280.141"

    static let userAgent =
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) " +
        "AJClassic/\(appVersion) Chrome/\(chromeVersion) Electron/\(electronVersion) Safari/537.36"
}
