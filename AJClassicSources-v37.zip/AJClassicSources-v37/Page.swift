import Foundation
import SwiftUI
import WebKit

struct AJWebViewContainer: UIViewRepresentable {
    @ObservedObject var coordinator: WebViewCoordinator

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        config.defaultWebpagePreferences = prefs
        config.mediaTypesRequiringUserActionForPlayback = []
        config.allowsInlineMediaPlayback = true

        // Register the console bridge BEFORE the page loads so early logs aren't lost.
        config.userContentController.add(context.coordinator, name: "consoleLog")

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.scrollView.backgroundColor = .black
        webView.scrollView.bounces = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        if #available(iOS 16.4, *) { webView.isInspectable = true }

        coordinator.webView = webView
        coordinator.pageLoaded = false
        webView.load(context.coordinator.request)

        let threeFingerHold = UILongPressGestureRecognizer(target: context.coordinator,
                                                           action: #selector(Coordinator.handleThreeFingerHold(_:)))
        threeFingerHold.numberOfTouchesRequired = 3
        threeFingerHold.minimumPressDuration = 0.5
        threeFingerHold.cancelsTouchesInView = false
        webView.addGestureRecognizer(threeFingerHold)

        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler {
        var parent: AJWebViewContainer
        var consoleWindow: UIWindow?
        var consoleTextView: UITextView?
        private var logBuffer: [String] = []
        private var retries = 0

        let request = URLRequest(url: URL(string: "http://127.0.0.1:\(LocalHTTPServer.port)/")!,
                                 cachePolicy: .reloadIgnoringLocalAndRemoteCacheData)

        init(_ parent: AJWebViewContainer) { self.parent = parent }

        // MARK: Navigation

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            retries = 0
            parent.coordinator.pageDidLoad()
        }

        // The local server may not be listening yet on a cold start -> retry instead of staying black.
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            retryLoad(webView, error: error)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            retryLoad(webView, error: error)
        }

        func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
            parent.coordinator.pageLoaded = false
            webView.load(request)
        }

        private func retryLoad(_ webView: WKWebView, error: Error) {
            appendLog("Page load failed: \(error.localizedDescription)")
            guard retries < 20 else { return }
            retries += 1
            parent.coordinator.pageLoaded = false
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak webView, request] in
                webView?.load(request)
            }
        }

        // MARK: Console

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            if message.name == "consoleLog", let text = message.body as? String {
                DispatchQueue.main.async { self.appendLog(text) }
            }
        }

        @objc func handleThreeFingerHold(_ gesture: UILongPressGestureRecognizer) {
            if gesture.state == .began { toggleConsole() }
        }

        func toggleConsole() {
            if let w = consoleWindow {
                w.isHidden = true
                consoleWindow = nil
                consoleTextView = nil
                return
            }

            guard let windowScene = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene }).first else { return }
            let width = windowScene.screen.bounds.width
            let win = UIWindow(windowScene: windowScene)
            win.frame = CGRect(x: 20, y: 50, width: width - 40, height: 350)
            win.windowLevel = .alert + 1
            win.backgroundColor = UIColor.black.withAlphaComponent(0.85)
            win.layer.cornerRadius = 12
            win.layer.borderWidth = 1
            win.layer.borderColor = UIColor.green.cgColor
            win.clipsToBounds = true

            let vc = UIViewController()
            vc.view.backgroundColor = .clear
            win.rootViewController = vc

            let tv = UITextView(frame: win.bounds.insetBy(dx: 10, dy: 10))
            tv.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            tv.backgroundColor = .clear
            tv.textColor = .green
            tv.font = UIFont.monospacedSystemFont(ofSize: 11, weight: .regular)
            tv.isEditable = false
            tv.text = "[Console - hold 3 fingers again to close]\n" + logBuffer.joined(separator: "\n")
            vc.view.addSubview(tv)

            win.isHidden = false
            consoleWindow = win
            consoleTextView = tv
            scrollToBottom()
        }

        func appendLog(_ text: String) {
            logBuffer.append(text)
            if logBuffer.count > 1500 { logBuffer.removeFirst(logBuffer.count - 1500) }
            guard let tv = consoleTextView else { return }
            tv.text += "\n" + text
            scrollToBottom()
        }

        private func scrollToBottom() {
            guard let tv = consoleTextView else { return }
            let len = (tv.text as NSString).length
            if len > 0 { tv.scrollRangeToVisible(NSRange(location: len - 1, length: 1)) }
        }
    }
}

struct HTMLTemplate {
    static let template = #"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
        <style>
            html, body { width: 100%; height: 100%; margin: 0; padding: 0; background-color: #000; overflow: hidden; touch-action: none; -webkit-user-select: none; }
            #player-container { width: 100%; height: 100%; position: absolute; top: 0; left: 0; }
            ruffle-player { display: block; }
            #ajload { position: fixed; left: 50%; top: 42%; transform: translate(-50%, -50%); z-index: 99990; pointer-events: none;
                      display: flex; flex-direction: column; align-items: center; gap: 10px; padding: 18px 26px; border-radius: 16px;
                      background: rgba(20, 30, 10, 0.78); color: #fff7cc; font: 600 15px -apple-system, Helvetica, sans-serif;
                      text-shadow: 0 1px 2px #000; transition: opacity .35s; }
            #ajload.hide { opacity: 0; }
            #ajload .spin { width: 46px; height: 46px; border-radius: 50%; border: 5px solid rgba(255, 224, 120, .25); border-top-color: #ffd34d;
                            animation: ajspin 0.9s linear infinite; }
            #ajload .sub { font-weight: 400; font-size: 12px; opacity: .85; }
            @keyframes ajspin { to { transform: rotate(360deg); } }
        </style>
        <script>
            // ---- Console -> native bridge ----
            (function () {
                var lines = [];
                window.__ajHadError = false;
                window.__ajShow = function (line) {
                    if (line !== null && line !== undefined) { lines.push(line); if (lines.length > 20) lines.shift(); }
                    var el = document.getElementById('ajstatus');
                    if (el) el.textContent = lines.join('\n');
                };
                window.__ajHide = function () {
                    var el = document.getElementById('ajstatus');
                    if (el) el.style.display = 'none';
                };
                function send(m) {
                    if (/^(ERROR|JS Exception|Unhandled)/.test(m)) window.__ajHadError = true;
                    try { window.__ajShow(m); } catch (e) {}
                    try { window.webkit.messageHandlers.consoleLog.postMessage(m); } catch (e) {}
                }
                ['log', 'info', 'warn', 'error', 'debug'].forEach(function (k) {
                    var orig = console[k];
                    console[k] = function () {
                        var msg = [].slice.call(arguments).map(function (x) {
                            try { return (typeof x === 'object') ? JSON.stringify(x) : String(x); } catch (e) { return String(x); }
                        }).join(' ');
                        send((k === 'log' ? '' : k.toUpperCase() + ': ') + msg);
                        try { orig.apply(console, arguments); } catch (e) {}
                    };
                });
                window.addEventListener('error', function (e) {
                    send('JS Exception: ' + e.message + ' @' + (e.filename || '') + ':' + (e.lineno || ''));
                });
                window.addEventListener('unhandledrejection', function (e) {
                    send('Unhandled rejection: ' + ((e.reason && e.reason.message) || e.reason));
                });
            })();


            // ---- Socket tap (v37): log what crosses the Ruffle <-> SmartFox WebSocket bridge (redacted) ----
            (function () {
                var OWS = window.WebSocket;
                if (!OWS) return;
                var dec = new TextDecoder('utf-8'), nWS = 0, nMsg = 0, nLines = 0, MAXLINES = 220, seen = {};
                window.__ajTapVerbose = false;
                function redact(s) {
                    return s.replace(/<pword>[\s\S]*?<\/pword>/gi, '<pword>[x]</pword>')
                            .replace(/<nick>[\s\S]*?<\/nick>/gi, '<nick>[x]</nick>')
                            .replace(/eyJ[\w-]{8,}\.[\w-]{8,}\.[\w-]{8,}/g, '[jwt]')
                            .replace(/(auth_token|refresh_token|password)(["'=:\s]+)[^"'&,\s<%]+/gi, '$1$2[x]');
                }
                function label(m) {
                    var f = m.split('%');
                    if (f.length > 4 && f[1] === 'xt') return 'xt ' + f[2] + ' ' + f[3] + ' room=' + f[4];
                    var a = /action=['"]([^'"]+)['"]/.exec(m);
                    if (a) return 'sys ' + a[1];
                    return m.charAt(0) === '<' ? 'xml' : (m.charAt(0) === '{' ? 'json' : 'other');
                }
                function preview(m, lab) {
                    if (window.__ajTapVerbose) return redact(m).slice(0, 400);
                    if (/ xt /.test(lab)) return /sm|chat|msg|pm|say|whisper|mail|buddy/i.test(lab) ? '' : redact(m).slice(0, 48);  // never echo chat text
                    return redact(m).slice(0, 110);
                }
                function tap(id, dir, d) {
                    var u8;
                    if (typeof d === 'string') u8 = new TextEncoder().encode(d);
                    else if (d instanceof ArrayBuffer) u8 = new Uint8Array(d);
                    else if (ArrayBuffer.isView(d)) u8 = new Uint8Array(d.buffer, d.byteOffset, d.byteLength);
                    else return;
                    var parts = dec.decode(u8).split('\0');
                    for (var i = 0; i < parts.length; i++) {
                        var m = parts[i];
                        if (!m) continue;
                        nMsg++;
                        var lab = dir + ' ' + label(m), first = !seen[lab];
                        seen[lab] = (seen[lab] || 0) + 1;
                        if (!(first || window.__ajTapVerbose) && nLines >= MAXLINES) continue;
                        if (!first && !window.__ajTapVerbose && seen[lab] % 25 !== 0 && nLines >= 60) continue;
                        nLines++;
                        console.log('WS#' + id + ' ' + lab + ' ' + m.length + 'B' + (seen[lab] > 1 ? ' (x' + seen[lab] + ')' : '') +
                                    ' ' + preview(m, lab) + (i === parts.length - 1 && u8.length && u8[u8.length - 1] !== 0 ? ' [partial]' : ''));
                    }
                }
                window.WebSocket = function (url, protocols) {
                    var ws = (protocols === undefined) ? new OWS(url) : new OWS(url, protocols);
                    if (String(url).indexOf('127.0.0.1') === -1) return ws;
                    var id = ++nWS;
                    console.log('WS#' + id + ' connecting ' + url);
                    ws.addEventListener('open', function () { console.log('WS#' + id + ' open'); });
                    ws.addEventListener('error', function () { console.log('WS#' + id + ' ERROR (bridge unreachable?)'); });
                    ws.addEventListener('close', function (e) { console.log('WS#' + id + ' closed code=' + e.code + ' clean=' + e.wasClean + ' totalMsgs=' + nMsg); });
                    ws.addEventListener('message', function (e) { tap(id, '<-', e.data); });
                    var os = ws.send;
                    ws.send = function (d) { try { tap(id, '->', d); } catch (e) {} return os.apply(ws, arguments); };
                    return ws;
                };
                window.WebSocket.prototype = OWS.prototype;
                ['CONNECTING', 'OPEN', 'CLOSING', 'CLOSED'].forEach(function (k) { try { window.WebSocket[k] = OWS[k]; } catch (e) {} });
            })();

            // ---- ExternalInterface host bridge: log + auto-stub every JS name the SWF calls ----
            var AJ_UA = "__AJ_UA__";
            (function () {
                var seen = {}, n = 0, F = window.Function;
                function resolve(path) {
                    var cur = window, parts = path.split('.');
                    for (var i = 0; i < parts.length; i++) {
                        if (cur === undefined || cur === null) return undefined;
                        cur = cur[parts[i]];
                    }
                    return cur;
                }
                function ensure(path) {
                    if (resolve(path) !== undefined) return;
                    var parts = path.split('.'), cur = window;
                    for (var i = 0; i < parts.length - 1; i++) {
                        if (cur[parts[i]] === undefined || cur[parts[i]] === null) cur[parts[i]] = {};
                        cur = cur[parts[i]];
                    }
                    var last = parts[parts.length - 1], hits = 0;
                    cur[last] = function () {
                        if (hits++ < 3) {
                            var a = ''; try { a = JSON.stringify([].slice.call(arguments)).slice(0, 120); } catch (e) {}
                            console.log('HOSTCALL ' + path + '(' + a + ')');
                        }
                        return null;
                    };
                    console.log('STUBBED ' + path);
                }
                function note(args) {
                    try {
                        var b = String(args[args.length - 1] || '');
                        if (!/^\s*return\s/.test(b) || b.length > 140) return;
                        var m = b.match(/^\s*return\s*\(?\s*([A-Za-z_$][\w$]*(?:\.[\w$]+)*)\s*\)?\s*\(/);
                        if (m && !seen[m[1]]) {
                            seen[m[1]] = 1;
                            if (n++ < 80) console.log('FN: ' + m[1]);
                            ensure(m[1]);
                        }
                    } catch (e) {}
                }
                try {
                    window.Function = new Proxy(F, {
                        construct: function (t, a, nt) { note(a); return Reflect.construct(t, a, nt); },
                        apply: function (t, th, a) { note(a); return Reflect.apply(t, th, a); }
                    });
                } catch (e) { console.warn('Function spy unavailable: ' + e); }

                // Present a desktop AJ Classic user-agent to the SWF. Applied only right before the
                // SWF loads, so Ruffle's own mobile detection (done at init) is unaffected.
                window.__ajSpoofUA = function () {
                    function def(o) { Object.defineProperty(o, 'userAgent', { get: function () { return AJ_UA; }, configurable: true }); }
                    try { def(Navigator.prototype); } catch (e) { try { def(navigator); } catch (e2) { console.error('UA spoof failed: ' + e2); } }
                    console.log('UA now: ' + navigator.userAgent);
                };
                // Analytics hooks the client calls; silently accept.
                window.mrc = window.mrc || function () { return null; };
                window.handleGAEvent = window.handleGAEvent || function () { return null; };
            })();

            // ---- Route cross-origin game requests through the local proxy (adds CORS) ----
            (function () {
                var ORIGIN = location.origin;
                var DIRECT_HOSTS = ['unpkg.com', 'cdn.jsdelivr.net'];
                function rewrite(u) {
                    try {
                        var abs = new URL(u, location.href);
                        if (abs.protocol !== 'http:' && abs.protocol !== 'https:') return u;
                        if (abs.origin === ORIGIN) return u;
                        if (DIRECT_HOSTS.indexOf(abs.hostname) !== -1) return u;
                        return ORIGIN + '/proxy/' + abs.protocol.slice(0, -1) + '/' + abs.host + abs.pathname + abs.search;
                    } catch (e) { return u; }
                }
                window.__ajRewrite = rewrite;

                // ---- Network trace (diagnostic): URL, status, size, first bytes, zlib/gzip sniff ----
                var __netN = 0;
                window.__ajNet = window.__ajNet || { pending: 0, bytes: 0, done: 0, last: Date.now() };
                function netStart() { window.__ajNet.pending++; window.__ajNet.last = Date.now(); }
                function netEnd(n) { var N = window.__ajNet; N.pending = Math.max(0, N.pending - 1); N.done++; N.bytes += n || 0; N.last = Date.now(); }
                function hex(u8, n) { var o = []; for (var i = 0; i < Math.min(n, u8.length); i++) o.push((u8[i] < 16 ? '0' : '') + u8[i].toString(16)); return o.join(' '); }
                function sniff(u8) {
                    if (u8.length >= 2 && u8[0] === 0x1f && u8[1] === 0x8b) return 'GZIP';
                    if (u8.length >= 2 && (u8[0] & 0x0f) === 8 && (((u8[0] << 8) | u8[1]) % 31) === 0) return 'ZLIB';
                    if (u8.length >= 3 && /^(FWS|CWS|ZWS)$/.test(String.fromCharCode(u8[0], u8[1], u8[2]))) return 'SWF';
                    var t = ''; for (var i = 0; i < Math.min(8, u8.length); i++) t += String.fromCharCode(u8[i]);
                    if (/^\s*[<{\[]/.test(t)) return 'TEXT';
                    return 'BIN?';
                }
                var __netSeen = {};
                function traceNet(kind, url, status, buf, extra) {
                    try {
                        netEnd(buf ? buf.byteLength : 0);
                        var rep = __netSeen[url] = (__netSeen[url] || 0) + 1;
                        // Collapse repeated successful fetches of the same URL (Ruffle refetches imports a lot):
                        // only log the 1st, 2nd, 5th, 10th, 25th, 50th, 100th time, with a repeat count.
                        if (rep > 1 && status === 200 && [2, 5, 10, 25, 50, 100].indexOf(rep) === -1) return;
                        extra = (extra || '') + (rep > 1 ? ' (x' + rep + ')' : '');
                        var id = ++__netN, u8 = buf ? new Uint8Array(buf) : new Uint8Array(0);
                        var short = String(url).replace(/^https?:\/\/[^\/]+\/proxy\//, '');
                        window.__ajNetLog = window.__ajNetLog || [];
                        window.__ajNetLog.push({ id: id, kind: kind, url: url, status: status, len: u8.length });
                        console.log('NET#' + id + ' ' + kind + ' ' + status + ' ' + u8.length + 'B ' + sniff(u8) + ' [' + hex(u8, 6) + '] ' + short.slice(0, 90) + (extra ? ' ' + extra : ''));
                    } catch (e) {}
                }
                window.__ajDumpNet = function () { console.log('NETLOG ' + JSON.stringify(window.__ajNetLog || [])); };

                // ---- Defpack / roomDef diagnostics + inflate workaround (v34) ----
                var AJ_REWRAP_DEFPACKS = false;
                function nativeInflate(u8, fmt) {
                    var ds = new DecompressionStream(fmt);
                    var w = ds.writable.getWriter();
                    w.write(u8).catch(function () {});
                    w.close().catch(function () {});
                    return new Response(ds.readable).arrayBuffer();
                }
                function storedDeflate(u8) {
                    var CH = 65535, n = Math.max(1, Math.ceil(u8.length / CH));
                    var out = new Uint8Array(u8.length + n * 5), o = 0;
                    for (var i = 0; i < n; i++) {
                        var s = i * CH, len = Math.min(CH, u8.length - s);
                        out[o++] = (i === n - 1) ? 1 : 0;
                        out[o++] = len & 255; out[o++] = len >> 8;
                        out[o++] = (~len) & 255; out[o++] = ((~len) >> 8) & 255;
                        out.set(u8.subarray(s, s + len), o); o += len;
                    }
                    return out;
                }
                function findAscii(u8, word) {
                    var c0 = word.charCodeAt(0), L = word.length;
                    outer: for (var i = 0, e = u8.length - L; i <= e; i++) {
                        if (u8[i] !== c0) continue;
                        for (var j = 1; j < L; j++) if (u8[i + j] !== word.charCodeAt(j)) continue outer;
                        return i;
                    }
                    return -1;
                }
                function ajAscii(u8, n) { var s = ''; for (var i = 0; i < Math.min(n, u8.length); i++) { var c = u8[i]; s += (c >= 32 && c < 127) ? String.fromCharCode(c) : '.'; } return s; }
                function ajStats(u8) {
                    var n = Math.min(u8.length, 65536), cnt = [], pr = 0, i, H = 0;
                    for (i = 0; i < 256; i++) cnt.push(0);
                    for (i = 0; i < n; i++) { cnt[u8[i]]++; if (u8[i] >= 32 && u8[i] < 127) pr++; }
                    for (i = 0; i < 256; i++) if (cnt[i]) { var p = cnt[i] / n; H -= p * Math.log(p) / Math.log(2); }
                    var top = cnt.map(function (v, k) { return [k, v]; }).sort(function (a, b) { return b[1] - a[1]; }).slice(0, 6).map(function (x) { return x[0].toString(16) + ':' + x[1]; }).join(' ');
                    return 'entropy ' + H.toFixed(2) + ' bits/byte, printable ' + Math.round(100 * pr / n) + '%, top bytes ' + top;
                }
                function ajStrings(u8, limit) {
                    var out = [], cur = '';
                    for (var i = 0; i < Math.min(u8.length, 16384) && out.length < limit; i++) {
                        var c = u8[i];
                        if (c >= 32 && c < 127) cur += String.fromCharCode(c);
                        else { if (cur.length >= 4) out.push(cur); cur = ''; }
                    }
                    return out;
                }
                function ajIsB64(u8) {
                    for (var i = 0; i < u8.length; i++) {
                        var c = u8[i];
                        if (!((c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 43 || c === 47 || c === 61 || c === 10 || c === 13 || c === 32)) return false;
                    }
                    return true;
                }
                function ajDumpUnknown(id, u8) {
                    var t = 'UNKNOWN ' + id + ' ';
                    console.log(t + ajStats(u8));
                    console.log(t + 'hex ' + hex(u8, 48));
                    console.log(t + 'ascii ' + ajAscii(u8, 96));
                    var tries = [['deflate', 0], ['gzip', 0]];
                    for (var k = 1; k <= 12; k++) tries.push(['deflate-raw', k]);
                    tries.forEach(function (x) {
                        nativeInflate(u8.subarray(x[1]), x[0]).then(function (raw) {
                            console.log(t + 'decodes as ' + x[0] + ' after skipping ' + x[1] + ' bytes -> ' + raw.byteLength + 'B');
                        }, function () {});
                    });
                    if (ajIsB64(u8)) {
                        try {
                            var s = '';
                            for (var i = 0; i < u8.length; i++) { var c = u8[i]; if (c !== 10 && c !== 13 && c !== 32) s += String.fromCharCode(c); }
                            var bin = atob(s), b = new Uint8Array(bin.length);
                            for (var j = 0; j < bin.length; j++) b[j] = bin.charCodeAt(j);
                            console.log(t + 'is base64 -> ' + b.length + 'B, hex ' + hex(b, 16));
                            ['deflate-raw', 'deflate'].forEach(function (f) {
                                nativeInflate(b, f).then(function (raw) { console.log(t + 'base64 then ' + f + ' OK -> ' + raw.byteLength + 'B'); }, function () {});
                            });
                        } catch (e) { console.log(t + 'base64 decode failed: ' + e); }
                    }
                }
                // ---- In-memory cache for sharedFonts.swf (Ruffle re-fetches it for every layer SWF that imports it) ----
                var AJ_CACHE = {};
                function ajCacheKey(url) { return url.indexOf('/sharedFonts.swf') !== -1 ? url.split('?')[0] : null; }
                function ajFromCache(url) {
                    var k = ajCacheKey(url), h = k && AJ_CACHE[k];
                    if (!h) return null;
                    var r = new Response(h.buf.slice(0), { status: 200, headers: { 'Content-Type': h.type } });
                    try { Object.defineProperty(r, 'url', { value: url }); } catch (e) {}
                    return Promise.resolve(r);
                }
                function ajToCache(url, resp) {
                    var k = ajCacheKey(url);
                    if (!k || !resp.ok || AJ_CACHE[k]) return resp;
                    resp.clone().arrayBuffer().then(function (b) {
                        AJ_CACHE[k] = { buf: b, type: resp.headers.get('content-type') || 'application/x-shockwave-flash' };
                        console.log('CACHED ' + k.slice(-30) + ' ' + b.byteLength + 'B (later requests served from memory)');
                    }, function () {});
                    return resp;
                }

                // ---- AMF3 inspector (v37): parse the inflated roomDef ourselves so we can tell "bad data" from "Ruffle can't read it" ----
                function ajAmf3Summary(u8) {
                    var p = 0, strs = [], objs = [], traits = [], classes = {}, keyCount = {}, assets = [], st = { arrays: 0, objects: 0, bytes: 0 };
                    var dec = new TextDecoder(), dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
                    function b() { if (p >= u8.length) throw new Error('unexpected end at ' + p); return u8[p++]; }
                    function u29() { var n = 0, i = 0, c; for (; i < 3; i++) { c = b(); if (!(c & 128)) return (n << 7) | c; n = (n << 7) | (c & 127); } return (n << 8) | b(); }
                    function str() {
                        var h = u29();
                        if (!(h & 1)) { if ((h >> 1) >= strs.length) throw new Error('bad string ref at ' + p); return strs[h >> 1]; }
                        var l = h >> 1; if (!l) return '';
                        if (p + l > u8.length) throw new Error('string overruns data at ' + p);
                        var s = dec.decode(u8.subarray(p, p + l)); p += l; strs.push(s); return s;
                    }
                    function ref(h) { if ((h >> 1) >= objs.length) throw new Error('bad object ref at ' + p); return objs[h >> 1]; }
                    function val(depth) {
                        if (depth > 200) throw new Error('nesting too deep at ' + p);
                        var t = b(), h, n, i, k, o, a;
                        switch (t) {
                            case 0: case 1: return null;
                            case 2: return false;
                            case 3: return true;
                            case 4: n = u29(); return n > 0x0FFFFFFF ? n - 0x20000000 : n;
                            case 5: n = dv.getFloat64(p); p += 8; return n;
                            case 6: return str();
                            case 7: case 11: h = u29(); if (!(h & 1)) return ref(h); p += h >> 1; objs.push('[xml]'); return '[xml]';
                            case 8: h = u29(); if (!(h & 1)) return ref(h); p += 8; objs.push('[date]'); return '[date]';
                            case 9:
                                h = u29(); if (!(h & 1)) return ref(h);
                                n = h >> 1; a = []; objs.push(a); st.arrays++;
                                for (;;) { k = str(); if (k === '') break; a[k] = val(depth + 1); }
                                for (i = 0; i < n; i++) a.push(val(depth + 1));
                                return a;
                            case 10:
                                h = u29(); if (!(h & 1)) return ref(h);
                                var tr;
                                if (!(h & 2)) { tr = traits[h >> 2]; if (!tr) throw new Error('bad traits ref at ' + p); }
                                else {
                                    if (h & 4) throw new Error('externalizable object at ' + p + ' (Ruffle needs a registered class for this)');
                                    tr = { dyn: !!(h & 8), names: [], cls: '' };
                                    n = h >> 4; tr.cls = str();
                                    for (i = 0; i < n; i++) tr.names.push(str());
                                    traits.push(tr);
                                }
                                o = {}; objs.push(o); st.objects++;
                                if (tr.cls) classes[tr.cls] = (classes[tr.cls] || 0) + 1;
                                for (i = 0; i < tr.names.length; i++) { k = tr.names[i]; keyCount[k] = (keyCount[k] || 0) + 1; o[k] = val(depth + 1); }
                                if (tr.dyn) for (;;) { k = str(); if (k === '') break; keyCount[k] = (keyCount[k] || 0) + 1; o[k] = val(depth + 1); }
                                if (typeof o.assetName === 'string' && assets.length < 400) assets.push(o.assetName);
                                return o;
                            case 12: h = u29(); if (!(h & 1)) return ref(h); n = h >> 1; if (p + n > u8.length) throw new Error('bytearray overruns data at ' + p); p += n; st.bytes += n; objs.push('[bytes]'); return '[bytes]';
                            case 13: case 14: case 15: case 16:
                                h = u29(); if (!(h & 1)) return ref(h);
                                n = h >> 1; b(); a = []; objs.push(a);
                                if (t === 16) str();
                                for (i = 0; i < n; i++) { if (t === 16) a.push(val(depth + 1)); else p += (t === 15 ? 8 : 4); }
                                return a;
                            case 17: h = u29(); if (!(h & 1)) return ref(h); n = h >> 1; b(); a = []; objs.push(a); for (i = 0; i < n; i++) { val(depth + 1); val(depth + 1); } return a;
                            default: throw new Error('unknown marker 0x' + t.toString(16) + ' at ' + (p - 1));
                        }
                    }
                    var root = val(0), rk = (root && typeof root === 'object') ? Object.keys(root) : [];
                    var cls = Object.keys(classes).map(function (k) { return k + ':' + classes[k]; }).join(',');
                    var uniq = {}, an = assets.filter(function (x) { return uniq[x] ? false : (uniq[x] = 1); });
                    return 'parsed OK, ' + (p === u8.length ? 'consumed all ' + p + 'B' : 'STOPPED at ' + p + ' of ' + u8.length + 'B') +
                        '; root keys [' + rk.slice(0, 12).join(',') + '], objects ' + st.objects + ', arrays ' + st.arrays + ', embedded bytes ' + st.bytes +
                        '; typed classes {' + cls + '}; "stages" key ' + (keyCount.stages ? 'PRESENT x' + keyCount.stages : 'absent') +
                        '; ' + an.length + ' assetNames: ' + an.slice(0, 8).join(' | ');
                }

                function ajPostFetch(url, resp) {
                    var isDef = url.indexOf('/defPacks/') !== -1, isRoom = url.indexOf('/roomDefs/') !== -1;
                    if (!(isDef || isRoom) || !resp.ok || typeof DecompressionStream === 'undefined') return resp;
                    var id = url.split('?')[0].split('/').pop().slice(0, 8);
                    var tag = isDef ? 'DEFPACK ' : 'ROOMDEF ';
                    return resp.clone().arrayBuffer().then(function (buf) {
                        var u8 = new Uint8Array(buf);
                        return nativeInflate(u8, isDef ? 'deflate-raw' : 'deflate').then(function (raw) {
                            var r8 = new Uint8Array(raw);
                            if (isRoom) {
                                var head = '';
                                for (var i = 0; i < Math.min(40, r8.length); i++) { var c = r8[i]; head += (c >= 32 && c < 127) ? String.fromCharCode(c) : '.'; }
                                console.log(tag + id + ' native inflate OK ' + u8.length + 'B -> ' + r8.length + 'B, head "' + head + '", "stages" at ' + findAscii(r8, 'stages'));
                                console.log(tag + id + ' strings: ' + ajStrings(r8, 40).join(' | '));
                                try { console.log(tag + id + ' AMF3 ' + ajAmf3Summary(r8)); }
                                catch (e) { console.log(tag + id + ' AMF3 parse FAILED: ' + e.message); }
                                return resp;
                            }
                            console.log(tag + id + ' native inflate OK ' + u8.length + 'B -> ' + r8.length + 'B');
                            if (!AJ_REWRAP_DEFPACKS) return resp;
                            var out = new Response(storedDeflate(r8), { status: 200, headers: { 'Content-Type': 'application/octet-stream' } });
                            try { Object.defineProperty(out, 'url', { value: resp.url }); } catch (e) {}
                            return out;
                        }, function (err) {
                            console.log(tag + id + ' native inflate FAILED (' + u8.length + 'B, first ' + hex(u8, 4) + '): ' + err);
                            if (isDef) ajDumpUnknown(id, u8);
                            return resp;
                        });
                    }, function () { return resp; });
                }

                var origFetch = window.fetch;
                window.fetch = function (input, init) {
                    try {
                        if (typeof input === 'string' || (window.URL && input instanceof URL)) {
                            var ru = rewrite(String(input));
                            var cachedS = ajFromCache(ru); if (cachedS) return cachedS;
                            var pr = origFetch.call(this, ru, init);
                            if (ru.indexOf('/proxy/') !== -1) {
                                netStart();
                                pr.then(function (resp) {
                                    try { resp.clone().arrayBuffer().then(function (b) { traceNet('fetch', ru, resp.status, b, resp.headers.get('content-type') || ''); }, function () { netEnd(0); }); } catch (e) { netEnd(0); }
                                }, function (err) { netEnd(0); console.log('NET fetch FAILED ' + ru + ' ' + err); });
                            }
                            return (ru.indexOf('/proxy/') !== -1) ? pr.then(function (r) { return ajPostFetch(ru, r); }).then(function (r) { return ajToCache(ru, r); }) : pr;
                        }
                        if (window.Request && input instanceof Request) {
                            var nu = rewrite(input.url);
                            var cachedR = ajFromCache(nu); if (cachedR) return cachedR;
                            var rq = (nu !== input.url) ? new Request(nu, input) : input;
                            var rp = origFetch.call(this, rq, init);
                            if (nu.indexOf('/proxy/') !== -1) {
                                netStart();
                                rp.then(function (resp) {
                                    try { resp.clone().arrayBuffer().then(function (b) { traceNet('fetch(req)', nu, resp.status, b, resp.headers.get('content-type') || ''); }, function () { netEnd(0); }); } catch (e) { netEnd(0); }
                                }, function (err) { netEnd(0); console.log('NET fetch(req) FAILED ' + nu + ' ' + err); });
                            }
                            return (nu.indexOf('/proxy/') !== -1) ? rp.then(function (r) { return ajPostFetch(nu, r); }).then(function (r) { return ajToCache(nu, r); }) : rp;
                        }
                    } catch (e) { console.error('fetch rewrite failed: ' + e); }
                    return origFetch.call(this, input, init);
                };

                var origOpen = XMLHttpRequest.prototype.open;
                XMLHttpRequest.prototype.open = function (method, url) {
                    var args = [].slice.call(arguments);
                    args[1] = rewrite(String(url));
                    var xu = args[1], xhr = this;
                    if (xu.indexOf('/proxy/') !== -1) {
                        netStart();
                        xhr.addEventListener('loadend', function () {
                            try {
                                var r = xhr.response, b = null;
                                if (r instanceof ArrayBuffer) b = r;
                                else if (typeof r === 'string') b = new TextEncoder().encode(r).buffer;
                                traceNet('xhr', xu, xhr.status, b, xhr.responseType || 'text');
                            } catch (e) {}
                        });
                    }
                    return origOpen.apply(this, args);
                };
            })();

            // ---- Ruffle config + loader with CDN fallback ----
            window.RufflePlayer = window.RufflePlayer || {};
            window.RufflePlayer.config = {
                autoplay: "on",
                unmuteOverlay: "hidden",
                splashScreen: false,
                allowScriptAccess: true,
                warnOnUnsupportedContent: false,
                letterbox: "on",
                upgradeToHttps: false,
                quality: "medium",
                backgroundColor: "#000000"
            };

            (function loadRuffle(urls, i) {
                if (i >= urls.length) { console.error('Ruffle failed to load from every CDN (check internet connection).'); return; }
                var s = document.createElement('script');
                s.src = urls[i];
                s.onload = function () { console.log('Ruffle loaded from ' + urls[i]); };
                s.onerror = function () {
                    console.warn('Ruffle CDN failed: ' + urls[i]);
                    loadRuffle(urls, i + 1);
                };
                document.head.appendChild(s);
            })([
                'https://unpkg.com/@ruffle-rs/ruffle',
                'https://cdn.jsdelivr.net/npm/@ruffle-rs/ruffle'
            ], 0);
        </script>
        <script>
            // ---- Minimal LZMA decoder (SWF "ZWS") ----
            function lzmaDecode(props, input, inOff, outSize) {
              var d = props[0], lc = d % 9; d = (d / 9) | 0; var lp = d % 5, pb = (d / 5) | 0;
              var out = new Uint8Array(outSize), outPos = 0, pos = inOff;
              var range = 4294967295, code = 0;
              if (input[pos++] !== 0) throw new Error('bad lzma stream');
              for (var i = 0; i < 4; i++) code = code * 256 + input[pos++];
              function mk(n) { var a = new Uint16Array(n); a.fill(1024); return a; }
              var isMatch = mk(192), isRep = mk(12), isRepG0 = mk(12), isRepG1 = mk(12), isRepG2 = mk(12), isRep0Long = mk(192);
              var posSlotP = mk(256), specPos = mk(115), align = mk(16);
              function mkLen() { return { c: mk(2), low: mk(128), mid: mk(128), high: mk(256) }; }
              var lenDec = mkLen(), repLen = mkLen();
              var lit = mk(0x300 << (lc + lp));
              function norm() { if (range < 16777216) { range *= 256; code = code * 256 + input[pos++]; } }
              function bit(p, i) {
                var pr = p[i], bound = (range >>> 11) * pr, b;
                if (code < bound) { range = bound; p[i] = pr + ((2048 - pr) >>> 5); b = 0; }
                else { range -= bound; code -= bound; p[i] = pr - (pr >>> 5); b = 1; }
                norm(); return b;
              }
              function direct(n) {
                var r = 0;
                while (n--) { range = Math.floor(range / 2); var b = 0; if (code >= range) { code -= range; b = 1; } r = r * 2 + b; norm(); }
                return r;
              }
              function tree(p, off, n) { var m = 1; for (var i = 0; i < n; i++) m = (m << 1) + bit(p, off + m); return m - (1 << n); }
              function rtree(p, off, n) { var m = 1, s = 0; for (var i = 0; i < n; i++) { var b = bit(p, off + m); m = (m << 1) + b; s |= b << i; } return s; }
              function len(L, ps) {
                if (!bit(L.c, 0)) return tree(L.low, ps << 3, 3);
                if (!bit(L.c, 1)) return 8 + tree(L.mid, ps << 3, 3);
                return 16 + tree(L.high, 0, 8);
              }
              function dist(l) {
                var ls = l < 4 ? l : 3, slot = tree(posSlotP, ls << 6, 6);
                if (slot < 4) return slot;
                var nd = (slot >> 1) - 1, dd = (2 | (slot & 1)) * Math.pow(2, nd);
                if (slot < 14) return dd + rtree(specPos, dd - slot, nd);
                return dd + direct(nd - 4) * 16 + rtree(align, 0, 4);
              }
              var state = 0, rep0 = 0, rep1 = 0, rep2 = 0, rep3 = 0;
              while (outPos < outSize) {
                var ps = outPos & ((1 << pb) - 1);
                if (!bit(isMatch, (state << 4) + ps)) {
                  var prev = outPos > 0 ? out[outPos - 1] : 0;
                  var base = 0x300 * (((outPos & ((1 << lp) - 1)) << lc) + (prev >> (8 - lc)));
                  var sym = 1;
                  if (state >= 7) {
                    var mb = out[outPos - rep0 - 1];
                    do {
                      var mbit = (mb >> 7) & 1; mb <<= 1;
                      var b = bit(lit, base + ((1 + mbit) << 8) + sym);
                      sym = (sym << 1) | b;
                      if (mbit !== b) break;
                    } while (sym < 0x100);
                  }
                  while (sym < 0x100) sym = (sym << 1) | bit(lit, base + sym);
                  out[outPos++] = sym & 255;
                  state = state < 4 ? 0 : (state < 10 ? state - 3 : state - 6);
                  continue;
                }
                var l;
                if (bit(isRep, state)) {
                  if (outPos === 0) throw new Error('lzma: bad rep');
                  if (!bit(isRepG0, state)) {
                    if (!bit(isRep0Long, (state << 4) + ps)) {
                      state = state < 7 ? 9 : 11; out[outPos] = out[outPos - rep0 - 1]; outPos++; continue;
                    }
                  } else {
                    var dd;
                    if (!bit(isRepG1, state)) dd = rep1;
                    else { if (!bit(isRepG2, state)) dd = rep2; else { dd = rep3; rep3 = rep2; } rep2 = rep1; }
                    rep1 = rep0; rep0 = dd;
                  }
                  l = len(repLen, ps); state = state < 7 ? 8 : 11;
                } else {
                  rep3 = rep2; rep2 = rep1; rep1 = rep0;
                  l = len(lenDec, ps); state = state < 7 ? 7 : 10;
                  rep0 = dist(l);
                  if (rep0 === 4294967295) break;
                }
                l += 2;
                if (rep0 >= outPos) throw new Error('lzma: bad distance');
                for (var k = 0; k < l && outPos < outSize; k++) { out[outPos] = out[outPos - rep0 - 1]; outPos++; }
              }
              if (outPos !== outSize) throw new Error('lzma: short output');
              return out;
            }

            // ---- SWF patch: flash.net.SecureSocket -> flash.net.Socket (AIR-only class missing in Ruffle) ----
            window.__ajAbcStrings = window.__ajAbcStrings || [];
            function patchAbcStrings(abc, from, to) {
              var p = 4;
              function vr() { var r = 0, s = 0, b; do { b = abc[p++]; r += (b & 127) * Math.pow(2, s); s += 7; } while (b & 128); return r; }
              var n = vr(); for (var i = 1; i < n; i++) vr();            // ints
              n = vr(); for (i = 1; i < n; i++) vr();                    // uints
              n = vr(); p += n > 1 ? (n - 1) * 8 : 0;                    // doubles
              var strCount = vr(), dec = new TextDecoder(), enc = new TextEncoder();
              var repl = enc.encode(to), hitStart = -1, hitEnd = -1;
              for (i = 1; i < strCount; i++) {
                var start = p, l = vr(), bodyStart = p;
                p += l;
                var str = dec.decode(abc.subarray(bodyStart, bodyStart + l));
                window.__ajAbcStrings.push(str);
                if (hitStart < 0 && str === from) { hitStart = start; hitEnd = p; }
              }
              if (hitStart < 0) return null;
              var lenBytes = [repl.length]; // < 128
              var out = new Uint8Array(abc.length - (hitEnd - hitStart) + lenBytes.length + repl.length);
              out.set(abc.subarray(0, hitStart), 0);
              out.set(lenBytes, hitStart);
              out.set(repl, hitStart + lenBytes.length);
              out.set(abc.subarray(hitEnd), hitStart + lenBytes.length + repl.length);
              return out;
            }

            // ---- SWF bytecode patches (same-length, so no offsets/exception tables move) ----
            // Located by byte signature (multiname indexes are wildcarded); verified to match exactly once
            // in ajclient.swf build 1830.
            //  1. SmartFoxClient.isSecureSocketSupported() reads SecureSocket.isSupported. After the
            //     SecureSocket->Socket rename that property does not exist, so connect() aborts with
            //     "Could not connect to Animal Jam [2097409]". Make the method just `return true`.
            //  2. SmartFoxClient.handleSocketConnection() pins the TLS certificate via
            //     SecureSocket.serverCertificate, which a plain Socket does not have (the native bridge
            //     already does the TLS). Force that `if` to be false so the pin check is skipped.
            var __U = '(?:[\\x80-\\xff]{0,4}[\\x00-\\x7f])';
            var RE_SUPPORTED = new RegExp('\\xd0\\x30\\x60' + __U + '\\x66' + __U + '\\x2a\\x12[\\s\\S]{3}\\x29\\x5d' + __U + '\\x46' + __U + '\\x00\\x76\\x48');
            var RE_CERTPIN = new RegExp('(\\x60' + __U + '\\x96\\x2a\\x12[\\s\\S]{3}\\x29)(\\x60' + __U + '\\x60' + __U + '\\xb3)(?=\\x12[\\s\\S]{3}\\x60' + __U + '\\x60' + __U + '\\x87\\x80' + __U + '\\xd7\\xd3\\x66' + __U + '\\x20\\x14)');
            // 3-5. LoadProgress.startLoad()/loadCompleteHandler()/loadProgressHandler() write to
            //      LoadProgress._loadScreenContent (loadPercentageVisibility / loadPercentage) without a null
            //      check. That object only exists once the embedded load-screen SWF has fired its 'complete'
            //      event; if it is still null when login finishes, OnLogin dies with TypeError #1009 in
            //      startLoad. Replace each `setproperty` with `pop; pop` (same length) so the cosmetic
            //      percentage widget becomes optional.
            var RE_SL_START = new RegExp('\\xd0\\x30\\x5d' + __U + '\\x26\\x4f' + __U + '\\x01\\x60' + __U + '\\x26(\\x61' + __U + ')\\x60' + __U + '\\x66' + __U + '\\x60' + __U + '\\x60' + __U + '\\x60' + __U + '\\x4f' + __U + '\\x03\\x47');
            var RE_SL_DONE  = new RegExp('\\xd0\\x30\\xd1\\x66' + __U + '\\x5e' + __U + '\\x2b\\x61' + __U + '\\x60' + __U + '\\x27(\\x61' + __U + ')\\x60' + __U + '\\x20\\x13');
            var RE_SL_PROG  = new RegExp('\\x60' + __U + '\\xd1\\x66' + __U + '\\x66' + __U + '(\\x61' + __U + ')\\x10');
            function nopSet(out, m, grp) {            // overwrite group `grp` of match m with pop,pop,nop...
                var st = m.index + m[0].indexOf(grp), i;
                out[st] = 0x29; out[st + 1] = 0x29;
                for (i = 2; i < grp.length; i++) out[st + i] = 0x02;
            }

            function patchAbcCode(abc) {
              var parts = [], i;
              for (i = 0; i < abc.length; i += 0x8000) parts.push(String.fromCharCode.apply(null, abc.subarray(i, i + 0x8000)));
              var s = parts.join(''), out = null, n = 0;
              var m = RE_SUPPORTED.exec(s);
              if (m) {
                out = out || new Uint8Array(abc);
                var o = m.index + 2;                       // keep getlocal0 / pushscope
                out[o] = 0x26; out[o + 1] = 0x48;          // pushtrue; returnvalue
                for (i = o + 2; i < m.index + m[0].length; i++) out[i] = 0x02;   // nop padding
                n++;
              }
              m = RE_CERTPIN.exec(s);
              if (m) {
                out = out || new Uint8Array(abc);
                var st = m.index + m[1].length, len = m[2].length;
                out[st] = 0x27;                            // pushfalse (replaces getlex/getlex/istypelate)
                for (i = 1; i < len; i++) out[st + i] = 0x02;
                n++;
              }
              [RE_SL_START, RE_SL_DONE, RE_SL_PROG].forEach(function (re, k) {
                var mm = re.exec(s);
                if (mm) {
                  out = out || new Uint8Array(abc);
                  nopSet(out, mm, mm[1]);
                  n++;
                } else console.log('SWF patch ' + (k + 3) + ' not found');
              });
              console.log('SWF bytecode patches applied: ' + n + '/5');
              return out;
            }

            function patchSWF(buf, from, to) {
              var u8 = new Uint8Array(buf);
              var sig = String.fromCharCode(u8[0], u8[1], u8[2]);
              var body;
              if (sig === 'FWS') body = u8.subarray(8);
              else if (sig === 'ZWS') {
                var total = (u8[4] | (u8[5] << 8) | (u8[6] << 16) | (u8[7] << 24)) >>> 0;
                body = lzmaDecode(u8.subarray(12, 17), u8, 17, total - 8);
              } else throw new Error('Unsupported SWF signature ' + sig + ' (CWS needs inflate)');

              var nbits = body[0] >> 3, p = Math.ceil((5 + nbits * 4) / 8) + 4; // RECT + framerate + framecount
              var chunks = [body.subarray(0, p)], patched = false;
              while (p < body.length) {
                var h = body[p] | (body[p + 1] << 8), code = h >> 6, len = h & 63, hl = 2;
                if (len === 63) { len = (body[p + 2] | (body[p + 3] << 8) | (body[p + 4] << 16) | (body[p + 5] << 24)) >>> 0; hl = 6; }
                var data = body.subarray(p + hl, p + hl + len);
                if (code === 82 || code === 72) {
                  var off = 0;
                  if (code === 82) { off = 4; while (data[off++] !== 0) {} }
                  var abc = patchAbcStrings(data.subarray(off), from, to);
                  var coded = patchAbcCode(abc || data.subarray(off));
                  if (coded) abc = coded;
                  if (abc) {
                    var nd = new Uint8Array(off + abc.length);
                    nd.set(data.subarray(0, off), 0); nd.set(abc, off);
                    var hdr = new Uint8Array(6), nl = nd.length;
                    var nh = (code << 6) | 63;
                    hdr[0] = nh & 255; hdr[1] = nh >> 8; hdr[2] = nl & 255; hdr[3] = (nl >> 8) & 255; hdr[4] = (nl >> 16) & 255; hdr[5] = (nl >>> 24) & 255;
                    chunks.push(hdr, nd); patched = true; p += hl + len; continue;
                  }
                }
                chunks.push(body.subarray(p, p + hl + len));
                p += hl + len;
                if (code === 0) break;
              }
              var sz = 0; chunks.forEach(function (c) { sz += c.length; });
              var out = new Uint8Array(8 + sz);
              out[0] = 70; out[1] = 87; out[2] = 83; out[3] = u8[3];
              var tl = 8 + sz; out[4] = tl & 255; out[5] = (tl >> 8) & 255; out[6] = (tl >> 16) & 255; out[7] = (tl >>> 24) & 255;
              var o = 8; chunks.forEach(function (c) { out.set(c, o); o += c.length; });
              return { data: out, patched: patched };
            }
        </script>
    </head>
    <body>
        <div id="player-container"></div>
        <div id="ajload"><div class="spin"></div><div id="ajloadtxt">Loading…</div><div class="sub" id="ajloadsub"></div></div>
        <pre id="ajstatus" style="position:fixed;left:6px;right:6px;top:48px;max-height:250px;overflow:hidden;margin:0;z-index:99999;pointer-events:none;color:#7CFC00;font:9px/1.25 Menlo,monospace;white-space:pre-wrap;word-break:break-all;text-shadow:0 0 3px #000;"></pre>
        <script>
            window.__ajShow(null);
            // ---- Loading indicator (the client's own load screen never appears under Ruffle) ----
            (function () {
                var el = document.getElementById('ajload'), tx = document.getElementById('ajloadtxt'), sub = document.getElementById('ajloadsub');
                var t0 = Date.now();
                setInterval(function () {
                    var N = window.__ajNet || { pending: 0, bytes: 0, done: 0, last: Date.now() };
                    var now = Date.now(), busy = N.pending > 0 || (now - N.last) < 4000 || !window.__ajLoggedIn;
                    el.classList.toggle('hide', !busy);
                    if (!busy) return;
                    tx.textContent = window.__ajLoggedIn ? (N.pending > 0 ? 'Loading… ' + N.pending + ' downloading' : 'Loading…') : 'Connecting…';
                    sub.textContent = (N.bytes / 1048576).toFixed(1) + ' MB · ' + N.done + ' files · ' + Math.round((now - t0) / 1000) + 's';
                }, 250);
            })();
            console.log('Player page ready. WebAssembly: ' + (typeof WebAssembly));
            // Global functions the client calls through ExternalInterface (seen in the log).
            window.mrc = function () { var m = [].slice.call(arguments).join(','); if (/ON_LOGIN/.test(m)) window.__ajLoggedIn = true; console.log('HOST mrc(' + m + ')'); };
            window.handleGAEvent = function () { console.log('HOST handleGAEvent(' + [].slice.call(arguments).join(',') + ')'); };
            window.aj_initialized = function () { console.log('HOST aj_initialized(' + [].slice.call(arguments).join(',') + ')'); };

            var seenProp = {};
            function spyObj(name, obj) {
                return new Proxy(obj, {
                    get: function (t, p, r) {
                        if (typeof p === 'string' && !seenProp[name + p]) {
                            seenProp[name + p] = 1;
                            console.log('HOST ' + name + '.' + p + (p in t ? '' : '  (MISSING)'));
                        }
                        if (typeof p === 'string' && !(p in t) && p !== 'then') return function () { return null; };
                        return Reflect.get(t, p, r);
                    }
                });
            }
            window.aj = spyObj('aj', {
                ready: function () { return true; },
                login: function () {},
                logout: function () {},
                reload: function () { location.reload(); },
                openExternalUrl: function (url) { console.log("External URL: " + url); },
                getDF: function () { return window.__ajFlashvars ? window.__ajFlashvars.df : ""; },
                getAuthToken: function () { return window.__ajFlashvars ? window.__ajFlashvars.auth_token : ""; },
                getUsername: function () { return window.__ajFlashvars ? window.__ajFlashvars.username : ""; },
                getPlatform: function () { return "mac"; },
                getVersion: function () { return "__AJ_VER__"; },
                minimize: function () {}, maximize: function () {}, close: function () {}, showWindow: function () {}
            });
            window.ipcRenderer = spyObj('ipcRenderer', {
                send: function (ch) { console.log("IPC send: " + ch); },
                on: function () {},
                invoke: function (ch) { console.log("IPC invoke: " + ch); return Promise.resolve({}); }
            });

            window.aj_initialized = function () { console.log('aj_initialized called'); return true; };

            function dumpAbcHints() {
                try {
                    var S = window.__ajAbcStrings || [];
                    console.log('ABC strings: ' + S.length);
                    var re = /version|updat|restart|classic|electron|userAgent|navigator|ExternalInterface|desktop|platform|ipc|launcher|appVer/i;
                    var seen = {}, out = [];
                    S.forEach(function (x) { if (re.test(x) && x.length < 80 && !seen[x]) { seen[x] = 1; out.push(x); } });
                    console.log('HINTS(' + out.length + '): ' + out.slice(0, 70).join(' | '));
                    for (var i = 0; i < S.length; i++) {
                        if (/needs to be updated|classic\.animaljam/i.test(S[i])) {
                            console.log('NEAR #' + i + ': ' + S.slice(Math.max(0, i - 14), i + 15).map(function (x) { return x.slice(0, 45); }).join(' | '));
                            break;
                        }
                    }
                } catch (e) { console.error('dumpAbcHints failed: ' + e); }
            }

            function whenRuffleReady(cb, waited) {
                waited = waited || 0;
                if (window.RufflePlayer && typeof window.RufflePlayer.newest === 'function') { cb(); return; }
                if (waited > 30000) { console.error('Timed out waiting for Ruffle.'); return; }
                setTimeout(function () { whenRuffleReady(cb, waited + 200); }, 200);
            }

            window.startAJWithSession = function (flashvars, swfUrl, baseContentUrl, socketProxies) {
                window.__ajFlashvars = flashvars;
                console.log("Starting Ruffle with SWF: " + swfUrl);
                whenRuffleReady(function () {
                    var container = document.getElementById("player-container");
                    container.innerHTML = "";

                    var ruffle = window.RufflePlayer.newest();
                    if (!ruffle) { console.error("Ruffle failed to initialise."); return; }

                    try { console.log("Ruffle version: " + (ruffle.version || (window.RufflePlayer.sources && Object.keys(window.RufflePlayer.sources)) || "?")); } catch (e) {}
                    var player = ruffle.createPlayer();
                    player.addEventListener("loadedmetadata", function () {
                        try { console.log("SWF metadata: " + JSON.stringify(player.metadata)); } catch (e) {}
                    });
                    player.style.width = "100%";
                    player.style.height = "100%";
                    container.appendChild(player);

                    player.addEventListener("fscommand", function (e) {
                        console.log("FSCommand: " + e.detail.command + " " + e.detail.args);
                    });

                    var common = {
                        base: baseContentUrl,
                        parameters: flashvars,
                        allowScriptAccess: true,
                        allowNetworking: "all",
                        letterbox: "on",
                        upgradeToHttps: false,
                        autoplay: "on",
                        unmuteOverlay: "hidden",
                        splashScreen: false,
                        quality: "medium",
                        backgroundColor: "#000000",
                        socketProxy: socketProxies || []
                    };
                    function finished() {
                        console.log("Ruffle load() resolved");
                        setTimeout(function () { if (!window.__ajHadError) window.__ajHide(); }, 20000);
                    }
                    function byUrl(reason) {
                        console.error(reason + " - loading SWF by URL (unpatched)");
                        return player.load(Object.assign({ url: swfUrl }, common)).then(finished);
                    }

                    // Ruffle has no flash.net.SecureSocket (AIR-only). Patch the SWF to use
                    // flash.net.Socket; the native bridge already does the TLS.
                    fetch(swfUrl).then(function (r) {
                        console.log("SWF fetch status " + r.status);
                        if (!r.ok) throw new Error("HTTP " + r.status);
                        return r.arrayBuffer();
                    }).then(function (buf) {
                        var t0 = Date.now();
                        var res = patchSWF(buf, "SecureSocket", "Socket");
                        console.log("SWF " + buf.byteLength + " bytes, patch " +
                            (res.patched ? "applied (SecureSocket -> Socket)" : "NOT applied (string not found)") +
                            " in " + (Date.now() - t0) + "ms");
                        window.__ajSpoofUA();
                        return player.load(Object.assign({ data: res.data, swfFileName: "ajclient.swf" }, common)).then(finished);
                    }).catch(function (err) {
                        return byUrl("Patch/load failed: " + err);
                    }).catch(function (err) {
                        console.error("Ruffle load error: " + err);
                    });
                });
            };
        </script>
    </body>
    </html>
    """#

    static let playerHTML = template
        .replacingOccurrences(of: "__AJ_UA__", with: AJEnv.userAgent)
        .replacingOccurrences(of: "__AJ_VER__", with: AJEnv.appVersion)
}
