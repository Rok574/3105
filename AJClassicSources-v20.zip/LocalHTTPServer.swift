import Foundation
import Network

final class LocalHTTPServer {
    static let shared = LocalHTTPServer()
    private var listener: NWListener?
    private var isRunning = false

    func start(port: UInt16 = 8080) {
        guard !isRunning else { return }
        do {
            let parameters = NWParameters.tcp
            parameters.allowLocalEndpointReuse = true
            listener = try NWListener(using: parameters, on: NWEndpoint.Port(rawValue: port)!)
            
            listener?.newConnectionHandler = { connection in
                connection.start(queue: .global(qos: .userInitiated))
                connection.receiveMessage { data, _, _, _ in
                    guard let data = data, let requestStr = String(data: data, encoding: .utf8) else {
                        connection.cancel()
                        return
                    }
                    LocalHTTPServer.shared.handleRequest(requestStr, connection: connection)
                }
            }
            
            listener?.start(queue: .global(qos: .userInitiated))
            isRunning = true
        } catch {}
    }

    private func handleRequest(_ request: String, connection: NWConnection) {
        let lines = request.components(separatedBy: "\r\n")
        guard let requestLine = lines.first else {
            connection.cancel()
            return
        }
        
        let parts = requestLine.components(separatedBy: " ")
        guard parts.count >= 2 else {
            connection.cancel()
            return
        }
        
        let path = parts[1]
        
        if path.hasPrefix("/proxy?url=") {
            guard let encodedURLStr = path.components(separatedBy: "/proxy?url=").last,
                  let targetURL = URL(string: encodedURLStr.removingPercentEncoding ?? encodedURLStr) else {
                sendPlainResponse(connection: connection, statusCode: 400, text: "Bad URL")
                return
            }
            
            var req = URLRequest(url: targetURL)
            req.setValue("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) AJClassic/1.6.4 Chrome/87.0.4280.141 Electron/11.5.0 Safari/537.36", forHTTPHeaderField: "User-Agent")
            
            URLSession.shared.dataTask(with: req) { data, response, _ in
                guard let data = data, let httpResponse = response as? HTTPURLResponse else {
                    self.sendPlainResponse(connection: connection, statusCode: 502, text: "Gateway Error")
                    return
                }
                
                var headers = [
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "GET, POST, OPTIONS, HEAD",
                    "Access-Control-Allow-Headers": "*"
                ]
                if let contentType = httpResponse.allHeaderFields["Content-Type"] as? String {
                    headers["Content-Type"] = contentType
                }
                
                self.sendDataResponse(connection: connection, statusCode: httpResponse.statusCode, headers: headers, body: data)
            }.resume()
            
        } else {
            let html = HTMLTemplate.playerHTML
            let data = Data(html.utf8)
            let headers = [
                "Content-Type": "text/html; charset=utf-8",
                "Access-Control-Allow-Origin": "*"
            ]
            sendDataResponse(connection: connection, statusCode: 200, headers: headers, body: data)
        }
    }

    private func sendPlainResponse(connection: NWConnection, statusCode: Int, text: String) {
        let data = Data(text.utf8)
        let headers = [
            "Content-Type": "text/plain",
            "Access-Control-Allow-Origin": "*"
        ]
        sendDataResponse(connection: connection, statusCode: statusCode, headers: headers, body: data)
    }

    private func sendDataResponse(connection: NWConnection, statusCode: Int, headers: [String: String], body: Data) {
        let statusText = statusCode == 200 ? "OK" : "Error"
        var headerString = "HTTP/1.1 \(statusCode) \(statusText)\r\n"
        var finalHeaders = headers
        finalHeaders["Content-Length"] = "\(body.count)"
        finalHeaders["Connection"] = "close"
        
        for (k, v) in finalHeaders {
            headerString += "\(k): \(v)\r\n"
        }
        headerString += "\r\n"
        
        var responseData = Data(headerString.utf8)
        responseData.append(body)
        
        connection.send(content: responseData, completion: .contentProcessed({ _ in
            connection.cancel()
        }))
    }
}
