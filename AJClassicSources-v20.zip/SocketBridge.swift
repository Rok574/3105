import Foundation
import Network

final class SocketBridge {
    static let shared = SocketBridge()
    private var listener: NWListener?
    private var isRunning = false

    func startLocalBridge(port: UInt16 = 8765) {
        guard !isRunning else { return }
        do {
            let parameters = NWParameters.tcp
            parameters.allowLocalEndpointReuse = true
            listener = try NWListener(using: parameters, on: NWEndpoint.Port(rawValue: port)!)
            
            listener?.newConnectionHandler = { client in
                client.start(queue: .global(qos: .userInitiated))
                let remote = NWConnection(to: .hostPort(host: "lb-iss02-classic-prod.animaljam.com", port: 443), using: .tls)
                remote.start(queue: .global(qos: .userInitiated))
                
                let forward = { (from: NWConnection, to: NWConnection) in
                    from.receiveMessage { data, _, _, _ in
                        if let data = data, !data.isEmpty {
                            to.send(content: data, completion: .contentProcessed({ _ in }))
                            forward(from, to)
                        }
                    }
                }
                forward(client, remote)
                forward(remote, client)
            }
            
            listener?.start(queue: .global(qos: .userInitiated))
            isRunning = true
        } catch {}
    }
}
