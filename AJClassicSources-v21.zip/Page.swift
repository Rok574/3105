import Foundation
import SwiftUI
import WebKit

struct AJWebViewContainer: UIViewRepresentable {
    @Binding var session: AJSession?
    @ObservedObject var coordinator: WebViewCoordinator

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        config.defaultWebpagePreferences = prefs

        config.mediaTypesRequiringUserActionForPlayback = []
        config.allowsInlineMediaPlayback = true

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        
        coordinator.webView = webView

        if let url = URL(string: "http://127.0.0.1:8080/") {
            webView.load(URLRequest(url: url))
        }

        let threeFingerHold = UILongPressGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleThreeFingerHold(_:)))
        threeFingerHold.numberOfTouchesRequired = 3
        threeFingerHold.minimumPressDuration = 0.5
        webView.addGestureRecognizer(threeFingerHold)

        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler {
        var parent: AJWebViewContainer
        var consoleWindow: UIWindow?
        var consoleTextView: UITextView?

        init(_ parent: AJWebViewContainer) { self.parent = parent }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            webView.configuration.userContentController.add(self, name: "consoleLog")
        }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            if message.name == "consoleLog", let text = message.body as? String {
                DispatchQueue.main.async {
                    self.appendLog(text)
                }
            }
        }

        @objc func handleThreeFingerHold(_ gesture: UILongPressGestureRecognizer) {
            if gesture.state == .began {
                toggleConsole()
            }
        }

        func toggleConsole() {
            if consoleWindow != nil {
                consoleWindow?.isHidden = true
                consoleWindow = nil
                return
            }

            guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene else { return }
            let win = UIWindow(windowScene: windowScene)
            win.frame = CGRect(x: 20, y: 50, width: UIScreen.main.bounds.width - 40, height: 350)
            win.windowLevel = .alert + 1
            win.backgroundColor = UIColor.black.withAlphaComponent(0.85)
            win.layer.cornerRadius = 12
            win.layer.borderWidth = 1
            win.layer.borderColor = UIColor.green.cgColor
            win.clipsToBounds = true

            let tv = UITextView(frame: win.bounds.insetBy(dx: 10, dy: 10))
            tv.backgroundColor = .clear
            tv.textColor = .green
            tv.font = UIFont.monospacedSystemFont(ofSize: 11, weight: .regular)
            tv.isEditable = false
            tv.text = "[Console Initialized - Hold 3 fingers again to close]\n"
            
            win.addSubview(tv)
            win.isHidden = false
            self.consoleWindow = win
            self.consoleTextView = tv
        }

        func appendLog(_ text: String) {
            guard let tv = consoleTextView else { return }
            tv.text += "\n" + text
            let bottom = NSMakeRange(tv.text.count - 1, 1)
            tv.scrollRangeToVisible(bottom)
        }
    }
}

struct HTMLTemplate {
    static let playerHTML = """
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <style>
            html, body { width: 100%; height: 100%; margin: 0; padding: 0; background-color: #000000; overflow: hidden; }
            #player-container { width: 100%; height: 100%; position: absolute; top: 0; left: 0; }
        </style>
        <script>
            (function() {
                const origLog = console.log;
                const origError = console.error;
                const origWarn = console.warn;
                console.log = function(...args) {
                    origLog.apply(console, args);
                    try { window.webkit.messageHandlers.consoleLog.postMessage(args.join(' ')); } catch(e){}
                };
                console.error = function(...args) {
                    origError.apply(console, args);
                    try { window.webkit.messageHandlers.consoleLog.postMessage('ERROR: ' + args.join(' ')); } catch(e){}
                };
                console.warn = function(...args) {
                    origWarn.apply(console, args);
                    try { window.webkit.messageHandlers.consoleLog.postMessage('WARN: ' + args.join(' ')); } catch(e){}
                };
                window.addEventListener('error', function(e) {
                    try { window.webkit.messageHandlers.consoleLog.postMessage('JS Exception: ' + e.message); } catch(err){}
                });
            })();

            window.RufflePlayer = window.RufflePlayer || {};
            window.RufflePlayer.config = {
                autoplay: "on",
                unmuteOverlay: "hidden",
                allowScriptAccess: "always",
                warnOnUnsupportedContent: false,
                letterbox: "on",
                wmode: "direct",
                backgroundColor: "#000000"
            };
        </script>
        <script src="https://unpkg.com/@ruffle-rs/ruffle"></script>
    </head>
    <body>
        <div id="player-container"></div>
        <script>
            window.aj = window.aj || {
                ready: function() { console.log("AJ ExternalInterface: ready"); return true; },
                login: function() { console.log("AJ ExternalInterface: login"); },
                logout: function() { console.log("AJ ExternalInterface: logout"); },
                reload: function() { location.reload(); },
                openExternalUrl: function(url) { console.log("External URL:", url); },
                getDF: function() { return window.__ajFlashvars ? window.__ajFlashvars.df : ""; },
                getAuthToken: function() { return window.__ajFlashvars ? window.__ajFlashvars.auth_token : ""; },
                getUsername: function() { return window.__ajFlashvars ? window.__ajFlashvars.username : ""; },
                getPlatform: function() { return "mac"; },
                getVersion: function() { return "1.6.4"; },
                minimize: function() {},
                maximize: function() {},
                close: function() {},
                showWindow: function() {}
            };
            window.ipcRenderer = window.ipcRenderer || {
                send: function(ch, data) { console.log("IPC send:", ch, data); },
                on: function() {},
                invoke: function(ch, data) { console.log("IPC invoke:", ch); return Promise.resolve({}); }
            };

            window.startAJWithSession = function(flashvars, swfUrl, baseContentUrl, socketProxies) {
                window.__ajFlashvars = flashvars;
                console.log("Starting Ruffle with SWF:", swfUrl);
                
                const container = document.getElementById("player-container");
                container.innerHTML = "";

                const ruffle = window.RufflePlayer.newest();
                if (!ruffle) {
                    console.error("Ruffle failed to load.");
                    return;
                }

                const player = ruffle.createPlayer();
                player.style.width = "100%";
                player.style.height = "100%";
                container.appendChild(player);

                player.addEventListener("fscommand", (e) => {
                    console.log("FSCommand:", e.detail.command, e.detail.args);
                });

                player.load({
                    url: swfUrl,
                    base: baseContentUrl,
                    parameters: flashvars,
                    allowScriptAccess: "always",
                    allowNetworking: "all",
                    wmode: "direct",
                    letterbox: "on",
                    upgradeToHttps: false,
                    socketProxy: socketProxies || []
                });
            };
        </script>
    </body>
    </html>
    """
}
