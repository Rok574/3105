#import "THGWidgetManager.h"
#import <objc/message.h>

static NSString * const kTHGPreferencesPath = @"/var/mobile/Library/Preferences/com.rok574.todayhsgrid.plist";
static NSString * const kTHGHSWidgetsDirectory = @"/Library/HSWidgets";

@interface NSObject (HSWidgetRuntime)
+ (HSWidgetSize)minimumSize;
- (void)setRequestedSize:(HSWidgetSize)size;
@end

@implementation THGWidgetBundleInfo
@end

@implementation THGPlacedWidget

- (NSDictionary *)dictionaryRepresentation {
    return @{
        @"uuid": self.uuid ?: [[NSUUID UUID] UUIDString],
        @"bundleIdentifier": self.bundleIdentifier ?: @"",
        @"bundlePath": self.bundlePath ?: @"",
        @"displayName": self.displayName ?: @"Widget",
        @"principalClassName": self.principalClassName ?: @"",
        @"sizePreset": @(self.sizePreset)
    };
}

+ (nullable instancetype)widgetFromDictionary:(NSDictionary *)dict {
    if (![dict isKindOfClass:[NSDictionary class]]) return nil;
    NSString *bundlePath = dict[@"bundlePath"];
    NSString *principalClass = dict[@"principalClassName"];
    if (!bundlePath.length || !principalClass.length) return nil;

    THGPlacedWidget *item = [[THGPlacedWidget alloc] init];
    item.uuid = dict[@"uuid"] ?: [[NSUUID UUID] UUIDString];
    item.bundleIdentifier = dict[@"bundleIdentifier"] ?: @"";
    item.bundlePath = bundlePath;
    item.displayName = dict[@"displayName"] ?: @"Widget";
    item.principalClassName = principalClass;
    item.sizePreset = [dict[@"sizePreset"] integerValue];
    return item;
}

@end

@interface THGWidgetManager ()
@property (nonatomic, strong) NSMutableArray<THGPlacedWidget *> *mutablePlacedWidgets;
@end

@implementation THGWidgetManager

+ (instancetype)sharedManager {
    static THGWidgetManager *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [[THGWidgetManager alloc] init];
    });
    return shared;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _mutablePlacedWidgets = [NSMutableArray array];
        [self reloadSavedWidgets];
    }
    return self;
}

+ (HSWidgetSize)hsSizeForPreset:(THGWidgetSizePreset)preset {
    HSWidgetSize size;
    switch (preset) {
        case THGWidgetSizeSmall:
            size.numRows = 2;
            size.numCols = 2;
            break;
        case THGWidgetSizeMedium:
            size.numRows = 2;
            size.numCols = 4;
            break;
        case THGWidgetSizeLarge:
            size.numRows = 4;
            size.numCols = 4;
            break;
        case THGWidgetSizeCompact:
            size.numRows = 1;
            size.numCols = 2;
            break;
    }
    return size;
}

- (NSArray<THGWidgetBundleInfo *> *)availableHSWidgets {
    NSMutableArray<THGWidgetBundleInfo *> *results = [NSMutableArray array];
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:kTHGHSWidgetsDirectory]) {
        return results;
    }

    NSError *error = nil;
    NSArray<NSString *> *contents = [fm contentsOfDirectoryAtPath:kTHGHSWidgetsDirectory error:&error];
    if (error || !contents.count) {
        return results;
    }

    for (NSString *entry in contents) {
        if (![entry.pathExtension.lowercaseString isEqualToString:@"bundle"]) {
            continue;
        }
        NSString *fullPath = [kTHGHSWidgetsDirectory stringByAppendingPathComponent:entry];
        NSBundle *bundle = [NSBundle bundleWithPath:fullPath];
        if (!bundle) continue;

        NSDictionary *info = bundle.infoDictionary;
        NSString *principalClassName = info[@"NSPrincipalClass"];
        if (!principalClassName.length) continue;

        THGWidgetBundleInfo *bundleInfo = [[THGWidgetBundleInfo alloc] init];
        bundleInfo.bundlePath = fullPath;
        bundleInfo.bundleIdentifier = info[@"CFBundleIdentifier"] ?: entry;
        bundleInfo.displayName = info[@"HSWidgetDisplayName"] ?: info[@"CFBundleDisplayName"] ?: info[@"CFBundleName"] ?: [entry stringByDeletingPathExtension];
        bundleInfo.principalClassName = principalClassName;

        NSString *iconName = info[@"HSWidgetIcon"];
        if (iconName.length) {
            UIImage *img = [UIImage imageNamed:iconName inBundle:bundle compatibleWithTraitCollection:nil];
            if (!img) {
                NSString *iconPath = [bundle pathForResource:iconName ofType:@"png"];
                if (iconPath) img = [UIImage imageWithContentsOfFile:iconPath];
            }
            bundleInfo.iconImage = img;
        }

        HSWidgetSize minSize = {2, 2};
        @try {
            if (!bundle.isLoaded) {
                [bundle load];
            }
            Class cls = NSClassFromString(principalClassName);
            if (cls && [cls respondsToSelector:@selector(minimumSize)]) {
                minSize = ((HSWidgetSize (*)(id, SEL))objc_msgSend)(cls, @selector(minimumSize));
            }
        } @catch (NSException *exception) {
            minSize = (HSWidgetSize){2, 2};
        }
        bundleInfo.minimumSize = minSize;
        [results addObject:bundleInfo];
    }

    [results sortUsingComparator:^NSComparisonResult(THGWidgetBundleInfo *a, THGWidgetBundleInfo *b) {
        return [a.displayName localizedCaseInsensitiveCompare:b.displayName];
    }];

    return results;
}

- (NSArray<THGPlacedWidget *> *)placedWidgets {
    return [self.mutablePlacedWidgets copy];
}

- (void)addWidget:(THGWidgetBundleInfo *)bundleInfo sizePreset:(THGWidgetSizePreset)preset {
    if (!bundleInfo) return;
    THGPlacedWidget *placed = [[THGPlacedWidget alloc] init];
    placed.uuid = [[NSUUID UUID] UUIDString];
    placed.bundleIdentifier = bundleInfo.bundleIdentifier;
    placed.bundlePath = bundleInfo.bundlePath;
    placed.displayName = bundleInfo.displayName;
    placed.principalClassName = bundleInfo.principalClassName;
    placed.sizePreset = preset;

    [self.mutablePlacedWidgets addObject:placed];
    [self saveWidgets];
}

- (void)removeWidgetAtIndex:(NSUInteger)index {
    if (index >= self.mutablePlacedWidgets.count) return;
    [self.mutablePlacedWidgets removeObjectAtIndex:index];
    [self saveWidgets];
}

- (void)moveWidgetAtIndex:(NSUInteger)fromIndex toIndex:(NSUInteger)toIndex {
    if (fromIndex >= self.mutablePlacedWidgets.count || toIndex >= self.mutablePlacedWidgets.count || fromIndex == toIndex) {
        return;
    }
    THGPlacedWidget *widget = self.mutablePlacedWidgets[fromIndex];
    [self.mutablePlacedWidgets removeObjectAtIndex:fromIndex];
    [self.mutablePlacedWidgets insertObject:widget atIndex:toIndex];
    [self saveWidgets];
}

- (void)reloadSavedWidgets {
    [self.mutablePlacedWidgets removeAllObjects];
    NSDictionary *prefs = [NSDictionary dictionaryWithContentsOfFile:kTHGPreferencesPath];
    NSArray *savedArray = prefs[@"placedWidgets"];
    if ([savedArray isKindOfClass:[NSArray class]]) {
        for (NSDictionary *dict in savedArray) {
            THGPlacedWidget *placed = [THGPlacedWidget widgetFromDictionary:dict];
            if (placed) {
                [self.mutablePlacedWidgets addObject:placed];
            }
        }
    }
}

- (void)saveWidgets {
    NSMutableArray *serialized = [NSMutableArray arrayWithCapacity:self.mutablePlacedWidgets.count];
    for (THGPlacedWidget *w in self.mutablePlacedWidgets) {
        [serialized addObject:[w dictionaryRepresentation]];
    }
    NSMutableDictionary *prefs = [[NSDictionary dictionaryWithContentsOfFile:kTHGPreferencesPath] mutableCopy] ?: [NSMutableDictionary dictionary];
    prefs[@"placedWidgets"] = serialized;
    [prefs writeToFile:kTHGPreferencesPath atomically:YES];
}

- (nullable UIViewController *)instantiateViewControllerForPlacedWidget:(THGPlacedWidget *)placed {
    if (!placed.bundlePath.length || !placed.principalClassName.length) return nil;
    if (placed.viewController) return placed.viewController;

    @try {
        NSBundle *bundle = [NSBundle bundleWithPath:placed.bundlePath];
        if (!bundle) return nil;
        if (!bundle.isLoaded) {
            NSError *loadErr = nil;
            if (![bundle loadAndReturnError:&loadErr]) {
                return nil;
            }
        }

        Class widgetClass = NSClassFromString(placed.principalClassName);
        if (!widgetClass || ![widgetClass isSubclassOfClass:[UIViewController class]]) {
            return nil;
        }

        UIViewController *vc = [[widgetClass alloc] init];
        HSWidgetSize hsSize = [THGWidgetManager hsSizeForPreset:placed.sizePreset];
        if ([vc respondsToSelector:@selector(setRequestedSize:)]) {
            ((void (*)(id, SEL, HSWidgetSize))objc_msgSend)(vc, @selector(setRequestedSize:), hsSize);
        }
        placed.viewController = vc;
        return vc;
    } @catch (NSException *exception) {
        return nil;
    }
}

@end
