# TodayHSGrid (iOS 11 – 12)

Add **HSWidgets** directly to the iOS 11–12 **Today View** (the minus-one page to the left of the Home Screen) in an iOS 14+ style 4-column grid, while hiding native Today Widget headers and keeping their top spacing intact.

## Features
- **HSWidgets in Today View**: Dynamically discovers installed `.bundle` widgets in `/Library/HSWidgets/` at runtime (no extra compile-time `.tbd` needed).
- **iOS 14+ Style Grid**: Packs `2×2` (Small) and `2×1` (Compact) widgets side-by-side in 2 columns, and `4×2` (Medium) / `4×4` (Large) widgets full-width with `14pt` gutters and `20pt` continuous corner radii.
- **Clean Today Widgets**: Hides `WGWidgetPlatterView`'s `_headerContentView` and `_headerOverlayView` visually (`alpha = 0`) while preserving the header's frame so Today Widget content keeps proper top spacing.
- **Persistent Layout**: Saves your Today View widget layout to `/var/mobile/Library/Preferences/com.rok574.todayhsgrid.plist`.

## Build & Install (Theos)
```bash
make package
# Install the generated .deb from ./packages/ via Sileo, Zebra, Filza, or dpkg -i
```

## Usage
1. Swipe right from your Home Screen to open the **Today View**.
2. Tap **+ Add HSWidget** at the bottom of the HSWidget grid to pick any installed HSWidget and choose its grid size (`2×2`, `4×2`, `2×1`, or `4×4`).
3. Long-press the grid or tap **Edit Grid** to remove widgets.
