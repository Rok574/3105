#import <UIKit/UIKit.h>
#import "THGWidgetManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface THGWidgetPickerController : UITableViewController
@property (nonatomic, copy, nullable) void (^onSelectWidget)(THGWidgetBundleInfo *bundleInfo, THGWidgetSizePreset sizePreset, NSDictionary * _Nullable options);
@end

NS_ASSUME_NONNULL_END
