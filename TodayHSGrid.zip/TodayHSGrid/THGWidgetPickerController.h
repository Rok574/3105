#import <UIKit/UIKit.h>
#import "THGWidgetManager.h"

@interface THGWidgetPickerController : UITableViewController
@property (nonatomic, copy) void (^onSelectWidget)(THGWidgetBundleInfo *bundleInfo, THGWidgetSizePreset sizePreset);
@end
