#import "THGWidgetGridView.h"
#import <QuartzCore/QuartzCore.h>

static const CGFloat kTHGHorizontalInset = 16.0;
static const CGFloat kTHGGridGutter = 14.0;
static const CGFloat kTHGCornerRadius = 20.0;

@interface UIView (THGContinuousCorner)
- (void)_setContinuousCornerRadius:(CGFloat)radius;
@end

@interface THGGridCardView : UIView
@property (nonatomic, strong) THGPlacedWidget *placedWidget;
@property (nonatomic, assign) NSUInteger widgetIndex;
@property (nonatomic, strong) UIVisualEffectView *backdropView;
@property (nonatomic, strong) UIView *contentContainer;
@property (nonatomic, strong) UIButton *removeButton;
@property (nonatomic, strong) UIButton *settingsButton;
@property (nonatomic, strong) UIPanGestureRecognizer *dragPanGesture;
@property (nonatomic, assign) CGRect targetGridFrame;
@property (nonatomic, copy) void (^onRemove)(NSUInteger index);
@property (nonatomic, copy) void (^onConfigure)(NSUInteger index);
- (void)setEditing:(BOOL)editing animated:(BOOL)animated;
@end

@implementation THGGridCardView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.clipsToBounds = NO;

        UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
        _backdropView = [[UIVisualEffectView alloc] initWithEffect:blur];
        _backdropView.frame = self.bounds;
        _backdropView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _backdropView.alpha = 0.65;
        _backdropView.clipsToBounds = YES;
        if ([_backdropView respondsToSelector:@selector(_setContinuousCornerRadius:)]) {
            [_backdropView _setContinuousCornerRadius:kTHGCornerRadius];
        } else {
            _backdropView.layer.cornerRadius = kTHGCornerRadius;
        }
        [self addSubview:_backdropView];

        _contentContainer = [[UIView alloc] initWithFrame:self.bounds];
        _contentContainer.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _contentContainer.backgroundColor = [UIColor clearColor];
        _contentContainer.clipsToBounds = YES;
        if ([_contentContainer respondsToSelector:@selector(_setContinuousCornerRadius:)]) {
            [_contentContainer _setContinuousCornerRadius:kTHGCornerRadius];
        } else {
            _contentContainer.layer.cornerRadius = kTHGCornerRadius;
        }
        [self addSubview:_contentContainer];

        _removeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _removeButton.frame = CGRectMake(-6, -6, 26, 26);
        _removeButton.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleBottomMargin;
        _removeButton.backgroundColor = [UIColor colorWithWhite:0.88 alpha:0.95];
        _removeButton.layer.cornerRadius = 13.0;
        _removeButton.layer.shadowColor = [UIColor blackColor].CGColor;
        _removeButton.layer.shadowOpacity = 0.25;
        _removeButton.layer.shadowRadius = 3.0;
        _removeButton.layer.shadowOffset = CGSizeMake(0, 1);
        [_removeButton setTitle:@"−" forState:UIControlStateNormal];
        [_removeButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _removeButton.titleLabel.font = [UIFont boldSystemFontOfSize:17];
        _removeButton.hidden = YES;
        [_removeButton addTarget:self action:@selector(handleRemoveTap) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_removeButton];

        _settingsButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _settingsButton.frame = CGRectMake(CGRectGetWidth(frame) - 20, -6, 26, 26);
        _settingsButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleBottomMargin;
        _settingsButton.backgroundColor = [UIColor colorWithWhite:0.88 alpha:0.95];
        _settingsButton.layer.cornerRadius = 13.0;
        _settingsButton.layer.shadowColor = [UIColor blackColor].CGColor;
        _settingsButton.layer.shadowOpacity = 0.25;
        _settingsButton.layer.shadowRadius = 3.0;
        _settingsButton.layer.shadowOffset = CGSizeMake(0, 1);
        [_settingsButton setTitle:@"⚙" forState:UIControlStateNormal];
        [_settingsButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _settingsButton.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
        _settingsButton.hidden = YES;
        [_settingsButton addTarget:self action:@selector(handleSettingsTap) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_settingsButton];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.removeButton.frame = CGRectMake(-6, -6, 26, 26);
    self.settingsButton.frame = CGRectMake(CGRectGetWidth(self.bounds) - 20, -6, 26, 26);
}

- (void)handleRemoveTap {
    if (self.onRemove) {
        self.onRemove(self.widgetIndex);
    }
}

- (void)handleSettingsTap {
    if (self.onConfigure) {
        self.onConfigure(self.widgetIndex);
    }
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animated {
    self.removeButton.hidden = !editing;
    BOOL hasPrefs = (self.placedWidget.preferencesClassName.length > 0 || self.placedWidget.addNewOptionsClassName.length > 0);
    self.settingsButton.hidden = !(editing && hasPrefs);
    self.dragPanGesture.enabled = editing;
    self.contentContainer.userInteractionEnabled = !editing;

    if (editing) {
        if (![self.layer animationForKey:@"thgJiggle"]) {
            CAKeyframeAnimation *anim = [CAKeyframeAnimation animationWithKeyPath:@"transform.rotation.z"];
            anim.values = @[@(-0.014), @(0.014), @(-0.014)];
            anim.duration = 0.26;
            anim.repeatCount = HUGE_VALF;
            [self.layer addAnimation:anim forKey:@"thgJiggle"];
        }
    } else {
        [self.layer removeAnimationForKey:@"thgJiggle"];
    }
}

@end

@interface THGWidgetGridView ()
@property (nonatomic, strong) NSMutableArray<THGGridCardView *> *cardViews;
@property (nonatomic, strong) NSLayoutConstraint *heightConstraint;
@property (nonatomic, assign) CGFloat computedHeight;
@property (nonatomic, weak, nullable) THGGridCardView *activeDraggedCard;
@end

@implementation THGWidgetGridView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _cardViews = [NSMutableArray array];
        self.backgroundColor = [UIColor clearColor];
        self.translatesAutoresizingMaskIntoConstraints = NO;

        UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPress:)];
        longPress.minimumPressDuration = 0.45;
        [self addGestureRecognizer:longPress];
    }
    return self;
}

- (void)handleLongPress:(UILongPressGestureRecognizer *)gr {
    if (gr.state == UIGestureRecognizerStateBegan) {
        [self setEditing:!self.isEditing];
    }
}

- (void)setEditing:(BOOL)editing {
    _editing = editing;
    for (THGGridCardView *card in self.cardViews) {
        [card setEditing:editing animated:YES];
    }
    if ([self.delegate respondsToSelector:@selector(widgetGridView:didToggleEditMode:)]) {
        [self.delegate widgetGridView:self didToggleEditMode:editing];
    }
}

- (void)reloadGrid {
    for (THGGridCardView *card in self.cardViews) {
        if (card.placedWidget.viewController.parentViewController == self.parentViewController) {
            [card.placedWidget.viewController willMoveToParentViewController:nil];
            [card.placedWidget.viewController.view removeFromSuperview];
            [card.placedWidget.viewController removeFromParentViewController];
        }
        [card removeFromSuperview];
    }
    [self.cardViews removeAllObjects];

    NSArray<THGPlacedWidget *> *widgets = [[THGWidgetManager sharedManager] placedWidgets];
    __weak typeof(self) weakSelf = self;

    [widgets enumerateObjectsUsingBlock:^(THGPlacedWidget *placed, NSUInteger idx, BOOL *stop) {
        THGGridCardView *card = [[THGGridCardView alloc] initWithFrame:CGRectZero];
        card.placedWidget = placed;
        card.widgetIndex = idx;
        card.onRemove = ^(NSUInteger removeIdx) {
            [[THGWidgetManager sharedManager] removeWidgetAtIndex:removeIdx];
            [weakSelf reloadGrid];
        };
        card.onConfigure = ^(NSUInteger configIdx) {
            if ([weakSelf.delegate respondsToSelector:@selector(widgetGridView:didRequestConfigureWidgetAtIndex:)]) {
                [weakSelf.delegate widgetGridView:weakSelf didRequestConfigureWidgetAtIndex:configIdx];
            }
        };

        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:weakSelf action:@selector(handleCardDrag:)];
        pan.enabled = weakSelf.isEditing;
        [card addGestureRecognizer:pan];
        card.dragPanGesture = pan;

        UIViewController *vc = [[THGWidgetManager sharedManager] instantiateViewControllerForPlacedWidget:placed];
        if (vc) {
            if (weakSelf.parentViewController) {
                [weakSelf.parentViewController addChildViewController:vc];
            }
            vc.view.frame = card.contentContainer.bounds;
            vc.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            [card.contentContainer addSubview:vc.view];
            if (weakSelf.parentViewController) {
                [vc didMoveToParentViewController:weakSelf.parentViewController];
            }
        } else {
            UILabel *fallback = [[UILabel alloc] initWithFrame:card.contentContainer.bounds];
            fallback.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            fallback.text = placed.displayName ?: @"Widget";
            fallback.textColor = [UIColor colorWithWhite:1.0 alpha:0.8];
            fallback.font = [UIFont systemFontOfSize:13 weight:UIFontWeightMedium];
            fallback.textAlignment = NSTextAlignmentCenter;
            fallback.numberOfLines = 2;
            [card.contentContainer addSubview:fallback];
        }

        [card setEditing:weakSelf.isEditing animated:NO];
        [weakSelf addSubview:card];
        [weakSelf.cardViews addObject:card];
    }];

    [self setNeedsLayout];
    [self layoutIfNeeded];
}

- (void)handleCardDrag:(UIPanGestureRecognizer *)pan {
    THGGridCardView *card = (THGGridCardView *)pan.view;
    if (![card isKindOfClass:[THGGridCardView class]] || !self.isEditing) return;

    if (pan.state == UIGestureRecognizerStateBegan) {
        self.activeDraggedCard = card;
        [self bringSubviewToFront:card];
        [card.layer removeAnimationForKey:@"thgJiggle"];
        [UIView animateWithDuration:0.15 animations:^{
            card.transform = CGAffineTransformMakeScale(1.04, 1.04);
            card.alpha = 0.9;
        }];
    } else if (pan.state == UIGestureRecognizerStateChanged) {
        CGPoint translation = [pan translationInView:self];
        card.center = CGPointMake(card.center.x + translation.x, card.center.y + translation.y);
        [pan setTranslation:CGPointZero inView:self];

        CGPoint center = card.center;
        NSUInteger fromIdx = [self.cardViews indexOfObject:card];
        if (fromIdx == NSNotFound) return;

        for (NSUInteger i = 0; i < self.cardViews.count; i++) {
            THGGridCardView *other = self.cardViews[i];
            if (other == card) continue;
            if (CGRectContainsPoint(other.targetGridFrame, center)) {
                [[THGWidgetManager sharedManager] moveWidgetAtIndex:fromIdx toIndex:i];
                [self.cardViews removeObjectAtIndex:fromIdx];
                [self.cardViews insertObject:card atIndex:i];
                for (NSUInteger j = 0; j < self.cardViews.count; j++) {
                    self.cardViews[j].widgetIndex = j;
                }
                [UIView animateWithDuration:0.22 delay:0 options:UIViewAnimationOptionAllowUserInteraction animations:^{
                    [self setNeedsLayout];
                    [self layoutIfNeeded];
                } completion:nil];
                break;
            }
        }
    } else if (pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled) {
        self.activeDraggedCard = nil;
        [UIView animateWithDuration:0.22 animations:^{
            card.transform = CGAffineTransformIdentity;
            card.alpha = 1.0;
            card.frame = card.targetGridFrame;
        } completion:^(BOOL finished) {
            if (self.isEditing) {
                [card setEditing:YES animated:YES];
            }
        }];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];

    CGFloat containerWidth = CGRectGetWidth(self.bounds);
    if (containerWidth <= 0) {
        containerWidth = CGRectGetWidth([UIScreen mainScreen].bounds);
    }

    CGFloat availableWidth = containerWidth - (kTHGHorizontalInset * 2.0);
    CGFloat halfWidth = floor((availableWidth - kTHGGridGutter) / 2.0);
    CGFloat smallHeight = halfWidth;
    CGFloat compactHeight = floor((smallHeight - kTHGGridGutter) / 2.0);
    CGFloat largeHeight = (smallHeight * 2.0) + kTHGGridGutter;

    CGFloat colY[2] = { 0.0, 0.0 };

    for (THGGridCardView *card in self.cardViews) {
        THGWidgetSizePreset preset = card.placedWidget.sizePreset;
        CGRect frame = CGRectZero;

        if (preset == THGWidgetSizeSmall || preset == THGWidgetSizeCompact) {
            CGFloat h = (preset == THGWidgetSizeSmall) ? smallHeight : compactHeight;
            NSInteger col = (colY[0] <= colY[1]) ? 0 : 1;
            CGFloat x = kTHGHorizontalInset + (col * (halfWidth + kTHGGridGutter));
            CGFloat y = colY[col];
            frame = CGRectMake(x, y, halfWidth, h);
            colY[col] = y + h + kTHGGridGutter;
        } else {
            CGFloat h = (preset == THGWidgetSizeLarge) ? largeHeight : smallHeight;
            CGFloat y = MAX(colY[0], colY[1]);
            frame = CGRectMake(kTHGHorizontalInset, y, availableWidth, h);
            colY[0] = y + h + kTHGGridGutter;
            colY[1] = colY[0];
        }

        card.targetGridFrame = frame;
        if (card != self.activeDraggedCard) {
            card.frame = frame;
        }
    }

    CGFloat totalHeight = 0.0;
    if (self.cardViews.count > 0) {
        totalHeight = MAX(colY[0], colY[1]) - kTHGGridGutter;
        if (totalHeight < 0) totalHeight = 0.0;
    }

    if (fabs(self.computedHeight - totalHeight) > 0.5 || !self.heightConstraint) {
        self.computedHeight = totalHeight;
        if (!self.heightConstraint) {
            self.heightConstraint = [self.heightAnchor constraintEqualToConstant:totalHeight];
            self.heightConstraint.priority = UILayoutPriorityRequired;
            self.heightConstraint.active = YES;
        } else {
            self.heightConstraint.constant = totalHeight;
        }
        [self invalidateIntrinsicContentSize];
        if ([self.delegate respondsToSelector:@selector(widgetGridView:didChangeHeight:)]) {
            [self.delegate widgetGridView:self didChangeHeight:totalHeight];
        }
    }
}

- (CGSize)intrinsicContentSize {
    CGFloat w = CGRectGetWidth(self.bounds) > 0 ? CGRectGetWidth(self.bounds) : CGRectGetWidth([UIScreen mainScreen].bounds);
    return CGSizeMake(w, self.computedHeight);
}

- (CGSize)sizeThatFits:(CGSize)size {
    return CGSizeMake(size.width, self.computedHeight);
}

- (void)notifyWidgetsWillAppear:(BOOL)animated {
    for (THGGridCardView *card in self.cardViews) {
        [card.placedWidget.viewController beginAppearanceTransition:YES animated:animated];
        [card.placedWidget.viewController endAppearanceTransition];
    }
}

- (void)notifyWidgetsDidDisappear:(BOOL)animated {
    for (THGGridCardView *card in self.cardViews) {
        [card.placedWidget.viewController beginAppearanceTransition:NO animated:animated];
        [card.placedWidget.viewController endAppearanceTransition];
    }
}

@end
