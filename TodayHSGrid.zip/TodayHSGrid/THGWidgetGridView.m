#import "THGWidgetGridView.h"
#import <QuartzCore/QuartzCore.h>

static const CGFloat kTHGHorizontalInset = 16.0;
static const CGFloat kTHGGridGutter = 14.0;
static const CGFloat kTHGCornerRadius = 20.0;
static const CGFloat kTHGToolbarHeight = 38.0;

@interface UIView (THGContinuousCorner)
- (void)_setContinuousCornerRadius:(CGFloat)radius;
@end

@interface THGGridCardView : UIView
@property (nonatomic, strong) THGPlacedWidget *placedWidget;
@property (nonatomic, assign) NSUInteger widgetIndex;
@property (nonatomic, strong) UIVisualEffectView *backdropView;
@property (nonatomic, strong) UIView *contentContainer;
@property (nonatomic, strong) UIButton *removeButton;
@property (nonatomic, copy) void (^onRemove)(NSUInteger index);
- (void)setEditing:(BOOL)editing animated:(BOOL)animated;
@end

@implementation THGGridCardView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.clipsToBounds = NO;

        UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
        _backdropView = [[UIVisualEffectView alloc] initWithEffect:blur];
        _backdropView.frame = self.bounds;
        _backdropView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _backdropView.alpha = 0.65;
        _backdropView.clipsToBounds = YES;
        if ([_backdropView respondsToSelector:@selector(_setContinuousCornerRadius:)]) {
            [_backdropView _setContinuousCornerRadius:kTHGCornerRadius];
        } else {
            _backdropView.layer.cornerRadius = kTHGCornerRadius;
        }
        [self addSubview:_backdropView];

        _contentContainer = [[UIView alloc] initWithFrame:self.bounds];
        _contentContainer.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _contentContainer.backgroundColor = [UIColor clearColor];
        _contentContainer.clipsToBounds = YES;
        if ([_contentContainer respondsToSelector:@selector(_setContinuousCornerRadius:)]) {
            [_contentContainer _setContinuousCornerRadius:kTHGCornerRadius];
        } else {
            _contentContainer.layer.cornerRadius = kTHGCornerRadius;
        }
        [self addSubview:_contentContainer];

        _removeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _removeButton.frame = CGRectMake(-6, -6, 26, 26);
        _removeButton.backgroundColor = [UIColor colorWithWhite:0.85 alpha:0.95];
        _removeButton.layer.cornerRadius = 13.0;
        _removeButton.layer.shadowColor = [UIColor blackColor].CGColor;
        _removeButton.layer.shadowOpacity = 0.25;
        _removeButton.layer.shadowRadius = 3.0;
        _removeButton.layer.shadowOffset = CGSizeMake(0, 1);
        [_removeButton setTitle:@"−" forState:UIControlStateNormal];
        [_removeButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _removeButton.titleLabel.font = [UIFont boldSystemFontOfSize:17];
        _removeButton.hidden = YES;
        [_removeButton addTarget:self action:@selector(handleRemoveTap) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_removeButton];
    }
    return self;
}

- (void)handleRemoveTap {
    if (self.onRemove) {
        self.onRemove(self.widgetIndex);
    }
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animated {
    self.removeButton.hidden = !editing;
    if (editing) {
        if (![self.layer animationForKey:@"thgJiggle"]) {
            CAKeyframeAnimation *anim = [CAKeyframeAnimation animationWithKeyPath:@"transform.rotation.z"];
            anim.values = @[@(-0.015), @(0.015), @(-0.015)];
            anim.duration = 0.26;
            anim.repeatCount = HUGE_VALF;
            [self.layer addAnimation:anim forKey:@"thgJiggle"];
        }
    } else {
        [self.layer removeAnimationForKey:@"thgJiggle"];
    }
}

@end

@interface THGWidgetGridView ()
@property (nonatomic, strong) NSMutableArray<THGGridCardView *> *cardViews;
@property (nonatomic, strong) UIView *toolbarView;
@property (nonatomic, strong) UIButton *addWidgetButton;
@property (nonatomic, strong) UIButton *editToggleButton;
@property (nonatomic, strong) NSLayoutConstraint *heightConstraint;
@property (nonatomic, assign) CGFloat computedHeight;
@end

@implementation THGWidgetGridView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _cardViews = [NSMutableArray array];
        self.backgroundColor = [UIColor clearColor];
        self.translatesAutoresizingMaskIntoConstraints = NO;
        [self setupToolbar];

        UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPress:)];
        longPress.minimumPressDuration = 0.45;
        [self addGestureRecognizer:longPress];
    }
    return self;
}

- (void)setupToolbar {
    _toolbarView = [[UIView alloc] initWithFrame:CGRectZero];
    _toolbarView.backgroundColor = [UIColor clearColor];
    [self addSubview:_toolbarView];

    _addWidgetButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_addWidgetButton setTitle:@"+ Add HSWidget" forState:UIControlStateNormal];
    [_addWidgetButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _addWidgetButton.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    _addWidgetButton.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.18];
    _addWidgetButton.layer.cornerRadius = 15.0;
    _addWidgetButton.contentEdgeInsets = UIEdgeInsetsMake(6, 14, 6, 14);
    [_addWidgetButton addTarget:self action:@selector(handleAddTapped) forControlEvents:UIControlEventTouchUpInside];
    [_toolbarView addSubview:_addWidgetButton];

    _editToggleButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_editToggleButton setTitle:@"Edit Grid" forState:UIControlStateNormal];
    [_editToggleButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _editToggleButton.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightMedium];
    _editToggleButton.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.14];
    _editToggleButton.layer.cornerRadius = 15.0;
    _editToggleButton.contentEdgeInsets = UIEdgeInsetsMake(6, 14, 6, 14);
    [_editToggleButton addTarget:self action:@selector(handleEditTapped) forControlEvents:UIControlEventTouchUpInside];
    [_toolbarView addSubview:_editToggleButton];
}

- (void)handleLongPress:(UILongPressGestureRecognizer *)gr {
    if (gr.state == UIGestureRecognizerStateBegan) {
        [self setEditing:!self.isEditing];
    }
}

- (void)handleAddTapped {
    if ([self.delegate respondsToSelector:@selector(widgetGridViewDidRequestAddWidget:)]) {
        [self.delegate widgetGridViewDidRequestAddWidget:self];
    }
}

- (void)handleEditTapped {
    [self setEditing:!self.isEditing];
}

- (void)setEditing:(BOOL)editing {
    _editing = editing;
    [_editToggleButton setTitle:(editing ? @"Done" : @"Edit Grid") forState:UIControlStateNormal];
    _editToggleButton.backgroundColor = editing ? [UIColor colorWithRed:0.20 green:0.55 blue:1.0 alpha:0.85] : [UIColor colorWithWhite:1.0 alpha:0.14];
    for (THGGridCardView *card in self.cardViews) {
        [card setEditing:editing animated:YES];
    }
    if ([self.delegate respondsToSelector:@selector(widgetGridView:didToggleEditMode:)]) {
        [self.delegate widgetGridView:self didToggleEditMode:editing];
    }
}

- (void)reloadGrid {
    for (THGGridCardView *card in self.cardViews) {
        if (card.placedWidget.viewController.parentViewController == self.parentViewController) {
            [card.placedWidget.viewController willMoveToParentViewController:nil];
            [card.placedWidget.viewController.view removeFromSuperview];
            [card.placedWidget.viewController removeFromParentViewController];
        }
        [card removeFromSuperview];
    }
    [self.cardViews removeAllObjects];

    NSArray<THGPlacedWidget *> *widgets = [[THGWidgetManager sharedManager] placedWidgets];
    __weak typeof(self) weakSelf = self;

    [widgets enumerateObjectsUsingBlock:^(THGPlacedWidget *placed, NSUInteger idx, BOOL *stop) {
        THGGridCardView *card = [[THGGridCardView alloc] initWithFrame:CGRectZero];
        card.placedWidget = placed;
        card.widgetIndex = idx;
        card.onRemove = ^(NSUInteger removeIdx) {
            [[THGWidgetManager sharedManager] removeWidgetAtIndex:removeIdx];
            [weakSelf reloadGrid];
        };

        UIViewController *vc = [[THGWidgetManager sharedManager] instantiateViewControllerForPlacedWidget:placed];
        if (vc) {
            if (self.parentViewController) {
                [self.parentViewController addChildViewController:vc];
            }
            vc.view.frame = card.contentContainer.bounds;
            vc.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            [card.contentContainer addSubview:vc.view];
            if (self.parentViewController) {
                [vc didMoveToParentViewController:self.parentViewController];
            }
        } else {
            UILabel *fallback = [[UILabel alloc] initWithFrame:card.contentContainer.bounds];
            fallback.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            fallback.text = placed.displayName ?: @"Widget";
            fallback.textColor = [UIColor colorWithWhite:1.0 alpha:0.8];
            fallback.font = [UIFont systemFontOfSize:13 weight:UIFontWeightMedium];
            fallback.textAlignment = NSTextAlignmentCenter;
            fallback.numberOfLines = 2;
            [card.contentContainer addSubview:fallback];
        }

        [card setEditing:self.isEditing animated:NO];
        [self addSubview:card];
        [self.cardViews addObject:card];
    }];

    [self setNeedsLayout];
    [self layoutIfNeeded];
}

- (void)layoutSubviews {
    [super layoutSubviews];

    CGFloat containerWidth = CGRectGetWidth(self.bounds);
    if (containerWidth <= 0) {
        containerWidth = CGRectGetWidth([UIScreen mainScreen].bounds);
    }

    CGFloat availableWidth = containerWidth - (kTHGHorizontalInset * 2.0);
    CGFloat halfWidth = floor((availableWidth - kTHGGridGutter) / 2.0);
    CGFloat smallHeight = halfWidth;
    CGFloat compactHeight = floor((smallHeight - kTHGGridGutter) / 2.0);
    CGFloat largeHeight = (smallHeight * 2.0) + kTHGGridGutter;

    // Bin-pack into 2 half-width columns (4-column grid equivalent)
    CGFloat colY[2] = { 0.0, 0.0 };

    for (THGGridCardView *card in self.cardViews) {
        THGWidgetSizePreset preset = card.placedWidget.sizePreset;
        CGRect frame = CGRectZero;

        if (preset == THGWidgetSizeSmall || preset == THGWidgetSizeCompact) {
            CGFloat h = (preset == THGWidgetSizeSmall) ? smallHeight : compactHeight;
            NSInteger col = (colY[0] <= colY[1]) ? 0 : 1;
            CGFloat x = kTHGHorizontalInset + (col * (halfWidth + kTHGGridGutter));
            CGFloat y = colY[col];
            frame = CGRectMake(x, y, halfWidth, h);
            colY[col] = y + h + kTHGGridGutter;
        } else {
            CGFloat h = (preset == THGWidgetSizeLarge) ? largeHeight : smallHeight;
            CGFloat y = MAX(colY[0], colY[1]);
            frame = CGRectMake(kTHGHorizontalInset, y, availableWidth, h);
            colY[0] = y + h + kTHGGridGutter;
            colY[1] = colY[0];
        }

        card.frame = frame;
    }

    CGFloat gridBottom = MAX(colY[0], colY[1]);
    if (self.cardViews.count == 0) {
        gridBottom = 0.0;
    }

    self.toolbarView.frame = CGRectMake(kTHGHorizontalInset, gridBottom, availableWidth, kTHGToolbarHeight);
    CGSize addSize = [self.addWidgetButton sizeThatFits:CGSizeMake(availableWidth, 30)];
    CGSize editSize = [self.editToggleButton sizeThatFits:CGSizeMake(availableWidth, 30)];
    CGFloat btnY = floor((kTHGToolbarHeight - 30.0) / 2.0);
    self.addWidgetButton.frame = CGRectMake(0, btnY, addSize.width + 8.0, 30.0);
    self.editToggleButton.frame = CGRectMake(availableWidth - (editSize.width + 8.0), btnY, editSize.width + 8.0, 30.0);

    CGFloat totalHeight = gridBottom + kTHGToolbarHeight + 6.0;
    if (fabs(self.computedHeight - totalHeight) > 0.5) {
        self.computedHeight = totalHeight;
        if (!self.heightConstraint) {
            self.heightConstraint = [self.heightAnchor constraintEqualToConstant:totalHeight];
            self.heightConstraint.priority = UILayoutPriorityRequired;
            self.heightConstraint.active = YES;
        } else {
            self.heightConstraint.constant = totalHeight;
        }
        [self invalidateIntrinsicContentSize];
        if ([self.delegate respondsToSelector:@selector(widgetGridView:didChangeHeight:)]) {
            [self.delegate widgetGridView:self didChangeHeight:totalHeight];
        }
    }
}

- (CGSize)intrinsicContentSize {
    CGFloat w = CGRectGetWidth(self.bounds) > 0 ? CGRectGetWidth(self.bounds) : CGRectGetWidth([UIScreen mainScreen].bounds);
    return CGSizeMake(w, MAX(self.computedHeight, kTHGToolbarHeight + 6.0));
}

- (CGSize)sizeThatFits:(CGSize)size {
    return CGSizeMake(size.width, MAX(self.computedHeight, kTHGToolbarHeight + 6.0));
}

- (void)notifyWidgetsWillAppear:(BOOL)animated {
    for (THGGridCardView *card in self.cardViews) {
        [card.placedWidget.viewController beginAppearanceTransition:YES animated:animated];
        [card.placedWidget.viewController endAppearanceTransition];
    }
}

- (void)notifyWidgetsDidDisappear:(BOOL)animated {
    for (THGGridCardView *card in self.cardViews) {
        [card.placedWidget.viewController beginAppearanceTransition:NO animated:animated];
        [card.placedWidget.viewController endAppearanceTransition];
    }
}

@end
