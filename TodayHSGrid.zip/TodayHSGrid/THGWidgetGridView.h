#import <UIKit/UIKit.h>
#import "THGWidgetManager.h"

NS_ASSUME_NONNULL_BEGIN

@class THGWidgetGridView;

@protocol THGWidgetGridViewDelegate <NSObject>
@optional
- (void)widgetGridViewDidRequestAddWidget:(THGWidgetGridView *)gridView;
- (void)widgetGridView:(THGWidgetGridView *)gridView didChangeHeight:(CGFloat)newHeight;
- (void)widgetGridView:(THGWidgetGridView *)gridView didToggleEditMode:(BOOL)editing;
@end

@interface THGWidgetGridView : UIView

@property (nonatomic, weak, nullable) UIViewController *parentViewController;
@property (nonatomic, weak, nullable) id<THGWidgetGridViewDelegate> delegate;
@property (nonatomic, assign, getter=isEditing) BOOL editing;
@property (nonatomic, readonly) CGFloat computedHeight;

- (void)reloadGrid;
- (void)notifyWidgetsWillAppear:(BOOL)animated;
- (void)notifyWidgetsDidDisappear:(BOOL)animated;

@end

NS_ASSUME_NONNULL_END
