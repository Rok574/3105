#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import "THGWidgetManager.h"
#import "THGWidgetGridView.h"
#import "THGWidgetPickerController.h"

@interface WGWidgetListViewController : UIViewController <THGWidgetGridViewDelegate>
@property (nonatomic, strong) THGWidgetGridView *thgGridView;
- (UIStackView *)_stackView;
@end

@interface WGWidgetPlatterView : UIView
- (UIView *)_headerContentView;
- (UIView *)_headerOverlayView;
- (void)_setContinuousCornerRadius:(CGFloat)radius;
@end

static UIStackView *THGFindStackView(UIViewController *vc) {
    if (!vc) return nil;
    if ([vc respondsToSelector:@selector(_stackView)]) {
        UIStackView *sv = [(WGWidgetListViewController *)vc _stackView];
        if ([sv isKindOfClass:[UIStackView class]]) return sv;
    }
    @try {
        id sv = [vc valueForKey:@"_stackView"];
        if ([sv isKindOfClass:[UIStackView class]]) return (UIStackView *)sv;
    } @catch (NSException *e) {}

    // Fallback: walk subviews of vc.view
    for (UIView *sub in vc.view.subviews) {
        if ([sub isKindOfClass:[UIStackView class]]) return (UIStackView *)sub;
        for (UIView *nested in sub.subviews) {
            if ([nested isKindOfClass:[UIStackView class]]) return (UIStackView *)nested;
        }
    }
    return nil;
}

%hook WGWidgetListViewController

%property (nonatomic, strong) THGWidgetGridView *thgGridView;

- (void)viewDidLoad {
    %orig;

    UIStackView *stackView = THGFindStackView(self);
    if (!stackView) return;

    stackView.spacing = 14.0;

    if (!self.thgGridView) {
        THGWidgetGridView *grid = [[THGWidgetGridView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), 60)];
        grid.parentViewController = self;
        grid.delegate = self;
        self.thgGridView = grid;
        [stackView insertArrangedSubview:grid atIndex:0];
        [grid reloadGrid];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    %orig;
    [self.thgGridView notifyWidgetsWillAppear:animated];
}

- (void)viewDidDisappear:(BOOL)animated {
    %orig;
    [self.thgGridView notifyWidgetsDidDisappear:animated];
}

%new
- (void)widgetGridViewDidRequestAddWidget:(THGWidgetGridView *)gridView {
    THGWidgetPickerController *picker = [[THGWidgetPickerController alloc] initWithStyle:UITableViewStylePlain];
    __weak typeof(gridView) weakGrid = gridView;
    picker.onSelectWidget = ^(THGWidgetBundleInfo *bundleInfo, THGWidgetSizePreset sizePreset) {
        [[THGWidgetManager sharedManager] addWidget:bundleInfo sizePreset:sizePreset];
        [weakGrid reloadGrid];
    };

    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:picker];
    nav.modalPresentationStyle = UIModalPresentationFormSheet;
    [self presentViewController:nav animated:YES completion:nil];
}

%new
- (void)widgetGridView:(THGWidgetGridView *)gridView didChangeHeight:(CGFloat)newHeight {
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
}

%end

%hook WGWidgetPlatterView

- (void)layoutSubviews {
    %orig;

    // Match modern iOS 14+ widget card corner radius
    if ([self respondsToSelector:@selector(_setContinuousCornerRadius:)]) {
        [self _setContinuousCornerRadius:20.0];
    } else {
        self.layer.cornerRadius = 20.0;
    }

    // Hide the Today Widget top header visually while preserving its frame & top spacing
    UIView *headerContent = nil;
    if ([self respondsToSelector:@selector(_headerContentView)]) {
        headerContent = [self _headerContentView];
    } else {
        @try {
            headerContent = [self valueForKey:@"_headerContentView"];
        } @catch (NSException *e) {}
    }

    if (headerContent) {
        headerContent.alpha = 0.0;
        headerContent.userInteractionEnabled = NO;
    }

    // Hide the darker translucent header strip so the top spacing blends cleanly
    UIView *headerOverlay = nil;
    if ([self respondsToSelector:@selector(_headerOverlayView)]) {
        headerOverlay = [self _headerOverlayView];
    } else {
        @try {
            headerOverlay = [self valueForKey:@"_headerOverlayView"];
        } @catch (NSException *e) {}
    }

    if (headerOverlay) {
        headerOverlay.alpha = 0.0;
        headerOverlay.hidden = YES;
    }
}

%end
