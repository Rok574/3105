#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import "THGWidgetManager.h"
#import "THGWidgetGridView.h"
#import "THGWidgetPickerController.h"

static NSString * const kTHGTodayEditNotification = @"THGTodayEditButtonTappedNotification";
static const void *kTHGOriginalTargetsKey = &kTHGOriginalTargetsKey;
static const void *kTHGPlatterHookedKey = &kTHGPlatterHookedKey;
static const void *kTHGPlatterPanKey = &kTHGPlatterPanKey;
static const void *kTHGLastFooterBtnKey = &kTHGLastFooterBtnKey;

@interface WGWidgetListViewController : UIViewController <THGWidgetGridViewDelegate>
@property (nonatomic, strong) THGWidgetGridView *thgGridView;
@property (nonatomic, assign) NSUInteger thgConfiguringIndex;
@property (nonatomic, assign) BOOL thgTodayEditMode;
- (UIStackView *)_stackView;
@end

@interface WGWidgetGroupViewController : UIViewController
@end

@interface WGWidgetListFooterView : UIView
- (UIButton *)editButton;
@end

@interface WGWidgetPlatterView : UIView
- (UIView *)_headerContentView;
- (UIView *)_headerOverlayView;
- (void)_setContinuousCornerRadius:(CGFloat)radius;
@end

static UIStackView *THGFindStackView(UIViewController *vc) {
    if (!vc) return nil;
    if ([vc respondsToSelector:@selector(_stackView)]) {
        UIStackView *sv = [(WGWidgetListViewController *)vc _stackView];
        if ([sv isKindOfClass:[UIStackView class]]) return sv;
    }
    @try {
        id sv = [vc valueForKey:@"_stackView"];
        if ([sv isKindOfClass:[UIStackView class]]) return (UIStackView *)sv;
    } @catch (NSException *e) {}

    for (UIView *sub in vc.view.subviews) {
        if ([sub isKindOfClass:[UIStackView class]]) return (UIStackView *)sub;
        for (UIView *nested in sub.subviews) {
            if ([nested isKindOfClass:[UIStackView class]]) return (UIStackView *)nested;
        }
    }
    return nil;
}

static void THGSetViewJiggling(UIView *view, BOOL jiggle) {
    if (jiggle) {
        if (![view.layer animationForKey:@"thgJiggle"]) {
            CAKeyframeAnimation *anim = [CAKeyframeAnimation animationWithKeyPath:@"transform.rotation.z"];
            anim.values = @[@(-0.008), @(0.008), @(-0.008)];
            anim.duration = 0.28;
            anim.repeatCount = HUGE_VALF;
            [view.layer addAnimation:anim forKey:@"thgJiggle"];
        }
    } else {
        [view.layer removeAnimationForKey:@"thgJiggle"];
    }
}

static UIView *THGFindPlatterContainerInStack(UIView *view, UIStackView *stackView) {
    UIView *cur = view;
    while (cur && cur.superview != stackView) {
        cur = cur.superview;
    }
    return (cur.superview == stackView) ? cur : nil;
}

static void THGEnsureGridAttached(WGWidgetListViewController *listVC) {
    if (!listVC || !listVC.isViewLoaded) return;

    UIStackView *stackView = THGFindStackView(listVC);
    if (!stackView) return;

    stackView.spacing = 14.0;
    stackView.hidden = NO;
    stackView.alpha = 1.0;
    listVC.view.hidden = NO;
    listVC.view.alpha = 1.0;

    if (!listVC.thgGridView) {
        THGWidgetGridView *grid = [[THGWidgetGridView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(listVC.view.bounds), 0)];
        grid.parentViewController = listVC;
        grid.delegate = listVC;
        listVC.thgGridView = grid;
        [stackView insertArrangedSubview:grid atIndex:0];
        [grid reloadGrid];
    } else if (![stackView.arrangedSubviews containsObject:listVC.thgGridView]) {
        [stackView insertArrangedSubview:listVC.thgGridView atIndex:0];
        [listVC.thgGridView setNeedsLayout];
    }
    listVC.thgGridView.hidden = NO;

    for (UIView *arranged in stackView.arrangedSubviews) {
        if (arranged == listVC.thgGridView) continue;
        if ([arranged isKindOfClass:NSClassFromString(@"WGWidgetListFooterView")]) continue;
        if (objc_getAssociatedObject(arranged, kTHGPlatterHookedKey)) continue;

        objc_setAssociatedObject(arranged, kTHGPlatterHookedKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

        UILongPressGestureRecognizer *lp = [[UILongPressGestureRecognizer alloc] initWithTarget:listVC action:@selector(thgHandleTodayWidgetLongPress:)];
        lp.minimumPressDuration = 0.45;
        [arranged addGestureRecognizer:lp];

        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:listVC action:@selector(thgHandleTodayWidgetPan:)];
        pan.enabled = listVC.thgTodayEditMode;
        [arranged addGestureRecognizer:pan];
        objc_setAssociatedObject(arranged, kTHGPlatterPanKey, pan, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
}

%hook WGWidgetListViewController

%property (nonatomic, strong) THGWidgetGridView *thgGridView;
%property (nonatomic, assign) NSUInteger thgConfiguringIndex;
%property (nonatomic, assign) BOOL thgTodayEditMode;

- (void)viewDidLoad {
    %orig;
    THGEnsureGridAttached(self);
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(thgHandleFooterEditNotification:) name:kTHGTodayEditNotification object:nil];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    %orig;
}

- (void)viewWillAppear:(BOOL)animated {
    %orig;
    THGEnsureGridAttached(self);
    [self.thgGridView notifyWidgetsWillAppear:animated];
}

- (void)viewWillLayoutSubviews {
    %orig;
    THGEnsureGridAttached(self);
}

- (void)_configureStackView {
    %orig;
    THGEnsureGridAttached(self);
}

- (void)viewDidDisappear:(BOOL)animated {
    %orig;
    [self thgSetAllEditMode:NO];
    [self.thgGridView notifyWidgetsDidDisappear:animated];
}

%new
- (void)thgSetAllEditMode:(BOOL)editing {
    self.thgTodayEditMode = editing;
    self.thgGridView.editing = editing;

    UIStackView *stackView = THGFindStackView(self);
    for (UIView *arranged in stackView.arrangedSubviews) {
        if (arranged == self.thgGridView) continue;
        if ([arranged isKindOfClass:NSClassFromString(@"WGWidgetListFooterView")]) continue;
        THGSetViewJiggling(arranged, editing);
        UIPanGestureRecognizer *pan = objc_getAssociatedObject(arranged, kTHGPlatterPanKey);
        if (pan) pan.enabled = editing;
    }

    UIButton *lastBtn = objc_getAssociatedObject(self, kTHGLastFooterBtnKey);
    if ([lastBtn isKindOfClass:[UIButton class]]) {
        [lastBtn setTitle:(editing ? @"Done" : @"Edit") forState:UIControlStateNormal];
    }
}

%new
- (void)thgHandleTodayWidgetLongPress:(UILongPressGestureRecognizer *)gr {
    if (gr.state == UIGestureRecognizerStateBegan) {
        [self thgSetAllEditMode:!self.thgTodayEditMode];
    }
}

%new
- (void)thgHandleTodayWidgetPan:(UIPanGestureRecognizer *)pan {
    if (!self.thgTodayEditMode) return;
    UIStackView *stackView = THGFindStackView(self);
    if (!stackView) return;

    UIView *dragged = THGFindPlatterContainerInStack(pan.view, stackView);
    if (!dragged) return;

    if (pan.state == UIGestureRecognizerStateBegan) {
        [stackView bringSubviewToFront:dragged];
        THGSetViewJiggling(dragged, NO);
        [UIView animateWithDuration:0.15 animations:^{
            dragged.transform = CGAffineTransformMakeScale(1.03, 1.03);
            dragged.alpha = 0.9;
        }];
    } else if (pan.state == UIGestureRecognizerStateChanged) {
        CGPoint translation = [pan translationInView:stackView];
        dragged.center = CGPointMake(dragged.center.x, dragged.center.y + translation.y);
        [pan setTranslation:CGPointZero inView:stackView];

        CGFloat dragMidY = dragged.center.y;
        NSArray<UIView *> *arranged = stackView.arrangedSubviews;
        NSUInteger fromIdx = [arranged indexOfObject:dragged];
        if (fromIdx == NSNotFound) return;

        for (NSUInteger i = 0; i < arranged.count; i++) {
            UIView *other = arranged[i];
            if (other == dragged) continue;
            if ([other isKindOfClass:NSClassFromString(@"WGWidgetListFooterView")]) continue;
            if (CGRectGetHeight(other.frame) < 10.0) continue;

            if (dragMidY >= CGRectGetMinY(other.frame) && dragMidY <= CGRectGetMaxY(other.frame)) {
                [stackView removeArrangedSubview:dragged];
                [stackView insertArrangedSubview:dragged atIndex:i];
                [UIView animateWithDuration:0.22 delay:0 options:UIViewAnimationOptionAllowUserInteraction animations:^{
                    [stackView layoutIfNeeded];
                } completion:nil];
                break;
            }
        }
    } else if (pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled) {
        [UIView animateWithDuration:0.22 animations:^{
            dragged.transform = CGAffineTransformIdentity;
            dragged.alpha = 1.0;
            [stackView layoutIfNeeded];
        } completion:^(BOOL finished) {
            if (self.thgTodayEditMode) {
                THGSetViewJiggling(dragged, YES);
            }
        }];
    }
}

%new
- (void)thgHandleFooterEditNotification:(NSNotification *)note {
    if (!self.view.window) return;
    UIButton *btn = [note.object isKindOfClass:[UIButton class]] ? (UIButton *)note.object : nil;
    if (btn) {
        objc_setAssociatedObject(self, kTHGLastFooterBtnKey, btn, OBJC_ASSOCIATION_ASSIGN);
    }

    if (self.thgTodayEditMode) {
        [self thgSetAllEditMode:NO];
        return;
    }

    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"Edit Today View"
                                                                   message:nil
                                                            preferredStyle:UIAlertControllerStyleActionSheet];

    __weak typeof(self) weakSelf = self;
    [sheet addAction:[UIAlertAction actionWithTitle:@"Add HSWidget" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        [weakSelf widgetGridViewDidRequestAddWidget:weakSelf.thgGridView];
    }]];

    [sheet addAction:[UIAlertAction actionWithTitle:@"Edit Layout (Move / Remove)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        [weakSelf thgSetAllEditMode:YES];
    }]];

    [sheet addAction:[UIAlertAction actionWithTitle:@"Manage Apple Today Widgets" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        NSArray *savedPairs = objc_getAssociatedObject(btn, kTHGOriginalTargetsKey);
        for (NSDictionary *pair in savedPairs) {
            id target = pair[@"target"];
            SEL sel = NSSelectorFromString(pair[@"action"]);
            if (target && sel && [target respondsToSelector:sel]) {
                ((void (*)(id, SEL, id))objc_msgSend)(target, sel, btn);
            }
        }
    }]];

    [sheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];

    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad && btn) {
        sheet.popoverPresentationController.sourceView = btn;
        sheet.popoverPresentationController.sourceRect = btn.bounds;
    }

    [self presentViewController:sheet animated:YES completion:nil];
}

%new
- (void)widgetGridView:(THGWidgetGridView *)gridView didToggleEditMode:(BOOL)editing {
    if (self.thgTodayEditMode != editing) {
        [self thgSetAllEditMode:editing];
    }
}

%new
- (void)widgetGridViewDidRequestAddWidget:(THGWidgetGridView *)gridView {
    THGWidgetPickerController *picker = [[THGWidgetPickerController alloc] initWithStyle:UITableViewStylePlain];
    __weak typeof(self) weakSelf = self;
    __weak typeof(gridView) weakGrid = gridView;

    picker.onSelectWidget = ^(THGWidgetBundleInfo *bundleInfo, THGWidgetSizePreset sizePreset, NSDictionary *options) {
        THGPlacedWidget *placed = [[THGWidgetManager sharedManager] addWidget:bundleInfo sizePreset:sizePreset options:options];
        [weakGrid reloadGrid];

        if (!bundleInfo.addNewOptionsClassName.length && placed.preferencesClassName.length) {
            NSUInteger newIndex = [[[THGWidgetManager sharedManager] placedWidgets] count] - 1;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [weakSelf widgetGridView:weakGrid didRequestConfigureWidgetAtIndex:newIndex];
            });
        }
    };

    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:picker];
    nav.modalPresentationStyle = UIModalPresentationFormSheet;
    [self presentViewController:nav animated:YES completion:nil];
}

%new
- (void)widgetGridView:(THGWidgetGridView *)gridView didRequestConfigureWidgetAtIndex:(NSUInteger)index {
    NSArray<THGPlacedWidget *> *widgets = [[THGWidgetManager sharedManager] placedWidgets];
    if (index >= widgets.count) return;
    THGPlacedWidget *placed = widgets[index];

    NSString *className = placed.preferencesClassName.length ? placed.preferencesClassName : placed.addNewOptionsClassName;
    if (!className.length) return;

    NSBundle *bundle = [NSBundle bundleWithPath:placed.bundlePath];
    if (bundle && !bundle.isLoaded) [bundle load];

    Class prefsClass = NSClassFromString(className);
    if (!prefsClass || ![prefsClass isSubclassOfClass:[UIViewController class]]) return;

    UIViewController *prefsVC = [[prefsClass alloc] init];
    self.thgConfiguringIndex = index;

    @try {
        [prefsVC setValue:placed.viewController forKey:@"widgetViewController"];
    } @catch (NSException *e) {}
    @try {
        NSMutableDictionary *mutableOpts = [placed.widgetOptions mutableCopy] ?: [NSMutableDictionary dictionary];
        [prefsVC setValue:mutableOpts forKey:@"widgetOptions"];
    } @catch (NSException *e) {}
    @try {
        NSMutableDictionary *mutableOpts = [placed.widgetOptions mutableCopy] ?: [NSMutableDictionary dictionary];
        [prefsVC setValue:mutableOpts forKey:@"options"];
    } @catch (NSException *e) {}

    if (!prefsVC.navigationItem.rightBarButtonItem) {
        prefsVC.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(thgDismissPreferences)];
    }

    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:prefsVC];
    nav.modalPresentationStyle = UIModalPresentationFormSheet;
    [self presentViewController:nav animated:YES completion:nil];
}

%new
- (void)thgDismissPreferences {
    UIViewController *presented = self.presentedViewController;
    NSDictionary *updatedOptions = nil;
    if ([presented isKindOfClass:[UINavigationController class]]) {
        UIViewController *top = ((UINavigationController *)presented).topViewController;
        @try {
            id opts = [top valueForKey:@"widgetOptions"];
            if ([opts isKindOfClass:[NSDictionary class]]) updatedOptions = opts;
        } @catch (NSException *e) {}
        if (!updatedOptions) {
            @try {
                id opts = [top valueForKey:@"options"];
                if ([opts isKindOfClass:[NSDictionary class]]) updatedOptions = opts;
            } @catch (NSException *e) {}
        }
    }

    if (updatedOptions) {
        [[THGWidgetManager sharedManager] updateOptions:updatedOptions forWidgetAtIndex:self.thgConfiguringIndex];
    }

    __weak typeof(self) weakSelf = self;
    [self dismissViewControllerAnimated:YES completion:^{
        [weakSelf.thgGridView reloadGrid];
    }];
}

%new
- (void)widgetGridView:(THGWidgetGridView *)gridView didChangeHeight:(CGFloat)newHeight {
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
}

%end

%hook WGWidgetListFooterView

- (void)layoutSubviews {
    %orig;

    UIButton *editBtn = nil;
    if ([self respondsToSelector:@selector(editButton)]) {
        editBtn = [self editButton];
    }
    if (!editBtn) {
        for (UIView *sub in self.subviews) {
            if ([sub isKindOfClass:[UIButton class]]) {
                editBtn = (UIButton *)sub;
                break;
            }
        }
    }

    if (editBtn && !objc_getAssociatedObject(editBtn, kTHGOriginalTargetsKey)) {
        NSMutableArray *pairs = [NSMutableArray array];
        for (id target in editBtn.allTargets) {
            if (target == self) continue;
            NSArray *actions = [editBtn actionsForTarget:target forControlEvent:UIControlEventTouchUpInside];
            for (NSString *act in actions) {
                [pairs addObject:@{ @"target": target, @"action": act }];
            }
        }
        objc_setAssociatedObject(editBtn, kTHGOriginalTargetsKey, pairs, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        [editBtn removeTarget:nil action:NULL forControlEvents:UIControlEventTouchUpInside];
        [editBtn addTarget:self action:@selector(thgEditButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    }
}

%new
- (void)thgEditButtonTapped:(UIButton *)sender {
    [[NSNotificationCenter defaultCenter] postNotificationName:kTHGTodayEditNotification object:sender];
}

%end

%hook WGWidgetGroupViewController

- (void)viewWillAppear:(BOOL)animated {
    %orig;
    for (UIViewController *child in self.childViewControllers) {
        if ([child isKindOfClass:NSClassFromString(@"WGWidgetListViewController")]) {
            child.view.hidden = NO;
            child.view.alpha = 1.0;
            THGEnsureGridAttached((WGWidgetListViewController *)child);
        }
    }
}

- (void)viewWillLayoutSubviews {
    %orig;
    for (UIViewController *child in self.childViewControllers) {
        if ([child isKindOfClass:NSClassFromString(@"WGWidgetListViewController")]) {
            child.view.hidden = NO;
            child.view.alpha = 1.0;
            if (CGRectGetHeight(child.view.frame) < 40.0) {
                CGRect f = child.view.frame;
                f.size.height = MAX(CGRectGetHeight(self.view.bounds), 120.0);
                child.view.frame = f;
            }
        }
    }
}

%end

%hook WGWidgetPlatterView

- (void)layoutSubviews {
    %orig;

    if ([self respondsToSelector:@selector(_setContinuousCornerRadius:)]) {
        [self _setContinuousCornerRadius:20.0];
    } else {
        self.layer.cornerRadius = 20.0;
    }

    UIView *headerContent = nil;
    if ([self respondsToSelector:@selector(_headerContentView)]) {
        headerContent = [self _headerContentView];
    } else {
        @try {
            headerContent = [self valueForKey:@"_headerContentView"];
        } @catch (NSException *e) {}
    }

    if (headerContent) {
        headerContent.alpha = 0.0;
        headerContent.userInteractionEnabled = NO;
    }

    UIView *headerOverlay = nil;
    if ([self respondsToSelector:@selector(_headerOverlayView)]) {
        headerOverlay = [self _headerOverlayView];
    } else {
        @try {
            headerOverlay = [self valueForKey:@"_headerOverlayView"];
        } @catch (NSException *e) {}
    }

    if (headerOverlay) {
        headerOverlay.alpha = 0.0;
        headerOverlay.hidden = YES;
    }

    @try {
        UIView *mainOverlay = [self valueForKey:@"_mainOverlayView"];
        if ([mainOverlay isKindOfClass:[UIView class]]) {
            mainOverlay.frame = self.bounds;
        }
    } @catch (NSException *e) {}
}

%end
