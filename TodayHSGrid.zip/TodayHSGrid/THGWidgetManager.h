#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, THGWidgetSizePreset) {
    THGWidgetSizeSmall = 0,   // 2x2 (half width, square)
    THGWidgetSizeMedium = 1,  // 4x2 (full width, same height as small)
    THGWidgetSizeLarge = 2,   // 4x4 (full width, double height + gutter)
    THGWidgetSizeCompact = 3  // 2x1 (half width, half height pill)
};

typedef struct HSWidgetPosition {
    NSUInteger row;
    NSUInteger col;
} HSWidgetPosition;

typedef struct HSWidgetSize {
    NSUInteger numRows;
    NSUInteger numCols;
} HSWidgetSize;

typedef struct HSWidgetFrame {
    HSWidgetPosition position;
    HSWidgetSize size;
} HSWidgetFrame;

@interface THGWidgetBundleInfo : NSObject
@property (nonatomic, copy) NSString *bundleIdentifier;
@property (nonatomic, copy) NSString *bundlePath;
@property (nonatomic, copy) NSString *displayName;
@property (nonatomic, copy) NSString *principalClassName;
@property (nonatomic, copy, nullable) NSString *addNewOptionsClassName;
@property (nonatomic, copy, nullable) NSString *preferencesClassName;
@property (nonatomic, strong, nullable) UIImage *iconImage;
@property (nonatomic, assign) HSWidgetSize minimumSize;
@end

@interface THGPlacedWidget : NSObject
@property (nonatomic, copy) NSString *uuid;
@property (nonatomic, copy) NSString *bundleIdentifier;
@property (nonatomic, copy) NSString *bundlePath;
@property (nonatomic, copy) NSString *displayName;
@property (nonatomic, copy) NSString *principalClassName;
@property (nonatomic, copy, nullable) NSString *preferencesClassName;
@property (nonatomic, copy, nullable) NSString *addNewOptionsClassName;
@property (nonatomic, strong, nullable) NSDictionary *widgetOptions;
@property (nonatomic, assign) THGWidgetSizePreset sizePreset;
@property (nonatomic, strong, nullable) UIViewController *viewController;
- (NSDictionary *)dictionaryRepresentation;
+ (nullable instancetype)widgetFromDictionary:(NSDictionary *)dict;
@end

@interface THGWidgetManager : NSObject
+ (instancetype)sharedManager;
- (NSArray<THGWidgetBundleInfo *> *)availableHSWidgets;
- (NSArray<THGPlacedWidget *> *)placedWidgets;
- (THGPlacedWidget *)addWidget:(THGWidgetBundleInfo *)bundleInfo sizePreset:(THGWidgetSizePreset)preset options:(nullable NSDictionary *)options;
- (void)updateOptions:(nullable NSDictionary *)options forWidgetAtIndex:(NSUInteger)index;
- (void)removeWidgetAtIndex:(NSUInteger)index;
- (void)moveWidgetAtIndex:(NSUInteger)fromIndex toIndex:(NSUInteger)toIndex;
- (void)reloadSavedWidgets;
- (nullable UIViewController *)instantiateViewControllerForPlacedWidget:(THGPlacedWidget *)placed;
+ (HSWidgetSize)hsSizeForPreset:(THGWidgetSizePreset)preset;
@end

NS_ASSUME_NONNULL_END
