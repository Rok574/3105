#import "THGWidgetPickerController.h"

@interface THGOptionsDelegateProxy : NSObject
@property (nonatomic, copy) void (^completion)(NSDictionary * _Nullable options);
@end

@implementation THGOptionsDelegateProxy

- (void)finishWithOptions:(NSDictionary *)options {
    if (self.completion) {
        void (^cb)(NSDictionary *) = self.completion;
        self.completion = nil;
        cb([options isKindOfClass:[NSDictionary class]] ? options : nil);
    }
}

- (void)addNewOptionsController:(id)controller didFinishWithOptions:(NSDictionary *)options {
    [self finishWithOptions:options];
}

- (void)additionalOptionsViewController:(id)controller didFinishWithOptions:(NSDictionary *)options {
    [self finishWithOptions:options];
}

- (void)optionsViewController:(id)controller didFinishWithOptions:(NSDictionary *)options {
    [self finishWithOptions:options];
}

- (void)didFinishAdditionalOptions:(NSDictionary *)options {
    [self finishWithOptions:options];
}

- (void)didFinishWithOptions:(NSDictionary *)options {
    [self finishWithOptions:options];
}

@end

@interface THGWidgetPickerController ()
@property (nonatomic, strong) NSArray<THGWidgetBundleInfo *> *widgets;
@property (nonatomic, strong, nullable) THGOptionsDelegateProxy *activeOptionsProxy;
@property (nonatomic, weak, nullable) UIViewController *activeOptionsVC;
@property (nonatomic, strong, nullable) THGWidgetBundleInfo *pendingBundleInfo;
@property (nonatomic, assign) THGWidgetSizePreset pendingPreset;
@end

@implementation THGWidgetPickerController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Add HSWidget";
    if (@available(iOS 11.0, *)) {
        self.navigationController.navigationBar.prefersLargeTitles = NO;
    }

    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(dismissSelf)];

    self.widgets = [[THGWidgetManager sharedManager] availableHSWidgets];
    self.tableView.rowHeight = 60.0;
    self.tableView.tableFooterView = [UIView new];

    if (self.widgets.count == 0) {
        UILabel *emptyLabel = [[UILabel alloc] initWithFrame:CGRectMake(24, 0, CGRectGetWidth(self.view.bounds) - 48, 160)];
        emptyLabel.text = @"No HSWidgets found in /Library/HSWidgets.\n\nInstall HSWidgets or any HSWidget bundle from Sileo/Zebra first.";
        emptyLabel.textColor = [UIColor grayColor];
        emptyLabel.font = [UIFont systemFontOfSize:14];
        emptyLabel.textAlignment = NSTextAlignmentCenter;
        emptyLabel.numberOfLines = 0;
        self.tableView.backgroundView = emptyLabel;
    }
}

- (void)dismissSelf {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.widgets.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"THGWidgetCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }

    THGWidgetBundleInfo *info = self.widgets[indexPath.row];
    cell.textLabel.text = info.displayName;
    cell.textLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
    NSString *configTag = (info.addNewOptionsClassName.length || info.preferencesClassName.length) ? @" • Configurable" : @"";
    cell.detailTextLabel.text = [NSString stringWithFormat:@"Min size: %lux%lu%@", (unsigned long)info.minimumSize.numCols, (unsigned long)info.minimumSize.numRows, configTag];
    cell.detailTextLabel.textColor = [UIColor grayColor];
    cell.imageView.image = info.iconImage;
    cell.imageView.layer.cornerRadius = 8.0;
    cell.imageView.clipsToBounds = YES;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    THGWidgetBundleInfo *info = self.widgets[indexPath.row];

    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:info.displayName
                                                                   message:@"Choose widget grid size"
                                                            preferredStyle:UIAlertControllerStyleActionSheet];

    __weak typeof(self) weakSelf = self;
    void (^pickPreset)(THGWidgetSizePreset) = ^(THGWidgetSizePreset preset) {
        [weakSelf handleSelectedBundle:info preset:preset];
    };

    [sheet addAction:[UIAlertAction actionWithTitle:@"Small (2×2 Square)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        pickPreset(THGWidgetSizeSmall);
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Medium (4×2 Wide)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        pickPreset(THGWidgetSizeMedium);
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Compact (2×1 Pill)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        pickPreset(THGWidgetSizeCompact);
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Large (4×4)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        pickPreset(THGWidgetSizeLarge);
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];

    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
        sheet.popoverPresentationController.sourceView = cell;
        sheet.popoverPresentationController.sourceRect = cell.bounds;
    }

    [self presentViewController:sheet animated:YES completion:nil];
}

- (void)handleSelectedBundle:(THGWidgetBundleInfo *)info preset:(THGWidgetSizePreset)preset {
    if (info.addNewOptionsClassName.length) {
        NSBundle *bundle = [NSBundle bundleWithPath:info.bundlePath];
        if (!bundle.isLoaded) [bundle load];
        Class optClass = NSClassFromString(info.addNewOptionsClassName);
        if (optClass && [optClass isSubclassOfClass:[UIViewController class]]) {
            UIViewController *optVC = [[optClass alloc] init];
            self.pendingBundleInfo = info;
            self.pendingPreset = preset;
            self.activeOptionsVC = optVC;

            __weak typeof(self) weakSelf = self;
            self.activeOptionsProxy = [[THGOptionsDelegateProxy alloc] init];
            self.activeOptionsProxy.completion = ^(NSDictionary *options) {
                if (weakSelf.onSelectWidget) {
                    weakSelf.onSelectWidget(info, preset, options);
                }
                [weakSelf dismissViewControllerAnimated:YES completion:nil];
            };

            @try {
                [optVC setValue:self.activeOptionsProxy forKey:@"delegate"];
            } @catch (NSException *e) {}
            @try {
                [optVC setValue:self.activeOptionsProxy forKey:@"addNewDelegate"];
            } @catch (NSException *e) {}
            @try {
                [optVC setValue:[THGWidgetManager hsSizeForPreset:preset].numRows > 0 ? @(preset) : @(0) forKey:@"widgetSize"];
            } @catch (NSException *e) {}

            if (!optVC.navigationItem.rightBarButtonItem) {
                optVC.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Add" style:UIBarButtonItemStyleDone target:self action:@selector(finishActiveOptionsManually)];
            }
            [self.navigationController pushViewController:optVC animated:YES];
            return;
        }
    }

    if (self.onSelectWidget) {
        self.onSelectWidget(info, preset, nil);
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)finishActiveOptionsManually {
    NSDictionary *extracted = nil;
    UIViewController *vc = self.activeOptionsVC;
    if (vc) {
        @try {
            id opts = [vc valueForKey:@"options"];
            if ([opts isKindOfClass:[NSDictionary class]]) extracted = opts;
        } @catch (NSException *e) {}
        if (!extracted) {
            @try {
                id opts = [vc valueForKey:@"widgetOptions"];
                if ([opts isKindOfClass:[NSDictionary class]]) extracted = opts;
            } @catch (NSException *e) {}
        }
    }
    if (self.activeOptionsProxy) {
        [self.activeOptionsProxy finishWithOptions:extracted];
    } else if (self.pendingBundleInfo && self.onSelectWidget) {
        self.onSelectWidget(self.pendingBundleInfo, self.pendingPreset, extracted);
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

@end
