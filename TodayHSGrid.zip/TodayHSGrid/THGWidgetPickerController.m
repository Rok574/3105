#import "THGWidgetPickerController.h"

@interface THGWidgetPickerController ()
@property (nonatomic, strong) NSArray<THGWidgetBundleInfo *> *widgets;
@end

@implementation THGWidgetPickerController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Add HSWidget";
    if (@available(iOS 11.0, *)) {
        self.navigationController.navigationBar.prefersLargeTitles = NO;
    }

    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(dismissSelf)];

    self.widgets = [[THGWidgetManager sharedManager] availableHSWidgets];
    self.tableView.rowHeight = 60.0;
    self.tableView.tableFooterView = [UIView new];

    if (self.widgets.count == 0) {
        UILabel *emptyLabel = [[UILabel alloc] initWithFrame:CGRectMake(24, 0, CGRectGetWidth(self.view.bounds) - 48, 160)];
        emptyLabel.text = @"No HSWidgets found in /Library/HSWidgets.\n\nInstall HSWidgets or any HSWidget bundle from Sileo/Zebra first.";
        emptyLabel.textColor = [UIColor grayColor];
        emptyLabel.font = [UIFont systemFontOfSize:14];
        emptyLabel.textAlignment = NSTextAlignmentCenter;
        emptyLabel.numberOfLines = 0;
        self.tableView.backgroundView = emptyLabel;
    }
}

- (void)dismissSelf {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.widgets.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"THGWidgetCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }

    THGWidgetBundleInfo *info = self.widgets[indexPath.row];
    cell.textLabel.text = info.displayName;
    cell.textLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"Min size: %lux%lu", (unsigned long)info.minimumSize.numCols, (unsigned long)info.minimumSize.numRows];
    cell.detailTextLabel.textColor = [UIColor grayColor];
    cell.imageView.image = info.iconImage;
    cell.imageView.layer.cornerRadius = 8.0;
    cell.imageView.clipsToBounds = YES;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    THGWidgetBundleInfo *info = self.widgets[indexPath.row];

    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:info.displayName
                                                                   message:@"Choose widget grid size"
                                                            preferredStyle:UIAlertControllerStyleActionSheet];

    __weak typeof(self) weakSelf = self;
    void (^pickPreset)(THGWidgetSizePreset) = ^(THGWidgetSizePreset preset) {
        if (weakSelf.onSelectWidget) {
            weakSelf.onSelectWidget(info, preset);
        }
        [weakSelf dismissViewControllerAnimated:YES completion:nil];
    };

    [sheet addAction:[UIAlertAction actionWithTitle:@"Small (2×2 Square)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        pickPreset(THGWidgetSizeSmall);
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Medium (4×2 Wide)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        pickPreset(THGWidgetSizeMedium);
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Compact (2×1 Pill)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        pickPreset(THGWidgetSizeCompact);
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Large (4×4)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        pickPreset(THGWidgetSizeLarge);
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];

    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
        sheet.popoverPresentationController.sourceView = cell;
        sheet.popoverPresentationController.sourceRect = cell.bounds;
    }

    [self presentViewController:sheet animated:YES completion:nil];
}

@end
