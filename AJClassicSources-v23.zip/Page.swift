import Foundation
import SwiftUI
import WebKit

struct AJWebViewContainer: UIViewRepresentable {
    @ObservedObject var coordinator: WebViewCoordinator

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        config.defaultWebpagePreferences = prefs
        config.mediaTypesRequiringUserActionForPlayback = []
        config.allowsInlineMediaPlayback = true

        // Register the console bridge BEFORE the page loads so early logs aren't lost.
        config.userContentController.add(context.coordinator, name: "consoleLog")

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.scrollView.backgroundColor = .black
        webView.scrollView.bounces = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        if #available(iOS 16.4, *) { webView.isInspectable = true }

        coordinator.webView = webView
        coordinator.pageLoaded = false
        webView.load(context.coordinator.request)

        let threeFingerHold = UILongPressGestureRecognizer(target: context.coordinator,
                                                           action: #selector(Coordinator.handleThreeFingerHold(_:)))
        threeFingerHold.numberOfTouchesRequired = 3
        threeFingerHold.minimumPressDuration = 0.5
        threeFingerHold.cancelsTouchesInView = false
        webView.addGestureRecognizer(threeFingerHold)

        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler {
        var parent: AJWebViewContainer
        var consoleWindow: UIWindow?
        var consoleTextView: UITextView?
        private var logBuffer: [String] = []
        private var retries = 0

        let request = URLRequest(url: URL(string: "http://127.0.0.1:\(LocalHTTPServer.port)/")!,
                                 cachePolicy: .reloadIgnoringLocalAndRemoteCacheData)

        init(_ parent: AJWebViewContainer) { self.parent = parent }

        // MARK: Navigation

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            retries = 0
            parent.coordinator.pageDidLoad()
        }

        // The local server may not be listening yet on a cold start -> retry instead of staying black.
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            retryLoad(webView, error: error)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            retryLoad(webView, error: error)
        }

        func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
            parent.coordinator.pageLoaded = false
            webView.load(request)
        }

        private func retryLoad(_ webView: WKWebView, error: Error) {
            appendLog("Page load failed: \(error.localizedDescription)")
            guard retries < 20 else { return }
            retries += 1
            parent.coordinator.pageLoaded = false
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak webView, request] in
                webView?.load(request)
            }
        }

        // MARK: Console

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            if message.name == "consoleLog", let text = message.body as? String {
                DispatchQueue.main.async { self.appendLog(text) }
            }
        }

        @objc func handleThreeFingerHold(_ gesture: UILongPressGestureRecognizer) {
            if gesture.state == .began { toggleConsole() }
        }

        func toggleConsole() {
            if let w = consoleWindow {
                w.isHidden = true
                consoleWindow = nil
                consoleTextView = nil
                return
            }

            guard let windowScene = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene }).first else { return }
            let width = windowScene.screen.bounds.width
            let win = UIWindow(windowScene: windowScene)
            win.frame = CGRect(x: 20, y: 50, width: width - 40, height: 350)
            win.windowLevel = .alert + 1
            win.backgroundColor = UIColor.black.withAlphaComponent(0.85)
            win.layer.cornerRadius = 12
            win.layer.borderWidth = 1
            win.layer.borderColor = UIColor.green.cgColor
            win.clipsToBounds = true

            let vc = UIViewController()
            vc.view.backgroundColor = .clear
            win.rootViewController = vc

            let tv = UITextView(frame: win.bounds.insetBy(dx: 10, dy: 10))
            tv.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            tv.backgroundColor = .clear
            tv.textColor = .green
            tv.font = UIFont.monospacedSystemFont(ofSize: 11, weight: .regular)
            tv.isEditable = false
            tv.text = "[Console - hold 3 fingers again to close]\n" + logBuffer.joined(separator: "\n")
            vc.view.addSubview(tv)

            win.isHidden = false
            consoleWindow = win
            consoleTextView = tv
            scrollToBottom()
        }

        func appendLog(_ text: String) {
            logBuffer.append(text)
            if logBuffer.count > 500 { logBuffer.removeFirst(logBuffer.count - 500) }
            guard let tv = consoleTextView else { return }
            tv.text += "\n" + text
            scrollToBottom()
        }

        private func scrollToBottom() {
            guard let tv = consoleTextView else { return }
            let len = (tv.text as NSString).length
            if len > 0 { tv.scrollRangeToVisible(NSRange(location: len - 1, length: 1)) }
        }
    }
}

struct HTMLTemplate {
    static let playerHTML = #"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
        <style>
            html, body { width: 100%; height: 100%; margin: 0; padding: 0; background-color: #000; overflow: hidden; touch-action: none; -webkit-user-select: none; }
            #player-container { width: 100%; height: 100%; position: absolute; top: 0; left: 0; }
            ruffle-player { display: block; }
        </style>
        <script>
            // ---- Console -> native bridge ----
            (function () {
                var lines = [];
                window.__ajHadError = false;
                window.__ajShow = function (line) {
                    if (line !== null && line !== undefined) { lines.push(line); if (lines.length > 14) lines.shift(); }
                    var el = document.getElementById('ajstatus');
                    if (el) el.textContent = lines.join('\n');
                };
                window.__ajHide = function () {
                    var el = document.getElementById('ajstatus');
                    if (el) el.style.display = 'none';
                };
                function send(m) {
                    if (/^(ERROR|WARN|JS Exception|Unhandled)/.test(m)) window.__ajHadError = true;
                    try { window.__ajShow(m); } catch (e) {}
                    try { window.webkit.messageHandlers.consoleLog.postMessage(m); } catch (e) {}
                }
                ['log', 'info', 'warn', 'error', 'debug'].forEach(function (k) {
                    var orig = console[k];
                    console[k] = function () {
                        var msg = [].slice.call(arguments).map(function (x) {
                            try { return (typeof x === 'object') ? JSON.stringify(x) : String(x); } catch (e) { return String(x); }
                        }).join(' ');
                        send((k === 'log' ? '' : k.toUpperCase() + ': ') + msg);
                        try { orig.apply(console, arguments); } catch (e) {}
                    };
                });
                window.addEventListener('error', function (e) {
                    send('JS Exception: ' + e.message + ' @' + (e.filename || '') + ':' + (e.lineno || ''));
                });
                window.addEventListener('unhandledrejection', function (e) {
                    send('Unhandled rejection: ' + ((e.reason && e.reason.message) || e.reason));
                });
            })();

            // ---- Route cross-origin game requests through the local proxy (adds CORS) ----
            (function () {
                var ORIGIN = location.origin;
                var DIRECT_HOSTS = ['unpkg.com', 'cdn.jsdelivr.net'];
                function rewrite(u) {
                    try {
                        var abs = new URL(u, location.href);
                        if (abs.protocol !== 'http:' && abs.protocol !== 'https:') return u;
                        if (abs.origin === ORIGIN) return u;
                        if (DIRECT_HOSTS.indexOf(abs.hostname) !== -1) return u;
                        return ORIGIN + '/proxy/' + abs.protocol.slice(0, -1) + '/' + abs.host + abs.pathname + abs.search;
                    } catch (e) { return u; }
                }
                window.__ajRewrite = rewrite;

                var origFetch = window.fetch;
                window.fetch = function (input, init) {
                    try {
                        if (typeof input === 'string' || (window.URL && input instanceof URL)) {
                            return origFetch.call(this, rewrite(String(input)), init);
                        }
                        if (window.Request && input instanceof Request) {
                            var nu = rewrite(input.url);
                            if (nu !== input.url) return origFetch.call(this, new Request(nu, input), init);
                        }
                    } catch (e) { console.error('fetch rewrite failed: ' + e); }
                    return origFetch.call(this, input, init);
                };

                var origOpen = XMLHttpRequest.prototype.open;
                XMLHttpRequest.prototype.open = function (method, url) {
                    var args = [].slice.call(arguments);
                    args[1] = rewrite(String(url));
                    return origOpen.apply(this, args);
                };
            })();

            // ---- Ruffle config + loader with CDN fallback ----
            window.RufflePlayer = window.RufflePlayer || {};
            window.RufflePlayer.config = {
                autoplay: "on",
                unmuteOverlay: "hidden",
                splashScreen: false,
                allowScriptAccess: true,
                warnOnUnsupportedContent: false,
                letterbox: "on",
                upgradeToHttps: false,
                backgroundColor: "#000000"
            };

            (function loadRuffle(urls, i) {
                if (i >= urls.length) { console.error('Ruffle failed to load from every CDN (check internet connection).'); return; }
                var s = document.createElement('script');
                s.src = urls[i];
                s.onload = function () { console.log('Ruffle loaded from ' + urls[i]); };
                s.onerror = function () {
                    console.warn('Ruffle CDN failed: ' + urls[i]);
                    loadRuffle(urls, i + 1);
                };
                document.head.appendChild(s);
            })([
                'https://unpkg.com/@ruffle-rs/ruffle',
                'https://cdn.jsdelivr.net/npm/@ruffle-rs/ruffle'
            ], 0);
        </script>
    </head>
    <body>
        <div id="player-container"></div>
        <pre id="ajstatus" style="position:fixed;left:6px;right:6px;bottom:6px;margin:0;z-index:99999;pointer-events:none;color:#7CFC00;font:10px/1.3 Menlo,monospace;white-space:pre-wrap;word-break:break-all;text-shadow:0 0 3px #000;"></pre>
        <script>
            window.__ajShow(null);
            console.log('Player page ready. WebAssembly: ' + (typeof WebAssembly));
            window.aj = window.aj || {
                ready: function () { console.log("AJ ExternalInterface: ready"); return true; },
                login: function () { console.log("AJ ExternalInterface: login"); },
                logout: function () { console.log("AJ ExternalInterface: logout"); },
                reload: function () { location.reload(); },
                openExternalUrl: function (url) { console.log("External URL: " + url); },
                getDF: function () { return window.__ajFlashvars ? window.__ajFlashvars.df : ""; },
                getAuthToken: function () { return window.__ajFlashvars ? window.__ajFlashvars.auth_token : ""; },
                getUsername: function () { return window.__ajFlashvars ? window.__ajFlashvars.username : ""; },
                getPlatform: function () { return "mac"; },
                getVersion: function () { return "1.6.4"; },
                minimize: function () {}, maximize: function () {}, close: function () {}, showWindow: function () {}
            };
            window.ipcRenderer = window.ipcRenderer || {
                send: function (ch, data) { console.log("IPC send: " + ch); },
                on: function () {},
                invoke: function (ch) { console.log("IPC invoke: " + ch); return Promise.resolve({}); }
            };

            function whenRuffleReady(cb, waited) {
                waited = waited || 0;
                if (window.RufflePlayer && typeof window.RufflePlayer.newest === 'function') { cb(); return; }
                if (waited > 30000) { console.error('Timed out waiting for Ruffle.'); return; }
                setTimeout(function () { whenRuffleReady(cb, waited + 200); }, 200);
            }

            window.startAJWithSession = function (flashvars, swfUrl, baseContentUrl, socketProxies) {
                window.__ajFlashvars = flashvars;
                console.log("Starting Ruffle with SWF: " + swfUrl);
                fetch(swfUrl).then(function (r) {
                    console.log("SWF fetch status " + r.status + " type " + r.headers.get("content-type"));
                    return r.arrayBuffer();
                }).then(function (b) {
                    var h = new Uint8Array(b.slice(0, 3));
                    console.log("SWF bytes " + b.byteLength + " header " + String.fromCharCode(h[0], h[1], h[2]));
                }).catch(function (e) { console.error("SWF precheck failed: " + e); });
                whenRuffleReady(function () {
                    var container = document.getElementById("player-container");
                    container.innerHTML = "";

                    var ruffle = window.RufflePlayer.newest();
                    if (!ruffle) { console.error("Ruffle failed to initialise."); return; }

                    try { console.log("Ruffle version: " + (ruffle.version || (window.RufflePlayer.sources && Object.keys(window.RufflePlayer.sources)) || "?")); } catch (e) {}
                    var player = ruffle.createPlayer();
                    player.addEventListener("loadedmetadata", function () {
                        try { console.log("SWF metadata: " + JSON.stringify(player.metadata)); } catch (e) {}
                    });
                    player.style.width = "100%";
                    player.style.height = "100%";
                    container.appendChild(player);

                    player.addEventListener("fscommand", function (e) {
                        console.log("FSCommand: " + e.detail.command + " " + e.detail.args);
                    });

                    player.load({
                        url: swfUrl,
                        base: baseContentUrl,
                        parameters: flashvars,
                        allowScriptAccess: true,
                        allowNetworking: "all",
                        letterbox: "on",
                        upgradeToHttps: false,
                        autoplay: "on",
                        unmuteOverlay: "hidden",
                        splashScreen: false,
                        backgroundColor: "#000000",
                        socketProxy: socketProxies || []
                    }).then(function () {
                        console.log("Ruffle load() resolved");
                        setTimeout(function () { if (!window.__ajHadError) window.__ajHide(); }, 20000);
                    }).catch(function (err) {
                        console.error("Ruffle load error: " + err);
                    });
                });
            };
        </script>
    </body>
    </html>
    """#
}
