import SwiftUI

@main
struct GlassCordApp: App {
    @State private var store = DiscordStore()

    var body: some Scene {
        WindowGroup {
            Group {
                if store.isAuthenticated {
                    MainShellView()
                        .transition(.opacity.combined(with: .scale(scale: 0.98)))
                } else {
                    WebLoginView()
                        .transition(.opacity)
                }
            }
            .animation(.spring(duration: 0.4), value: store.isAuthenticated)
            .environment(store)
        }
    }
}
