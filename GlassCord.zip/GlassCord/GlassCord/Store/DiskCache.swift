import Foundation

struct CachedWorkspaceSnapshot: Codable, Sendable {
    var currentUser: DiscordUser?
    var guilds: [DiscordGuild]
    var guildFolders: [DiscordGuildFolder]
    var dmChannels: [DiscordChannel]
    var channelsByGuild: [String: [DiscordChannel]]
    var messagesByChannel: [String: [DiscordMessage]]
    var relationships: [DiscordRelationship]
    var selectedGuildId: String?
    var selectedChannelId: String?
    var savedAt: Date
}

actor DiskCache {
    static let shared = DiskCache()

    private let cacheURL: URL = {
        let dir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!
        return dir.appendingPathComponent("GlassCordSnapshot_v1.json")
    }()

    func loadSnapshot() -> CachedWorkspaceSnapshot? {
        guard let data = try? Data(contentsOf: cacheURL) else { return nil }
        return try? JSONDecoder().decode(CachedWorkspaceSnapshot.self, from: data)
    }

    func saveSnapshot(_ snapshot: CachedWorkspaceSnapshot) {
        // Keep cache lean: store at most 40 most recent messages per channel for instant startup
        var trimmed = snapshot
        trimmed.messagesByChannel = snapshot.messagesByChannel.mapValues { Array($0.suffix(40)) }
        guard let data = try? JSONEncoder().encode(trimmed) else { return }
        try? data.write(to: cacheURL, options: .atomic)
    }

    func clear() {
        try? FileManager.default.removeItem(at: cacheURL)
    }
}
