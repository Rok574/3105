import Foundation
import SwiftUI

@MainActor
@Observable
final class DiscordStore {
    let api = DiscordAPI()
    let gateway = DiscordGateway()
    let voiceEngine = VoiceEngine()

    var isAuthenticated = false
    var isConnecting = false
    var connectionStatus: String = "Disconnected"
    var errorBanner: String?
    var uploadStatusText: String?

    var currentUser: DiscordUser?
    var guilds: [DiscordGuild] = []
    var guildFolders: [DiscordGuildFolder] = []
    var dmChannels: [DiscordChannel] = []
    var channelsByGuild: [String: [DiscordChannel]] = [:]
    var messagesByChannel: [String: [DiscordMessage]] = [:]
    var pinnedMessagesByChannel: [String: [DiscordMessage]] = [:]
    var relationships: [DiscordRelationship] = []
    var presences: [String: PresenceStatus] = [:]
    var readStates: [String: DiscordReadState] = [:]
    var typingUsersByChannel: [String: [String: Date]] = [:]
    var voiceStatesByChannel: [String: [DiscordVoiceState]] = [:]

    var selectedGuildId: String?
    var selectedChannelId: String?
    var connectedVoiceChannelId: String?
    var connectedVoiceGuildId: String?
    var selfMute = false
    var selfDeaf = false

    private var myVoiceSessionId: String?
    private var pendingVoiceServerUpdate: VoiceServerUpdatePayload?

    // MARK: - GlassCord Extras (Fake Nitro, Free Emojis, Catbox)
    var currentPresence: PresenceStatus = .online
    var customStatusText: String = ""

    var fakeNitroEnabled: Bool = UserDefaults.standard.object(forKey: "gc_fakeNitro") as? Bool ?? true {
        didSet { UserDefaults.standard.set(fakeNitroEnabled, forKey: "gc_fakeNitro") }
    }
    var freeEmojisEnabled: Bool = UserDefaults.standard.object(forKey: "gc_freeEmojis") as? Bool ?? true {
        didSet { UserDefaults.standard.set(freeEmojisEnabled, forKey: "gc_freeEmojis") }
    }
    var catboxAutoFallback: Bool = UserDefaults.standard.object(forKey: "gc_catboxFallback") as? Bool ?? true {
        didSet { UserDefaults.standard.set(catboxAutoFallback, forKey: "gc_catboxFallback") }
    }
    var catboxThresholdMB: Int = UserDefaults.standard.object(forKey: "gc_catboxThresholdMB") as? Int ?? 10 {
        didSet { UserDefaults.standard.set(catboxThresholdMB, forKey: "gc_catboxThresholdMB") }
    }
    var catboxUserhash: String = UserDefaults.standard.string(forKey: "gc_catboxUserhash") ?? "" {
        didSet { UserDefaults.standard.set(catboxUserhash, forKey: "gc_catboxUserhash") }
    }

    private var typingCleanupTask: Task<Void, Never>?
    private var saveCacheTask: Task<Void, Never>?

    init() {
        gateway.onEvent = { [weak self] event in
            await self?.handleGatewayEvent(event)
        }
        if let saved = KeychainHelper.loadToken(), !saved.isEmpty {
            self.isAuthenticated = true
            self.connectionStatus = "Syncing..."
            Task {
                await loadCachedSnapshotIfAvailable()
                await authenticate(with: saved, persist: false)
            }
        }
    }

    private func loadCachedSnapshotIfAvailable() async {
        guard let snap = await DiskCache.shared.loadSnapshot() else { return }
        if currentUser == nil { currentUser = snap.currentUser }
        if guilds.isEmpty { guilds = snap.guilds }
        if guildFolders.isEmpty { guildFolders = snap.guildFolders }
        if dmChannels.isEmpty { dmChannels = snap.dmChannels }
        if channelsByGuild.isEmpty { channelsByGuild = snap.channelsByGuild }
        if messagesByChannel.isEmpty { messagesByChannel = snap.messagesByChannel }
        if relationships.isEmpty { relationships = snap.relationships }
        if selectedGuildId == nil { selectedGuildId = snap.selectedGuildId }
        if selectedChannelId == nil { selectedChannelId = snap.selectedChannelId }
    }

    private func scheduleCacheSave() {
        saveCacheTask?.cancel()
        saveCacheTask = Task { [weak self] in
            try? await Task.sleep(for: .seconds(1.5))
            guard let self, !Task.isCancelled else { return }
            let snapshot = CachedWorkspaceSnapshot(
                currentUser: self.currentUser,
                guilds: self.guilds,
                guildFolders: self.guildFolders,
                dmChannels: self.dmChannels,
                channelsByGuild: self.channelsByGuild,
                messagesByChannel: self.messagesByChannel,
                relationships: self.relationships,
                selectedGuildId: self.selectedGuildId,
                selectedChannelId: self.selectedChannelId,
                savedAt: Date()
            )
            await DiskCache.shared.saveSnapshot(snapshot)
        }
    }

    func authenticate(with rawToken: String, persist: Bool = true) async {
        let token = rawToken.trimmingCharacters(in: CharacterSet(charactersIn: "\" \n\r\t"))
        guard !token.isEmpty else { return }

        isConnecting = true
        connectionStatus = "Connecting..."
        errorBanner = nil
        await api.setToken(token)

        do {
            let user = try await api.fetchCurrentUser()
            self.currentUser = user
            if persist {
                KeychainHelper.saveToken(token)
            }
            self.isAuthenticated = true
            gateway.connect(token: token)
            startTypingCleanupLoop()
        } catch {
            self.isConnecting = false
            self.connectionStatus = "Auth failed"
            self.errorBanner = error.localizedDescription
            if case DiscordAPIError.unauthorized = error {
                self.isAuthenticated = false
                KeychainHelper.deleteToken()
                await DiskCache.shared.clear()
            }
        }
    }

    func signOut() {
        voiceEngine.disconnect()
        gateway.disconnect()
        KeychainHelper.deleteToken()
        Task { await DiskCache.shared.clear() }
        isAuthenticated = false
        isConnecting = false
        connectionStatus = "Signed out"
        currentUser = nil
        guilds = []
        guildFolders = []
        dmChannels = []
        channelsByGuild = [:]
        messagesByChannel = [:]
        relationships = []
        presences = [:]
        selectedGuildId = nil
        selectedChannelId = nil
        connectedVoiceChannelId = nil
        connectedVoiceGuildId = nil
        myVoiceSessionId = nil
        pendingVoiceServerUpdate = nil
    }

    // MARK: - Selection & Data Loading
    func selectGuild(_ guildId: String?) async {
        selectedGuildId = guildId
        if let guildId {
            if channelsByGuild[guildId] == nil || channelsByGuild[guildId]?.isEmpty == true {
                do {
                    let fetched = try await api.fetchGuildChannels(guildId: guildId)
                    channelsByGuild[guildId] = fetched.sorted { ($0.position ?? 0) < ($1.position ?? 0) }
                } catch {
                    errorBanner = error.localizedDescription
                }
            }
            if let firstText = channelsByGuild[guildId]?.first(where: { $0.isTextLike }) {
                await selectChannel(firstText.id)
            }
        } else if let firstDM = sortedDMChannels.first {
            await selectChannel(firstDM.id)
        }
        scheduleCacheSave()
    }

    func selectChannel(_ channelId: String) async {
        selectedChannelId = channelId
        if messagesByChannel[channelId] == nil || messagesByChannel[channelId]?.isEmpty == true {
            await loadMessages(channelId: channelId)
        } else {
            Task { await loadMessages(channelId: channelId) }
        }
        if let lastId = messagesByChannel[channelId]?.last?.id {
            Task { try? await api.ackMessage(channelId: channelId, messageId: lastId) }
            readStates[channelId] = DiscordReadState(id: channelId, lastMessageId: lastId, mentionCount: 0)
        }
        scheduleCacheSave()
    }

    func loadMessages(channelId: String, loadOlder: Bool = false) async {
        let beforeId = loadOlder ? messagesByChannel[channelId]?.first?.id : nil
        do {
            let fetched = try await api.fetchMessages(channelId: channelId, before: beforeId, limit: 50)
            if loadOlder {
                let existing = messagesByChannel[channelId] ?? []
                let existingIds = Set(existing.map(\.id))
                let uniqueOlder = fetched.filter { !existingIds.contains($0.id) }
                messagesByChannel[channelId] = uniqueOlder + existing
            } else {
                messagesByChannel[channelId] = fetched
            }
            scheduleCacheSave()
        } catch {
            errorBanner = error.localizedDescription
        }
    }

    func sendMessage(
        channelId: String,
        content: String,
        replyToMessageId: String? = nil,
        attachments: [OutgoingAttachment] = []
    ) async {
        var finalContent = content.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !finalContent.isEmpty || !attachments.isEmpty else { return }

        let maxBytes = catboxThresholdMB * 1024 * 1024
        var directAttachments: [OutgoingAttachment] = []
        var catboxQueue: [OutgoingAttachment] = []

        for att in attachments {
            if catboxAutoFallback && att.data.count > maxBytes {
                catboxQueue.append(att)
            } else {
                directAttachments.append(att)
            }
        }

        var catboxLinks: [String] = []
        if !catboxQueue.isEmpty {
            uploadStatusText = "Uploading \(catboxQueue.count) large file(s) to Catbox..."
            for att in catboxQueue {
                do {
                    let link = try await CatboxUploader.shared.upload(
                        data: att.data,
                        filename: att.filename,
                        mimeType: att.mimeType,
                        userhash: catboxUserhash
                    )
                    catboxLinks.append(link)
                } catch {
                    uploadStatusText = nil
                    errorBanner = error.localizedDescription
                    return
                }
            }
            uploadStatusText = nil
        }

        if !catboxLinks.isEmpty {
            let linksBlock = catboxLinks.joined(separator: "\n")
            finalContent = finalContent.isEmpty ? linksBlock : "\(finalContent)\n\(linksBlock)"
        }

        do {
            let sent = try await api.sendMessage(
                channelId: channelId,
                content: finalContent,
                replyToMessageId: replyToMessageId,
                attachments: directAttachments
            )
            appendMessageIfNeeded(sent)
            scheduleCacheSave()
        } catch let err as DiscordAPIError {
            if catboxAutoFallback,
               !directAttachments.isEmpty,
               case .httpError(let code, let body) = err,
               code == 413 || body.contains("40005") || body.lowercased().contains("too large") {
                uploadStatusText = "Discord rejected size — uploading to Catbox..."
                var fallbackLinks: [String] = []
                for att in directAttachments {
                    if let link = try? await CatboxUploader.shared.upload(
                        data: att.data,
                        filename: att.filename,
                        mimeType: att.mimeType,
                        userhash: catboxUserhash
                    ) {
                        fallbackLinks.append(link)
                    }
                }
                uploadStatusText = nil
                if !fallbackLinks.isEmpty {
                    let joined = fallbackLinks.joined(separator: "\n")
                    let retryContent = finalContent.isEmpty ? joined : "\(finalContent)\n\(joined)"
                    if let sent = try? await api.sendMessage(
                        channelId: channelId,
                        content: retryContent,
                        replyToMessageId: replyToMessageId,
                        attachments: []
                    ) {
                        appendMessageIfNeeded(sent)
                        scheduleCacheSave()
                        return
                    }
                }
            }
            errorBanner = err.localizedDescription
        } catch {
            errorBanner = error.localizedDescription
        }
    }

    func editMessage(channelId: String, messageId: String, newContent: String) async {
        do {
            let updated = try await api.editMessage(channelId: channelId, messageId: messageId, content: newContent)
            updateMessage(updated)
            scheduleCacheSave()
        } catch {
            errorBanner = error.localizedDescription
        }
    }

    func deleteMessage(channelId: String, messageId: String) async {
        do {
            try await api.deleteMessage(channelId: channelId, messageId: messageId)
            messagesByChannel[channelId]?.removeAll { $0.id == messageId }
            scheduleCacheSave()
        } catch {
            errorBanner = error.localizedDescription
        }
    }

    func toggleReaction(channelId: String, messageId: String, emoji: DiscordEmoji, currentlyMe: Bool) async {
        do {
            if currentlyMe {
                try await api.removeReaction(channelId: channelId, messageId: messageId, emoji: emoji.apiIdentifier)
            } else {
                try await api.addReaction(channelId: channelId, messageId: messageId, emoji: emoji.apiIdentifier)
            }
        } catch {
            errorBanner = error.localizedDescription
        }
    }

    func notifyTyping(channelId: String) {
        Task { try? await api.triggerTyping(channelId: channelId) }
    }

    func openDM(with userId: String) async {
        if let existing = dmChannels.first(where: { $0.type == .dm && $0.recipients?.contains(where: { $0.id == userId }) == true }) {
            selectedGuildId = nil
            await selectChannel(existing.id)
            return
        }
        do {
            let dm = try await api.createDM(recipientId: userId)
            if !dmChannels.contains(where: { $0.id == dm.id }) {
                dmChannels.insert(dm, at: 0)
            }
            selectedGuildId = nil
            await selectChannel(dm.id)
        } catch {
            errorBanner = error.localizedDescription
        }
    }

    // MARK: - Voice Channel State & WebRTC Engine
    func joinVoiceChannel(_ channel: DiscordChannel) {
        connectedVoiceChannelId = channel.id
        connectedVoiceGuildId = channel.guildId
        pendingVoiceServerUpdate = nil
        gateway.sendVoiceStateUpdate(
            guildId: channel.guildId,
            channelId: channel.id,
            selfMute: selfMute,
            selfDeaf: selfDeaf
        )
    }

    func leaveVoiceChannel() {
        voiceEngine.disconnect()
        gateway.sendVoiceStateUpdate(guildId: connectedVoiceGuildId, channelId: nil, selfMute: false, selfDeaf: false)
        connectedVoiceChannelId = nil
        connectedVoiceGuildId = nil
        myVoiceSessionId = nil
        pendingVoiceServerUpdate = nil
    }

    func toggleMute() {
        selfMute.toggle()
        voiceEngine.setMuted(selfMute)
        if let ch = connectedVoiceChannelId {
            gateway.sendVoiceStateUpdate(guildId: connectedVoiceGuildId, channelId: ch, selfMute: selfMute, selfDeaf: selfDeaf)
        }
    }

    func toggleDeafen() {
        selfDeaf.toggle()
        if selfDeaf { selfMute = true }
        voiceEngine.setDeafened(selfDeaf)
        if let ch = connectedVoiceChannelId {
            gateway.sendVoiceStateUpdate(guildId: connectedVoiceGuildId, channelId: ch, selfMute: selfMute, selfDeaf: selfDeaf)
        }
    }

    private func tryStartVoiceEngine() {
        guard let vsu = pendingVoiceServerUpdate,
              let endpoint = vsu.endpoint,
              let sessionId = myVoiceSessionId,
              let uid = currentUser?.id else { return }

        let serverId = vsu.guildId ?? vsu.channelId ?? ""
        guard !serverId.isEmpty else { return }

        voiceEngine.connect(
            serverId: serverId,
            userId: uid,
            sessionId: sessionId,
            token: vsu.token,
            endpoint: endpoint
        )
    }

    func updateStatus(_ status: PresenceStatus, customText: String) async {
        currentPresence = status
        customStatusText = customText
        gateway.sendPresenceUpdate(status: status)
        try? await api.updatePresence(status: status, customText: customText)
    }

    // MARK: - Computed Helpers
    var sortedDMChannels: [DiscordChannel] {
        dmChannels.sorted { ($0.lastMessageId ?? "0") > ($1.lastMessageId ?? "0") }
    }

    var activeChannel: DiscordChannel? {
        guard let selectedChannelId else { return nil }
        if let dm = dmChannels.first(where: { $0.id == selectedChannelId }) { return dm }
        for channels in channelsByGuild.values {
            if let ch = channels.first(where: { $0.id == selectedChannelId }) { return ch }
        }
        return nil
    }

    var activeGuild: DiscordGuild? {
        guard let selectedGuildId else { return nil }
        return guilds.first(where: { $0.id == selectedGuildId })
    }

    var allCustomEmojisByGuild: [(guild: DiscordGuild, emojis: [DiscordEmoji])] {
        guilds.compactMap { guild in
            guard let emojis = guild.emojis, !emojis.isEmpty else { return nil }
            return (guild, emojis)
        }
    }

    func emojiInsertionString(for emoji: DiscordEmoji, inGuildId: String?) -> String {
        guard let id = emoji.id, let name = emoji.name else {
            return emoji.name ?? ""
        }
        let isSameGuild = inGuildId != nil && guilds.first(where: { $0.id == inGuildId })?.emojis?.contains(where: { $0.id == id }) == true
        let isAnimated = emoji.animated ?? false

        if isSameGuild && !isAnimated {
            return "<:\(name):\(id)>"
        }
        if fakeNitroEnabled || freeEmojisEnabled {
            let ext = isAnimated ? "gif" : "png"
            return "https://cdn.discordapp.com/emojis/\(id).\(ext)?size=48&quality=lossless"
        }
        return "<\(isAnimated ? "a" : ""):\(name):\(id)>"
    }

    func isUnread(channel: DiscordChannel) -> Bool {
        guard let lastMsg = channel.lastMessageId else { return false }
        guard let readId = readStates[channel.id]?.lastMessageId else { return false }
        return lastMsg > readId
    }

    func typingText(for channelId: String) -> String? {
        guard let map = typingUsersByChannel[channelId] else { return nil }
        let activeIds = map.filter { Date().timeIntervalSince($0.value) < 8 && $0.key != currentUser?.id }.keys
        guard !activeIds.isEmpty else { return nil }
        let names = activeIds.compactMap { uid in
            relationships.first(where: { $0.user.id == uid })?.user.displayName
            ?? messagesByChannel[channelId]?.last(where: { $0.author.id == uid })?.author.displayName
            ?? "Someone"
        }
        if names.count == 1 { return "\(names[0]) is typing..." }
        if names.count == 2 { return "\(names[0]) and \(names[1]) are typing..." }
        return "Several people are typing..."
    }

    // MARK: - Gateway Event Handling
    private func handleGatewayEvent(_ event: GatewayEvent) async {
        switch event {
        case .connected:
            isConnecting = false
            connectionStatus = "Connected"
        case .disconnected(let reason):
            connectionStatus = "Reconnecting (\(reason))..."
        case .ready(let ready):
            currentUser = ready.user
            guilds = ready.guilds
            guildFolders = ready.userSettings?.guildFolders ?? []
            if let status = ready.userSettings?.status {
                currentPresence = status
            }
            dmChannels = ready.privateChannels ?? []
            relationships = ready.relationships ?? []
            for p in ready.presences ?? [] {
                if let uid = p.user?.id, let status = p.status {
                    presences[uid] = status
                }
            }
            for rs in ready.readState ?? [] {
                readStates[rs.id] = rs
            }
            for guild in ready.guilds {
                if let chs = guild.channels {
                    channelsByGuild[guild.id] = chs.sorted { ($0.position ?? 0) < ($1.position ?? 0) }
                }
            }
            if selectedChannelId == nil, let firstDM = sortedDMChannels.first {
                await selectChannel(firstDM.id)
            }
            scheduleCacheSave()
        case .messageCreate(let msg):
            appendMessageIfNeeded(msg)
            typingUsersByChannel[msg.channelId]?.removeValue(forKey: msg.author.id)
            updateChannelLastMessage(channelId: msg.channelId, messageId: msg.id)
            scheduleCacheSave()
        case .messageUpdate(let msg):
            updateMessage(msg)
        case .messageDelete(let id, let channelId):
            messagesByChannel[channelId]?.removeAll { $0.id == id }
        case .reactionAdd(let channelId, let messageId, let userId, let emoji):
            applyReactionDelta(channelId: channelId, messageId: messageId, emoji: emoji, delta: 1, isMe: userId == currentUser?.id)
        case .reactionRemove(let channelId, let messageId, let userId, let emoji):
            applyReactionDelta(channelId: channelId, messageId: messageId, emoji: emoji, delta: -1, isMe: userId == currentUser?.id)
        case .typingStart(let channelId, let userId):
            var map = typingUsersByChannel[channelId] ?? [:]
            map[userId] = Date()
            typingUsersByChannel[channelId] = map
        case .presenceUpdate(let presence):
            if let uid = presence.user?.id, let status = presence.status {
                presences[uid] = status
            }
        case .channelCreate(let ch):
            if let gid = ch.guildId {
                var list = channelsByGuild[gid] ?? []
                list.append(ch)
                channelsByGuild[gid] = list.sorted { ($0.position ?? 0) < ($1.position ?? 0) }
            } else if !dmChannels.contains(where: { $0.id == ch.id }) {
                dmChannels.insert(ch, at: 0)
            }
        case .channelUpdate(let ch):
            if let gid = ch.guildId, var list = channelsByGuild[gid] {
                if let idx = list.firstIndex(where: { $0.id == ch.id }) {
                    list[idx] = ch
                    channelsByGuild[gid] = list.sorted { ($0.position ?? 0) < ($1.position ?? 0) }
                }
            } else if let idx = dmChannels.firstIndex(where: { $0.id == ch.id }) {
                dmChannels[idx] = ch
            }
        case .channelDelete(let ch):
            if let gid = ch.guildId {
                channelsByGuild[gid]?.removeAll { $0.id == ch.id }
            } else {
                dmChannels.removeAll { $0.id == ch.id }
            }
        case .guildCreate(let guild):
            if let idx = guilds.firstIndex(where: { $0.id == guild.id }) {
                guilds[idx] = guild
            } else {
                guilds.append(guild)
            }
            if let chs = guild.channels {
                channelsByGuild[guild.id] = chs.sorted { ($0.position ?? 0) < ($1.position ?? 0) }
            }
        case .relationshipAdd(let rel):
            if let idx = relationships.firstIndex(where: { $0.id == rel.id }) {
                relationships[idx] = rel
            } else {
                relationships.append(rel)
            }
        case .relationshipRemove(let id):
            relationships.removeAll { $0.id == id }
        case .voiceStateUpdate(let vs):
            for key in voiceStatesByChannel.keys {
                voiceStatesByChannel[key]?.removeAll { $0.userId == vs.userId }
            }
            if let chId = vs.channelId {
                var list = voiceStatesByChannel[chId] ?? []
                list.append(vs)
                voiceStatesByChannel[chId] = list
            }
            if vs.userId == currentUser?.id {
                myVoiceSessionId = vs.sessionId
                if vs.channelId == nil {
                    voiceEngine.disconnect()
                    connectedVoiceChannelId = nil
                    connectedVoiceGuildId = nil
                } else {
                    tryStartVoiceEngine()
                }
            }
        case .voiceServerUpdate(let vsu):
            pendingVoiceServerUpdate = vsu
            tryStartVoiceEngine()
        }
    }

    private func appendMessageIfNeeded(_ msg: DiscordMessage) {
        var list = messagesByChannel[msg.channelId] ?? []
        if !list.contains(where: { $0.id == msg.id }) {
            list.append(msg)
            messagesByChannel[msg.channelId] = list
        }
    }

    private func updateMessage(_ msg: DiscordMessage) {
        guard var list = messagesByChannel[msg.channelId],
              let idx = list.firstIndex(where: { $0.id == msg.id }) else { return }
        list[idx] = msg
        messagesByChannel[msg.channelId] = list
    }

    private func updateChannelLastMessage(channelId: String, messageId: String) {
        if let idx = dmChannels.firstIndex(where: { $0.id == channelId }) {
            dmChannels[idx].lastMessageId = messageId
        }
        for (gid, var list) in channelsByGuild {
            if let idx = list.firstIndex(where: { $0.id == channelId }) {
                list[idx].lastMessageId = messageId
                channelsByGuild[gid] = list
                break
            }
        }
    }

    private func applyReactionDelta(channelId: String, messageId: String, emoji: DiscordEmoji, delta: Int, isMe: Bool) {
        guard var list = messagesByChannel[channelId],
              let mIdx = list.firstIndex(where: { $0.id == messageId }) else { return }
        var reactions = list[mIdx].reactions ?? []
        if let rIdx = reactions.firstIndex(where: { $0.emoji.apiIdentifier == emoji.apiIdentifier }) {
            reactions[rIdx].count += delta
            if isMe { reactions[rIdx].me = delta > 0 }
            if reactions[rIdx].count <= 0 { reactions.remove(at: rIdx) }
        } else if delta > 0 {
            reactions.append(DiscordReaction(count: 1, me: isMe, emoji: emoji))
        }
        list[mIdx].reactions = reactions
        messagesByChannel[channelId] = list
    }

    private func startTypingCleanupLoop() {
        typingCleanupTask?.cancel()
        typingCleanupTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(3))
                guard let self else { break }
                let now = Date()
                for (cid, map) in self.typingUsersByChannel {
                    let filtered = map.filter { now.timeIntervalSince($0.value) < 8 }
                    self.typingUsersByChannel[cid] = filtered.isEmpty ? nil : filtered
                }
            }
        }
    }
}
