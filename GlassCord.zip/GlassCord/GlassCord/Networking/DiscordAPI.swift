import Foundation

enum DiscordAPIError: LocalizedError {
    case invalidURL
    case unauthorized
    case httpError(Int, String)
    case decodingError(Error)

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "Invalid Discord API URL."
        case .unauthorized: return "Discord token expired or invalid. Please sign in again."
        case .httpError(let code, let body): return "HTTP \(code): \(body)"
        case .decodingError(let err): return "Decoding error: \(err.localizedDescription)"
        }
    }
}

struct OutgoingAttachment: Sendable {
    let filename: String
    let mimeType: String
    let data: Data
}

actor DiscordAPI {
    static let baseURL = "https://discord.com/api/v10"
    private let session: URLSession
    private var token: String = ""

    private static let superPropertiesBase64: String = {
        let props: [String: Any] = [
            "os": "iOS",
            "browser": "Discord iOS",
            "device": "iPhone17,1",
            "system_locale": Locale.current.identifier,
            "client_version": "265.0",
            "release_channel": "stable",
            "os_version": "26.0"
        ]
        let data = (try? JSONSerialization.data(withJSONObject: props)) ?? Data()
        return data.base64EncodedString()
    }()

    init() {
        let config = URLSessionConfiguration.default
        config.httpAdditionalHeaders = [
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.9"
        ]
        self.session = URLSession(configuration: config)
    }

    func setToken(_ newToken: String) {
        self.token = newToken
    }

    private func request<T: Decodable>(
        _ path: String,
        method: String = "GET",
        body: Data? = nil,
        contentType: String = "application/json"
    ) async throws -> T {
        guard let url = URL(string: Self.baseURL + path) else { throw DiscordAPIError.invalidURL }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue(token, forHTTPHeaderField: "Authorization")
        req.setValue(Self.superPropertiesBase64, forHTTPHeaderField: "X-Super-Properties")
        req.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 26_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148", forHTTPHeaderField: "User-Agent")
        if let body {
            req.httpBody = body
            req.setValue(contentType, forHTTPHeaderField: "Content-Type")
        }

        let (data, response) = try await session.data(for: req)
        guard let http = response as? HTTPURLResponse else {
            throw DiscordAPIError.httpError(-1, "No HTTP response")
        }
        if http.statusCode == 401 {
            throw DiscordAPIError.unauthorized
        }
        guard (200..<300).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? ""
            throw DiscordAPIError.httpError(http.statusCode, text)
        }
        if T.self == EmptyResponse.self {
            return EmptyResponse() as! T
        }
        do {
            return try JSONDecoder().decode(T.self, from: data)
        } catch {
            throw DiscordAPIError.decodingError(error)
        }
    }

    private func sendEmpty(_ path: String, method: String = "POST", body: Data? = nil) async throws {
        let _: EmptyResponse = try await request(path, method: method, body: body)
    }

    // MARK: - User & Settings
    func fetchCurrentUser() async throws -> DiscordUser {
        try await request("/users/@me")
    }

    func fetchUser(_ userId: String) async throws -> DiscordUser {
        try await request("/users/\(userId)")
    }

    func updatePresence(status: PresenceStatus, customText: String?) async throws {
        var payload: [String: Any] = ["status": status.rawValue]
        if let customText {
            payload["custom_status"] = customText.isEmpty ? NSNull() : ["text": customText]
        }
        let data = try JSONSerialization.data(withJSONObject: payload)
        try await sendEmpty("/users/@me/settings", method: "PATCH", body: data)
    }

    // MARK: - Guilds & Channels
    func fetchGuilds() async throws -> [DiscordGuild] {
        try await request("/users/@me/guilds")
    }

    func fetchGuildChannels(guildId: String) async throws -> [DiscordChannel] {
        try await request("/guilds/\(guildId)/channels")
    }

    func fetchDMChannels() async throws -> [DiscordChannel] {
        try await request("/users/@me/channels")
    }

    func createDM(recipientId: String) async throws -> DiscordChannel {
        let data = try JSONSerialization.data(withJSONObject: ["recipient_id": recipientId])
        return try await request("/users/@me/channels", method: "POST", body: data)
    }

    // MARK: - Messages
    func fetchMessages(channelId: String, before: String? = nil, limit: Int = 50) async throws -> [DiscordMessage] {
        var path = "/channels/\(channelId)/messages?limit=\(limit)"
        if let before {
            path += "&before=\(before)"
        }
        let messages: [DiscordMessage] = try await request(path)
        return messages.reversed()
    }

    func fetchPinnedMessages(channelId: String) async throws -> [DiscordMessage] {
        try await request("/channels/\(channelId)/pins")
    }

    func sendMessage(
        channelId: String,
        content: String,
        replyToMessageId: String? = nil,
        attachments: [OutgoingAttachment] = []
    ) async throws -> DiscordMessage {
        var payload: [String: Any] = [
            "content": content,
            "nonce": String(Int64(Date().timeIntervalSince1970 * 1000)) + "000000",
            "tts": false
        ]
        if let replyToMessageId {
            payload["message_reference"] = ["message_id": replyToMessageId]
        }

        if attachments.isEmpty {
            let body = try JSONSerialization.data(withJSONObject: payload)
            return try await request("/channels/\(channelId)/messages", method: "POST", body: body)
        }

        let boundary = "GlassCord-\(UUID().uuidString)"
        var body = Data()
        let jsonData = try JSONSerialization.data(withJSONObject: payload)

        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"payload_json\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: application/json\r\n\r\n".data(using: .utf8)!)
        body.append(jsonData)
        body.append("\r\n".data(using: .utf8)!)

        for (idx, file) in attachments.enumerated() {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"files[\(idx)]\"; filename=\"\(file.filename)\"\r\n".data(using: .utf8)!)
            body.append("Content-Type: \(file.mimeType)\r\n\r\n".data(using: .utf8)!)
            body.append(file.data)
            body.append("\r\n".data(using: .utf8)!)
        }
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)

        return try await request(
            "/channels/\(channelId)/messages",
            method: "POST",
            body: body,
            contentType: "multipart/form-data; boundary=\(boundary)"
        )
    }

    func editMessage(channelId: String, messageId: String, content: String) async throws -> DiscordMessage {
        let data = try JSONSerialization.data(withJSONObject: ["content": content])
        return try await request("/channels/\(channelId)/messages/\(messageId)", method: "PATCH", body: data)
    }

    func deleteMessage(channelId: String, messageId: String) async throws {
        try await sendEmpty("/channels/\(channelId)/messages/\(messageId)", method: "DELETE")
    }

    func pinMessage(channelId: String, messageId: String) async throws {
        try await sendEmpty("/channels/\(channelId)/pins/\(messageId)", method: "PUT")
    }

    func triggerTyping(channelId: String) async throws {
        try await sendEmpty("/channels/\(channelId)/typing", method: "POST")
    }

    func ackMessage(channelId: String, messageId: String) async throws {
        let data = try JSONSerialization.data(withJSONObject: ["token": NSNull()])
        try await sendEmpty("/channels/\(channelId)/messages/\(messageId)/ack", method: "POST", body: data)
    }

    // MARK: - Reactions
    func addReaction(channelId: String, messageId: String, emoji: String) async throws {
        let encoded = emoji.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? emoji
        try await sendEmpty("/channels/\(channelId)/messages/\(messageId)/reactions/\(encoded)/@me", method: "PUT")
    }

    func removeReaction(channelId: String, messageId: String, emoji: String) async throws {
        let encoded = emoji.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? emoji
        try await sendEmpty("/channels/\(channelId)/messages/\(messageId)/reactions/\(encoded)/@me", method: "DELETE")
    }

    // MARK: - Search
    func searchGuildMessages(guildId: String, query: String) async throws -> [DiscordMessage] {
        let encoded = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? query
        let res: SearchMessagesResponse = try await request("/guilds/\(guildId)/messages/search?content=\(encoded)")
        return res.messages.compactMap(\.first)
    }

    // MARK: - Relationships (Friends)
    func fetchRelationships() async throws -> [DiscordRelationship] {
        try await request("/users/@me/relationships")
    }

    func sendFriendRequest(username: String) async throws {
        let parts = username.split(separator: "#")
        let payload: [String: Any]
        if parts.count == 2 {
            payload = ["username": String(parts[0]), "discriminator": String(parts[1])]
        } else {
            payload = ["username": username]
        }
        let data = try JSONSerialization.data(withJSONObject: payload)
        try await sendEmpty("/users/@me/relationships", method: "POST", body: data)
    }

    func acceptFriendRequest(userId: String) async throws {
        let data = try JSONSerialization.data(withJSONObject: [String: Any]())
        try await sendEmpty("/users/@me/relationships/\(userId)", method: "PUT", body: data)
    }

    func removeRelationship(userId: String) async throws {
        try await sendEmpty("/users/@me/relationships/\(userId)", method: "DELETE")
    }
}

private struct EmptyResponse: Decodable {}
