import Foundation

enum CatboxError: LocalizedError {
    case invalidResponse
    case serverError(String)

    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "Catbox returned an invalid response."
        case .serverError(let msg): return "Catbox upload failed: \(msg)"
        }
    }
}

actor CatboxUploader {
    static let shared = CatboxUploader()
    private let endpoint = URL(string: "https://catbox.moe/user/api.php")!

    func upload(data: Data, filename: String, mimeType: String, userhash: String? = nil) async throws -> String {
        let boundary = "GlassCordCatbox-\(UUID().uuidString)"
        var body = Data()

        func appendField(name: String, value: String) {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(name)\"\r\n\r\n".data(using: .utf8)!)
            body.append("\(value)\r\n".data(using: .utf8)!)
        }

        appendField(name: "reqtype", value: "fileupload")
        if let userhash, !userhash.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            appendField(name: "userhash", value: userhash.trimmingCharacters(in: .whitespacesAndNewlines))
        }

        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"fileToUpload\"; filename=\"\(filename)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: \(mimeType)\r\n\r\n".data(using: .utf8)!)
        body.append(data)
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)

        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        req.setValue("GlassCord/1.0 (iOS)", forHTTPHeaderField: "User-Agent")
        req.httpBody = body
        req.timeoutInterval = 180

        let (respData, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse else {
            throw CatboxError.invalidResponse
        }
        let text = String(data: respData, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard (200..<300).contains(http.statusCode), text.hasPrefix("https://") else {
            throw CatboxError.serverError(text.isEmpty ? "HTTP \(http.statusCode)" : text)
        }
        return text
    }
}
