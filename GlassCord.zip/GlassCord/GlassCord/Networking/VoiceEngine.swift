import Foundation
import AVFoundation
import CallKit
import WebRTC

struct VoiceServerUpdatePayload: Codable, Sendable {
    let token: String
    let guildId: String?
    let channelId: String?
    let endpoint: String?

    enum CodingKeys: String, CodingKey {
        case token, endpoint
        case guildId = "guild_id"
        case channelId = "channel_id"
    }
}

@MainActor
@Observable
final class VoiceEngine: NSObject {
    var statusText: String = "Idle"
    var isAudioConnected = false
    var speakingUserIds: Set<String> = []

    private var webSocket: URLSessionWebSocketTask?
    private let session = URLSession(configuration: .default)
    private var heartbeatTask: Task<Void, Never>?
    private var receiveTask: Task<Void, Never>?

    private var serverId: String = ""
    private var userId: String = ""
    private var sessionId: String = ""
    private var token: String = ""
    private var mySSRC: UInt32 = 0
    private var didSelectProtocol = false

    // CallKit
    private let callController = CXCallController()
    private var callProvider: CXProvider?
    private var activeCallUUID: UUID?

    // WebRTC objects
    private static let factory: RTCPeerConnectionFactory = {
        RTCInitializeSSL()
        let encoderFactory = RTCDefaultVideoEncoderFactory()
        let decoderFactory = RTCDefaultVideoDecoderFactory()
        return RTCPeerConnectionFactory(encoderFactory: encoderFactory, decoderFactory: decoderFactory)
    }()

    private var peerConnection: RTCPeerConnection?
    private var localAudioTrack: RTCAudioTrack?

    override init() {
        super.init()
        let config = CXProviderConfiguration()
        config.supportsVideo = false
        config.maximumCallsPerCallGroup = 1
        config.supportedHandleTypes = [.generic]
        let provider = CXProvider(configuration: config)
        provider.setDelegate(self, queue: nil)
        self.callProvider = provider
    }

    func startCallKitSession(title: String) {
        let uuid = UUID()
        activeCallUUID = uuid
        let handle = CXHandle(type: .generic, value: title)
        let action = CXStartCallAction(call: uuid, handle: handle)
        let tx = CXTransaction(action: action)
        callController.request(tx) { _ in }
    }

    func connect(serverId: String, userId: String, sessionId: String, token: String, endpoint: String) {
        disconnectSocketAndPeerOnly()

        self.serverId = serverId
        self.userId = userId
        self.sessionId = sessionId
        self.token = token
        self.didSelectProtocol = false
        self.statusText = "Connecting to Voice Gateway..."

        configureAudioSession()
        setupPeerConnection()

        let cleanHost = endpoint
            .replacingOccurrences(of: "wss://", with: "")
            .replacingOccurrences(of: ":443", with: "")
        guard let url = URL(string: "wss://\(cleanHost)/?v=8") else {
            statusText = "Invalid voice endpoint"
            return
        }

        let task = session.webSocketTask(with: url)
        self.webSocket = task
        task.resume()

        receiveTask = Task { [weak self] in
            await self?.receiveLoop(task: task)
        }
    }

    private func disconnectSocketAndPeerOnly() {
        heartbeatTask?.cancel()
        receiveTask?.cancel()
        webSocket?.cancel(with: .normalClosure, reason: nil)
        webSocket = nil
        peerConnection?.close()
        peerConnection = nil
        localAudioTrack = nil
        isAudioConnected = false
        speakingUserIds.removeAll()
    }

    func disconnect() {
        disconnectSocketAndPeerOnly()
        statusText = "Disconnected"
        if let uuid = activeCallUUID {
            let action = CXEndCallAction(call: uuid)
            callController.request(CXTransaction(action: action)) { _ in }
            activeCallUUID = nil
        }
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    func setMuted(_ muted: Bool) {
        localAudioTrack?.isEnabled = !muted
        if mySSRC != 0 {
            sendSpeaking(speaking: muted ? 0 : 1)
        }
        if let uuid = activeCallUUID {
            let action = CXSetMutedCallAction(call: uuid, muted: muted)
            callController.request(CXTransaction(action: action)) { _ in }
        }
    }

    func setDeafened(_ deafened: Bool) {
        guard let pc = peerConnection else { return }
        for transceiver in pc.transceivers where transceiver.mediaType == .audio {
            transceiver.receiver.track?.isEnabled = !deafened
        }
        if deafened {
            setMuted(true)
        }
    }

    // MARK: - Audio & WebRTC Setup
    private func configureAudioSession() {
        let audio = AVAudioSession.sharedInstance()
        do {
            try audio.setCategory(.playAndRecord, mode: .voiceChat, options: [.defaultToSpeaker, .allowBluetoothHFP])
            try audio.setActive(true)
        } catch {
            statusText = "Audio session error: \(error.localizedDescription)"
        }
    }

    private func setupPeerConnection() {
        let config = RTCConfiguration()
        config.sdpSemantics = .unifiedPlan
        config.continualGatheringPolicy = .gatherContinually
        config.iceServers = [
            RTCIceServer(urlStrings: ["stun:stun.l.google.com:19302"])
        ]

        let constraints = RTCMediaConstraints(mandatoryConstraints: nil, optionalConstraints: nil)
        guard let pc = Self.factory.peerConnection(with: config, constraints: constraints, delegate: self) else {
            statusText = "Failed to create RTCPeerConnection"
            return
        }

        let audioConstraints = RTCMediaConstraints(mandatoryConstraints: nil, optionalConstraints: nil)
        let audioSource = Self.factory.audioSource(with: audioConstraints)
        let track = Self.factory.audioTrack(with: audioSource, trackId: "glasscord-audio-0")
        track.isEnabled = true
        self.localAudioTrack = track

        pc.add(track, streamIds: ["glasscord-stream"])
        self.peerConnection = pc
    }

    // MARK: - Voice Gateway Loop
    private func receiveLoop(task: URLSessionWebSocketTask) async {
        while !Task.isCancelled {
            do {
                let message = try await task.receive()
                let data: Data
                switch message {
                case .string(let str): data = Data(str.utf8)
                case .data(let raw): data = raw
                @unknown default: continue
                }
                await handleVoicePayload(data)
            } catch {
                statusText = "Voice closed"
                isAudioConnected = false
                break
            }
        }
    }

    private func handleVoicePayload(_ data: Data) async {
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let op = json["op"] as? Int else { return }

        switch op {
        case 8: // Hello
            if let d = json["d"] as? [String: Any],
               let intervalMs = d["heartbeat_interval"] as? Double {
                startHeartbeat(intervalSeconds: intervalMs / 1000.0)
                sendIdentify()
            }
        case 2: // Ready
            if let d = json["d"] as? [String: Any],
               let ssrc = d["ssrc"] as? UInt32 {
                self.mySSRC = ssrc
                statusText = "Negotiating WebRTC..."
                await createAndSendOffer()
            }
        case 4: // Session Description (Answer)
            if let d = json["d"] as? [String: Any],
               let sdp = d["sdp"] as? String {
                let answer = RTCSessionDescription(type: .answer, sdp: sdp)
                peerConnection?.setRemoteDescription(answer) { [weak self] error in
                    Task { @MainActor in
                        if let error {
                            self?.statusText = "SDP error: \(error.localizedDescription)"
                        } else {
                            self?.isAudioConnected = true
                            self?.statusText = "Voice Connected"
                            if let uuid = self?.activeCallUUID {
                                self?.callProvider?.reportOutgoingCall(with: uuid, connectedAt: Date())
                            }
                            self?.sendSpeaking(speaking: 1)
                        }
                    }
                }
            }
        case 5: // Speaking
            if let d = json["d"] as? [String: Any],
               let uid = d["user_id"] as? String,
               let speaking = d["speaking"] as? Int {
                if speaking != 0 {
                    speakingUserIds.insert(uid)
                } else {
                    speakingUserIds.remove(uid)
                }
            }
        case 13: // Client Disconnect
            if let d = json["d"] as? [String: Any],
               let uid = d["user_id"] as? String {
                speakingUserIds.remove(uid)
            }
        default:
            break
        }
    }

    private func createAndSendOffer() async {
        guard let pc = peerConnection, !didSelectProtocol else { return }
        let constraints = RTCMediaConstraints(
            mandatoryConstraints: [
                kRTCMediaConstraintsOfferToReceiveAudio: kRTCMediaConstraintsValueTrue,
                kRTCMediaConstraintsOfferToReceiveVideo: kRTCMediaConstraintsValueFalse
            ],
            optionalConstraints: nil
        )

        do {
            let offer = try await pc.offer(for: constraints)
            try await pc.setLocalDescription(offer)
            try? await Task.sleep(for: .milliseconds(350))
            let finalSDP = pc.localDescription?.sdp ?? offer.sdp
            didSelectProtocol = true
            sendSelectProtocol(sdp: finalSDP)
        } catch {
            statusText = "Offer failed: \(error.localizedDescription)"
        }
    }

    private func startHeartbeat(intervalSeconds: Double) {
        heartbeatTask?.cancel()
        heartbeatTask = Task { [weak self] in
            while !Task.isCancelled {
                let nonce = Int(Date().timeIntervalSince1970 * 1000)
                self?.sendPayload(op: 3, d: nonce)
                try? await Task.sleep(for: .seconds(intervalSeconds))
            }
        }
    }

    private func sendIdentify() {
        let d: [String: Any] = [
            "server_id": serverId,
            "user_id": userId,
            "session_id": sessionId,
            "token": token,
            "video": false
        ]
        sendPayload(op: 0, d: d)
    }

    private func sendSelectProtocol(sdp: String) {
        let d: [String: Any] = [
            "protocol": "webrtc",
            "data": sdp
        ]
        sendPayload(op: 1, d: d)
    }

    private func sendSpeaking(speaking: Int) {
        let d: [String: Any] = [
            "speaking": speaking,
            "delay": 0,
            "ssrc": mySSRC
        ]
        sendPayload(op: 5, d: d)
    }

    private func sendPayload(op: Int, d: Any) {
        let payload: [String: Any] = ["op": op, "d": d]
        guard let data = try? JSONSerialization.data(withJSONObject: payload),
              let str = String(data: data, encoding: .utf8) else { return }
        webSocket?.send(.string(str)) { _ in }
    }
}

extension VoiceEngine: CXProviderDelegate {
    nonisolated func providerDidReset(_ provider: CXProvider) {}

    nonisolated func provider(_ provider: CXProvider, perform action: CXStartCallAction) {
        action.fulfill()
    }

    nonisolated func provider(_ provider: CXProvider, perform action: CXEndCallAction) {
        Task { @MainActor in
            self.disconnectSocketAndPeerOnly()
        }
        action.fulfill()
    }

    nonisolated func provider(_ provider: CXProvider, perform action: CXSetMutedCallAction) {
        Task { @MainActor in
            self.localAudioTrack?.isEnabled = !action.isMuted
        }
        action.fulfill()
    }
}

extension VoiceEngine: RTCPeerConnectionDelegate {
    nonisolated func peerConnection(_ peerConnection: RTCPeerConnection, didChange stateChanged: RTCSignalingState) {}
    nonisolated func peerConnection(_ peerConnection: RTCPeerConnection, didAdd stream: RTCMediaStream) {}
    nonisolated func peerConnection(_ peerConnection: RTCPeerConnection, didRemove stream: RTCMediaStream) {}
    nonisolated func peerConnectionShouldNegotiate(_ peerConnection: RTCPeerConnection) {}
    nonisolated func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCIceConnectionState) {
        Task { @MainActor [weak self] in
            switch newState {
            case .connected, .completed:
                self?.isAudioConnected = true
                self?.statusText = "Voice Connected"
            case .disconnected, .failed:
                self?.isAudioConnected = false
                self?.statusText = "ICE Reconnecting..."
            default:
                break
            }
        }
    }
    nonisolated func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCIceGatheringState) {}
    nonisolated func peerConnection(_ peerConnection: RTCPeerConnection, didGenerate candidate: RTCIceCandidate) {}
    nonisolated func peerConnection(_ peerConnection: RTCPeerConnection, didRemove candidates: [RTCIceCandidate]) {}
    nonisolated func peerConnection(_ peerConnection: RTCPeerConnection, didOpen dataChannel: RTCDataChannel) {}
}
