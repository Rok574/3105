import Foundation

enum GatewayEvent: Sendable {
    case connected
    case disconnected(String)
    case ready(ReadyPayload)
    case messageCreate(DiscordMessage)
    case messageUpdate(DiscordMessage)
    case messageDelete(id: String, channelId: String)
    case reactionAdd(channelId: String, messageId: String, userId: String, emoji: DiscordEmoji)
    case reactionRemove(channelId: String, messageId: String, userId: String, emoji: DiscordEmoji)
    case typingStart(channelId: String, userId: String)
    case presenceUpdate(DiscordPresence)
    case channelCreate(DiscordChannel)
    case channelUpdate(DiscordChannel)
    case channelDelete(DiscordChannel)
    case guildCreate(DiscordGuild)
    case relationshipAdd(DiscordRelationship)
    case relationshipRemove(id: String)
    case voiceStateUpdate(DiscordVoiceState)
    case voiceServerUpdate(VoiceServerUpdatePayload)
}

struct ReadyPayload: Codable, Sendable {
    let user: DiscordUser
    let guilds: [DiscordGuild]
    let privateChannels: [DiscordChannel]?
    let relationships: [DiscordRelationship]?
    let presences: [DiscordPresence]?
    let readState: [DiscordReadState]?
    let userSettings: UserSettings?
    let sessionId: String
    let resumeGatewayUrl: String?

    enum CodingKeys: String, CodingKey {
        case user, guilds, relationships, presences
        case privateChannels = "private_channels"
        case readState = "read_state"
        case userSettings = "user_settings"
        case sessionId = "session_id"
        case resumeGatewayUrl = "resume_gateway_url"
    }

    struct UserSettings: Codable, Sendable {
        var guildFolders: [DiscordGuildFolder]?
        var status: PresenceStatus?

        enum CodingKeys: String, CodingKey {
            case status
            case guildFolders = "guild_folders"
        }
    }
}

final class DiscordGateway: @unchecked Sendable {
    private var webSocketTask: URLSessionWebSocketTask?
    private let session = URLSession(configuration: .default)
    private var heartbeatTask: Task<Void, Never>?
    private var receiveTask: Task<Void, Never>?

    private var token: String = ""
    private var sequence: Int?
    private var sessionId: String?
    private var resumeGatewayURL: String?
    private var isStopped = false
    private var reconnectAttempt = 0

    var onEvent: (@Sendable (GatewayEvent) async -> Void)?

    func connect(token: String) {
        self.token = token
        self.isStopped = false
        self.reconnectAttempt = 0
        openSocket(urlString: resumeGatewayURL ?? "wss://gateway.discord.gg/?v=10&encoding=json")
    }

    func disconnect() {
        isStopped = true
        heartbeatTask?.cancel()
        receiveTask?.cancel()
        webSocketTask?.cancel(with: .normalClosure, reason: nil)
        webSocketTask = nil
    }

    func sendVoiceStateUpdate(guildId: String?, channelId: String?, selfMute: Bool, selfDeaf: Bool) {
        let d: [String: Any] = [
            "guild_id": guildId ?? NSNull(),
            "channel_id": channelId ?? NSNull(),
            "self_mute": selfMute,
            "self_deaf": selfDeaf,
            "self_video": false
        ]
        sendPayload(op: 4, d: d)
    }

    func sendPresenceUpdate(status: PresenceStatus) {
        let d: [String: Any] = [
            "since": NSNull(),
            "activities": [],
            "status": status.rawValue,
            "afk": false
        ]
        sendPayload(op: 3, d: d)
    }

    private func openSocket(urlString: String) {
        let normalized = urlString.contains("?v=10") ? urlString : "\(urlString)/?v=10&encoding=json"
        guard let url = URL(string: normalized) else { return }

        webSocketTask?.cancel(with: .goingAway, reason: nil)
        let task = session.webSocketTask(with: url)
        self.webSocketTask = task
        task.resume()

        receiveTask?.cancel()
        receiveTask = Task { [weak self] in
            await self?.receiveLoop(task: task)
        }
    }

    private func receiveLoop(task: URLSessionWebSocketTask) async {
        while !Task.isCancelled && !isStopped {
            do {
                let message = try await task.receive()
                let data: Data
                switch message {
                case .string(let str):
                    data = Data(str.utf8)
                case .data(let raw):
                    data = raw
                @unknown default:
                    continue
                }
                await handleRawPayload(data)
            } catch {
                if !isStopped {
                    await onEvent?(.disconnected(error.localizedDescription))
                    await scheduleReconnect()
                }
                break
            }
        }
    }

    private func scheduleReconnect() async {
        heartbeatTask?.cancel()
        reconnectAttempt += 1
        let delay = min(pow(2.0, Double(reconnectAttempt)), 20.0)
        try? await Task.sleep(for: .seconds(delay))
        guard !isStopped else { return }
        openSocket(urlString: resumeGatewayURL ?? "wss://gateway.discord.gg/?v=10&encoding=json")
    }

    private func handleRawPayload(_ data: Data) async {
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let op = json["op"] as? Int else { return }

        if let s = json["s"] as? Int {
            sequence = s
        }

        switch op {
        case 10: // Hello
            if let d = json["d"] as? [String: Any],
               let intervalMs = d["heartbeat_interval"] as? Double {
                startHeartbeat(intervalSeconds: intervalMs / 1000.0)
                if let sessionId, let sequence {
                    sendResume(sessionId: sessionId, seq: sequence)
                } else {
                    sendIdentify()
                }
            }
        case 1: // Heartbeat request
            sendHeartbeat()
        case 7: // Reconnect
            openSocket(urlString: resumeGatewayURL ?? "wss://gateway.discord.gg/?v=10&encoding=json")
        case 9: // Invalid Session
            let resumable = (json["d"] as? Bool) ?? false
            if !resumable {
                sessionId = nil
                sequence = nil
                resumeGatewayURL = nil
            }
            try? await Task.sleep(for: .seconds(1.5))
            sendIdentify()
        case 0: // Dispatch
            guard let eventName = json["t"] as? String,
                  let d = json["d"] else { return }
            await handleDispatch(event: eventName, d: d)
        default:
            break
        }
    }

    private func startHeartbeat(intervalSeconds: Double) {
        heartbeatTask?.cancel()
        heartbeatTask = Task { [weak self] in
            let jitter = Double.random(in: 0.1...0.5) * intervalSeconds
            try? await Task.sleep(for: .seconds(jitter))
            while !Task.isCancelled {
                self?.sendHeartbeat()
                try? await Task.sleep(for: .seconds(intervalSeconds))
            }
        }
    }

    private func sendHeartbeat() {
        let d: Any = sequence ?? NSNull()
        sendPayload(op: 1, d: d)
    }

    private func sendIdentify() {
        let d: [String: Any] = [
            "token": token,
            "capabilities": 30717,
            "properties": [
                "os": "iOS",
                "browser": "Discord iOS",
                "device": "iPhone17,1",
                "system_locale": Locale.current.identifier,
                "client_version": "265.0",
                "release_channel": "stable",
                "os_version": "26.0"
            ],
            "presence": [
                "status": "online",
                "since": 0,
                "activities": [],
                "afk": false
            ],
            "compress": false
        ]
        sendPayload(op: 2, d: d)
    }

    private func sendResume(sessionId: String, seq: Int) {
        let d: [String: Any] = [
            "token": token,
            "session_id": sessionId,
            "seq": seq
        ]
        sendPayload(op: 6, d: d)
    }

    private func sendPayload(op: Int, d: Any) {
        let payload: [String: Any] = ["op": op, "d": d]
        guard let data = try? JSONSerialization.data(withJSONObject: payload),
              let str = String(data: data, encoding: .utf8) else { return }
        webSocketTask?.send(.string(str)) { _ in }
    }

    private func decode<T: Decodable>(_ obj: Any, as type: T.Type) -> T? {
        guard JSONSerialization.isValidJSONObject(obj),
              let data = try? JSONSerialization.data(withJSONObject: obj) else { return nil }
        return try? JSONDecoder().decode(T.self, from: data)
    }

    private func handleDispatch(event: String, d: Any) async {
        switch event {
        case "READY":
            if let ready = decode(d, as: ReadyPayload.self) {
                self.sessionId = ready.sessionId
                self.resumeGatewayURL = ready.resumeGatewayUrl
                self.reconnectAttempt = 0
                await onEvent?(.connected)
                await onEvent?(.ready(ready))
            }
        case "RESUMED":
            self.reconnectAttempt = 0
            await onEvent?(.connected)
        case "MESSAGE_CREATE":
            if let msg = decode(d, as: DiscordMessage.self) {
                await onEvent?(.messageCreate(msg))
            }
        case "MESSAGE_UPDATE":
            if let msg = decode(d, as: DiscordMessage.self) {
                await onEvent?(.messageUpdate(msg))
            }
        case "MESSAGE_DELETE":
            if let dict = d as? [String: Any],
               let id = dict["id"] as? String,
               let channelId = dict["channel_id"] as? String {
                await onEvent?(.messageDelete(id: id, channelId: channelId))
            }
        case "MESSAGE_REACTION_ADD":
            if let dict = d as? [String: Any],
               let channelId = dict["channel_id"] as? String,
               let messageId = dict["message_id"] as? String,
               let userId = dict["user_id"] as? String,
               let emojiObj = dict["emoji"],
               let emoji = decode(emojiObj, as: DiscordEmoji.self) {
                await onEvent?(.reactionAdd(channelId: channelId, messageId: messageId, userId: userId, emoji: emoji))
            }
        case "MESSAGE_REACTION_REMOVE":
            if let dict = d as? [String: Any],
               let channelId = dict["channel_id"] as? String,
               let messageId = dict["message_id"] as? String,
               let userId = dict["user_id"] as? String,
               let emojiObj = dict["emoji"],
               let emoji = decode(emojiObj, as: DiscordEmoji.self) {
                await onEvent?(.reactionRemove(channelId: channelId, messageId: messageId, userId: userId, emoji: emoji))
            }
        case "TYPING_START":
            if let dict = d as? [String: Any],
               let channelId = dict["channel_id"] as? String,
               let userId = dict["user_id"] as? String {
                await onEvent?(.typingStart(channelId: channelId, userId: userId))
            }
        case "PRESENCE_UPDATE":
            if let presence = decode(d, as: DiscordPresence.self) {
                await onEvent?(.presenceUpdate(presence))
            }
        case "CHANNEL_CREATE":
            if let channel = decode(d, as: DiscordChannel.self) {
                await onEvent?(.channelCreate(channel))
            }
        case "CHANNEL_UPDATE":
            if let channel = decode(d, as: DiscordChannel.self) {
                await onEvent?(.channelUpdate(channel))
            }
        case "CHANNEL_DELETE":
            if let channel = decode(d, as: DiscordChannel.self) {
                await onEvent?(.channelDelete(channel))
            }
        case "GUILD_CREATE":
            if let guild = decode(d, as: DiscordGuild.self) {
                await onEvent?(.guildCreate(guild))
            }
        case "RELATIONSHIP_ADD":
            if let rel = decode(d, as: DiscordRelationship.self) {
                await onEvent?(.relationshipAdd(rel))
            }
        case "RELATIONSHIP_REMOVE":
            if let dict = d as? [String: Any], let id = dict["id"] as? String {
                await onEvent?(.relationshipRemove(id: id))
            }
        case "VOICE_STATE_UPDATE":
            if let vs = decode(d, as: DiscordVoiceState.self) {
                await onEvent?(.voiceStateUpdate(vs))
            }
        case "VOICE_SERVER_UPDATE":
            if let vsu = decode(d, as: VoiceServerUpdatePayload.self) {
                await onEvent?(.voiceServerUpdate(vsu))
            }
        default:
            break
        }
    }
}
