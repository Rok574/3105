import SwiftUI
import UIKit

actor ImageLoader {
    static let shared = ImageLoader()

    private let memoryCache: NSCache<NSURL, UIImage> = {
        let cache = NSCache<NSURL, UIImage>()
        cache.countLimit = 400
        cache.totalCostLimit = 120 * 1024 * 1024 // 120 MB
        return cache
    }()

    private let diskDir: URL = {
        let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!
        let dir = base.appendingPathComponent("GlassCordImages", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }()

    private var inFlight: [URL: Task<UIImage?, Never>] = [:]

    func cachedImage(for url: URL) -> UIImage? {
        memoryCache.object(forKey: url as NSURL)
    }

    func load(url: URL) async -> UIImage? {
        if let mem = memoryCache.object(forKey: url as NSURL) {
            return mem
        }

        if let existing = inFlight[url] {
            return await existing.value
        }

        let task = Task<UIImage?, Never> {
            let fileURL = diskFileURL(for: url)
            if let data = try? Data(contentsOf: fileURL), let img = UIImage(data: data) {
                memoryCache.setObject(img, forKey: url as NSURL, cost: data.count)
                return img
            }

            do {
                let (data, response) = try await URLSession.shared.data(from: url)
                guard let http = response as? HTTPURLResponse,
                      (200..<300).contains(http.statusCode),
                      let img = UIImage(data: data) else {
                    return nil
                }
                memoryCache.setObject(img, forKey: url as NSURL, cost: data.count)
                try? data.write(to: fileURL, options: .atomic)
                return img
            } catch {
                return nil
            }
        }

        inFlight[url] = task
        let result = await task.value
        inFlight[url] = nil
        return result
    }

    private func diskFileURL(for url: URL) -> URL {
        let hash = Data(url.absoluteString.utf8).base64EncodedString()
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "+", with: "-")
            .prefix(80)
        return diskDir.appendingPathComponent(String(hash))
    }
}

struct CachedAsyncImage<Content: View, Placeholder: View>: View {
    let url: URL?
    @ViewBuilder let content: (Image) -> Content
    @ViewBuilder let placeholder: () -> Placeholder

    @State private var uiImage: UIImage?

    var body: some View {
        Group {
            if let uiImage {
                content(Image(uiImage: uiImage))
            } else {
                placeholder()
            }
        }
        .task(id: url) {
            guard let url else {
                uiImage = nil
                return
            }
            if let loaded = await ImageLoader.shared.load(url: url) {
                withAnimation(.easeIn(duration: 0.14)) {
                    uiImage = loaded
                }
            }
        }
    }
}
