import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

struct ChatView: View {
    @Environment(DiscordStore.self) private var store
    @State private var draftText = ""
    @State private var replyingTo: DiscordMessage?
    @State private var editingMessage: DiscordMessage?
    @State private var selectedPhotoItems: [PhotosPickerItem] = []
    @State private var pendingAttachments: [OutgoingAttachment] = []
    @State private var showPinnedSheet = false
    @State private var showEmojiPicker = false
    @State private var showFileImporter = false
    @State private var sendHapticTrigger = 0
    @State private var lastTypingSent = Date.distantPast
    @Namespace private var composerNS

    var body: some View {
        Group {
            if let channel = store.activeChannel {
                chatContent(for: channel)
                    .navigationTitle(channel.type == .dm ? channel.displayName : "#\(channel.displayName)")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .topBarTrailing) {
                            Button {
                                Task {
                                    let pins = (try? await store.api.fetchPinnedMessages(channelId: channel.id)) ?? []
                                    store.pinnedMessagesByChannel[channel.id] = pins
                                    showPinnedSheet = true
                                }
                            } label: {
                                Image(systemName: "pin.fill")
                            }
                        }
                    }
                    .sheet(isPresented: $showPinnedSheet) {
                        pinnedSheet(channelId: channel.id)
                            .presentationDetents([.medium, .large])
                    }
                    .sheet(isPresented: $showEmojiPicker) {
                        EmojiPickerSheet(currentGuildId: channel.guildId) { emojiString in
                            if draftText.isEmpty || draftText.hasSuffix(" ") {
                                draftText += emojiString + " "
                            } else {
                                draftText += " " + emojiString + " "
                            }
                        }
                        .presentationDetents([.medium, .large])
                    }
                    .fileImporter(
                        isPresented: $showFileImporter,
                        allowedContentTypes: [.item],
                        allowsMultipleSelection: true
                    ) { result in
                        if case .success(let urls) = result {
                            for url in urls {
                                guard url.startAccessingSecurityScopedResource() else { continue }
                                defer { url.stopAccessingSecurityScopedResource() }
                                if let data = try? Data(contentsOf: url) {
                                    let mime = UTType(filenameExtension: url.pathExtension)?.preferredMIMEType ?? "application/octet-stream"
                                    pendingAttachments.append(OutgoingAttachment(
                                        filename: url.lastPathComponent,
                                        mimeType: mime,
                                        data: data
                                    ))
                                }
                            }
                        }
                    }
            } else {
                ContentUnavailableView(
                    "Select a Channel",
                    systemImage: "number.circle",
                    description: Text("Choose a server channel or direct message from the sidebar.")
                )
            }
        }
    }

    @ViewBuilder
    private func chatContent(for channel: DiscordChannel) -> some View {
        let messages = store.messagesByChannel[channel.id] ?? []

        ZStack(alignment: .bottom) {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 2) {
                        if !messages.isEmpty {
                            Button("Load Earlier Messages") {
                                Task { await store.loadMessages(channelId: channel.id, loadOlder: true) }
                            }
                            .font(.caption.weight(.medium))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                        }

                        ForEach(Array(messages.enumerated()), id: \.element.id) { index, msg in
                            let prev = index > 0 ? messages[index - 1] : nil
                            let isGrouped = prev != nil
                                && prev?.author.id == msg.author.id
                                && msg.referencedMessage == nil
                                && msg.parsedDate.timeIntervalSince(prev!.parsedDate) < 300

                            MessageRowView(
                                message: msg,
                                isGrouped: isGrouped,
                                isOwnMessage: msg.author.id == store.currentUser?.id,
                                iMessageMode: store.iMessageModeEnabled,
                                onReply: { replyingTo = msg; editingMessage = nil },
                                onEdit: { editingMessage = msg; replyingTo = nil; draftText = msg.content },
                                onDelete: { Task { await store.deleteMessage(channelId: channel.id, messageId: msg.id) } },
                                onPin: { Task { try? await store.api.pinMessage(channelId: channel.id, messageId: msg.id) } },
                                onReact: { emoji, me in
                                    Task {
                                        await store.toggleReaction(
                                            channelId: channel.id,
                                            messageId: msg.id,
                                            emoji: emoji,
                                            currentlyMe: me
                                        )
                                    }
                                }
                            )
                            .id(msg.id)
                        }
                    }
                    .padding(.horizontal, 14)
                    .padding(.top, 8)
                    .padding(.bottom, 112)
                }
                .scrollDismissesKeyboard(.interactively)
                .onChange(of: messages.last?.id) { _, newId in
                    if let newId {
                        withAnimation(.easeOut(duration: 0.18)) {
                            proxy.scrollTo(newId, anchor: .bottom)
                        }
                    }
                }
            }

            VStack(spacing: 6) {
                if let uploadText = store.uploadStatusText {
                    HStack(spacing: 8) {
                        ProgressView().controlSize(.mini)
                        Text(uploadText)
                            .font(.caption.weight(.medium))
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 6)
                    .glassEffect(.regular, in: .capsule)
                }

                if let typing = store.typingText(for: channel.id) {
                    Text(typing)
                        .font(.caption2.weight(.medium))
                        .foregroundStyle(.secondary)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 4)
                        .glassEffect(.regular, in: .capsule)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 16)
                }

                floatingComposer(for: channel)
                    .padding(.horizontal, 12)
                    .padding(.bottom, 8)
            }
        }
        .sensoryFeedback(.impact(weight: .light), trigger: sendHapticTrigger)
        .onChange(of: selectedPhotoItems) { _, items in
            Task {
                var loaded: [OutgoingAttachment] = []
                for item in items {
                    if let data = try? await item.loadTransferable(type: Data.self) {
                        loaded.append(OutgoingAttachment(
                            filename: "media_\(UUID().uuidString.prefix(6)).jpg",
                            mimeType: "image/jpeg",
                            data: data
                        ))
                    }
                }
                pendingAttachments.append(contentsOf: loaded)
                selectedPhotoItems = []
            }
        }
    }

    @ViewBuilder
    private func floatingComposer(for channel: DiscordChannel) -> some View {
        VStack(spacing: 6) {
            if let replyingTo {
                HStack {
                    Image(systemName: "arrowshape.turn.up.left.fill")
                        .font(.caption)
                    Text("Replying to \(replyingTo.author.displayName)")
                        .font(.caption.weight(.medium))
                    Spacer()
                    Button { self.replyingTo = nil } label: {
                        Image(systemName: "xmark.circle.fill")
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 6)
                .glassEffect(.regular, in: .capsule)
            }

            if let editingMessage {
                HStack {
                    Image(systemName: "pencil")
                        .font(.caption)
                    Text("Editing message")
                        .font(.caption.weight(.medium))
                    Spacer()
                    Button {
                        self.editingMessage = nil
                        draftText = ""
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 6)
                .glassEffect(.regular, in: .capsule)
            }

            if !pendingAttachments.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(Array(pendingAttachments.enumerated()), id: \.offset) { idx, att in
                            let mb = Double(att.data.count) / (1024 * 1024)
                            let willCatbox = store.catboxAutoFallback && att.data.count > store.catboxThresholdMB * 1024 * 1024
                            HStack(spacing: 6) {
                                if let uiImg = UIImage(data: att.data) {
                                    Image(uiImage: uiImg)
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 38, height: 38)
                                        .clipShape(RoundedRectangle(cornerRadius: 8))
                                } else {
                                    Image(systemName: "doc.fill")
                                        .foregroundStyle(.indigo)
                                }
                                VStack(alignment: .leading, spacing: 1) {
                                    Text(att.filename)
                                        .font(.caption2.weight(.semibold))
                                        .lineLimit(1)
                                        .frame(maxWidth: 90, alignment: .leading)
                                    Text(willCatbox ? String(format: "%.1f MB · Catbox", mb) : String(format: "%.1f MB", mb))
                                        .font(.caption2)
                                        .foregroundStyle(willCatbox ? .purple : .secondary)
                                }
                                Button {
                                    pendingAttachments.remove(at: idx)
                                } label: {
                                    Image(systemName: "xmark.circle.fill")
                                        .foregroundStyle(.secondary)
                                }
                            }
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        }
                    }
                    .padding(.horizontal, 4)
                }
            }

            GlassEffectContainer(spacing: 8) {
                HStack(spacing: 8) {
                    Menu {
                        PhotosPicker(selection: $selectedPhotoItems, maxSelectionCount: 4, matching: .any(of: [.images, .videos])) {
                            Label("Photos & Videos", systemImage: "photo.on.rectangle")
                        }
                        Button {
                            showFileImporter = true
                        } label: {
                            Label("Choose File (Catbox up to 200 MB)", systemImage: "doc.badge.plus")
                        }
                    } label: {
                        Image(systemName: "plus")
                            .font(.body.weight(.semibold))
                            .frame(width: 36, height: 36)
                    }
                    .glassEffect(.regular.interactive(), in: .circle)
                    .glassEffectID("attach", in: composerNS)

                    Button {
                        showEmojiPicker = true
                    } label: {
                        Image(systemName: "face.smiling")
                            .font(.body)
                            .frame(width: 36, height: 36)
                    }
                    .glassEffect(.regular.interactive(), in: .circle)
                    .glassEffectID("emoji", in: composerNS)

                    TextField("Message #\(channel.displayName)", text: $draftText, axis: .vertical)
                        .lineLimit(1...5)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 9)
                        .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                        .glassEffectID("input", in: composerNS)
                        .onChange(of: draftText) { _, newValue in
                            if !newValue.isEmpty, Date().timeIntervalSince(lastTypingSent) > 6 {
                                lastTypingSent = Date()
                                store.notifyTyping(channelId: channel.id)
                            }
                        }

                    let canSend = !draftText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !pendingAttachments.isEmpty
                    if canSend {
                        Button {
                            sendHapticTrigger += 1
                            let text = draftText
                            let replyId = replyingTo?.id
                            let editMsg = editingMessage
                            let files = pendingAttachments
                            draftText = ""
                            replyingTo = nil
                            editingMessage = nil
                            pendingAttachments = []

                            Task {
                                if let editMsg {
                                    await store.editMessage(channelId: channel.id, messageId: editMsg.id, newContent: text)
                                } else {
                                    await store.sendMessage(
                                        channelId: channel.id,
                                        content: text,
                                        replyToMessageId: replyId,
                                        attachments: files
                                    )
                                }
                            }
                        } label: {
                            Image(systemName: "arrow.up")
                                .font(.body.weight(.bold))
                                .foregroundStyle(.white)
                                .frame(width: 36, height: 36)
                                .background(.indigo, in: Circle())
                        }
                        .glassEffect(.regular.interactive(), in: .circle)
                        .glassEffectID("send", in: composerNS)
                    }
                }
            }
        }
    }

    private func pinnedSheet(channelId: String) -> some View {
        NavigationStack {
            List(store.pinnedMessagesByChannel[channelId] ?? []) { msg in
                VStack(alignment: .leading, spacing: 4) {
                    Text(msg.author.displayName)
                        .font(.subheadline.weight(.semibold))
                    DiscordMarkdownText(content: msg.content)
                        .font(.subheadline)
                }
                .padding(.vertical, 4)
            }
            .navigationTitle("Pinned Messages")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done") { showPinnedSheet = false }
                }
            }
        }
    }
}

private struct MessageRowView: View {
    let message: DiscordMessage
    let isGrouped: Bool
    let isOwnMessage: Bool
    let iMessageMode: Bool
    let onReply: () -> Void
    let onEdit: () -> Void
    let onDelete: () -> Void
    let onPin: () -> Void
    let onReact: (DiscordEmoji, Bool) -> Void

    var body: some View {
        if iMessageMode {
            iMessageBubbleBody
        } else {
            discordRowBody
        }
    }

    @ViewBuilder
    private var iMessageBubbleBody: some View {
        VStack(alignment: isOwnMessage ? .trailing : .leading, spacing: 4) {
            HStack {
                if isOwnMessage { Spacer(minLength: 56) }

                VStack(alignment: .leading, spacing: 6) {
                    if !message.content.isEmpty {
                        DiscordMarkdownText(content: message.content)
                            .font(.body)
                            .foregroundStyle(isOwnMessage ? .white : .primary)
                    }
                    if let attachments = message.attachments, !attachments.isEmpty {
                        ForEach(attachments) { att in
                            if att.isImage, let url = URL(string: att.url) {
                                CachedAsyncImage(url: url) { img in
                                    img.resizable()
                                        .scaledToFit()
                                        .frame(maxWidth: 230, maxHeight: 230)
                                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                                } placeholder: {
                                    ProgressView()
                                }
                            }
                        }
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 9)
                .background(
                    isOwnMessage ? AnyShapeStyle(Color.blue.gradient) : AnyShapeStyle(.clear),
                    in: RoundedRectangle(cornerRadius: 20, style: .continuous)
                )
                .glassEffect(isOwnMessage ? .identity : .regular, in: RoundedRectangle(cornerRadius: 20, style: .continuous))

                if !isOwnMessage { Spacer(minLength: 56) }
            }

            if let reactions = message.reactions, !reactions.isEmpty {
                FlowReactionBar(reactions: reactions, onTap: onReact)
            }
        }
        .padding(.vertical, 3)
        .contextMenu {
            Button("Reply", systemImage: "arrowshape.turn.up.left", action: onReply)
            Button("Copy Text", systemImage: "doc.on.doc") {
                UIPasteboard.general.string = message.content
            }
            if isOwnMessage {
                Button("Edit", systemImage: "pencil", action: onEdit)
                Button("Delete", systemImage: "trash", role: .destructive, action: onDelete)
            }
        }
    }

    private var discordRowBody: some View {
        VStack(alignment: .leading, spacing: 4) {
            if let ref = message.referencedMessage {
                HStack(spacing: 6) {
                    Image(systemName: "arrowshape.turn.up.right")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                    Text(ref.author?.displayName ?? "Unknown")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                    Text(ref.content ?? "Attachment")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                .padding(.leading, 48)
            }

            HStack(alignment: .top, spacing: 10) {
                if isGrouped {
                    Color.clear.frame(width: 38, height: 1)
                } else {
                    AvatarView(url: message.author.avatarURL, decorationURL: message.author.avatarDecorationData?.imageURL, size: 38)
                }

                VStack(alignment: .leading, spacing: 4) {
                    if !isGrouped {
                        HStack(alignment: .firstTextBaseline, spacing: 6) {
                            Text(message.author.displayName)
                                .font(.subheadline.weight(.semibold))
                            if message.author.bot == true {
                                Text("APP")
                                    .font(.caption2.weight(.bold))
                                    .padding(.horizontal, 5)
                                    .padding(.vertical, 1)
                                    .background(.indigo.opacity(0.2), in: Capsule())
                                    .foregroundStyle(.indigo)
                            }
                            Text(message.parsedDate, style: .time)
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    }

                    if !message.content.isEmpty {
                        HStack(alignment: .lastTextBaseline, spacing: 4) {
                            DiscordMarkdownText(content: message.content)
                                .font(.body)
                            if message.editedTimestamp != nil {
                                Text("(edited)")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }

                    if let attachments = message.attachments, !attachments.isEmpty {
                        ForEach(attachments) { att in
                            if att.isImage, let url = URL(string: att.url) {
                                CachedAsyncImage(url: url) { img in
                                    img.resizable()
                                        .scaledToFit()
                                        .frame(maxWidth: 280, maxHeight: 280)
                                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                                } placeholder: {
                                    RoundedRectangle(cornerRadius: 16)
                                        .fill(.secondary.opacity(0.15))
                                        .frame(width: 220, height: 140)
                                        .overlay(ProgressView())
                                }
                            } else if let url = URL(string: att.url) {
                                Link(destination: url) {
                                    Label(att.filename, systemImage: "doc.fill")
                                        .font(.subheadline)
                                        .padding(10)
                                        .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 12))
                                }
                            }
                        }
                    }

                    if let embeds = message.embeds, !embeds.isEmpty {
                        ForEach(Array(embeds.enumerated()), id: \.offset) { _, embed in
                            VStack(alignment: .leading, spacing: 4) {
                                if let title = embed.title {
                                    Text(title).font(.subheadline.weight(.semibold))
                                }
                                if let desc = embed.description {
                                    DiscordMarkdownText(content: desc)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            .padding(10)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                        }
                    }

                    if let reactions = message.reactions, !reactions.isEmpty {
                        FlowReactionBar(reactions: reactions, onTap: onReact)
                    }
                }
            }
        }
        .padding(.vertical, isGrouped ? 2 : 6)
        .contentShape(Rectangle())
        .contextMenu {
            Button("Reply", systemImage: "arrowshape.turn.up.left", action: onReply)
            Button("Copy Text", systemImage: "doc.on.doc") {
                UIPasteboard.general.string = message.content
            }
            Menu("Add Reaction", systemImage: "face.smiling") {
                ForEach(["👍", "❤️", "😂", "🔥", "👀"], id: \.self) { sym in
                    Button(sym) {
                        onReact(DiscordEmoji(id: nil, name: sym, animated: false), false)
                    }
                }
            }
            Button("Pin Message", systemImage: "pin", action: onPin)
            if isOwnMessage {
                Button("Edit", systemImage: "pencil", action: onEdit)
                Button("Delete", systemImage: "trash", role: .destructive, action: onDelete)
            }
        }
    }
}

private struct FlowReactionBar: View {
    let reactions: [DiscordReaction]
    let onTap: (DiscordEmoji, Bool) -> Void

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                ForEach(Array(reactions.enumerated()), id: \.offset) { _, reaction in
                    Button {
                        onTap(reaction.emoji, reaction.me)
                    } label: {
                        HStack(spacing: 4) {
                            if let url = reaction.emoji.imageURL {
                                CachedAsyncImage(url: url) { img in
                                    img.resizable().frame(width: 16, height: 16)
                                } placeholder: {
                                    Text(reaction.emoji.displayString)
                                }
                            } else {
                                Text(reaction.emoji.displayString)
                            }
                            Text("\(reaction.count)")
                                .font(.caption2.weight(.semibold))
                        }
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(reaction.me ? Color.indigo.opacity(0.28) : Color.clear, in: Capsule())
                    }
                    .glassEffect(.regular.interactive(), in: .capsule)
                }
            }
        }
    }
}
