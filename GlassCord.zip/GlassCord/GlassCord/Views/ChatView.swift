import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

struct ChatView: View {
    @Environment(DiscordStore.self) private var store
    @State private var draftText = ""
    @State private var replyingTo: DiscordMessage?
    @State private var editingMessage: DiscordMessage?
    @State private var selectedPhotoItems: [PhotosPickerItem] = []
    @State private var pendingAttachments: [OutgoingAttachment] = []
    @State private var showChannelInfoSheet = false
    @State private var infoSearchText = ""
    @State private var inspectedUser: DiscordUser?
    @State private var lightboxURL: URL?
    @State private var showEmojiPicker = false
    @State private var reactionTargetMessage: DiscordMessage?
    @State private var showFileImporter = false
    @State private var showPollCreator = false
    @State private var pollQuestion = ""
    @State private var pollOption1 = ""
    @State private var pollOption2 = ""
    @State private var pollOption3 = ""
    @State private var pollAllowMulti = false
    @State private var sendHapticTrigger = 0
    @State private var lastTypingSent = Date.distantPast
    @Namespace private var composerNS

    var body: some View {
        Group {
            if let channel = store.activeChannel {
                let title = store.resolvedChannelName(channel)
                chatContent(for: channel, title: title)
                    .navigationTitle(channel.type == .dm || channel.type == .groupDM ? title : "#\(title)")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar(.hidden, for: .tabBar)
                    .toolbar {
                        ToolbarItemGroup(placement: .topBarTrailing) {
                            if channel.type == .dm || channel.type == .groupDM {
                                Button {
                                    if store.connectedVoiceChannelId == channel.id {
                                        store.leaveVoiceChannel()
                                    } else {
                                        store.joinVoiceChannel(channel)
                                    }
                                } label: {
                                    Image(systemName: store.connectedVoiceChannelId == channel.id ? "phone.down.fill" : "phone.fill")
                                        .foregroundStyle(store.connectedVoiceChannelId == channel.id ? .red : .green)
                                }
                            }

                            Button {
                                Task {
                                    let pins = (try? await store.api.fetchPinnedMessages(channelId: channel.id)) ?? []
                                    store.pinnedMessagesByChannel[channel.id] = pins
                                    showChannelInfoSheet = true
                                }
                            } label: {
                                Image(systemName: "info.circle")
                            }
                        }
                    }
                    .sheet(isPresented: $showChannelInfoSheet) {
                        channelInfoSheet(channel: channel, title: title)
                            .presentationDetents([.medium, .large])
                    }
                    .sheet(isPresented: $showEmojiPicker) {
                        EmojiPickerSheet(currentGuildId: channel.guildId) { emoji, emojiString in
                            if let target = reactionTargetMessage {
                                reactionTargetMessage = nil
                                Task {
                                    await store.toggleReaction(
                                        channelId: channel.id,
                                        messageId: target.id,
                                        emoji: emoji,
                                        currentlyMe: false
                                    )
                                }
                            } else {
                                if draftText.isEmpty || draftText.hasSuffix(" ") {
                                    draftText += emojiString + " "
                                } else {
                                    draftText += " " + emojiString + " "
                                }
                            }
                        }
                        .presentationDetents([.medium, .large])
                    }
                    .sheet(item: $inspectedUser) { user in
                        UserProfileSheet(user: user)
                    }
                    .fullScreenCover(item: Binding(
                        get: { lightboxURL.map { IdentifiableURL(url: $0) } },
                        set: { lightboxURL = $0?.url }
                    )) { item in
                        ImageLightboxView(url: item.url)
                    }
                    .sheet(isPresented: $showPollCreator) {
                        createPollSheet(channelId: channel.id)
                            .presentationDetents([.medium])
                    }
                    .fileImporter(
                        isPresented: $showFileImporter,
                        allowedContentTypes: [.item],
                        allowsMultipleSelection: true
                    ) { result in
                        if case .success(let urls) = result {
                            for url in urls {
                                guard url.startAccessingSecurityScopedResource() else { continue }
                                defer { url.stopAccessingSecurityScopedResource() }
                                if let data = try? Data(contentsOf: url) {
                                    let mime = UTType(filenameExtension: url.pathExtension)?.preferredMIMEType ?? "application/octet-stream"
                                    pendingAttachments.append(OutgoingAttachment(
                                        filename: url.lastPathComponent,
                                        mimeType: mime,
                                        data: data
                                    ))
                                }
                            }
                        }
                    }
            } else {
                ContentUnavailableView(
                    "Select a Channel",
                    systemImage: "number.circle",
                    description: Text("Choose a server channel or direct message from the sidebar.")
                )
            }
        }
    }

    private func extractEmojiIdentifier(from str: String) -> String? {
        if let r = str.range(of: #"<a?:([a-zA-Z0-9_]+):(\d+)>"#, options: .regularExpression) {
            let sub = String(str[r]).trimmingCharacters(in: CharacterSet(charactersIn: "<>"))
            let parts = sub.split(separator: ":")
            if parts.count >= 2 {
                return "\(parts[parts.count - 2]):\(parts[parts.count - 1])"
            }
        }
        if let r = str.range(of: #"emojis/(\d+)"#, options: .regularExpression) {
            let id = String(str[r]).replacingOccurrences(of: "emojis/", with: "")
            return "emoji:\(id)"
        }
        return str.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    @ViewBuilder
    private func chatContent(for channel: DiscordChannel, title: String) -> some View {
        let messages = store.messagesByChannel[channel.id] ?? []

        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 2) {
                    if !messages.isEmpty {
                        Button("Load Earlier Messages") {
                            Task { await store.loadMessages(channelId: channel.id, loadOlder: true) }
                        }
                        .font(.caption.weight(.medium))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                    }

                    ForEach(Array(messages.enumerated()), id: \.element.id) { index, msg in
                        let prev = index > 0 ? messages[index - 1] : nil
                        if prev == nil || !Calendar.current.isDate(prev!.parsedDate, inSameDayAs: msg.parsedDate) {
                            DateDividerView(date: msg.parsedDate)
                        }
                        let isGrouped = prev != nil
                            && prev?.author.id == msg.author.id
                            && msg.referencedMessage == nil
                            && Calendar.current.isDate(prev!.parsedDate, inSameDayAs: msg.parsedDate)
                            && msg.parsedDate.timeIntervalSince(prev!.parsedDate) < 300

                        MessageRowView(
                            message: msg,
                            isGrouped: isGrouped,
                            isOwnMessage: msg.author.id == store.currentUser?.id,
                            iMessageMode: store.iMessageModeEnabled,
                            authorStatus: store.presences[msg.author.id],
                            authorIsMobile: store.clientStatuses[msg.author.id]?.isMobileOnlyOrActive ?? false,
                            usersById: store.usersById,
                            channelsById: store.allChannelsById,
                            onReply: { replyingTo = msg; editingMessage = nil },
                            onEdit: { editingMessage = msg; replyingTo = nil; draftText = msg.content },
                            onDelete: { Task { await store.deleteMessage(channelId: channel.id, messageId: msg.id) } },
                            onPin: { Task { try? await store.api.pinMessage(channelId: channel.id, messageId: msg.id) } },
                            onReact: { emoji, me in
                                Task {
                                    await store.toggleReaction(
                                        channelId: channel.id,
                                        messageId: msg.id,
                                        emoji: emoji,
                                        currentlyMe: me
                                    )
                                }
                            },
                            onOpenCustomReaction: {
                                reactionTargetMessage = msg
                                showEmojiPicker = true
                            },
                            onVotePoll: { answerId in
                                Task {
                                    try? await store.api.votePoll(channelId: channel.id, messageId: msg.id, answerIds: [answerId])
                                    await store.loadMessages(channelId: channel.id)
                                }
                            },
                            onInspectUser: { inspectedUser = msg.author },
                            onOpenImage: { url in lightboxURL = url }
                        )
                        .id(msg.id)
                    }
                }
                .padding(.horizontal, 14)
                .padding(.top, 8)
                .padding(.bottom, 16)
            }
            .scrollDismissesKeyboard(.interactively)
            .onChange(of: messages.last?.id) { _, newId in
                if let newId {
                    withAnimation(.easeOut(duration: 0.18)) {
                        proxy.scrollTo(newId, anchor: .bottom)
                    }
                }
            }
            .safeAreaInset(edge: .bottom) {
                VStack(spacing: 6) {
                    if let uploadText = store.uploadStatusText {
                        HStack(spacing: 8) {
                            ProgressView().controlSize(.mini)
                            Text(uploadText)
                                .font(.caption.weight(.medium))
                        }
                        .padding(.horizontal, 14)
                        .padding(.vertical, 6)
                        .glassEffect(.regular, in: .capsule)
                    }

                    if let typing = store.typingText(for: channel.id) {
                        Text(typing)
                            .font(.caption2.weight(.medium))
                            .foregroundStyle(.secondary)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 4)
                            .glassEffect(.regular, in: .capsule)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 16)
                    }

                    mentionAutocompleteBar(for: channel)
                    floatingComposer(for: channel, title: title)
                        .padding(.horizontal, 12)
                        .padding(.bottom, 6)
                }
            }
        }
        .sensoryFeedback(.impact(weight: .light), trigger: sendHapticTrigger)
        .onChange(of: selectedPhotoItems) { _, items in
            Task {
                var loaded: [OutgoingAttachment] = []
                for item in items {
                    if let data = try? await item.loadTransferable(type: Data.self) {
                        loaded.append(OutgoingAttachment(
                            filename: "media_\(UUID().uuidString.prefix(6)).jpg",
                            mimeType: "image/jpeg",
                            data: data
                        ))
                    }
                }
                pendingAttachments.append(contentsOf: loaded)
                selectedPhotoItems = []
            }
        }
    }


    @ViewBuilder
    private func mentionAutocompleteBar(for channel: DiscordChannel) -> some View {
        if let atRange = draftText.range(of: "@[^\\s]*$", options: .regularExpression) {
            let query = String(draftText[atRange].dropFirst()).lowercased()
            let pool: [DiscordUser] = {
                let rec = store.resolvedRecipients(for: channel)
                if !rec.isEmpty { return rec }
                return Array(store.usersById.values)
            }()
            let matches = pool.filter {
                query.isEmpty || $0.displayName.lowercased().contains(query) || $0.username.lowercased().contains(query)
            }.prefix(6)

            if !matches.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(Array(matches)) { u in
                            Button {
                                draftText.replaceSubrange(atRange, with: "<@\(u.id)> ")
                            } label: {
                                HStack(spacing: 6) {
                                    AvatarView(url: u.avatarURL, size: 22)
                                    Text(u.displayName)
                                        .font(.caption.weight(.semibold))
                                }
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                            }
                            .glassEffect(.regular.interactive(), in: .capsule)
                        }
                    }
                    .padding(.horizontal, 14)
                }
            }
        }
    }

    @ViewBuilder
    private func floatingComposer(for channel: DiscordChannel, title: String) -> some View {
        VStack(spacing: 6) {
            if let replyingTo {
                HStack {
                    Image(systemName: "arrowshape.turn.up.left.fill")
                        .font(.caption)
                    Text("Replying to \(replyingTo.author.displayName)")
                        .font(.caption.weight(.medium))
                    Spacer()
                    Button { self.replyingTo = nil } label: {
                        Image(systemName: "xmark.circle.fill")
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 6)
                .glassEffect(.regular, in: .capsule)
            }

            if let editingMessage {
                HStack {
                    Image(systemName: "pencil")
                        .font(.caption)
                    Text("Editing message")
                        .font(.caption.weight(.medium))
                    Spacer()
                    Button {
                        self.editingMessage = nil
                        draftText = ""
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 6)
                .glassEffect(.regular, in: .capsule)
            }

            if !pendingAttachments.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(Array(pendingAttachments.enumerated()), id: \.offset) { idx, att in
                            let mb = Double(att.data.count) / (1024 * 1024)
                            HStack(spacing: 6) {
                                if let uiImg = UIImage(data: att.data) {
                                    Image(uiImage: uiImg)
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 38, height: 38)
                                        .clipShape(RoundedRectangle(cornerRadius: 8))
                                } else {
                                    Image(systemName: "doc.fill")
                                        .foregroundStyle(.indigo)
                                }
                                VStack(alignment: .leading, spacing: 1) {
                                    Text(att.filename)
                                        .font(.caption2.weight(.semibold))
                                        .lineLimit(1)
                                        .frame(maxWidth: 90, alignment: .leading)
                                    Text(String(format: "%.1f MB", mb))
                                        .font(.caption2)
                                        .foregroundStyle(.secondary)
                                }
                                Button {
                                    pendingAttachments.remove(at: idx)
                                } label: {
                                    Image(systemName: "xmark.circle.fill")
                                        .foregroundStyle(.secondary)
                                }
                            }
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        }
                    }
                    .padding(.horizontal, 4)
                }
            }

            GlassEffectContainer(spacing: 8) {
                HStack(spacing: 8) {
                    Menu {
                        PhotosPicker(selection: $selectedPhotoItems, maxSelectionCount: 4, matching: .any(of: [.images, .videos])) {
                            Label("Photos & Videos", systemImage: "photo.on.rectangle")
                        }
                        Button {
                            showFileImporter = true
                        } label: {
                            Label("Upload File", systemImage: "doc.badge.plus")
                        }
                        Button {
                            showPollCreator = true
                        } label: {
                            Label("Create Poll", systemImage: "chart.bar.xaxis")
                        }
                    } label: {
                        Image(systemName: "plus")
                            .font(.body.weight(.semibold))
                            .frame(width: 36, height: 36)
                    }
                    .glassEffect(.regular.interactive(), in: .circle)
                    .glassEffectID("attach", in: composerNS)

                    Button {
                        reactionTargetMessage = nil
                        showEmojiPicker = true
                    } label: {
                        Image(systemName: "face.smiling")
                            .font(.body)
                            .frame(width: 36, height: 36)
                    }
                    .glassEffect(.regular.interactive(), in: .circle)
                    .glassEffectID("emoji", in: composerNS)

                    TextField(channel.type == .dm || channel.type == .groupDM ? "Message \(title)" : "Message #\(title)", text: $draftText, axis: .vertical)
                        .lineLimit(1...5)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 9)
                        .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                        .glassEffectID("input", in: composerNS)
                        .onChange(of: draftText) { _, newValue in
                            if !newValue.isEmpty, Date().timeIntervalSince(lastTypingSent) > 6 {
                                lastTypingSent = Date()
                                store.notifyTyping(channelId: channel.id)
                            }
                        }

                    let canSend = !draftText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !pendingAttachments.isEmpty
                    if canSend {
                        Button {
                            sendHapticTrigger += 1
                            let text = draftText
                            let replyId = replyingTo?.id
                            let editMsg = editingMessage
                            let files = pendingAttachments
                            draftText = ""
                            replyingTo = nil
                            editingMessage = nil
                            pendingAttachments = []

                            Task {
                                if let editMsg {
                                    await store.editMessage(channelId: channel.id, messageId: editMsg.id, newContent: text)
                                } else {
                                    await store.sendMessage(
                                        channelId: channel.id,
                                        content: text,
                                        replyToMessageId: replyId,
                                        attachments: files
                                    )
                                }
                            }
                        } label: {
                            Image(systemName: "arrow.up")
                                .font(.body.weight(.bold))
                                .foregroundStyle(.white)
                                .frame(width: 36, height: 36)
                                .background(store.iMessageModeEnabled ? Color.blue : Color.indigo, in: Circle())
                        }
                        .glassEffect(.regular.interactive(), in: .circle)
                        .glassEffectID("send", in: composerNS)
                    }
                }
            }
        }
    }

    private func channelInfoSheet(channel: DiscordChannel, title: String) -> some View {
        let messages = store.messagesByChannel[channel.id] ?? []
        let filtered = infoSearchText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            ? []
            : messages.filter { $0.content.localizedCaseInsensitiveContains(infoSearchText) }

        return NavigationStack {
            List {
                if !filtered.isEmpty {
                    Section("Search Results") {
                        ForEach(filtered) { msg in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(msg.author.displayName)
                                    .font(.caption.weight(.semibold))
                                DiscordMarkdownText(
                                    content: msg.content,
                                    usersById: store.usersById,
                                    channelsById: store.allChannelsById
                                )
                                .font(.subheadline)
                            }
                            .padding(.vertical, 2)
                        }
                    }
                }

                if let topic = channel.topic, !topic.isEmpty {
                    Section("Topic") {
                        Text(topic)
                            .font(.subheadline)
                    }
                }

                Section("Pinned Messages") {
                    let pins = store.pinnedMessagesByChannel[channel.id] ?? []
                    if pins.isEmpty {
                        Text("No pinned messages.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(pins) { msg in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(msg.author.displayName)
                                    .font(.subheadline.weight(.semibold))
                                DiscordMarkdownText(
                                    content: msg.content,
                                    usersById: store.usersById,
                                    channelsById: store.allChannelsById
                                )
                                .font(.subheadline)
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
            }
            .navigationTitle(channel.type == .dm || channel.type == .groupDM ? title : "#\(title)")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $infoSearchText, prompt: "Search in channel")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { showChannelInfoSheet = false }
                }
            }
        }
    }

    private func createPollSheet(channelId: String) -> some View {
        NavigationStack {
            Form {
                Section("Question") {
                    TextField("Ask a question...", text: $pollQuestion)
                }
                Section("Options") {
                    TextField("Option 1", text: $pollOption1)
                    TextField("Option 2", text: $pollOption2)
                    TextField("Option 3 (optional)", text: $pollOption3)
                }
                Section {
                    Toggle("Allow Multiple Answers", isOn: $pollAllowMulti)
                }
            }
            .navigationTitle("Create Poll")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showPollCreator = false }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Post") {
                        let q = pollQuestion
                        let opts = [pollOption1, pollOption2, pollOption3]
                            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                            .filter { !$0.isEmpty }
                        let multi = pollAllowMulti
                        pollQuestion = ""
                        pollOption1 = ""
                        pollOption2 = ""
                        pollOption3 = ""
                        showPollCreator = false
                        Task {
                            if let msg = try? await store.api.sendPoll(channelId: channelId, question: q, answers: opts, allowMultiselect: multi) {
                                await store.loadMessages(channelId: channelId)
                                _ = msg
                            }
                        }
                    }
                    .disabled(pollQuestion.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || pollOption1.isEmpty || pollOption2.isEmpty)
                }
            }
        }
    }
}

private struct MessageRowView: View {
    let message: DiscordMessage
    let isGrouped: Bool
    let isOwnMessage: Bool
    let iMessageMode: Bool
    let authorStatus: PresenceStatus?
    let authorIsMobile: Bool
    let usersById: [String: DiscordUser]
    let channelsById: [String: DiscordChannel]
    let onReply: () -> Void
    let onEdit: () -> Void
    let onDelete: () -> Void
    let onPin: () -> Void
    let onReact: (DiscordEmoji, Bool) -> Void
    let onOpenCustomReaction: () -> Void
    let onVotePoll: (Int) -> Void
    let onInspectUser: () -> Void
    let onOpenImage: (URL) -> Void
    @State private var swipeOffset: CGFloat = 0

    var body: some View {
        if iMessageMode {
            iMessageBubbleBody
        } else {
            discordRowBody
        }
    }

    @ViewBuilder
    private var mediaContent: some View {
        if let poll = message.poll {
            VStack(alignment: .leading, spacing: 8) {
                Text(poll.question.text ?? "Poll")
                    .font(.subheadline.weight(.bold))
                ForEach(poll.answers) { ans in
                    let countObj = poll.results?.answerCounts?.first(where: { $0.id == ans.answerId })
                    let count = countObj?.count ?? 0
                    let voted = countObj?.meVoted ?? false
                    Button {
                        onVotePoll(ans.answerId)
                    } label: {
                        HStack {
                            Text(ans.pollMedia.text ?? "")
                                .font(.subheadline)
                            Spacer()
                            if count > 0 {
                                Text("\(count)")
                                    .font(.caption.weight(.semibold))
                                    .foregroundStyle(.secondary)
                            }
                            if voted {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundStyle(.indigo)
                            }
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(voted ? Color.indigo.opacity(0.22) : Color.secondary.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(12)
            .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }

        if let attachments = message.attachments, !attachments.isEmpty {
            ForEach(attachments) { att in
                if att.isVideo, let url = URL(string: att.url) {
                    InlineVideoPlayerView(url: url)
                        .frame(maxWidth: 280)
                } else if att.isGIF, let url = URL(string: att.url) {
                    AnimatedGIFView(url: url)
                        .frame(maxWidth: 280, maxHeight: 260)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                } else if att.isImage, let url = URL(string: att.url) {
                    Button { onOpenImage(url) } label: {
                        CachedAsyncImage(url: url) { img in
                            img.resizable()
                                .scaledToFit()
                                .frame(maxWidth: 280, maxHeight: 280)
                                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        } placeholder: {
                        RoundedRectangle(cornerRadius: 16)
                            .fill(.secondary.opacity(0.15))
                            .frame(width: 220, height: 140)
                            .overlay(ProgressView())
                        }
                    }
                    .buttonStyle(.plain)
                } else if let url = URL(string: att.url) {
                    Link(destination: url) {
                        Label(att.filename, systemImage: "doc.fill")
                            .font(.subheadline)
                            .padding(10)
                            .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 12))
                    }
                }
            }
        }

        if let embeds = message.embeds, !embeds.isEmpty {
            ForEach(Array(embeds.enumerated()), id: \.offset) { _, embed in
                if let vidStr = embed.video?.url ?? embed.video?.proxyUrl, let vidURL = URL(string: vidStr) {
                    if vidStr.lowercased().hasSuffix(".gif") {
                        AnimatedGIFView(url: vidURL)
                            .frame(maxWidth: 260, maxHeight: 240)
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    } else {
                        InlineVideoPlayerView(url: vidURL)
                            .frame(maxWidth: 270)
                    }
                } else if let imgStr = embed.image?.url ?? embed.thumbnail?.url, let imgURL = URL(string: imgStr) {
                    if imgStr.lowercased().contains(".gif") {
                        AnimatedGIFView(url: imgURL)
                            .frame(maxWidth: 260, maxHeight: 240)
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    } else {
                        CachedAsyncImage(url: imgURL) { img in
                            img.resizable()
                                .scaledToFit()
                                .frame(maxWidth: 260, maxHeight: 240)
                                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        } placeholder: {
                            EmptyView()
                        }
                    }
                } else if embed.title != nil || embed.description != nil {
                    VStack(alignment: .leading, spacing: 4) {
                        if let title = embed.title {
                            Text(title).font(.subheadline.weight(.semibold))
                        }
                        if let desc = embed.description {
                            DiscordMarkdownText(content: desc, usersById: usersById, channelsById: channelsById)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
            }
        }
    }

    @ViewBuilder
    private var iMessageBubbleBody: some View {
        VStack(alignment: isOwnMessage ? .trailing : .leading, spacing: 4) {
            HStack {
                if isOwnMessage { Spacer(minLength: 56) }

                VStack(alignment: .leading, spacing: 6) {
                    if !message.content.isEmpty {
                        DiscordMarkdownText(content: message.content, usersById: usersById, channelsById: channelsById)
                            .font(.body)
                            .foregroundStyle(isOwnMessage ? .white : .primary)
                    }
                    mediaContent
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 9)
                .background(
                    isOwnMessage ? AnyShapeStyle(Color.blue.gradient) : AnyShapeStyle(.clear),
                    in: RoundedRectangle(cornerRadius: 20, style: .continuous)
                )
                .glassEffect(isOwnMessage ? .identity : .regular, in: RoundedRectangle(cornerRadius: 20, style: .continuous))

                if !isOwnMessage { Spacer(minLength: 56) }
            }

            if let reactions = message.reactions, !reactions.isEmpty {
                FlowReactionBar(reactions: reactions, onTap: onReact)
            }
        }
        .padding(.vertical, 3)
        .contextMenu {
            Button("Reply", systemImage: "arrowshape.turn.up.left", action: onReply)
            Button("React with Any Emoji...", systemImage: "face.smiling", action: onOpenCustomReaction)
            Button("Copy Text", systemImage: "doc.on.doc") {
                UIPasteboard.general.string = message.content
            }
            if isOwnMessage {
                Button("Edit", systemImage: "pencil", action: onEdit)
                Button("Delete", systemImage: "trash", role: .destructive, action: onDelete)
            }
        }
    }

    private var discordRowBody: some View {
        VStack(alignment: .leading, spacing: 4) {
            if let ref = message.referencedMessage {
                HStack(spacing: 6) {
                    Image(systemName: "arrowshape.turn.up.right")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                    Text(ref.author?.displayName ?? "Unknown")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                    Text(ref.content ?? "Attachment")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                .padding(.leading, 48)
            }

            HStack(alignment: .top, spacing: 10) {
                if isGrouped {
                    Color.clear.frame(width: 38, height: 1)
                } else {
                    Button(action: onInspectUser) {
                        AvatarView(
                            url: message.author.avatarURL,
                            decorationURL: message.author.avatarDecorationData?.imageURL,
                            status: authorStatus,
                            isMobile: authorIsMobile,
                            size: 38
                        )
                    }
                    .buttonStyle(.plain)
                }

                VStack(alignment: .leading, spacing: 4) {
                    if !isGrouped {
                        HStack(alignment: .firstTextBaseline, spacing: 6) {
                            Text(message.author.displayName)
                                .font(.subheadline.weight(.semibold))
                            if message.author.bot == true {
                                Text("APP")
                                    .font(.caption2.weight(.bold))
                                    .padding(.horizontal, 5)
                                    .padding(.vertical, 1)
                                    .background(.indigo.opacity(0.2), in: Capsule())
                                    .foregroundStyle(.indigo)
                            }
                            Text(message.parsedDate, style: .time)
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    }

                    if !message.content.isEmpty {
                        HStack(alignment: .lastTextBaseline, spacing: 4) {
                            DiscordMarkdownText(
                                content: message.content,
                                usersById: usersById,
                                channelsById: channelsById
                            )
                            .font(.body)
                            if message.editedTimestamp != nil {
                                Text("(edited)")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }

                    mediaContent

                    if let reactions = message.reactions, !reactions.isEmpty {
                        FlowReactionBar(reactions: reactions, onTap: onReact)
                    }
                }
            }
        }
        .padding(.vertical, isGrouped ? 2 : 6)
        .offset(x: swipeOffset)
        .gesture(
            DragGesture(minimumDistance: 24)
                .onChanged { value in
                    if value.translation.width > 0 && abs(value.translation.height) < 30 {
                        swipeOffset = min(value.translation.width * 0.5, 52)
                    }
                }
                .onEnded { value in
                    if value.translation.width > 65 {
                        onReply()
                    }
                    withAnimation(.spring(duration: 0.25)) { swipeOffset = 0 }
                }
        )
        .contentShape(Rectangle())
        .contextMenu {
            Button("Reply", systemImage: "arrowshape.turn.up.left", action: onReply)
            Button("React with Any Emoji...", systemImage: "face.smiling", action: onOpenCustomReaction)
            Button("Copy Text", systemImage: "doc.on.doc") {
                UIPasteboard.general.string = message.content
            }
            Menu("Quick React", systemImage: "hand.thumbsup") {
                ForEach(["👍", "❤️", "😂", "🔥", "👀"], id: \.self) { sym in
                    Button(sym) {
                        onReact(DiscordEmoji(id: nil, name: sym, animated: false), false)
                    }
                }
            }
            Button("Pin Message", systemImage: "pin", action: onPin)
            if isOwnMessage {
                Button("Edit", systemImage: "pencil", action: onEdit)
                Button("Delete", systemImage: "trash", role: .destructive, action: onDelete)
            }
        }
    }
}

private struct FlowReactionBar: View {
    let reactions: [DiscordReaction]
    let onTap: (DiscordEmoji, Bool) -> Void

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                ForEach(Array(reactions.enumerated()), id: \.offset) { _, reaction in
                    Button {
                        onTap(reaction.emoji, reaction.me)
                    } label: {
                        HStack(spacing: 4) {
                            if let url = reaction.emoji.imageURL {
                                CachedAsyncImage(url: url) { img in
                                    img.resizable().frame(width: 16, height: 16)
                                } placeholder: {
                                    Text(reaction.emoji.displayString)
                                }
                            } else {
                                Text(reaction.emoji.displayString)
                            }
                            Text("\(reaction.count)")
                                .font(.caption2.weight(.semibold))
                        }
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(reaction.me ? Color.indigo.opacity(0.28) : Color.clear, in: Capsule())
                    }
                    .glassEffect(.regular.interactive(), in: .capsule)
                }
            }
        }
    }
}


private struct IdentifiableURL: Identifiable {
    let id = UUID()
    let url: URL
}

private struct DateDividerView: View {
    let date: Date
    var body: some View {
        HStack(spacing: 10) {
            VStack { Divider() }
            Text(label)
                .font(.caption2.weight(.semibold))
                .foregroundStyle(.secondary)
            VStack { Divider() }
        }
        .padding(.vertical, 8)
    }
    private var label: String {
        if Calendar.current.isDateInToday(date) { return "Today" }
        if Calendar.current.isDateInYesterday(date) { return "Yesterday" }
        return date.formatted(date: .abbreviated, time: .omitted)
    }
}
