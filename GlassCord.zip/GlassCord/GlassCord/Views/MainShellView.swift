import SwiftUI

enum MainTab: String, CaseIterable, Hashable {
    case chat = "Servers"
    case friends = "Friends"
    case search = "Search"
    case profile = "You"
}

struct MainShellView: View {
    @Environment(DiscordStore.self) private var store
    @State private var selectedTab: MainTab = .chat
    @State private var columnVisibility: NavigationSplitViewVisibility = .all
    @State private var searchQuery = ""
    @State private var searchResults: [DiscordMessage] = []
    @State private var isSearching = false

    var body: some View {
        ZStack(alignment: .bottom) {
            GlassBackgroundBackdrop()
                .ignoresSafeArea()

            TabView(selection: $selectedTab) {
                Tab("Servers", systemImage: "bubble.left.and.bubble.right.fill", value: MainTab.chat) {
                    NavigationSplitView(columnVisibility: $columnVisibility) {
                        ServerAndChannelView()
                    } detail: {
                        ChatView()
                    }
                    .navigationSplitViewStyle(.balanced)
                }

                Tab("Friends", systemImage: "person.2.fill", value: MainTab.friends) {
                    FriendsAndDMView {
                        selectedTab = .chat
                    }
                }

                Tab("Search", systemImage: "magnifyingglass", value: MainTab.search, role: .search) {
                    searchView
                }

                Tab("You", systemImage: "person.crop.circle.fill", value: MainTab.profile) {
                    ProfileAndSettingsView()
                }
            }
            .tabBarMinimizeBehavior(.onScrollDown)

            if store.connectedVoiceChannelId != nil {
                VoiceBarView()
                    .padding(.horizontal, 16)
                    .padding(.bottom, 64)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .animation(.spring(duration: 0.35), value: store.connectedVoiceChannelId)
    }

    private var searchView: some View {
        NavigationStack {
            List {
                if let guild = store.activeGuild {
                    Section("Searching in \(guild.name)") {
                        if isSearching {
                            ProgressView("Searching messages...")
                        } else if searchResults.isEmpty {
                            ContentUnavailableView(
                                "Search Messages",
                                systemImage: "magnifyingglass",
                                description: Text("Enter keywords to search \(guild.name).")
                            )
                        } else {
                            ForEach(searchResults) { msg in
                                Button {
                                    Task {
                                        await store.selectChannel(msg.channelId)
                                        selectedTab = .chat
                                    }
                                } label: {
                                    VStack(alignment: .leading, spacing: 4) {
                                        HStack {
                                            Text(msg.author.displayName)
                                                .font(.subheadline.weight(.semibold))
                                            Spacer()
                                            Text(msg.parsedDate, style: .relative)
                                                .font(.caption2)
                                                .foregroundStyle(.secondary)
                                        }
                                        DiscordMarkdownText(content: msg.content)
                                            .font(.subheadline)
                                            .lineLimit(3)
                                    }
                                    .padding(.vertical, 4)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                } else {
                    ContentUnavailableView(
                        "Select a Server First",
                        systemImage: "server.rack",
                        description: Text("Pick a server in the Servers tab to search its message history.")
                    )
                }
            }
            .scrollContentBackground(.hidden)
            .navigationTitle("Search")
            .searchable(text: $searchQuery, prompt: "Search server messages")
            .onSubmit(of: .search) {
                guard let gid = store.selectedGuildId, !searchQuery.isEmpty else { return }
                isSearching = true
                Task {
                    searchResults = (try? await store.api.searchGuildMessages(guildId: gid, query: searchQuery)) ?? []
                    isSearching = false
                }
            }
        }
    }
}
