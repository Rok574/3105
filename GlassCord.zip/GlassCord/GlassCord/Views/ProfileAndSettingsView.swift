import SwiftUI
import WebKit

struct ProfileAndSettingsView: View {
    @Environment(DiscordStore.self) private var store
    @State private var customStatusInput = ""

    var body: some View {
        @Bindable var bindableStore = store
        NavigationStack {
            List {
                if let user = store.currentUser {
                    Section {
                        HStack(spacing: 14) {
                            AvatarView(url: user.avatarURL, status: store.currentPresence, size: 60)
                            VStack(alignment: .leading, spacing: 4) {
                                HStack(spacing: 6) {
                                    Text(user.displayName)
                                        .font(.title3.weight(.bold))
                                    if store.fakeNitroEnabled {
                                        Label("Nitro", systemImage: "sparkles")
                                            .font(.caption2.weight(.bold))
                                            .padding(.horizontal, 7)
                                            .padding(.vertical, 2)
                                            .background(.purple.opacity(0.22), in: Capsule())
                                            .foregroundStyle(.purple)
                                    }
                                }
                                Text("@\(user.username)")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .padding(.vertical, 6)
                    }
                }

                Section("GlassCord Extras") {
                    Toggle("Fake Nitro", isOn: $bindableStore.fakeNitroEnabled)
                    Toggle("Free Cross-Server Emojis", isOn: $bindableStore.freeEmojisEnabled)
                    Toggle("Catbox Large File Fallback", isOn: $bindableStore.catboxAutoFallback)

                    if store.catboxAutoFallback {
                        Picker("Upload via Catbox above", selection: $bindableStore.catboxThresholdMB) {
                            Text("8 MB").tag(8)
                            Text("10 MB").tag(10)
                            Text("25 MB").tag(25)
                        }
                        TextField("Catbox Userhash (optional)", text: $bindableStore.catboxUserhash)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    }
                }

                Section("Presence") {
                    Picker("Status", selection: Binding(
                        get: { store.currentPresence },
                        set: { newStatus in
                            Task { await store.updateStatus(newStatus, customText: store.customStatusText) }
                        }
                    )) {
                        ForEach([PresenceStatus.online, .idle, .dnd, .invisible], id: \.self) { status in
                            Text(status.label).tag(status)
                        }
                    }

                    HStack {
                        TextField("Set a custom status...", text: $customStatusInput)
                        Button("Save") {
                            Task { await store.updateStatus(store.currentPresence, customText: customStatusInput) }
                        }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.small)
                    }
                }

                Section("Connection & Cache") {
                    LabeledContent("Gateway", value: store.connectionStatus)
                    LabeledContent("Servers", value: "\(store.guilds.count)")
                    LabeledContent("Direct Messages", value: "\(store.dmChannels.count)")
                    Button("Clear Local Cache") {
                        Task { await DiskCache.shared.clear() }
                    }
                }

                Section {
                    Button("Sign Out", role: .destructive) {
                        WKWebsiteDataStore.default().removeData(
                            ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(),
                            modifiedSince: .distantPast
                        ) {}
                        store.signOut()
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .navigationTitle("You")
            .onAppear {
                customStatusInput = store.customStatusText
            }
        }
    }
}
