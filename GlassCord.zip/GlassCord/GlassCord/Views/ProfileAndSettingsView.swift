import SwiftUI
import WebKit
import PhotosUI

struct ProfileAndSettingsView: View {
    @Environment(DiscordStore.self) private var store
    @State private var selectedProfileTab: ProfileTab = .main
    @State private var showSettingsSheet = false
    @State private var showEditProfileSheet = false
    @State private var showStatusSheet = false

    @State private var customStatusInput = ""
    @State private var displayNameInput = ""
    @State private var bioInput = ""
    @State private var pronounsInput = ""
    @State private var selectedAvatarItem: PhotosPickerItem?
    @State private var pendingAvatarData: Data?
    @State private var isSavingProfile = false

    enum ProfileTab: String, CaseIterable {
        case main = "Main"
        case connections = "Connections"
        case activity = "Activity"
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 0) {
                    bannerAndAvatarHeader

                    VStack(alignment: .leading, spacing: 14) {
                        identitySection
                        editProfileButton
                        profileTabBar

                        switch selectedProfileTab {
                        case .main:
                            mainProfileCards
                        case .connections:
                            connectionsCards
                        case .activity:
                            activityCards
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 10)
                    .padding(.bottom, 100)
                }
            }
            .ignoresSafeArea(edges: .top)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showSettingsSheet = true
                    } label: {
                        Image(systemName: "gearshape.fill")
                    }
                }
            }
            .sheet(isPresented: $showSettingsSheet) {
                settingsSheet
                    .presentationDetents([.large])
            }
            .sheet(isPresented: $showStatusSheet) {
                statusEditSheet
                    .presentationDetents([.medium])
            }
            .sheet(isPresented: $showEditProfileSheet) {
                editProfileSheet
                    .presentationDetents([.large])
            }
        }
    }

    // MARK: - Banner + Overlapping Avatar + Status Bubble
    private var bannerAndAvatarHeader: some View {
        ZStack(alignment: .bottomLeading) {
            Group {
                if let user = store.currentUser, let banner = user.banner, !banner.isEmpty,
                   let url = URL(string: "https://cdn.discordapp.com/banners/\(user.id)/\(banner).\(banner.hasPrefix("a_") ? "gif" : "png")?size=600") {
                    CachedAsyncImage(url: url) { img in
                        img.resizable().scaledToFill()
                    } placeholder: {
                        bannerFallbackGradient
                    }
                } else {
                    bannerFallbackGradient
                }
            }
            .frame(height: 165)
            .clipped()

            HStack(alignment: .bottom, spacing: 12) {
                if let user = store.currentUser {
                    AvatarView(url: user.avatarURL, status: store.currentPresence, size: 88)
                        .overlay(Circle().stroke(.background, lineWidth: 5))
                }

                Button {
                    customStatusInput = store.customStatusText
                    showStatusSheet = true
                } label: {
                    HStack(spacing: 6) {
                        Circle()
                            .fill(.secondary.opacity(0.4))
                            .frame(width: 6, height: 6)
                        Text(store.customStatusText.isEmpty ? "Set status..." : store.customStatusText)
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(store.customStatusText.isEmpty ? .secondary : .primary)
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .glassEffect(.regular.interactive(), in: .capsule)
                }
                .padding(.bottom, 10)
            }
            .padding(.horizontal, 16)
            .offset(y: 40)
        }
        .padding(.bottom, 44)
    }

    private var bannerFallbackGradient: some View {
        LinearGradient(
            colors: [.indigo.opacity(0.8), .purple.opacity(0.65), .cyan.opacity(0.45)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }

    // MARK: - Identity & Edit Button
    @ViewBuilder
    private var identitySection: some View {
        if let user = store.currentUser {
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 8) {
                    Text(user.displayName)
                        .font(.title2.weight(.bold))

                    if store.fakeNitroEnabled {
                        Label("Nitro", systemImage: "sparkles")
                            .font(.caption2.weight(.bold))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 3)
                            .background(.purple.opacity(0.24), in: Capsule())
                            .foregroundStyle(.purple)
                    }
                }

                HStack(spacing: 6) {
                    Text("@\(user.username)")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    if !store.pronounsText.isEmpty {
                        Text("• \(store.pronounsText)")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
    }

    private var editProfileButton: some View {
        Button {
            displayNameInput = store.currentUser?.globalName ?? store.currentUser?.username ?? ""
            bioInput = store.currentUser?.bio ?? ""
            pronounsInput = store.pronounsText
            pendingAvatarData = nil
            selectedAvatarItem = nil
            showEditProfileSheet = true
        } label: {
            Label("Edit Profile", systemImage: "pencil")
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
        }
        .glassEffect(.regular.interactive(), in: .capsule)
    }

    // MARK: - Profile Tabs
    private var profileTabBar: some View {
        HStack(spacing: 0) {
            ForEach(ProfileTab.allCases, id: \.self) { tab in
                let isSelected = selectedProfileTab == tab
                Button {
                    withAnimation(.spring(duration: 0.25)) {
                        selectedProfileTab = tab
                    }
                } label: {
                    VStack(spacing: 8) {
                        Text(tab.rawValue)
                            .font(.subheadline.weight(isSelected ? .semibold : .regular))
                            .foregroundStyle(isSelected ? .primary : .secondary)
                        Rectangle()
                            .fill(isSelected ? Color.indigo : Color.clear)
                            .frame(height: 2.5)
                            .clipShape(Capsule())
                    }
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.top, 4)
    }

    // MARK: - Tab Content Cards
    private var mainProfileCards: some View {
        VStack(spacing: 12) {
            profileCard(title: "About Me") {
                let bio = store.currentUser?.bio ?? ""
                Text(bio.isEmpty ? "No bio set yet." : bio)
                    .font(.subheadline)
                    .foregroundStyle(bio.isEmpty ? .secondary : .primary)
            }

            if let user = store.currentUser, let joined = Snowflake.date(from: user.id) {
                profileCard(title: "Member Since") {
                    HStack(spacing: 8) {
                        Image(systemName: "bubble.left.and.bubble.right.fill")
                            .foregroundStyle(.indigo)
                        Text(joined.formatted(date: .abbreviated, time: .omitted))
                            .font(.subheadline)
                    }
                }
            }

            profileCard(title: "GlassCord Quick Controls") {
                VStack(spacing: 10) {
                    HStack {
                        Label("Gateway", systemImage: "antenna.radiowaves.left.and.right")
                            .font(.subheadline)
                        Spacer()
                        Text(store.connectionStatus)
                            .font(.caption.weight(.medium))
                            .foregroundStyle(store.connectionStatus == "Connected" ? .green : .orange)
                    }
                    Divider()
                    HStack {
                        Label("Servers & DMs", systemImage: "server.rack")
                            .font(.subheadline)
                        Spacer()
                        Text("\(store.guilds.count) servers • \(store.dmChannels.count) DMs")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
    }

    private var connectionsCards: some View {
        profileCard(title: "Connected Accounts & Extras") {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Image(systemName: "sparkles")
                        .foregroundStyle(.purple)
                    Text("Fake Nitro & Free Emojis")
                        .font(.subheadline.weight(.medium))
                    Spacer()
                    Text(store.fakeNitroEnabled ? "Active" : "Off")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(store.fakeNitroEnabled ? .green : .secondary)
                }
                Divider()
                HStack {
                    Image(systemName: "arrow.up.doc.fill")
                        .foregroundStyle(.indigo)
                    Text("Catbox Large File Fallback")
                        .font(.subheadline.weight(.medium))
                    Spacer()
                    Text(store.catboxAutoFallback ? ">\(store.catboxThresholdMB) MB" : "Off")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(store.catboxAutoFallback ? .green : .secondary)
                }
            }
        }
    }

    private var activityCards: some View {
        profileCard(title: "Presence") {
            HStack {
                Text("Current Status")
                    .font(.subheadline)
                Spacer()
                Text(store.currentPresence.label)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.secondary)
            }
        }
    }

    private func profileCard<Content: View>(title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
                .textCase(.uppercase)
            content()
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    // MARK: - Settings Sheet
    private var settingsSheet: some View {
        @Bindable var bindableStore = store
        return NavigationStack {
            List {
                Section("Appearance") {
                    Toggle("iMessage Mode (Hide Servers)", isOn: $bindableStore.iMessageModeEnabled)
                }

                Section("GlassCord Extras") {
                    Toggle("Fake Nitro", isOn: $bindableStore.fakeNitroEnabled)
                    Toggle("Free Cross-Server Emojis", isOn: $bindableStore.freeEmojisEnabled)
                    Toggle("Catbox Large File Fallback", isOn: $bindableStore.catboxAutoFallback)

                    if store.catboxAutoFallback {
                        Picker("Upload via Catbox above", selection: $bindableStore.catboxThresholdMB) {
                            Text("8 MB").tag(8)
                            Text("10 MB").tag(10)
                            Text("25 MB").tag(25)
                        }
                        TextField("Catbox Userhash (optional)", text: $bindableStore.catboxUserhash)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    }
                }

                Section("Presence") {
                    Picker("Status", selection: Binding(
                        get: { store.currentPresence },
                        set: { newStatus in
                            Task { await store.updateStatus(newStatus, customText: store.customStatusText) }
                        }
                    )) {
                        ForEach([PresenceStatus.online, .idle, .dnd, .invisible], id: \.self) { status in
                            Text(status.label).tag(status)
                        }
                    }
                }

                Section("Connection & Cache") {
                    LabeledContent("Gateway", value: store.connectionStatus)
                    LabeledContent("Servers", value: "\(store.guilds.count)")
                    LabeledContent("Direct Messages", value: "\(store.dmChannels.count)")
                    Button("Clear Local Cache") {
                        Task { await DiskCache.shared.clear() }
                    }
                }

                Section {
                    Button("Sign Out", role: .destructive) {
                        showSettingsSheet = false
                        WKWebsiteDataStore.default().removeData(
                            ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(),
                            modifiedSince: .distantPast
                        ) {}
                        store.signOut()
                    }
                }
            }
            .navigationTitle("Settings")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { showSettingsSheet = false }
                }
            }
        }
    }

    private var statusEditSheet: some View {
        NavigationStack {
            Form {
                Section("Online Status") {
                    Picker("Status", selection: Binding(
                        get: { store.currentPresence },
                        set: { newStatus in
                            Task { await store.updateStatus(newStatus, customText: customStatusInput) }
                        }
                    )) {
                        ForEach([PresenceStatus.online, .idle, .dnd, .invisible], id: \.self) { status in
                            Text(status.label).tag(status)
                        }
                    }
                    .pickerStyle(.segmented)
                }

                Section("Custom Status Bubble") {
                    TextField("What's on your mind?", text: $customStatusInput)
                }
            }
            .navigationTitle("Edit Status")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showStatusSheet = false }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        let text = customStatusInput
                        showStatusSheet = false
                        Task { await store.updateStatus(store.currentPresence, customText: text) }
                    }
                }
            }
        }
    }

    private var editProfileSheet: some View {
        NavigationStack {
            Form {
                Section("Avatar") {
                    HStack(spacing: 16) {
                        if let pendingAvatarData, let uiImg = UIImage(data: pendingAvatarData) {
                            Image(uiImage: uiImg)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 64, height: 64)
                                .clipShape(Circle())
                        } else if let user = store.currentUser {
                            AvatarView(url: user.avatarURL, size: 64)
                        }

                        PhotosPicker(selection: $selectedAvatarItem, matching: .images) {
                            Label("Change Avatar", systemImage: "photo.on.rectangle")
                        }
                    }
                }

                Section("Display Name") {
                    TextField("Display Name", text: $displayNameInput)
                }

                Section("Pronouns") {
                    TextField("e.g. He/Him", text: $pronounsInput)
                }

                Section("Bio") {
                    TextField("Tell people about yourself...", text: $bioInput, axis: .vertical)
                        .lineLimit(3...6)
                }
            }
            .navigationTitle("Edit Profile")
            .onChange(of: selectedAvatarItem) { _, item in
                Task {
                    if let data = try? await item?.loadTransferable(type: Data.self),
                       let uiImg = UIImage(data: data),
                       let jpeg = uiImg.jpegData(compressionQuality: 0.85) {
                        pendingAvatarData = jpeg
                    }
                }
            }
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showEditProfileSheet = false }
                }
                ToolbarItem(placement: .confirmationAction) {
                    if isSavingProfile {
                        ProgressView()
                    } else {
                        Button("Save") {
                            isSavingProfile = true
                            Task {
                                await store.saveProfile(
                                    globalName: displayNameInput,
                                    bio: bioInput,
                                    pronouns: pronounsInput,
                                    avatarJPEGData: pendingAvatarData
                                )
                                isSavingProfile = false
                                showEditProfileSheet = false
                            }
                        }
                    }
                }
            }
        }
    }
}
