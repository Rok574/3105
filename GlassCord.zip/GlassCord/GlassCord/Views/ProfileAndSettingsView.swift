import SwiftUI
import WebKit
import PhotosUI

struct ProfileAndSettingsView: View {
    @Environment(DiscordStore.self) private var store
    @State private var selectedProfileTab: ProfileTab = .main
    @State private var showSettingsSheet = false
    @State private var showEditProfileSheet = false
    @State private var showStatusSheet = false

    @State private var customStatusInput = ""
    @State private var displayNameInput = ""
    @State private var bioInput = ""
    @State private var pronounsInput = ""
    @State private var selectedFont: NitroNameFont = .standard
    @State private var selectedEffect: NitroNameEffect = .none
    @State private var selectedProfileEffect: ProfileEffectStyle = .none
    @State private var selectedDecorationAsset: String = ""
    @State private var selectedAvatarItem: PhotosPickerItem?
    @State private var pendingAvatarData: Data?
    @State private var isSavingProfile = false

    private let decorationPresets: [(label: String, asset: String)] = [
        ("None", ""),
        ("Sakura Petals", "a_8ffa2ba9bff18e96b76c2e66fd0d7fa3"),
        ("Cyberpunk Ring", "a_10b9f886b513b77ccdd67c8784f1a496"),
        ("Cat Ears", "a_85d79b13d64026b0c36d2d8e5f1c31f0"),
        ("Golden Halo", "a_d7a846722d7392e9f0f8f718c6f333a0")
    ]

    enum ProfileTab: String, CaseIterable {
        case main = "Main"
        case connections = "Connections"
        case activity = "Activity"
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 0) {
                    bannerAndAvatarHeader

                    VStack(alignment: .leading, spacing: 14) {
                        identitySection
                        editProfileButton
                        profileTabBar

                        switch selectedProfileTab {
                        case .main:
                            mainProfileCards
                        case .connections:
                            connectionsCards
                        case .activity:
                            activityCards
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 10)
                    .padding(.bottom, 100)
                }
            }
            .ignoresSafeArea(edges: .top)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showSettingsSheet = true
                    } label: {
                        Image(systemName: "gearshape.fill")
                    }
                }
            }
            .sheet(isPresented: $showSettingsSheet) {
                settingsSheet
                    .presentationDetents([.large])
            }
            .sheet(isPresented: $showStatusSheet) {
                statusEditSheet
                    .presentationDetents([.medium])
            }
            .sheet(isPresented: $showEditProfileSheet) {
                editProfileSheet
                    .presentationDetents([.large])
            }
        }
    }

    // MARK: - Banner + Overlapping Avatar + Status Bubble + Profile Effect
    private var bannerAndAvatarHeader: some View {
        ZStack(alignment: .bottomLeading) {
            ZStack {
                if let user = store.currentUser, let banner = user.banner, !banner.isEmpty,
                   let url = URL(string: "https://cdn.discordapp.com/banners/\(user.id)/\(banner).\(banner.hasPrefix("a_") ? "gif" : "png")?size=600") {
                    CachedAsyncImage(url: url) { img in
                        img.resizable().scaledToFill()
                    } placeholder: {
                        bannerFallbackGradient
                    }
                } else {
                    bannerFallbackGradient
                }

                ProfileEffectOverlay(style: store.selectedProfileEffect)
            }
            .frame(height: 170)
            .clipped()

            HStack(alignment: .bottom, spacing: 12) {
                if let user = store.currentUser {
                    AvatarView(
                        url: user.avatarURL,
                        decorationURL: store.currentDecorationURL,
                        status: store.currentPresence,
                        size: 88
                    )
                    .overlay(Circle().stroke(.background, lineWidth: 5))
                }

                Button {
                    customStatusInput = store.customStatusText
                    showStatusSheet = true
                } label: {
                    HStack(spacing: 6) {
                        Circle()
                            .fill(.secondary.opacity(0.4))
                            .frame(width: 6, height: 6)
                        Text(store.customStatusText.isEmpty ? "Set status..." : store.customStatusText)
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(store.customStatusText.isEmpty ? .secondary : .primary)
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .glassEffect(.regular.interactive(), in: .capsule)
                }
                .padding(.bottom, 10)
            }
            .padding(.horizontal, 16)
            .offset(y: 40)
        }
        .padding(.bottom, 44)
    }

    private var bannerFallbackGradient: some View {
        LinearGradient(
            colors: [.indigo.opacity(0.8), .purple.opacity(0.65), .cyan.opacity(0.45)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }

    // MARK: - Identity & Edit Button
    @ViewBuilder
    private var identitySection: some View {
        if let user = store.currentUser {
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 8) {
                    StyledDisplayNameView(
                        name: user.displayName,
                        fontStyle: store.selectedNameFont,
                        effect: store.selectedNameEffect,
                        size: 24
                    )

                    if store.fakeNitroEnabled {
                        Label("Nitro", systemImage: "sparkles")
                            .font(.caption2.weight(.bold))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 3)
                            .background(.purple.opacity(0.24), in: Capsule())
                            .foregroundStyle(.purple)
                    }
                }

                HStack(spacing: 6) {
                    Text("@\(user.username)")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    if !store.pronounsText.isEmpty {
                        Text("• \(store.pronounsText)")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }

                if !user.badges.isEmpty {
                    HStack(spacing: 6) {
                        ForEach(user.badges) { badge in
                            Image(systemName: badge.systemImage)
                                .font(.caption.weight(.bold))
                                .foregroundStyle(Color(
                                    red: Double((badge.tintHex >> 16) & 0xFF) / 255.0,
                                    green: Double((badge.tintHex >> 8) & 0xFF) / 255.0,
                                    blue: Double(badge.tintHex & 0xFF) / 255.0
                                ))
                                .padding(6)
                                .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                        }
                    }
                    .padding(.top, 2)
                }
            }
        }
    }

    private var editProfileButton: some View {
        HStack(spacing: 10) {
            Button {
                displayNameInput = store.currentUser?.globalName ?? store.currentUser?.username ?? ""
                bioInput = store.currentUser?.bio ?? ""
                pronounsInput = store.pronounsText
                selectedFont = store.selectedNameFont
                selectedEffect = store.selectedNameEffect
                selectedProfileEffect = store.selectedProfileEffect
                selectedDecorationAsset = store.selectedDecorationAsset
                pendingAvatarData = nil
                selectedAvatarItem = nil
                showEditProfileSheet = true
            } label: {
                Label("Edit Profile", systemImage: "pencil")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 11)
            }
            .glassEffect(.regular.interactive(), in: .capsule)

            Menu {
                ForEach([PresenceStatus.online, .idle, .dnd, .invisible], id: \.self) { status in
                    Button {
                        Task { await store.updateStatus(status, customText: store.customStatusText) }
                    } label: {
                        Label(status.label, systemImage: status == .idle ? "moon.fill" : (status == .dnd ? "minus.circle.fill" : "circle.fill"))
                    }
                }
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: store.currentPresence == .idle ? "moon.fill" : (store.currentPresence == .dnd ? "minus.circle.fill" : "circle.fill"))
                        .font(.caption)
                        .foregroundStyle(store.currentPresence == .online ? .green : (store.currentPresence == .idle ? .yellow : (store.currentPresence == .dnd ? .red : .gray)))
                    Text(store.currentPresence.label)
                        .font(.subheadline.weight(.semibold))
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 11)
            }
            .glassEffect(.regular.interactive(), in: .capsule)
        }
    }

    // MARK: - Profile Tabs
    private var profileTabBar: some View {
        HStack(spacing: 0) {
            ForEach(ProfileTab.allCases, id: \.self) { tab in
                let isSelected = selectedProfileTab == tab
                Button {
                    withAnimation(.spring(duration: 0.25)) {
                        selectedProfileTab = tab
                    }
                } label: {
                    VStack(spacing: 8) {
                        Text(tab.rawValue)
                            .font(.subheadline.weight(isSelected ? .semibold : .regular))
                            .foregroundStyle(isSelected ? .primary : .secondary)
                        Rectangle()
                            .fill(isSelected ? Color.indigo : Color.clear)
                            .frame(height: 2.5)
                            .clipShape(Capsule())
                    }
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.top, 4)
    }

    // MARK: - Tab Content Cards
    private var mainProfileCards: some View {
        VStack(spacing: 12) {
            profileCard(title: "About Me") {
                let bio = store.currentUser?.bio ?? ""
                Text(bio.isEmpty ? "No bio set yet." : bio)
                    .font(.subheadline)
                    .foregroundStyle(bio.isEmpty ? .secondary : .primary)
            }

            if let user = store.currentUser, let joined = Snowflake.date(from: user.id) {
                profileCard(title: "Member Since") {
                    HStack(spacing: 8) {
                        Image(systemName: "bubble.left.and.bubble.right.fill")
                            .foregroundStyle(.indigo)
                        Text(joined.formatted(date: .abbreviated, time: .omitted))
                            .font(.subheadline)
                    }
                }
            }


        }
    }

    private var connectionsCards: some View {
        VStack(spacing: 12) {
            if !store.connectedAccounts.isEmpty {
                profileCard(title: "Connections") {
                    VStack(spacing: 10) {
                        ForEach(store.connectedAccounts) { acc in
                            HStack {
                                Image(systemName: "link.circle.fill")
                                    .foregroundStyle(.indigo)
                                Text(acc.name)
                                    .font(.subheadline.weight(.medium))
                                if acc.verified == true {
                                    Image(systemName: "checkmark.seal.fill")
                                        .font(.caption)
                                        .foregroundStyle(.blue)
                                }
                                Spacer()
                                Text(acc.type.capitalized)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
            }
            extrasConnectionCard
        }
    }

    private var extrasConnectionCard: some View {
        profileCard(title: "Connected Accounts & Extras") {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Image(systemName: "sparkles")
                        .foregroundStyle(.purple)
                    Text("Fake Nitro & Free Emojis")
                        .font(.subheadline.weight(.medium))
                    Spacer()
                    Text(store.fakeNitroEnabled ? "Active" : "Off")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(store.fakeNitroEnabled ? .green : .secondary)
                }
                Divider()
                HStack {
                    Image(systemName: "arrow.up.doc.fill")
                        .foregroundStyle(.indigo)
                    Text("Catbox Large File Fallback")
                        .font(.subheadline.weight(.medium))
                    Spacer()
                    Text(store.catboxAutoFallback ? ">\(store.catboxThresholdMB) MB" : "Off")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(store.catboxAutoFallback ? .green : .secondary)
                }
            }
        }
    }

    private var activityCards: some View {
        profileCard(title: "Presence") {
            HStack {
                Text("Current Status")
                    .font(.subheadline)
                Spacer()
                Text(store.currentPresence.label)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.secondary)
            }
        }
    }

    private func profileCard<Content: View>(title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
                .textCase(.uppercase)
            content()
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    // MARK: - Settings Sheet
    private var settingsSheet: some View {
        @Bindable var bindableStore = store
        return NavigationStack {
            List {
                Section("Appearance") {
                    Toggle("iMessage Chat Style", isOn: $bindableStore.iMessageModeEnabled)
                }

                Section("GlassCord Extras") {
                    Toggle("Fake Nitro", isOn: $bindableStore.fakeNitroEnabled)
                    Toggle("Free Cross-Server Emojis", isOn: $bindableStore.freeEmojisEnabled)
                    Toggle("Catbox Large File Fallback", isOn: $bindableStore.catboxAutoFallback)

                    if store.catboxAutoFallback {
                        Picker("Upload via Catbox above", selection: $bindableStore.catboxThresholdMB) {
                            Text("8 MB").tag(8)
                            Text("10 MB").tag(10)
                            Text("25 MB").tag(25)
                        }
                        TextField("Catbox Userhash (optional)", text: $bindableStore.catboxUserhash)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    }
                }

                Section("Presence") {
                    Picker("Status", selection: Binding(
                        get: { store.currentPresence },
                        set: { newStatus in
                            Task { await store.updateStatus(newStatus, customText: store.customStatusText) }
                        }
                    )) {
                        ForEach([PresenceStatus.online, .idle, .dnd, .invisible], id: \.self) { status in
                            Text(status.label).tag(status)
                        }
                    }
                }

                Section("Connection & Cache") {
                    LabeledContent("Gateway", value: store.connectionStatus)
                    LabeledContent("Servers", value: "\(store.guilds.count)")
                    LabeledContent("Direct Messages", value: "\(store.dmChannels.count)")
                    Button("Clear Local Cache") {
                        Task { await DiskCache.shared.clear() }
                    }
                }

                Section {
                    Button("Sign Out", role: .destructive) {
                        showSettingsSheet = false
                        WKWebsiteDataStore.default().removeData(
                            ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(),
                            modifiedSince: .distantPast
                        ) {}
                        store.signOut()
                    }
                }
            }
            .navigationTitle("Settings")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { showSettingsSheet = false }
                }
            }
        }
    }

    private var statusEditSheet: some View {
        NavigationStack {
            Form {
                Section("Online Status") {
                    Picker("Status", selection: Binding(
                        get: { store.currentPresence },
                        set: { newStatus in
                            Task { await store.updateStatus(newStatus, customText: customStatusInput) }
                        }
                    )) {
                        ForEach([PresenceStatus.online, .idle, .dnd, .invisible], id: \.self) { status in
                            Text(status.label).tag(status)
                        }
                    }
                    .pickerStyle(.segmented)
                }

                Section("Custom Status Bubble") {
                    TextField("What's on your mind?", text: $customStatusInput)
                }
            }
            .navigationTitle("Edit Status")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showStatusSheet = false }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        let text = customStatusInput
                        showStatusSheet = false
                        Task { await store.updateStatus(store.currentPresence, customText: text) }
                    }
                }
            }
        }
    }

    private var editProfileSheet: some View {
        NavigationStack {
            Form {
                Section("Live Preview") {
                    HStack(spacing: 14) {
                        if let pendingAvatarData, let uiImg = UIImage(data: pendingAvatarData) {
                            Image(uiImage: uiImg)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 56, height: 56)
                                .clipShape(Circle())
                        } else if let user = store.currentUser {
                            let decoURL = selectedDecorationAsset.isEmpty
                                ? user.avatarDecorationData?.imageURL
                                : URL(string: "https://cdn.discordapp.com/avatar-decoration-presets/\(selectedDecorationAsset).png?size=160")
                            AvatarView(url: user.avatarURL, decorationURL: decoURL, size: 56)
                        }

                        StyledDisplayNameView(
                            name: displayNameInput.isEmpty ? (store.currentUser?.displayName ?? "You") : displayNameInput,
                            fontStyle: selectedFont,
                            effect: selectedEffect,
                            size: 20
                        )
                    }
                    .padding(.vertical, 4)

                    PhotosPicker(selection: $selectedAvatarItem, matching: .images) {
                        Label("Change Avatar", systemImage: "photo.on.rectangle")
                    }
                }

                Section("Identity") {
                    TextField("Display Name", text: $displayNameInput)
                    TextField("Pronouns (e.g. He/Him)", text: $pronounsInput)
                    TextField("Bio", text: $bioInput, axis: .vertical)
                        .lineLimit(3...6)
                }

                Section("Nitro Name Font & Style") {
                    Picker("Font", selection: $selectedFont) {
                        ForEach(NitroNameFont.allCases) { f in
                            Text(f.rawValue).tag(f)
                        }
                    }
                    Picker("Effect", selection: $selectedEffect) {
                        ForEach(NitroNameEffect.allCases) { e in
                            Text(e.rawValue).tag(e)
                        }
                    }
                }

                Section("Decorations & Profile Effects") {
                    Picker("Avatar Decoration", selection: $selectedDecorationAsset) {
                        ForEach(decorationPresets, id: \.asset) { preset in
                            Text(preset.label).tag(preset.asset)
                        }
                    }
                    TextField("Or Custom Decoration Asset ID", text: $selectedDecorationAsset)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()

                    Picker("Profile Effect", selection: $selectedProfileEffect) {
                        ForEach(ProfileEffectStyle.allCases) { effect in
                            Text(effect.rawValue).tag(effect)
                        }
                    }
                }
            }
            .navigationTitle("Edit Profile")
            .onChange(of: selectedAvatarItem) { _, item in
                Task {
                    if let data = try? await item?.loadTransferable(type: Data.self),
                       let uiImg = UIImage(data: data),
                       let jpeg = uiImg.jpegData(compressionQuality: 0.85) {
                        pendingAvatarData = jpeg
                    }
                }
            }
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showEditProfileSheet = false }
                }
                ToolbarItem(placement: .confirmationAction) {
                    if isSavingProfile {
                        ProgressView()
                    } else {
                        Button("Save") {
                            isSavingProfile = true
                            Task {
                                store.selectedNameFont = selectedFont
                                store.selectedNameEffect = selectedEffect
                                store.selectedProfileEffect = selectedProfileEffect
                                store.selectedDecorationAsset = selectedDecorationAsset
                                await store.saveProfile(
                                    globalName: displayNameInput,
                                    bio: bioInput,
                                    pronouns: pronounsInput,
                                    avatarJPEGData: pendingAvatarData
                                )
                                isSavingProfile = false
                                showEditProfileSheet = false
                            }
                        }
                    }
                }
            }
        }
    }
}
