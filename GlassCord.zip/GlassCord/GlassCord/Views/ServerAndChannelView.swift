import SwiftUI

struct ServerAndChannelView: View {
    @Environment(DiscordStore.self) private var store
    @Namespace private var railNS

    var body: some View {
        HStack(spacing: 0) {
            guildRail
                .frame(width: 72)

            Divider()

            channelList
        }
        .navigationTitle(store.activeGuild?.name ?? "Direct Messages")
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: - Guild Rail
    private var guildRail: some View {
        ScrollView(.vertical, showsIndicators: false) {
            GlassEffectContainer(spacing: 12) {
                VStack(spacing: 12) {
                    Button {
                        Task { await store.selectGuild(nil) }
                    } label: {
                        Image(systemName: "bubble.left.and.bubble.right.fill")
                            .font(.title3)
                            .foregroundStyle(store.selectedGuildId == nil ? .white : .primary)
                            .frame(width: 48, height: 48)
                            .background(store.selectedGuildId == nil ? Color.indigo : Color.clear, in: Circle())
                    }
                    .glassEffect(.regular.interactive(), in: .circle)
                    .glassEffectID("home-dm", in: railNS)

                    Divider()
                        .padding(.horizontal, 14)

                    ForEach(store.guilds) { guild in
                        let isSelected = store.selectedGuildId == guild.id
                        Button {
                            Task { await store.selectGuild(guild.id) }
                        } label: {
                            guildIcon(guild: guild, isSelected: isSelected)
                        }
                        .glassEffect(.regular.interactive(), in: RoundedRectangle(cornerRadius: isSelected ? 16 : 24, style: .continuous))
                        .glassEffectID("guild-\(guild.id)", in: railNS)
                    }
                }
                .padding(.vertical, 12)
            }
        }
    }

    @ViewBuilder
    private func guildIcon(guild: DiscordGuild, isSelected: Bool) -> some View {
        Group {
            if let url = guild.iconURL {
                CachedAsyncImage(url: url) { img in
                    img.resizable().scaledToFill()
                } placeholder: {
                    Text(guild.initials)
                        .font(.subheadline.weight(.bold))
                }
            } else {
                Text(guild.initials)
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(isSelected ? .white : .primary)
            }
        }
        .frame(width: 48, height: 48)
        .background(isSelected ? Color.indigo.opacity(0.85) : Color.secondary.opacity(0.18))
        .clipShape(RoundedRectangle(cornerRadius: isSelected ? 16 : 24, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: isSelected ? 16 : 24, style: .continuous)
                .stroke(isSelected ? Color.white.opacity(0.6) : Color.clear, lineWidth: 2)
        )
    }

    // MARK: - Channel List
    private var channelList: some View {
        List {
            if store.selectedGuildId == nil {
                Section("Direct Messages") {
                    ForEach(store.sortedDMChannels) { dm in
                        channelRow(dm)
                    }
                }
            } else if let guildId = store.selectedGuildId {
                let all = store.channelsByGuild[guildId] ?? []
                let categories = all.filter { $0.type == .guildCategory }
                let uncategorized = all.filter { $0.type != .guildCategory && $0.parentId == nil }

                if !uncategorized.isEmpty {
                    Section("Channels") {
                        ForEach(uncategorized) { ch in
                            channelRow(ch)
                        }
                    }
                }

                ForEach(categories) { category in
                    let children = all.filter { $0.parentId == category.id && $0.type != .guildCategory }
                    if !children.isEmpty {
                        Section(category.displayName.uppercased()) {
                            ForEach(children) { ch in
                                channelRow(ch)
                            }
                        }
                    }
                }
            }
        }
        .listStyle(.sidebar)
        .scrollContentBackground(.hidden)
    }

    @ViewBuilder
    private func channelRow(_ channel: DiscordChannel) -> some View {
        let isSelected = store.selectedChannelId == channel.id
        let unread = store.isUnread(channel: channel)

        Button {
            if channel.isVoiceLike {
                store.joinVoiceChannel(channel)
            } else {
                Task { await store.selectChannel(channel.id) }
            }
        } label: {
            HStack(spacing: 10) {
                if channel.type == .dm, let recipient = channel.recipients?.first {
                    AvatarView(url: recipient.avatarURL, status: store.presences[recipient.id], size: 28)
                } else {
                    Image(systemName: iconName(for: channel.type))
                        .font(.subheadline)
                        .foregroundStyle(isSelected ? .indigo : .secondary)
                        .frame(width: 22)
                }

                VStack(alignment: .leading, spacing: 2) {
                    Text(channel.displayName)
                        .font(unread ? .subheadline.weight(.bold) : .subheadline)
                        .foregroundStyle(isSelected ? .primary : (unread ? .primary : .secondary))
                        .lineLimit(1)

                    if channel.isVoiceLike,
                       let voiceUsers = store.voiceStatesByChannel[channel.id],
                       !voiceUsers.isEmpty {
                        Text("\(voiceUsers.count) in voice")
                            .font(.caption2)
                            .foregroundStyle(.green)
                    }
                }

                Spacer()

                if unread {
                    Circle()
                        .fill(.indigo)
                        .frame(width: 7, height: 7)
                }
            }
            .padding(.vertical, 4)
        }
        .listRowBackground(
            isSelected
                ? RoundedRectangle(cornerRadius: 12, style: .continuous).fill(.indigo.opacity(0.18))
                : RoundedRectangle(cornerRadius: 12, style: .continuous).fill(.clear)
        )
    }

    private func iconName(for type: ChannelType) -> String {
        switch type {
        case .guildVoice, .guildStageVoice: return "speaker.wave.2.fill"
        case .guildAnnouncement: return "megaphone.fill"
        case .guildForum: return "bubble.left.and.text.bubble.right.fill"
        case .groupDM: return "person.2.fill"
        default: return "number"
        }
    }
}
