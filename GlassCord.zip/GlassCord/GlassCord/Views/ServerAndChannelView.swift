import SwiftUI

struct ServerAndChannelView: View {
    @Environment(DiscordStore.self) private var store
    @State private var expandedFolderIds: Set<String> = []
    @Namespace private var railNS

    var body: some View {
        HStack(spacing: 0) {
            guildRail
                .frame(width: 72)

            Divider()

            channelList
        }
        .navigationTitle(store.activeGuild?.name ?? (store.iMessageModeEnabled ? "Messages" : "Direct Messages"))
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: - Guild Rail (Exact Discord Order + Collapsible Folders)
    private var guildRail: some View {
        let guildMap = Dictionary(uniqueKeysWithValues: store.guilds.map { ($0.id, $0) })
        let folderedIds = Set(store.guildFolders.flatMap(\.guildIds))
        let unfolderedGuilds = store.guilds.filter { !folderedIds.contains($0.id) }

        return ScrollView(.vertical, showsIndicators: false) {
            GlassEffectContainer(spacing: 10) {
                VStack(spacing: 10) {
                    Button {
                        Task { await store.selectGuild(nil) }
                    } label: {
                        Image(systemName: store.iMessageModeEnabled ? "message.fill" : "bubble.left.and.bubble.right.fill")
                            .font(.title3)
                            .foregroundStyle(store.selectedGuildId == nil ? .white : .primary)
                            .frame(width: 48, height: 48)
                            .background(store.selectedGuildId == nil ? (store.iMessageModeEnabled ? Color.blue : Color.indigo) : Color.clear, in: Circle())
                    }
                    .glassEffect(.regular.interactive(), in: .circle)
                    .glassEffectID("home-dm", in: railNS)

                    Divider()
                        .padding(.horizontal, 14)

                    ForEach(store.guildFolders, id: \.stableId) { folder in
                        let folderGuilds = folder.guildIds.compactMap { guildMap[$0] }
                        if folderGuilds.count == 1 && folder.id == nil {
                            let guild = folderGuilds[0]
                            guildRailButton(guild)
                        } else if !folderGuilds.isEmpty {
                            folderView(folder: folder, guilds: folderGuilds)
                        }
                    }

                    ForEach(unfolderedGuilds) { guild in
                        guildRailButton(guild)
                    }
                }
                .padding(.vertical, 12)
            }
        }
    }

    @ViewBuilder
    private func folderView(folder: DiscordGuildFolder, guilds: [DiscordGuild]) -> some View {
        let fid = folder.stableId
        let isExpanded = expandedFolderIds.contains(fid)
        let folderColor: Color = folder.color.map { Color(rgbInt: $0) } ?? .indigo

        VStack(spacing: 8) {
            Button {
                withAnimation(.spring(duration: 0.28)) {
                    if isExpanded {
                        expandedFolderIds.remove(fid)
                    } else {
                        expandedFolderIds.insert(fid)
                    }
                }
            } label: {
                if isExpanded {
                    Image(systemName: "folder.fill")
                        .font(.title3)
                        .foregroundStyle(folderColor)
                        .frame(width: 48, height: 48)
                } else {
                    LazyVGrid(columns: [GridItem(.fixed(18), spacing: 4), GridItem(.fixed(18), spacing: 4)], spacing: 4) {
                        ForEach(guilds.prefix(4)) { g in
                            Group {
                                if let url = g.iconURL {
                                    CachedAsyncImage(url: url) { img in
                                        img.resizable().scaledToFill()
                                    } placeholder: {
                                        Color.secondary.opacity(0.3)
                                    }
                                } else {
                                    Text(String(g.initials.prefix(1)))
                                        .font(.system(size: 9, weight: .bold))
                                }
                            }
                            .frame(width: 18, height: 18)
                            .clipShape(Circle())
                        }
                    }
                    .frame(width: 48, height: 48)
                    .background(folderColor.opacity(0.22), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
            }
            .glassEffect(.regular.interactive(), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .glassEffectID(fid, in: railNS)

            if isExpanded {
                ForEach(guilds) { guild in
                    guildRailButton(guild)
                }
            }
        }
        .padding(.vertical, isExpanded ? 6 : 0)
        .background(
            isExpanded
                ? RoundedRectangle(cornerRadius: 20, style: .continuous).fill(folderColor.opacity(0.14))
                : RoundedRectangle(cornerRadius: 20, style: .continuous).fill(.clear)
        )
    }

    private func guildRailButton(_ guild: DiscordGuild) -> some View {
        let isSelected = store.selectedGuildId == guild.id
        return Button {
            Task { await store.selectGuild(guild.id) }
        } label: {
            guildIcon(guild: guild, isSelected: isSelected)
        }
        .glassEffect(.regular.interactive(), in: RoundedRectangle(cornerRadius: isSelected ? 16 : 24, style: .continuous))
        .glassEffectID("guild-\(guild.id)", in: railNS)
    }

    @ViewBuilder
    private func guildIcon(guild: DiscordGuild, isSelected: Bool) -> some View {
        Group {
            if let url = guild.iconURL {
                CachedAsyncImage(url: url) { img in
                    img.resizable().scaledToFill()
                } placeholder: {
                    Text(guild.initials)
                        .font(.subheadline.weight(.bold))
                }
            } else {
                Text(guild.initials)
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(isSelected ? .white : .primary)
            }
        }
        .frame(width: 48, height: 48)
        .background(isSelected ? Color.indigo.opacity(0.85) : Color.secondary.opacity(0.18))
        .clipShape(RoundedRectangle(cornerRadius: isSelected ? 16 : 24, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: isSelected ? 16 : 24, style: .continuous)
                .stroke(isSelected ? Color.white.opacity(0.6) : Color.clear, lineWidth: 2)
        )
    }

    // MARK: - Channel List
    private var channelList: some View {
        @Bindable var bindableStore = store
        return List(selection: $bindableStore.selectedChannelId) {
            if store.selectedGuildId == nil {
                Section(store.iMessageModeEnabled ? "Messages" : "Direct Messages") {
                    if store.sortedDMChannels.isEmpty {
                        Text("Loading DMs...")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(store.sortedDMChannels) { dm in
                            channelRow(dm)
                        }
                    }
                }
            } else if let guildId = store.selectedGuildId {
                let rawAll = store.channelsByGuild[guildId] ?? []
                let all = store.activeGuild.map { g in rawAll.filter { $0.type == .guildCategory || store.canViewChannel($0, in: g) } } ?? rawAll
                let categories = all.filter { $0.type == .guildCategory }
                let uncategorized = all.filter { $0.type != .guildCategory && $0.parentId == nil }

                if all.isEmpty {
                    Text("Loading channels...")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                if !uncategorized.isEmpty {
                    Section("Channels") {
                        ForEach(uncategorized) { ch in
                            channelRow(ch)
                        }
                    }
                }

                ForEach(categories) { category in
                    let children = all.filter { $0.parentId == category.id && $0.type != .guildCategory }
                    if !children.isEmpty {
                        Section(category.displayName.uppercased()) {
                            ForEach(children) { ch in
                                channelRow(ch)
                            }
                        }
                    }
                }
            }
        }
        .listStyle(.sidebar)
        .scrollContentBackground(.hidden)
        .onChange(of: store.selectedChannelId) { _, newId in
            guard let newId else { return }
            Task { await store.selectChannel(newId) }
        }
    }

    @ViewBuilder
    private func channelRow(_ channel: DiscordChannel) -> some View {
        let isSelected = store.selectedChannelId == channel.id
        let unread = store.isUnread(channel: channel)

        if channel.isVoiceLike {
            Button {
                store.joinVoiceChannel(channel)
            } label: {
                channelRowLabel(channel: channel, isSelected: isSelected, unread: unread)
            }
        } else {
            NavigationLink(value: channel.id) {
                channelRowLabel(channel: channel, isSelected: isSelected, unread: unread)
            }
            .tag(channel.id)
        }
    }

    private func channelRowLabel(channel: DiscordChannel, isSelected: Bool, unread: Bool) -> some View {
        let resolvedDMRecipients = store.resolvedRecipients(for: channel)
        let resolvedName = store.resolvedChannelName(channel)

        return HStack(spacing: 10) {
            if store.iMessageModeEnabled && unread {
                Circle()
                    .fill(Color.blue)
                    .frame(width: 8, height: 8)
            }

            if channel.type == .dm, let recipient = resolvedDMRecipients.first {
                AvatarView(
                    url: recipient.avatarURL,
                    decorationURL: recipient.avatarDecorationData?.imageURL,
                    status: store.presences[recipient.id],
                    isMobile: store.clientStatuses[recipient.id]?.isMobileOnlyOrActive ?? false,
                    size: store.iMessageModeEnabled ? 38 : 30
                )
            } else if channel.type == .groupDM {
                if let iconURL = channel.iconURL {
                    AvatarView(url: iconURL, size: store.iMessageModeEnabled ? 38 : 30)
                } else {
                    Image(systemName: "person.2.circle.fill")
                        .font(.title2)
                        .foregroundStyle(.indigo)
                        .frame(width: store.iMessageModeEnabled ? 38 : 30)
                }
            } else {
                Image(systemName: iconName(for: channel.type))
                    .font(.subheadline)
                    .foregroundStyle(isSelected ? .indigo : .secondary)
                    .frame(width: 22)
            }

            VStack(alignment: .leading, spacing: 2) {
                Text(resolvedName)
                    .font(unread ? .subheadline.weight(.bold) : .subheadline)
                    .foregroundStyle(isSelected ? .primary : (unread ? .primary : .secondary))
                    .lineLimit(1)

                if store.iMessageModeEnabled, let lastMsg = store.messagesByChannel[channel.id]?.last {
                    Text(lastMsg.content.isEmpty ? "Attachment" : lastMsg.content)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                } else if channel.isVoiceLike,
                          let voiceUsers = store.voiceStatesByChannel[channel.id],
                          !voiceUsers.isEmpty {
                    Text("\(voiceUsers.count) in voice")
                        .font(.caption2)
                        .foregroundStyle(.green)
                }
            }

            Spacer()

            if unread && !store.iMessageModeEnabled {
                Circle()
                    .fill(.indigo)
                    .frame(width: 7, height: 7)
            }
        }
        .padding(.vertical, 4)
    }

    private func iconName(for type: ChannelType) -> String {
        switch type {
        case .guildVoice, .guildStageVoice: return "speaker.wave.2.fill"
        case .guildAnnouncement: return "megaphone.fill"
        case .guildForum: return "bubble.left.and.text.bubble.right.fill"
        case .groupDM: return "person.2.fill"
        default: return "number"
        }
    }
}

private extension Color {
    init(rgbInt: Int) {
        let r = Double((rgbInt >> 16) & 0xFF) / 255.0
        let g = Double((rgbInt >> 8) & 0xFF) / 255.0
        let b = Double(rgbInt & 0xFF) / 255.0
        self.init(red: r, green: g, blue: b)
    }
}
