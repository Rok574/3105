import SwiftUI

struct ServerAndChannelView: View {
    @Environment(DiscordStore.self) private var store
    @Namespace private var railNS

    var body: some View {
        HStack(spacing: 0) {
            guildRail
                .frame(width: 72)

            Divider()

            channelList
        }
        .navigationTitle(store.activeGuild?.name ?? (store.iMessageModeEnabled ? "Messages" : "Direct Messages"))
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: - Guild Rail
    private var guildRail: some View {
        ScrollView(.vertical, showsIndicators: false) {
            GlassEffectContainer(spacing: 12) {
                VStack(spacing: 12) {
                    Button {
                        Task { await store.selectGuild(nil) }
                    } label: {
                        Image(systemName: store.iMessageModeEnabled ? "message.fill" : "bubble.left.and.bubble.right.fill")
                            .font(.title3)
                            .foregroundStyle(store.selectedGuildId == nil ? .white : .primary)
                            .frame(width: 48, height: 48)
                            .background(store.selectedGuildId == nil ? (store.iMessageModeEnabled ? Color.blue : Color.indigo) : Color.clear, in: Circle())
                    }
                    .glassEffect(.regular.interactive(), in: .circle)
                    .glassEffectID("home-dm", in: railNS)

                    Divider()
                        .padding(.horizontal, 14)

                    ForEach(store.guilds) { guild in
                        let isSelected = store.selectedGuildId == guild.id
                        Button {
                            Task { await store.selectGuild(guild.id) }
                        } label: {
                            guildIcon(guild: guild, isSelected: isSelected)
                        }
                        .glassEffect(.regular.interactive(), in: RoundedRectangle(cornerRadius: isSelected ? 16 : 24, style: .continuous))
                        .glassEffectID("guild-\(guild.id)", in: railNS)
                    }
                }
                .padding(.vertical, 12)
            }
        }
    }

    @ViewBuilder
    private func guildIcon(guild: DiscordGuild, isSelected: Bool) -> some View {
        Group {
            if let url = guild.iconURL {
                CachedAsyncImage(url: url) { img in
                    img.resizable().scaledToFill()
                } placeholder: {
                    Text(guild.initials)
                        .font(.subheadline.weight(.bold))
                }
            } else {
                Text(guild.initials)
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(isSelected ? .white : .primary)
            }
        }
        .frame(width: 48, height: 48)
        .background(isSelected ? Color.indigo.opacity(0.85) : Color.secondary.opacity(0.18))
        .clipShape(RoundedRectangle(cornerRadius: isSelected ? 16 : 24, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: isSelected ? 16 : 24, style: .continuous)
                .stroke(isSelected ? Color.white.opacity(0.6) : Color.clear, lineWidth: 2)
        )
    }

    // MARK: - Channel List
    private var channelList: some View {
        @Bindable var bindableStore = store
        return List(selection: $bindableStore.selectedChannelId) {
            if store.selectedGuildId == nil {
                Section(store.iMessageModeEnabled ? "Messages" : "Direct Messages") {
                    if store.sortedDMChannels.isEmpty {
                        Text("Loading DMs...")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(store.sortedDMChannels) { dm in
                            channelRow(dm)
                        }
                    }
                }
            } else if let guildId = store.selectedGuildId {
                let all = store.channelsByGuild[guildId] ?? []
                let categories = all.filter { $0.type == .guildCategory }
                let uncategorized = all.filter { $0.type != .guildCategory && $0.parentId == nil }

                if all.isEmpty {
                    Text("Loading channels...")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                if !uncategorized.isEmpty {
                    Section("Channels") {
                        ForEach(uncategorized) { ch in
                            channelRow(ch)
                        }
                    }
                }

                ForEach(categories) { category in
                    let children = all.filter { $0.parentId == category.id && $0.type != .guildCategory }
                    if !children.isEmpty {
                        Section(category.displayName.uppercased()) {
                            ForEach(children) { ch in
                                channelRow(ch)
                            }
                        }
                    }
                }
            }
        }
        .listStyle(.sidebar)
        .scrollContentBackground(.hidden)
        .onChange(of: store.selectedChannelId) { _, newId in
            guard let newId else { return }
            Task { await store.selectChannel(newId) }
        }
    }

    @ViewBuilder
    private func channelRow(_ channel: DiscordChannel) -> some View {
        let isSelected = store.selectedChannelId == channel.id
        let unread = store.isUnread(channel: channel)

        if channel.isVoiceLike {
            Button {
                store.joinVoiceChannel(channel)
            } label: {
                channelRowLabel(channel: channel, isSelected: isSelected, unread: unread)
            }
        } else {
            NavigationLink(value: channel.id) {
                channelRowLabel(channel: channel, isSelected: isSelected, unread: unread)
            }
            .tag(channel.id)
        }
    }

    private func channelRowLabel(channel: DiscordChannel, isSelected: Bool, unread: Bool) -> some View {
        HStack(spacing: 10) {
            if store.iMessageModeEnabled && unread {
                Circle()
                    .fill(Color.blue)
                    .frame(width: 8, height: 8)
            }

            if channel.type == .dm, let recipient = channel.recipients?.first {
                AvatarView(
                    url: recipient.avatarURL,
                    decorationURL: recipient.avatarDecorationData?.imageURL,
                    status: store.presences[recipient.id],
                    size: store.iMessageModeEnabled ? 38 : 28
                )
            } else {
                Image(systemName: iconName(for: channel.type))
                    .font(.subheadline)
                    .foregroundStyle(isSelected ? .indigo : .secondary)
                    .frame(width: 22)
            }

            VStack(alignment: .leading, spacing: 2) {
                Text(channel.displayName)
                    .font(unread ? .subheadline.weight(.bold) : .subheadline)
                    .foregroundStyle(isSelected ? .primary : (unread ? .primary : .secondary))
                    .lineLimit(1)

                if store.iMessageModeEnabled, let lastMsg = store.messagesByChannel[channel.id]?.last {
                    Text(lastMsg.content.isEmpty ? "Attachment" : lastMsg.content)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                } else if channel.isVoiceLike,
                          let voiceUsers = store.voiceStatesByChannel[channel.id],
                          !voiceUsers.isEmpty {
                    Text("\(voiceUsers.count) in voice")
                        .font(.caption2)
                        .foregroundStyle(.green)
                }
            }

            Spacer()

            if unread && !store.iMessageModeEnabled {
                Circle()
                    .fill(.indigo)
                    .frame(width: 7, height: 7)
            }
        }
        .padding(.vertical, 4)
    }

    private func iconName(for type: ChannelType) -> String {
        switch type {
        case .guildVoice, .guildStageVoice: return "speaker.wave.2.fill"
        case .guildAnnouncement: return "megaphone.fill"
        case .guildForum: return "bubble.left.and.text.bubble.right.fill"
        case .groupDM: return "person.2.fill"
        default: return "number"
        }
    }
}
