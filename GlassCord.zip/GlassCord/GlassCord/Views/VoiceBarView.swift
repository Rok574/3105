import SwiftUI

struct VoiceBarView: View {
    @Environment(DiscordStore.self) private var store
    @State private var showParticipantsSheet = false
    @Namespace private var voiceNS

    var body: some View {
        let chId = store.connectedVoiceChannelId ?? ""
        let participants = store.voiceStatesByChannel[chId] ?? []

        GlassEffectContainer(spacing: 12) {
            HStack(spacing: 12) {
                Button {
                    showParticipantsSheet = true
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "waveform")
                            .foregroundStyle(store.voiceEngine.isAudioConnected ? .green : .yellow)
                            .symbolEffect(.variableColor.iterative)

                        VStack(alignment: .leading, spacing: 2) {
                            Text(store.voiceEngine.statusText)
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(store.voiceEngine.isAudioConnected ? .green : .yellow)
                            Text("\(participants.count) in call • Tap to view")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                .buttonStyle(.plain)

                Spacer()

                Button {
                    store.toggleMute()
                } label: {
                    Image(systemName: store.selfMute ? "mic.slash.fill" : "mic.fill")
                        .foregroundStyle(store.selfMute ? .red : .primary)
                        .frame(width: 36, height: 36)
                }
                .glassEffect(.regular.interactive(), in: .circle)
                .glassEffectID("mute", in: voiceNS)

                Button {
                    store.toggleDeafen()
                } label: {
                    Image(systemName: store.selfDeaf ? "speaker.slash.fill" : "headphones")
                        .foregroundStyle(store.selfDeaf ? .red : .primary)
                        .frame(width: 36, height: 36)
                }
                .glassEffect(.regular.interactive(), in: .circle)
                .glassEffectID("deaf", in: voiceNS)

                Button {
                    store.leaveVoiceChannel()
                } label: {
                    Image(systemName: "phone.down.fill")
                        .foregroundStyle(.white)
                        .frame(width: 36, height: 36)
                        .background(.red, in: Circle())
                }
                .glassEffect(.regular.interactive(), in: .circle)
                .glassEffectID("leave", in: voiceNS)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .glassEffect(.regular, in: .capsule)
        }
        .sheet(isPresented: $showParticipantsSheet) {
            NavigationStack {
                List(participants, id: \.userId) { vs in
                    let user = store.usersById[vs.userId]
                    let isSpeaking = store.voiceEngine.speakingUserIds.contains(vs.userId)
                    HStack(spacing: 12) {
                        AvatarView(url: user?.avatarURL, size: 42)
                            .overlay(
                                Circle()
                                    .stroke(isSpeaking ? Color.green : Color.clear, lineWidth: 3)
                            )
                        VStack(alignment: .leading, spacing: 2) {
                            Text(user?.displayName ?? "User \(vs.userId.suffix(4))")
                                .font(.subheadline.weight(.semibold))
                            Text(isSpeaking ? "Speaking" : "Connected")
                                .font(.caption2)
                                .foregroundStyle(isSpeaking ? .green : .secondary)
                        }
                        Spacer()
                        if vs.selfMute == true || vs.mute == true {
                            Image(systemName: "mic.slash.fill")
                                .foregroundStyle(.red)
                        }
                        if vs.selfDeaf == true || vs.deaf == true {
                            Image(systemName: "speaker.slash.fill")
                                .foregroundStyle(.red)
                        }
                    }
                }
                .navigationTitle("In Voice Call")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Done") { showParticipantsSheet = false }
                    }
                }
            }
            .presentationDetents([.medium])
        }
    }
}
