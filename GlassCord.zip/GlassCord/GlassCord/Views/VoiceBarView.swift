import SwiftUI

struct VoiceBarView: View {
    @Environment(DiscordStore.self) private var store
    @Namespace private var voiceNS

    var body: some View {
        GlassEffectContainer(spacing: 12) {
            HStack(spacing: 12) {
                Image(systemName: "waveform")
                    .foregroundStyle(store.voiceEngine.isAudioConnected ? .green : .yellow)
                    .symbolEffect(.variableColor.iterative)

                VStack(alignment: .leading, spacing: 2) {
                    Text(store.voiceEngine.statusText)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(store.voiceEngine.isAudioConnected ? .green : .yellow)
                    if let chId = store.connectedVoiceChannelId,
                       let gid = store.connectedVoiceGuildId,
                       let ch = store.channelsByGuild[gid]?.first(where: { $0.id == chId }) {
                        Text(ch.displayName)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }

                Spacer()

                Button {
                    store.toggleMute()
                } label: {
                    Image(systemName: store.selfMute ? "mic.slash.fill" : "mic.fill")
                        .foregroundStyle(store.selfMute ? .red : .primary)
                        .frame(width: 36, height: 36)
                }
                .glassEffect(.regular.interactive(), in: .circle)
                .glassEffectID("mute", in: voiceNS)

                Button {
                    store.toggleDeafen()
                } label: {
                    Image(systemName: store.selfDeaf ? "speaker.slash.fill" : "headphones")
                        .foregroundStyle(store.selfDeaf ? .red : .primary)
                        .frame(width: 36, height: 36)
                }
                .glassEffect(.regular.interactive(), in: .circle)
                .glassEffectID("deaf", in: voiceNS)

                Button {
                    store.leaveVoiceChannel()
                } label: {
                    Image(systemName: "phone.down.fill")
                        .foregroundStyle(.white)
                        .frame(width: 36, height: 36)
                        .background(.red, in: Circle())
                }
                .glassEffect(.regular.interactive(), in: .circle)
                .glassEffectID("leave", in: voiceNS)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .glassEffect(.regular, in: .capsule)
        }
    }
}
