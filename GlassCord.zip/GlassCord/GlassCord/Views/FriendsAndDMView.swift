import SwiftUI

struct FriendsAndDMView: View {
    @Environment(DiscordStore.self) private var store
    @State private var filter: FriendFilter = .online
    @State private var showAddFriend = false
    @State private var friendUsername = ""
    @State private var feedbackMessage: String?
    let onOpenChat: () -> Void

    enum FriendFilter: String, CaseIterable {
        case online = "Online"
        case all = "All"
        case pending = "Pending"
        case blocked = "Blocked"
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("Filter", selection: $filter) {
                    ForEach(FriendFilter.allCases, id: \.self) { item in
                        Text(item.rawValue).tag(item)
                    }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal, 16)
                .padding(.vertical, 8)

                List {
                    if filteredRelationships.isEmpty {
                        ContentUnavailableView(
                            "No Friends Here",
                            systemImage: "person.2",
                            description: Text("No \(filter.rawValue.lowercased()) friends found.")
                        )
                        .listRowBackground(Color.clear)
                    } else {
                        ForEach(filteredRelationships) { rel in
                            let user = store.resolvedUser(for: rel)
                            HStack(spacing: 12) {
                                AvatarView(
                                    url: user.avatarURL,
                                    decorationURL: user.avatarDecorationData?.imageURL,
                                    status: store.presences[user.id] ?? .offline,
                                    isMobile: store.clientStatuses[user.id]?.isMobileOnlyOrActive ?? false,
                                    size: 42
                                )
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(rel.nickname ?? user.displayName)
                                        .font(.subheadline.weight(.semibold))
                                    Text("@\(user.username)")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                Spacer()

                                if rel.type == 3 {
                                    Button("Accept") {
                                        Task { try? await store.api.acceptFriendRequest(userId: user.id) }
                                    }
                                    .buttonStyle(.borderedProminent)
                                    .controlSize(.small)
                                } else if rel.type == 1 {
                                    Button {
                                        Task {
                                            await store.openDM(with: user.id)
                                            onOpenChat()
                                        }
                                    } label: {
                                        Image(systemName: "bubble.left.fill")
                                            .padding(8)
                                    }
                                    .glassEffect(.regular.interactive(), in: .circle)
                                }
                            }
                            .swipeActions {
                                Button("Remove", role: .destructive) {
                                    Task { try? await store.api.removeRelationship(userId: user.id) }
                                }
                            }
                        }
                    }
                }
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("Friends")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showAddFriend = true
                    } label: {
                        Image(systemName: "person.badge.plus")
                    }
                }
            }
            .alert("Add Friend", isPresented: $showAddFriend) {
                TextField("Username", text: $friendUsername)
                    .textInputAutocapitalization(.never)
                Button("Send Request") {
                    let name = friendUsername
                    friendUsername = ""
                    Task {
                        do {
                            try await store.api.sendFriendRequest(username: name)
                            feedbackMessage = "Friend request sent to \(name)."
                        } catch {
                            feedbackMessage = error.localizedDescription
                        }
                    }
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("Enter a Discord username to send a friend request.")
            }
            .alert("Friend Request", isPresented: Binding(
                get: { feedbackMessage != nil },
                set: { if !$0 { feedbackMessage = nil } }
            )) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(feedbackMessage ?? "")
            }
        }
    }

    private var filteredRelationships: [DiscordRelationship] {
        switch filter {
        case .online:
            return store.relationships.filter { rel in
                let uid = store.resolvedUser(for: rel).id
                let st = store.presences[uid] ?? .offline
                return rel.type == 1 && st != .offline && st != .invisible
            }
        case .all:
            return store.relationships.filter { $0.type == 1 }
        case .pending:
            return store.relationships.filter { $0.type == 3 || $0.type == 4 }
        case .blocked:
            return store.relationships.filter { $0.type == 2 }
        }
    }
}
