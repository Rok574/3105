import SwiftUI

struct EmojiPickerSheet: View {
    @Environment(DiscordStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var search = ""
    let currentGuildId: String?
    let onSelect: (DiscordEmoji, String) -> Void

    private let columns = [GridItem(.adaptive(minimum: 48, maximum: 56), spacing: 10)]

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 18) {
                    ForEach(filteredGuildEmojis, id: \.guild.id) { entry in
                        VStack(alignment: .leading, spacing: 10) {
                            HStack(spacing: 8) {
                                CachedAsyncImage(url: entry.guild.iconURL) { img in
                                    img.resizable().scaledToFill()
                                } placeholder: {
                                    Text(entry.guild.initials).font(.caption2.bold())
                                }
                                .frame(width: 22, height: 22)
                                .clipShape(Circle())

                                Text(entry.guild.name)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.secondary)
                            }

                            LazyVGrid(columns: columns, spacing: 10) {
                                ForEach(entry.emojis, id: \.apiIdentifier) { emoji in
                                    Button {
                                        let str = store.emojiInsertionString(for: emoji, inGuildId: currentGuildId)
                                        onSelect(emoji, str)
                                        dismiss()
                                    } label: {
                                        CachedAsyncImage(url: emoji.imageURL) { img in
                                            img.resizable().scaledToFit()
                                        } placeholder: {
                                            ProgressView().controlSize(.mini)
                                        }
                                        .frame(width: 34, height: 34)
                                        .padding(6)
                                        .glassEffect(.regular.interactive(), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Server Emojis")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $search, prompt: "Search custom emojis")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
        }
    }

    private var filteredGuildEmojis: [(guild: DiscordGuild, emojis: [DiscordEmoji])] {
        let q = search.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return store.allCustomEmojisByGuild.compactMap { entry in
            let matches = q.isEmpty
                ? entry.emojis
                : entry.emojis.filter { ($0.name ?? "").lowercased().contains(q) }
            return matches.isEmpty ? nil : (entry.guild, matches)
        }
    }
}
