import SwiftUI

enum NitroNameFont: String, CaseIterable, Identifiable {
    case standard = "Standard"
    case serif = "Medieval / Serif"
    case rounded = "Bubble / Rounded"
    case mono = "Retro / Mono"

    var id: String { rawValue }

    var fontDesign: Font.Design {
        switch self {
        case .standard: return .default
        case .serif: return .serif
        case .rounded: return .rounded
        case .mono: return .monospaced
        }
    }
}

enum NitroNameEffect: String, CaseIterable, Identifiable {
    case none = "None"
    case sakura = "Sakura Glow"
    case neon = "Cyber Neon"
    case aurora = "Aurora"
    case sunset = "Sunset"
    case gold = "Royal Gold"

    var id: String { rawValue }

    var gradientColors: [Color] {
        switch self {
        case .none: return [.primary]
        case .sakura: return [Color(red: 1.0, green: 0.65, blue: 0.85), Color(red: 0.88, green: 0.48, blue: 0.96)]
        case .neon: return [.cyan, .indigo, .purple]
        case .aurora: return [.mint, .teal, .blue]
        case .sunset: return [.orange, .pink, .purple]
        case .gold: return [.yellow, .orange]
        }
    }
}

enum ProfileEffectStyle: String, CaseIterable, Identifiable {
    case none = "None"
    case sparkles = "Stardust Sparkles"
    case sakura = "Sakura Breeze"
    case aurora = "Aurora Shimmer"
    case cyber = "Cyber Pulse"

    var id: String { rawValue }
}

struct StyledDisplayNameView: View {
    let name: String
    var fontStyle: NitroNameFont = .standard
    var effect: NitroNameEffect = .none
    var size: CGFloat = 22

    var body: some View {
        let text = Text(name)
            .font(.system(size: size, weight: .bold, design: fontStyle.fontDesign))

        if effect == .none {
            text
        } else {
            text
                .foregroundStyle(
                    LinearGradient(
                        colors: effect.gradientColors,
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .shadow(color: effect.gradientColors.first?.opacity(0.55) ?? .clear, radius: 6, x: 0, y: 0)
        }
    }
}

struct ProfileEffectOverlay: View {
    let style: ProfileEffectStyle
    @State private var animate = false

    var body: some View {
        if style != .none {
            ZStack {
                switch style {
                case .none:
                    EmptyView()
                case .sparkles:
                    ForEach(0..<10, id: \.self) { i in
                        Image(systemName: "sparkle")
                            .font(.system(size: CGFloat(8 + (i % 4) * 3)))
                            .foregroundStyle(.white.opacity(animate ? 0.85 : 0.25))
                            .position(
                                x: CGFloat(30 + (i * 37) % 320),
                                y: CGFloat(25 + (i * 23) % 120)
                            )
                    }
                case .sakura:
                    ForEach(0..<8, id: \.self) { i in
                        Image(systemName: "leaf.fill")
                            .font(.system(size: 11))
                            .foregroundStyle(Color.pink.opacity(0.65))
                            .rotationEffect(.degrees(animate ? 35 : -20))
                            .position(
                                x: CGFloat(25 + (i * 45) % 330),
                                y: animate ? CGFloat(130 + (i % 3) * 15) : CGFloat(15 + (i % 3) * 20)
                            )
                    }
                case .aurora:
                    LinearGradient(
                        colors: [.mint.opacity(0.28), .indigo.opacity(0.22), .purple.opacity(0.26)],
                        startPoint: animate ? .topLeading : .bottomTrailing,
                        endPoint: animate ? .bottomTrailing : .topLeading
                    )
                case .cyber:
                    LinearGradient(
                        colors: [.cyan.opacity(0.25), .clear, .purple.opacity(0.28)],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                }
            }
            .allowsHitTesting(false)
            .onAppear {
                withAnimation(.easeInOut(duration: 3.2).repeatForever(autoreverses: true)) {
                    animate = true
                }
            }
        }
    }
}

struct GlassBackgroundBackdrop: View {
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        MeshGradient(
            width: 3,
            height: 3,
            points: [
                [0.0, 0.0], [0.5, 0.0], [1.0, 0.0],
                [0.0, 0.5], [0.5, 0.5], [1.0, 0.5],
                [0.0, 1.0], [0.5, 1.0], [1.0, 1.0]
            ],
            colors: scheme == .dark
                ? [
                    Color(red: 0.06, green: 0.07, blue: 0.14), Color(red: 0.11, green: 0.09, blue: 0.22), Color(red: 0.05, green: 0.11, blue: 0.18),
                    Color(red: 0.09, green: 0.07, blue: 0.18), Color(red: 0.15, green: 0.11, blue: 0.28), Color(red: 0.07, green: 0.13, blue: 0.22),
                    Color(red: 0.04, green: 0.05, blue: 0.10), Color(red: 0.08, green: 0.07, blue: 0.16), Color(red: 0.05, green: 0.09, blue: 0.14)
                ]
                : [
                    Color(red: 0.89, green: 0.92, blue: 0.99), Color(red: 0.93, green: 0.90, blue: 0.99), Color(red: 0.87, green: 0.95, blue: 0.98),
                    Color(red: 0.91, green: 0.91, blue: 0.98), Color(red: 0.96, green: 0.93, blue: 0.99), Color(red: 0.88, green: 0.95, blue: 0.97),
                    Color(red: 0.86, green: 0.90, blue: 0.97), Color(red: 0.92, green: 0.90, blue: 0.97), Color(red: 0.87, green: 0.93, blue: 0.96)
                ]
        )
    }
}

struct AvatarView: View {
    let url: URL?
    var decorationURL: URL? = nil
    var status: PresenceStatus? = nil
    var size: CGFloat = 40

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            ZStack {
                CachedAsyncImage(url: url) { img in
                    img.resizable().scaledToFill()
                } placeholder: {
                    Circle()
                        .fill(.indigo.opacity(0.22))
                        .overlay {
                            Image(systemName: "person.fill")
                                .font(.system(size: size * 0.42))
                                .foregroundStyle(.indigo)
                        }
                }
                .frame(width: size, height: size)
                .clipShape(Circle())

                if let decorationURL {
                    CachedAsyncImage(url: decorationURL) { img in
                        img.resizable().scaledToFit()
                    } placeholder: {
                        EmptyView()
                    }
                    .frame(width: size * 1.22, height: size * 1.22)
                    .allowsHitTesting(false)
                }
            }

            if let status, status != .offline, status != .invisible {
                Circle()
                    .fill(statusColor(status))
                    .frame(width: max(10, size * 0.28), height: max(10, size * 0.28))
                    .overlay(Circle().stroke(.background, lineWidth: 2))
            }
        }
    }

    private func statusColor(_ status: PresenceStatus) -> Color {
        switch status {
        case .online: return .green
        case .idle: return .yellow
        case .dnd: return .red
        case .invisible, .offline: return .gray
        }
    }
}

struct DiscordMarkdownText: View {
    let content: String

    private var customEmojiURLs: [URL] {
        var urls: [URL] = []
        let tagPattern = #"<(a?):[a-zA-Z0-9_]+:(\d+)>"#
        if let regex = try? NSRegularExpression(pattern: tagPattern) {
            let range = NSRange(content.startIndex..., in: content)
            for match in regex.matches(in: content, range: range) {
                if let animRange = Range(match.range(at: 1), in: content),
                   let idRange = Range(match.range(at: 2), in: content) {
                    let ext = content[animRange] == "a" ? "gif" : "png"
                    if let url = URL(string: "https://cdn.discordapp.com/emojis/\(content[idRange]).\(ext)?size=64") {
                        urls.append(url)
                    }
                }
            }
        }
        let cdnPattern = #"https://cdn\.discordapp\.com/emojis/\d+\.(?:png|gif|webp)(?:\?[^\s]*)?"#
        if let regex = try? NSRegularExpression(pattern: cdnPattern) {
            let range = NSRange(content.startIndex..., in: content)
            for match in regex.matches(in: content, range: range) {
                if let r = Range(match.range, in: content), let url = URL(string: String(content[r])) {
                    urls.append(url)
                }
            }
        }
        return urls
    }

    private var cleanedText: String {
        var text = content
        text = text.replacingOccurrences(of: #"<a?:[a-zA-Z0-9_]+:\d+>"#, with: "", options: .regularExpression)
        text = text.replacingOccurrences(of: #"https://cdn\.discordapp\.com/emojis/\d+\.(?:png|gif|webp)(?:\?[^\s]*)?"#, with: "", options: .regularExpression)
        return text.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            if !cleanedText.isEmpty {
                Text(attributedContent(cleanedText))
                    .textSelection(.enabled)
            }
            if !customEmojiURLs.isEmpty {
                let emojiSize: CGFloat = cleanedText.isEmpty ? 42 : 26
                HStack(spacing: 6) {
                    ForEach(Array(customEmojiURLs.prefix(8).enumerated()), id: \.offset) { _, url in
                        CachedAsyncImage(url: url) { img in
                            img.resizable().scaledToFit()
                        } placeholder: {
                            Color.clear
                        }
                        .frame(width: emojiSize, height: emojiSize)
                    }
                }
            }
        }
    }

    private func attributedContent(_ raw: String) -> AttributedString {
        let options = AttributedString.MarkdownParsingOptions(
            interpretedSyntax: .inlineOnlyPreservingWhitespace
        )
        return (try? AttributedString(markdown: raw, options: options)) ?? AttributedString(raw)
    }
}
