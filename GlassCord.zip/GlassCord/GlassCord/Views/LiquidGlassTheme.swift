import SwiftUI

struct GlassBackgroundBackdrop: View {
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        MeshGradient(
            width: 3,
            height: 3,
            points: [
                [0.0, 0.0], [0.5, 0.0], [1.0, 0.0],
                [0.0, 0.5], [0.5, 0.5], [1.0, 0.5],
                [0.0, 1.0], [0.5, 1.0], [1.0, 1.0]
            ],
            colors: scheme == .dark
                ? [
                    Color(red: 0.06, green: 0.07, blue: 0.14), Color(red: 0.11, green: 0.09, blue: 0.22), Color(red: 0.05, green: 0.11, blue: 0.18),
                    Color(red: 0.09, green: 0.07, blue: 0.18), Color(red: 0.15, green: 0.11, blue: 0.28), Color(red: 0.07, green: 0.13, blue: 0.22),
                    Color(red: 0.04, green: 0.05, blue: 0.10), Color(red: 0.08, green: 0.07, blue: 0.16), Color(red: 0.05, green: 0.09, blue: 0.14)
                ]
                : [
                    Color(red: 0.89, green: 0.92, blue: 0.99), Color(red: 0.93, green: 0.90, blue: 0.99), Color(red: 0.87, green: 0.95, blue: 0.98),
                    Color(red: 0.91, green: 0.91, blue: 0.98), Color(red: 0.96, green: 0.93, blue: 0.99), Color(red: 0.88, green: 0.95, blue: 0.97),
                    Color(red: 0.86, green: 0.90, blue: 0.97), Color(red: 0.92, green: 0.90, blue: 0.97), Color(red: 0.87, green: 0.93, blue: 0.96)
                ]
        )
    }
}

struct AvatarView: View {
    let url: URL?
    var status: PresenceStatus? = nil
    var size: CGFloat = 40

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            CachedAsyncImage(url: url) { img in
                img.resizable().scaledToFill()
            } placeholder: {
                Circle()
                    .fill(.indigo.opacity(0.22))
                    .overlay {
                        Image(systemName: "person.fill")
                            .font(.system(size: size * 0.42))
                            .foregroundStyle(.indigo)
                    }
            }
            .frame(width: size, height: size)
            .clipShape(Circle())

            if let status, status != .offline, status != .invisible {
                Circle()
                    .fill(statusColor(status))
                    .frame(width: max(10, size * 0.28), height: max(10, size * 0.28))
                    .overlay(Circle().stroke(.background, lineWidth: 2))
            }
        }
    }

    private func statusColor(_ status: PresenceStatus) -> Color {
        switch status {
        case .online: return .green
        case .idle: return .yellow
        case .dnd: return .red
        case .invisible, .offline: return .gray
        }
    }
}

struct DiscordMarkdownText: View {
    let content: String

    private var customEmojiURLs: [URL] {
        var urls: [URL] = []
        // Match <:name:id> or <a:name:id>
        let tagPattern = #"<(a?):[a-zA-Z0-9_]+:(\d+)>"#
        if let regex = try? NSRegularExpression(pattern: tagPattern) {
            let range = NSRange(content.startIndex..., in: content)
            for match in regex.matches(in: content, range: range) {
                if let animRange = Range(match.range(at: 1), in: content),
                   let idRange = Range(match.range(at: 2), in: content) {
                    let ext = content[animRange] == "a" ? "gif" : "png"
                    if let url = URL(string: "https://cdn.discordapp.com/emojis/\(content[idRange]).\(ext)?size=64") {
                        urls.append(url)
                    }
                }
            }
        }
        // Match Fake Nitro CDN emoji URLs
        let cdnPattern = #"https://cdn\.discordapp\.com/emojis/\d+\.(?:png|gif|webp)(?:\?[^\s]*)?"#
        if let regex = try? NSRegularExpression(pattern: cdnPattern) {
            let range = NSRange(content.startIndex..., in: content)
            for match in regex.matches(in: content, range: range) {
                if let r = Range(match.range, in: content), let url = URL(string: String(content[r])) {
                    urls.append(url)
                }
            }
        }
        return urls
    }

    private var cleanedText: String {
        var text = content
        text = text.replacingOccurrences(of: #"<a?:[a-zA-Z0-9_]+:\d+>"#, with: "", options: .regularExpression)
        text = text.replacingOccurrences(of: #"https://cdn\.discordapp\.com/emojis/\d+\.(?:png|gif|webp)(?:\?[^\s]*)?"#, with: "", options: .regularExpression)
        return text.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            if !cleanedText.isEmpty {
                Text(attributedContent(cleanedText))
                    .textSelection(.enabled)
            }
            if !customEmojiURLs.isEmpty {
                let emojiSize: CGFloat = cleanedText.isEmpty ? 42 : 26
                HStack(spacing: 6) {
                    ForEach(Array(customEmojiURLs.prefix(8).enumerated()), id: \.offset) { _, url in
                        CachedAsyncImage(url: url) { img in
                            img.resizable().scaledToFit()
                        } placeholder: {
                            Color.clear
                        }
                        .frame(width: emojiSize, height: emojiSize)
                    }
                }
            }
        }
    }

    private func attributedContent(_ raw: String) -> AttributedString {
        let options = AttributedString.MarkdownParsingOptions(
            interpretedSyntax: .inlineOnlyPreservingWhitespace
        )
        return (try? AttributedString(markdown: raw, options: options)) ?? AttributedString(raw)
    }
}
