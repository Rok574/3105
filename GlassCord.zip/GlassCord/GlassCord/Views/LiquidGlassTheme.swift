import SwiftUI
import AVKit
import ImageIO

enum NitroNameFont: String, CaseIterable, Identifiable {
    case standard = "Standard"
    case serif = "Medieval / Serif"
    case rounded = "Bubble / Rounded"
    case mono = "Retro / Mono"

    var id: String { rawValue }

    var fontDesign: Font.Design {
        switch self {
        case .standard: return .default
        case .serif: return .serif
        case .rounded: return .rounded
        case .mono: return .monospaced
        }
    }
}

enum NitroNameEffect: String, CaseIterable, Identifiable {
    case none = "None"
    case sakura = "Sakura Glow"
    case neon = "Cyber Neon"
    case aurora = "Aurora"
    case sunset = "Sunset"
    case gold = "Royal Gold"

    var id: String { rawValue }

    var gradientColors: [Color] {
        switch self {
        case .none: return [.primary]
        case .sakura: return [Color(red: 1.0, green: 0.65, blue: 0.85), Color(red: 0.88, green: 0.48, blue: 0.96)]
        case .neon: return [.cyan, .indigo, .purple]
        case .aurora: return [.mint, .teal, .blue]
        case .sunset: return [.orange, .pink, .purple]
        case .gold: return [.yellow, .orange]
        }
    }
}

enum ProfileEffectStyle: String, CaseIterable, Identifiable {
    case none = "None"
    case sparkles = "Stardust Sparkles"
    case sakura = "Sakura Breeze"
    case aurora = "Aurora Shimmer"
    case cyber = "Cyber Pulse"

    var id: String { rawValue }
}

struct StyledDisplayNameView: View {
    let name: String
    var fontStyle: NitroNameFont = .standard
    var effect: NitroNameEffect = .none
    var size: CGFloat = 22

    var body: some View {
        let text = Text(name)
            .font(.system(size: size, weight: .bold, design: fontStyle.fontDesign))

        if effect == .none {
            text
        } else {
            text
                .foregroundStyle(
                    LinearGradient(
                        colors: effect.gradientColors,
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .shadow(color: effect.gradientColors.first?.opacity(0.55) ?? .clear, radius: 6, x: 0, y: 0)
        }
    }
}

struct ProfileEffectOverlay: View {
    let style: ProfileEffectStyle
    @State private var animate = false

    var body: some View {
        if style != .none {
            ZStack {
                switch style {
                case .none:
                    EmptyView()
                case .sparkles:
                    ForEach(0..<10, id: \.self) { i in
                        Image(systemName: "sparkle")
                            .font(.system(size: CGFloat(8 + (i % 4) * 3)))
                            .foregroundStyle(.white.opacity(animate ? 0.85 : 0.25))
                            .position(
                                x: CGFloat(30 + (i * 37) % 320),
                                y: CGFloat(25 + (i * 23) % 120)
                            )
                    }
                case .sakura:
                    ForEach(0..<8, id: \.self) { i in
                        Image(systemName: "leaf.fill")
                            .font(.system(size: 11))
                            .foregroundStyle(Color.pink.opacity(0.65))
                            .rotationEffect(.degrees(animate ? 35 : -20))
                            .position(
                                x: CGFloat(25 + (i * 45) % 330),
                                y: animate ? CGFloat(130 + (i % 3) * 15) : CGFloat(15 + (i % 3) * 20)
                            )
                    }
                case .aurora:
                    LinearGradient(
                        colors: [.mint.opacity(0.28), .indigo.opacity(0.22), .purple.opacity(0.26)],
                        startPoint: animate ? .topLeading : .bottomTrailing,
                        endPoint: animate ? .bottomTrailing : .topLeading
                    )
                case .cyber:
                    LinearGradient(
                        colors: [.cyan.opacity(0.25), .clear, .purple.opacity(0.28)],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                }
            }
            .allowsHitTesting(false)
            .onAppear {
                withAnimation(.easeInOut(duration: 3.2).repeatForever(autoreverses: true)) {
                    animate = true
                }
            }
        }
    }
}

// MARK: - Animated GIF & Inline Video Views
struct AnimatedGIFView: UIViewRepresentable {
    let url: URL

    func makeUIView(context: Context) -> UIImageView {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFit
        iv.clipsToBounds = true
        iv.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        iv.setContentCompressionResistancePriority(.defaultLow, for: .vertical)
        return iv
    }

    func updateUIView(_ uiView: UIImageView, context: Context) {
        if context.coordinator.loadedURL == url { return }
        context.coordinator.loadedURL = url
        Task {
            guard let (data, _) = try? await URLSession.shared.data(from: url),
                  let animated = Self.animatedImage(from: data) else { return }
            await MainActor.run {
                uiView.image = animated
            }
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }
    final class Coordinator { var loadedURL: URL? }

    private static func animatedImage(from data: Data) -> UIImage? {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil) else {
            return UIImage(data: data)
        }
        let count = CGImageSourceGetCount(source)
        if count <= 1 { return UIImage(data: data) }
        var images: [UIImage] = []
        var totalDuration: Double = 0
        for i in 0..<count {
            guard let cg = CGImageSourceCreateImageAtIndex(source, i, nil) else { continue }
            images.append(UIImage(cgImage: cg))
            let props = CGImageSourceCopyPropertiesAtIndex(source, i, nil) as? [CFString: Any]
            let gifProps = props?[kCGImagePropertyGIFDictionary] as? [CFString: Any]
            let delay = (gifProps?[kCGImagePropertyGIFUnclampedDelayTime] as? Double)
                ?? (gifProps?[kCGImagePropertyGIFDelayTime] as? Double)
                ?? 0.1
            totalDuration += max(delay, 0.02)
        }
        return UIImage.animatedImage(with: images, duration: max(totalDuration, 0.2))
    }
}

struct InlineVideoPlayerView: View {
    let url: URL
    @State private var player: AVPlayer?

    var body: some View {
        Group {
            if let player {
                VideoPlayer(player: player)
                    .frame(height: 220)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            } else {
                RoundedRectangle(cornerRadius: 16)
                    .fill(.secondary.opacity(0.15))
                    .frame(width: 240, height: 180)
                    .overlay(ProgressView())
            }
        }
        .onAppear {
            if player == nil {
                player = AVPlayer(url: url)
            }
        }
        .onDisappear {
            player?.pause()
        }
    }
}

struct GlassBackgroundBackdrop: View {
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        MeshGradient(
            width: 3,
            height: 3,
            points: [
                [0.0, 0.0], [0.5, 0.0], [1.0, 0.0],
                [0.0, 0.5], [0.5, 0.5], [1.0, 0.5],
                [0.0, 1.0], [0.5, 1.0], [1.0, 1.0]
            ],
            colors: scheme == .dark
                ? [
                    Color(red: 0.03, green: 0.03, blue: 0.05), Color(red: 0.05, green: 0.05, blue: 0.09), Color(red: 0.03, green: 0.04, blue: 0.07),
                    Color(red: 0.04, green: 0.04, blue: 0.07), Color(red: 0.07, green: 0.06, blue: 0.11), Color(red: 0.04, green: 0.05, blue: 0.08),
                    Color(red: 0.02, green: 0.02, blue: 0.03), Color(red: 0.04, green: 0.04, blue: 0.06), Color(red: 0.02, green: 0.03, blue: 0.05)
                ]
                : [
                    Color(red: 0.95, green: 0.96, blue: 0.98), Color(red: 0.96, green: 0.95, blue: 0.99), Color(red: 0.94, green: 0.97, blue: 0.98),
                    Color(red: 0.95, green: 0.95, blue: 0.98), Color(red: 0.98, green: 0.96, blue: 0.99), Color(red: 0.94, green: 0.97, blue: 0.98),
                    Color(red: 0.93, green: 0.95, blue: 0.97), Color(red: 0.96, green: 0.95, blue: 0.98), Color(red: 0.94, green: 0.96, blue: 0.97)
                ]
        )
    }
}

struct AvatarView: View {
    let url: URL?
    var decorationURL: URL? = nil
    var status: PresenceStatus? = nil
    var isMobile: Bool = false
    var size: CGFloat = 40

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            ZStack {
                CachedAsyncImage(url: url) { img in
                    img.resizable().scaledToFill()
                } placeholder: {
                    Circle()
                        .fill(.indigo.opacity(0.22))
                        .overlay {
                            Image(systemName: "person.fill")
                                .font(.system(size: size * 0.42))
                                .foregroundStyle(.indigo)
                        }
                }
                .frame(width: size, height: size)
                .clipShape(Circle())

                if let decorationURL {
                    CachedAsyncImage(url: decorationURL) { img in
                        img.resizable().scaledToFit()
                    } placeholder: {
                        EmptyView()
                    }
                    .frame(width: size * 1.22, height: size * 1.22)
                    .allowsHitTesting(false)
                }
            }

            if let status, status != .offline, status != .invisible {
                let badgeSize = max(11, size * 0.30)
                if isMobile && status == .online {
                    Image(systemName: "iphone")
                        .font(.system(size: badgeSize, weight: .bold))
                        .foregroundStyle(.green)
                        .padding(2)
                        .background(.background, in: RoundedRectangle(cornerRadius: 4))
                } else if status == .idle {
                    Image(systemName: "moon.fill")
                        .font(.system(size: badgeSize))
                        .foregroundStyle(.yellow)
                        .padding(2)
                        .background(.background, in: Circle())
                } else if status == .dnd {
                    Image(systemName: "minus.circle.fill")
                        .font(.system(size: badgeSize))
                        .foregroundStyle(.red)
                        .background(.background, in: Circle())
                } else {
                    Circle()
                        .fill(statusColor(status))
                        .frame(width: badgeSize, height: badgeSize)
                        .overlay(Circle().stroke(.background, lineWidth: 2))
                }
            }
        }
    }

    private func statusColor(_ status: PresenceStatus) -> Color {
        switch status {
        case .online: return .green
        case .idle: return .yellow
        case .dnd: return .red
        case .invisible, .offline: return .gray
        }
    }
}

struct DiscordMarkdownText: View {
    let content: String
    var usersById: [String: DiscordUser] = [:]
    var channelsById: [String: DiscordChannel] = [:]

    private var customEmojiURLs: [URL] {
        var urls: [URL] = []
        let tagPattern = #"<(a?):[a-zA-Z0-9_]+:(\d+)>"#
        if let regex = try? NSRegularExpression(pattern: tagPattern) {
            let range = NSRange(content.startIndex..., in: content)
            for match in regex.matches(in: content, range: range) {
                if let animRange = Range(match.range(at: 1), in: content),
                   let idRange = Range(match.range(at: 2), in: content) {
                    let ext = content[animRange] == "a" ? "gif" : "png"
                    if let url = URL(string: "https://cdn.discordapp.com/emojis/\(content[idRange]).\(ext)?size=64") {
                        urls.append(url)
                    }
                }
            }
        }
        let cdnPattern = #"https://cdn\.discordapp\.com/emojis/\d+\.(?:png|gif|webp)(?:\?[^\s]*)?"#
        if let regex = try? NSRegularExpression(pattern: cdnPattern) {
            let range = NSRange(content.startIndex..., in: content)
            for match in regex.matches(in: content, range: range) {
                if let r = Range(match.range, in: content), let url = URL(string: String(content[r])) {
                    urls.append(url)
                }
            }
        }
        return urls
    }

    private var directGIFURLs: [URL] {
        let pattern = #"https://media\.tenor\.com/[^\s]+\.gif"#
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return [] }
        let range = NSRange(content.startIndex..., in: content)
        return regex.matches(in: content, range: range).compactMap { match in
            guard let r = Range(match.range, in: content) else { return nil }
            return URL(string: String(content[r]))
        }
    }

    private var cleanedText: String {
        var text = content
        // Replace <@123> and <@!123> with @DisplayName
        let userPattern = #"<@!?(\d+)>"#
        if let regex = try? NSRegularExpression(pattern: userPattern) {
            let ns = text as NSString
            let matches = regex.matches(in: text, range: NSRange(location: 0, length: ns.length)).reversed()
            for m in matches {
                let uid = ns.substring(with: m.range(at: 1))
                let name = usersById[uid]?.displayName ?? "user"
                text = (text as NSString).replacingCharacters(in: m.range, with: "**@\(name)**")
            }
        }
        // Replace <#123> with #channel-name
        let chPattern = #"<#(\d+)>"#
        if let regex = try? NSRegularExpression(pattern: chPattern) {
            let ns = text as NSString
            let matches = regex.matches(in: text, range: NSRange(location: 0, length: ns.length)).reversed()
            for m in matches {
                let cid = ns.substring(with: m.range(at: 1))
                let name = channelsById[cid]?.displayName ?? "channel"
                text = (text as NSString).replacingCharacters(in: m.range, with: "**#\(name)**")
            }
        }
        text = text.replacingOccurrences(of: #"<a?:[a-zA-Z0-9_]+:\d+>"#, with: "", options: .regularExpression)
        text = text.replacingOccurrences(of: #"https://cdn\.discordapp\.com/emojis/\d+\.(?:png|gif|webp)(?:\?[^\s]*)?"#, with: "", options: .regularExpression)
        for gifUrl in directGIFURLs {
            text = text.replacingOccurrences(of: gifUrl.absoluteString, with: "")
        }
        return text.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            if !cleanedText.isEmpty {
                Text(attributedContent(cleanedText))
                    .textSelection(.enabled)
            }
            if !customEmojiURLs.isEmpty {
                let emojiSize: CGFloat = cleanedText.isEmpty ? 42 : 26
                HStack(spacing: 6) {
                    ForEach(Array(customEmojiURLs.prefix(8).enumerated()), id: \.offset) { _, url in
                        if url.pathExtension.lowercased() == "gif" {
                            AnimatedGIFView(url: url)
                                .frame(width: emojiSize, height: emojiSize)
                        } else {
                            CachedAsyncImage(url: url) { img in
                                img.resizable().scaledToFit()
                            } placeholder: {
                                Color.clear
                            }
                            .frame(width: emojiSize, height: emojiSize)
                        }
                    }
                }
            }
            ForEach(directGIFURLs, id: \.absoluteString) { gifURL in
                AnimatedGIFView(url: gifURL)
                    .frame(maxWidth: 260, maxHeight: 220)
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
        }
    }

    private func attributedContent(_ raw: String) -> AttributedString {
        let options = AttributedString.MarkdownParsingOptions(
            interpretedSyntax: .inlineOnlyPreservingWhitespace
        )
        return (try? AttributedString(markdown: raw, options: options)) ?? AttributedString(raw)
    }
}


struct ImageLightboxView: View {
    let url: URL
    @Environment(\.dismiss) private var dismiss
    @State private var scale: CGFloat = 1.0

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()
                CachedAsyncImage(url: url) { img in
                    img.resizable()
                        .scaledToFit()
                        .scaleEffect(scale)
                        .gesture(
                            MagnifyGesture()
                                .onChanged { value in scale = max(1.0, value.magnification) }
                                .onEnded { _ in withAnimation(.spring()) { scale = 1.0 } }
                        )
                } placeholder: {
                    ProgressView().tint(.white)
                }
            }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Close") { dismiss() }
                        .tint(.white)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    ShareLink(item: url) {
                        Image(systemName: "square.and.arrow.up")
                    }
                    .tint(.white)
                }
            }
        }
    }
}
