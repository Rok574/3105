import SwiftUI

struct UserProfileSheet: View {
    @Environment(DiscordStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    let user: DiscordUser
    var onOpenDM: (() -> Void)? = nil

    @State private var fullProfile: UserProfileResponse?

    var body: some View {
        let resolvedUser = fullProfile?.user ?? user
        let bio = fullProfile?.userProfile?.bio ?? resolvedUser.bio ?? ""
        let pronouns = fullProfile?.userProfile?.pronouns ?? ""
        let banner = fullProfile?.userProfile?.banner ?? resolvedUser.banner

        NavigationStack {
            ScrollView {
                VStack(spacing: 0) {
                    ZStack(alignment: .bottomLeading) {
                        Group {
                            if let banner, !banner.isEmpty,
                               let url = URL(string: "https://cdn.discordapp.com/banners/\(resolvedUser.id)/\(banner).\(banner.hasPrefix("a_") ? "gif" : "png")?size=600") {
                                CachedAsyncImage(url: url) { img in
                                    img.resizable().scaledToFill()
                                } placeholder: {
                                    LinearGradient(colors: [.indigo.opacity(0.75), .purple.opacity(0.6)], startPoint: .topLeading, endPoint: .bottomTrailing)
                                }
                            } else {
                                LinearGradient(colors: [.indigo.opacity(0.75), .purple.opacity(0.6)], startPoint: .topLeading, endPoint: .bottomTrailing)
                            }
                        }
                        .frame(height: 140)
                        .clipped()

                        AvatarView(
                            url: resolvedUser.avatarURL,
                            decorationURL: resolvedUser.avatarDecorationData?.imageURL,
                            status: store.presences[resolvedUser.id],
                            isMobile: store.clientStatuses[resolvedUser.id]?.isMobileOnlyOrActive ?? false,
                            size: 82
                        )
                        .overlay(Circle().stroke(.background, lineWidth: 5))
                        .padding(.horizontal, 16)
                        .offset(y: 38)
                    }
                    .padding(.bottom, 42)

                    VStack(alignment: .leading, spacing: 12) {
                        Text(resolvedUser.displayName)
                            .font(.title2.weight(.bold))

                        HStack(spacing: 6) {
                            Text("@\(resolvedUser.username)")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                            if !pronouns.isEmpty {
                                Text("• \(pronouns)")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        }

                        if !resolvedUser.badges.isEmpty {
                            HStack(spacing: 6) {
                                ForEach(resolvedUser.badges) { badge in
                                    Image(systemName: badge.systemImage)
                                        .font(.caption.weight(.bold))
                                        .foregroundStyle(Color(
                                            red: Double((badge.tintHex >> 16) & 0xFF) / 255.0,
                                            green: Double((badge.tintHex >> 8) & 0xFF) / 255.0,
                                            blue: Double(badge.tintHex & 0xFF) / 255.0
                                        ))
                                        .padding(6)
                                        .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 8))
                                }
                            }
                        }

                        if resolvedUser.id != store.currentUser?.id {
                            Button {
                                Task {
                                    await store.openDM(with: resolvedUser.id)
                                    dismiss()
                                    onOpenDM?()
                                }
                            } label: {
                                Label("Message", systemImage: "bubble.left.fill")
                                    .font(.subheadline.weight(.semibold))
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 10)
                            }
                            .glassEffect(.regular.interactive(), in: .capsule)
                        }

                        if !bio.isEmpty {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("ABOUT ME")
                                    .font(.caption.weight(.semibold))
                                    .foregroundStyle(.secondary)
                                Text(bio)
                                    .font(.subheadline)
                            }
                            .padding(14)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        }

                        if let joined = Snowflake.date(from: resolvedUser.id) {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("MEMBER SINCE")
                                    .font(.caption.weight(.semibold))
                                    .foregroundStyle(.secondary)
                                Text(joined.formatted(date: .abbreviated, time: .omitted))
                                    .font(.subheadline)
                            }
                            .padding(14)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 24)
                }
            }
            .ignoresSafeArea(edges: .top)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
            .task {
                fullProfile = try? await store.api.fetchUserProfile(user.id)
            }
        }
    }
}
