import SwiftUI
import WebKit

struct WebLoginView: View {
    @Environment(DiscordStore.self) private var store
    @State private var reloadTrigger = UUID()
    @State private var showManualTokenSheet = false
    @State private var manualToken = ""
    @State private var statusText = "Sign in to Discord below — your session token is captured automatically."
    @Namespace private var glassNS

    var body: some View {
        ZStack(alignment: .bottom) {
            GlassBackgroundBackdrop()
                .ignoresSafeArea()

            VStack(spacing: 0) {
                headerBar
                DiscordAuthWebView(
                    reloadTrigger: reloadTrigger,
                    onTokenCaptured: { token in
                        statusText = "Token captured! Signing in..."
                        Task { await store.authenticate(with: token, persist: true) }
                    }
                )
                .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                .padding(.horizontal, 12)
                .padding(.bottom, 84)
            }

            bottomGlassControls
                .padding(.horizontal, 16)
                .padding(.bottom, 16)
        }
        .sheet(isPresented: $showManualTokenSheet) {
            manualTokenSheet
                .presentationDetents([.medium])
        }
    }

    private var headerBar: some View {
        HStack(spacing: 12) {
            Image(systemName: "bubble.left.and.bubble.right.fill")
                .font(.title2)
                .foregroundStyle(.indigo)
            VStack(alignment: .leading, spacing: 2) {
                Text("GlassCord")
                    .font(.headline)
                Text(store.errorBanner ?? statusText)
                    .font(.caption)
                    .foregroundStyle(store.errorBanner != nil ? .red : .secondary)
                    .lineLimit(2)
            }
            Spacer()
            if store.isConnecting {
                ProgressView()
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }

    private var bottomGlassControls: some View {
        GlassEffectContainer(spacing: 16) {
            HStack(spacing: 12) {
                Button {
                    reloadTrigger = UUID()
                    statusText = "Reloaded Discord login."
                } label: {
                    Label("Reload", systemImage: "arrow.clockwise")
                        .font(.subheadline.weight(.medium))
                        .padding(.horizontal, 14)
                        .padding(.vertical, 10)
                }
                .glassEffect(.regular.interactive(), in: .capsule)
                .glassEffectID("reload", in: glassNS)

                Spacer()

                Button {
                    showManualTokenSheet = true
                } label: {
                    Label("Paste Token", systemImage: "key.fill")
                        .font(.subheadline.weight(.medium))
                        .padding(.horizontal, 14)
                        .padding(.vertical, 10)
                }
                .glassEffect(.regular.interactive(), in: .capsule)
                .glassEffectID("manualToken", in: glassNS)
            }
        }
    }

    private var manualTokenSheet: some View {
        NavigationStack {
            Form {
                Section("Discord User Token") {
                    SecureField("Paste token here", text: $manualToken)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                Section {
                    Button("Sign In with Token") {
                        let token = manualToken
                        showManualTokenSheet = false
                        Task { await store.authenticate(with: token, persist: true) }
                    }
                    .disabled(manualToken.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                } footer: {
                    Text("Stored securely in your iOS Keychain on-device.")
                }
            }
            .navigationTitle("Manual Token Login")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showManualTokenSheet = false }
                }
            }
        }
    }
}

private struct DiscordAuthWebView: UIViewRepresentable {
    let reloadTrigger: UUID
    let onTokenCaptured: (String) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onTokenCaptured: onTokenCaptured)
    }

    func makeUIView(context: Context) -> WKWebView {
        let contentController = WKUserContentController()
        contentController.add(context.coordinator, name: "tokenCaptured")

        // Intercepts Discord token from fetch/XHR Authorization headers and iframe localStorage
        let js = """
        (function() {
            if (window.__glassCordHooked) return;
            window.__glassCordHooked = true;
            let sent = false;

            function emitToken(raw) {
                if (sent || !raw) return;
                const cleaned = String(raw).replace(/^"|"$/g, '').trim();
                if (cleaned.length > 20 && !cleaned.startsWith('Bearer ')) {
                    sent = true;
                    window.webkit.messageHandlers.tokenCaptured.postMessage(cleaned);
                }
            }

            const origFetch = window.fetch;
            window.fetch = function(input, init) {
                try {
                    const headers = init && init.headers;
                    if (headers) {
                        const auth = headers.Authorization || headers.authorization || (headers.get && headers.get('Authorization'));
                        if (auth) emitToken(auth);
                    }
                } catch (_) {}
                return origFetch.apply(this, arguments);
            };

            const origSetHeader = XMLHttpRequest.prototype.setRequestHeader;
            XMLHttpRequest.prototype.setRequestHeader = function(name, value) {
                try {
                    if (name && name.toLowerCase() === 'authorization') {
                        emitToken(value);
                    }
                } catch (_) {}
                return origSetHeader.apply(this, arguments);
            };

            setInterval(function() {
                if (sent) return;
                try {
                    const iframe = document.createElement('iframe');
                    iframe.style.display = 'none';
                    document.body && document.body.appendChild(iframe);
                    const token = iframe.contentWindow && iframe.contentWindow.localStorage.getItem('token');
                    iframe.remove();
                    if (token) emitToken(token);
                } catch (_) {}
            }, 1000);
        })();
        """

        let script = WKUserScript(source: js, injectionTime: .atDocumentStart, forMainFrameOnly: false)
        contentController.addUserScript(script)

        let config = WKWebViewConfiguration()
        config.userContentController = contentController
        config.websiteDataStore = .default()

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 26_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1"
        webView.navigationDelegate = context.coordinator
        context.coordinator.lastReload = reloadTrigger
        webView.load(URLRequest(url: URL(string: "https://discord.com/login")!))
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        if context.coordinator.lastReload != reloadTrigger {
            context.coordinator.lastReload = reloadTrigger
            webView.load(URLRequest(url: URL(string: "https://discord.com/login")!))
        }
    }

    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate {
        let onTokenCaptured: (String) -> Void
        var lastReload: UUID = UUID()
        private var didCapture = false

        init(onTokenCaptured: @escaping (String) -> Void) {
            self.onTokenCaptured = onTokenCaptured
        }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.name == "tokenCaptured",
                  !didCapture,
                  let token = message.body as? String,
                  !token.isEmpty else { return }
            didCapture = true
            DispatchQueue.main.async {
                self.onTokenCaptured(token)
            }
        }
    }
}
