import Foundation

// MARK: - Snowflake Helper
enum Snowflake {
    static let discordEpochMs: UInt64 = 1_420_070_400_000

    static func date(from id: String) -> Date? {
        guard let raw = UInt64(id) else { return nil }
        let ms = (raw >> 22) + discordEpochMs
        return Date(timeIntervalSince1970: TimeInterval(ms) / 1000.0)
    }
}

// MARK: - User & Presence
struct DiscordUser: Codable, Identifiable, Hashable, Sendable {
    let id: String
    var username: String
    var globalName: String?
    var discriminator: String?
    var avatar: String?
    var banner: String?
    var accentColor: Int?
    var bio: String?
    var bot: Bool?

    enum CodingKeys: String, CodingKey {
        case id, username, discriminator, avatar, banner, bio, bot
        case globalName = "global_name"
        case accentColor = "accent_color"
    }

    var displayName: String {
        if let globalName, !globalName.isEmpty { return globalName }
        return username
    }

    var avatarURL: URL? {
        if let avatar, !avatar.isEmpty {
            let ext = avatar.hasPrefix("a_") ? "gif" : "png"
            return URL(string: "https://cdn.discordapp.com/avatars/\(id)/\(avatar).\(ext)?size=128")
        }
        let index: Int
        if let disc = discriminator, disc != "0", let num = Int(disc) {
            index = num % 5
        } else if let raw = UInt64(id) {
            index = Int((raw >> 22) % 6)
        } else {
            index = 0
        }
        return URL(string: "https://cdn.discordapp.com/embed/avatars/\(index).png")
    }
}

enum PresenceStatus: String, Codable, CaseIterable, Sendable {
    case online
    case idle
    case dnd
    case invisible
    case offline

    var label: String {
        switch self {
        case .online: return "Online"
        case .idle: return "Idle"
        case .dnd: return "Do Not Disturb"
        case .invisible: return "Invisible"
        case .offline: return "Offline"
        }
    }
}

struct DiscordActivity: Codable, Hashable, Sendable {
    var name: String
    var type: Int
    var state: String?
    var details: String?
}

struct DiscordPresence: Codable, Hashable, Sendable {
    var user: PartialUser?
    var status: PresenceStatus?
    var activities: [DiscordActivity]?

    struct PartialUser: Codable, Hashable, Sendable {
        let id: String
    }
}

// MARK: - Guilds & Folders
struct DiscordGuild: Codable, Identifiable, Hashable, Sendable {
    let id: String
    var name: String
    var icon: String?
    var banner: String?
    var ownerId: String?
    var channels: [DiscordChannel]?
    var roles: [DiscordRole]?
    var emojis: [DiscordEmoji]?

    enum CodingKeys: String, CodingKey {
        case id, name, icon, banner, channels, roles, emojis
        case ownerId = "owner_id"
    }

    var iconURL: URL? {
        guard let icon, !icon.isEmpty else { return nil }
        let ext = icon.hasPrefix("a_") ? "gif" : "png"
        return URL(string: "https://cdn.discordapp.com/icons/\(id)/\(icon).\(ext)?size=128")
    }

    var initials: String {
        name.split(separator: " ")
            .prefix(2)
            .compactMap { $0.first }
            .map(String.init)
            .joined()
            .uppercased()
    }
}

struct DiscordGuildFolder: Codable, Identifiable, Hashable, Sendable {
    var id: Int?
    var name: String?
    var color: Int?
    var guildIds: [String]

    enum CodingKeys: String, CodingKey {
        case id, name, color
        case guildIds = "guild_ids"
    }
}

struct DiscordRole: Codable, Identifiable, Hashable, Sendable {
    let id: String
    var name: String
    var color: Int
    var position: Int
}

// MARK: - Channels
enum ChannelType: Int, Codable, Sendable {
    case guildText = 0
    case dm = 1
    case guildVoice = 2
    case groupDM = 3
    case guildCategory = 4
    case guildAnnouncement = 5
    case announcementThread = 10
    case publicThread = 11
    case privateThread = 12
    case guildStageVoice = 13
    case guildDirectory = 14
    case guildForum = 15
    case guildMedia = 16
    case unknown = -1

    init(from decoder: Decoder) throws {
        let raw = try decoder.singleValueContainer().decode(Int.self)
        self = ChannelType(rawValue: raw) ?? .unknown
    }
}

struct DiscordChannel: Codable, Identifiable, Hashable, Sendable {
    let id: String
    var type: ChannelType
    var guildId: String?
    var name: String?
    var topic: String?
    var position: Int?
    var parentId: String?
    var lastMessageId: String?
    var recipients: [DiscordUser]?
    var icon: String?
    var nsfw: Bool?

    enum CodingKeys: String, CodingKey {
        case id, type, name, topic, position, recipients, icon, nsfw
        case guildId = "guild_id"
        case parentId = "parent_id"
        case lastMessageId = "last_message_id"
    }

    var displayName: String {
        if let name, !name.isEmpty { return name }
        if let recipients, !recipients.isEmpty {
            return recipients.map(\.displayName).joined(separator: ", ")
        }
        return "channel-\(id.suffix(4))"
    }

    var isVoiceLike: Bool {
        type == .guildVoice || type == .guildStageVoice
    }

    var isTextLike: Bool {
        switch type {
        case .guildText, .dm, .groupDM, .guildAnnouncement, .announcementThread, .publicThread, .privateThread, .guildForum:
            return true
        default:
            return false
        }
    }
}

// MARK: - Messages, Attachments, Embeds, Reactions
struct DiscordMessage: Codable, Identifiable, Hashable, Sendable {
    let id: String
    var channelId: String
    var guildId: String?
    var author: DiscordUser
    var content: String
    var timestamp: String
    var editedTimestamp: String?
    var attachments: [DiscordAttachment]?
    var embeds: [DiscordEmbed]?
    var reactions: [DiscordReaction]?
    var referencedMessage: ReferencedMessageBox?
    var type: Int?
    var pinned: Bool?
    var mentionEveryone: Bool?

    enum CodingKeys: String, CodingKey {
        case id, author, content, timestamp, attachments, embeds, reactions, type, pinned
        case channelId = "channel_id"
        case guildId = "guild_id"
        case editedTimestamp = "edited_timestamp"
        case referencedMessage = "referenced_message"
        case mentionEveryone = "mention_everyone"
    }

    var parsedDate: Date {
        let iso = ISO8601DateFormatter()
        iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let d = iso.date(from: timestamp) { return d }
        iso.formatOptions = [.withInternetDateTime]
        return iso.date(from: timestamp) ?? Snowflake.date(from: id) ?? Date()
    }
}

final class ReferencedMessageBox: Codable, Hashable, @unchecked Sendable {
    let id: String
    let channelId: String
    let author: DiscordUser?
    let content: String?

    enum CodingKeys: String, CodingKey {
        case id, author, content
        case channelId = "channel_id"
    }

    static func == (lhs: ReferencedMessageBox, rhs: ReferencedMessageBox) -> Bool {
        lhs.id == rhs.id && lhs.content == rhs.content
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}

struct DiscordAttachment: Codable, Identifiable, Hashable, Sendable {
    let id: String
    var filename: String
    var size: Int
    var url: String
    var proxyUrl: String?
    var contentType: String?
    var width: Int?
    var height: Int?

    enum CodingKeys: String, CodingKey {
        case id, filename, size, url, width, height
        case proxyUrl = "proxy_url"
        case contentType = "content_type"
    }

    var isImage: Bool {
        if let ct = contentType, ct.hasPrefix("image/") { return true }
        let lower = filename.lowercased()
        return lower.hasSuffix(".png") || lower.hasSuffix(".jpg") || lower.hasSuffix(".jpeg") || lower.hasSuffix(".gif") || lower.hasSuffix(".webp")
    }
}

struct DiscordEmbed: Codable, Hashable, Sendable {
    var title: String?
    var description: String?
    var url: String?
    var color: Int?
    var author: EmbedAuthor?
    var image: EmbedMedia?
    var thumbnail: EmbedMedia?
    var footer: EmbedFooter?
    var fields: [EmbedField]?

    struct EmbedAuthor: Codable, Hashable, Sendable {
        var name: String?
        var url: String?
        var iconUrl: String?
        enum CodingKeys: String, CodingKey {
            case name, url
            case iconUrl = "icon_url"
        }
    }

    struct EmbedMedia: Codable, Hashable, Sendable {
        var url: String?
        var width: Int?
        var height: Int?
    }

    struct EmbedFooter: Codable, Hashable, Sendable {
        var text: String?
    }

    struct EmbedField: Codable, Hashable, Sendable {
        var name: String
        var value: String
        var inline: Bool?
    }
}

struct DiscordEmoji: Codable, Hashable, Sendable {
    var id: String?
    var name: String?
    var animated: Bool?

    var displayString: String {
        if let id, let name {
            return ":\(name):"
        }
        return name ?? "❓"
    }

    var apiIdentifier: String {
        if let id, let name {
            return "\(name):\(id)"
        }
        return name ?? ""
    }

    var imageURL: URL? {
        guard let id else { return nil }
        let ext = (animated ?? false) ? "gif" : "png"
        return URL(string: "https://cdn.discordapp.com/emojis/\(id).\(ext)?size=64")
    }
}

struct DiscordReaction: Codable, Hashable, Sendable {
    var count: Int
    var me: Bool
    var emoji: DiscordEmoji
}

// MARK: - Relationships & Voice
struct DiscordRelationship: Codable, Identifiable, Hashable, Sendable {
    let id: String
    var type: Int // 1=Friend, 2=Blocked, 3=Incoming, 4=Outgoing
    var user: DiscordUser
    var nickname: String?
}

struct DiscordVoiceState: Codable, Hashable, Sendable {
    var guildId: String?
    var channelId: String?
    var userId: String
    var sessionId: String?
    var selfMute: Bool?
    var selfDeaf: Bool?
    var mute: Bool?
    var deaf: Bool?

    enum CodingKeys: String, CodingKey {
        case userId = "user_id"
        case guildId = "guild_id"
        case channelId = "channel_id"
        case sessionId = "session_id"
        case selfMute = "self_mute"
        case selfDeaf = "self_deaf"
        case mute, deaf
    }
}

struct DiscordReadState: Codable, Hashable, Sendable {
    let id: String
    var lastMessageId: String?
    var mentionCount: Int?

    enum CodingKeys: String, CodingKey {
        case id
        case lastMessageId = "last_message_id"
        case mentionCount = "mention_count"
    }
}

struct SearchMessagesResponse: Codable, Sendable {
    let messages: [[DiscordMessage]]
    let totalResults: Int?

    enum CodingKeys: String, CodingKey {
        case messages
        case totalResults = "total_results"
    }
}
