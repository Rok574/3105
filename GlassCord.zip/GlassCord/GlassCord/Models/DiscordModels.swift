import Foundation

// MARK: - Snowflake Helper
enum Snowflake {
    static let discordEpochMs: UInt64 = 1_420_070_400_000

    static func date(from id: String) -> Date? {
        guard let raw = UInt64(id) else { return nil }
        let ms = (raw >> 22) + discordEpochMs
        return Date(timeIntervalSince1970: TimeInterval(ms) / 1000.0)
    }
}

// MARK: - User, Badges & Profile
struct AvatarDecorationData: Codable, Hashable, Sendable {
    var asset: String
    var skuId: String?

    enum CodingKeys: String, CodingKey {
        case asset
        case skuId = "sku_id"
    }

    var imageURL: URL? {
        guard !asset.isEmpty else { return nil }
        return URL(string: "https://cdn.discordapp.com/avatar-decoration-presets/\(asset).png?size=160")
    }
}

struct DisplayNameStyle: Codable, Hashable, Sendable {
    var fontId: Int?
    var effectId: Int?
    var colors: [Int]?

    enum CodingKeys: String, CodingKey {
        case colors
        case fontId = "font_id"
        case effectId = "effect_id"
    }
}

struct DiscordBadge: Identifiable, Hashable, Sendable {
    let id: String
    let label: String
    let systemImage: String
    let tintHex: UInt32
}

struct DiscordUser: Codable, Identifiable, Hashable, Sendable {
    let id: String
    var username: String
    var globalName: String?
    var discriminator: String?
    var avatar: String?
    var banner: String?
    var accentColor: Int?
    var bio: String?
    var bot: Bool?
    var publicFlags: Int?
    var flags: Int?
    var premiumType: Int?
    var avatarDecorationData: AvatarDecorationData?
    var displayNameStyles: DisplayNameStyle?

    enum CodingKeys: String, CodingKey {
        case id, username, discriminator, avatar, banner, bio, bot, flags
        case globalName = "global_name"
        case accentColor = "accent_color"
        case publicFlags = "public_flags"
        case premiumType = "premium_type"
        case avatarDecorationData = "avatar_decoration_data"
        case displayNameStyles = "display_name_styles"
    }

    var displayName: String {
        if let globalName, !globalName.isEmpty { return globalName }
        return username
    }

    var badges: [DiscordBadge] {
        let mask = publicFlags ?? flags ?? 0
        var list: [DiscordBadge] = []
        if (premiumType ?? 0) > 0 {
            list.append(DiscordBadge(id: "nitro", label: "Nitro", systemImage: "sparkles", tintHex: 0xFF73FA))
        }
        if (mask & (1 << 0)) != 0 {
            list.append(DiscordBadge(id: "staff", label: "Discord Staff", systemImage: "wrench.and.screwdriver.fill", tintHex: 0x5865F2))
        }
        if (mask & (1 << 1)) != 0 {
            list.append(DiscordBadge(id: "partner", label: "Partner", systemImage: "infinity", tintHex: 0x5865F2))
        }
        if (mask & (1 << 2)) != 0 {
            list.append(DiscordBadge(id: "hypesquad_events", label: "HypeSquad Events", systemImage: "star.fill", tintHex: 0xF59E0B))
        }
        if (mask & (1 << 3)) != 0 {
            list.append(DiscordBadge(id: "bughunter1", label: "Bug Hunter", systemImage: "ladybug.fill", tintHex: 0x22C55E))
        }
        if (mask & (1 << 6)) != 0 {
            list.append(DiscordBadge(id: "bravery", label: "HypeSquad Bravery", systemImage: "shield.fill", tintHex: 0x9C84EF))
        }
        if (mask & (1 << 7)) != 0 {
            list.append(DiscordBadge(id: "brilliance", label: "HypeSquad Brilliance", systemImage: "flame.fill", tintHex: 0xF47B67))
        }
        if (mask & (1 << 8)) != 0 {
            list.append(DiscordBadge(id: "balance", label: "HypeSquad Balance", systemImage: "leaf.fill", tintHex: 0x45DDC0))
        }
        if (mask & (1 << 9)) != 0 {
            list.append(DiscordBadge(id: "early", label: "Early Supporter", systemImage: "gem", tintHex: 0xEC4899))
        }
        if (mask & (1 << 22)) != 0 {
            list.append(DiscordBadge(id: "activedev", label: "Active Developer", systemImage: "chevron.left.forwardslash.chevron.right", tintHex: 0x22C55E))
        }
        return list
    }

    var avatarURL: URL? {
        if let avatar, !avatar.isEmpty {
            let ext = avatar.hasPrefix("a_") ? "gif" : "png"
            return URL(string: "https://cdn.discordapp.com/avatars/\(id)/\(avatar).\(ext)?size=128")
        }
        let index: Int
        if let disc = discriminator, disc != "0", let num = Int(disc) {
            index = num % 5
        } else if let raw = UInt64(id) {
            index = Int((raw >> 22) % 6)
        } else {
            index = 0
        }
        return URL(string: "https://cdn.discordapp.com/embed/avatars/\(index).png")
    }
}

struct UserProfileResponse: Codable, Sendable {
    var user: DiscordUser?
    var userProfile: UserProfileDetail?
    var connectedAccounts: [ConnectedAccount]?

    enum CodingKeys: String, CodingKey {
        case user
        case userProfile = "user_profile"
        case connectedAccounts = "connected_accounts"
    }

    struct UserProfileDetail: Codable, Sendable {
        var bio: String?
        var pronouns: String?
        var banner: String?
        var accentColor: Int?
        var profileEffect: ProfileEffectRef?

        enum CodingKeys: String, CodingKey {
            case bio, pronouns, banner
            case accentColor = "accent_color"
            case profileEffect = "profile_effect"
        }

        struct ProfileEffectRef: Codable, Sendable {
            var id: String?
        }
    }

    struct ConnectedAccount: Codable, Identifiable, Hashable, Sendable {
        var id: String
        var type: String
        var name: String
        var verified: Bool?
    }
}

enum PresenceStatus: String, Codable, CaseIterable, Sendable {
    case online
    case idle
    case dnd
    case invisible
    case offline

    var label: String {
        switch self {
        case .online: return "Online"
        case .idle: return "Idle"
        case .dnd: return "Do Not Disturb"
        case .invisible: return "Invisible"
        case .offline: return "Offline"
        }
    }
}

struct ClientStatus: Codable, Hashable, Sendable {
    var desktop: String?
    var mobile: String?
    var web: String?

    var isMobileOnlyOrActive: Bool {
        mobile == "online" && desktop != "online" && web != "online"
    }
}

struct DiscordActivity: Codable, Hashable, Sendable {
    var name: String
    var type: Int
    var state: String?
    var details: String?
}

struct DiscordPresence: Codable, Hashable, Sendable {
    var user: PartialUser?
    var userId: String?
    var status: PresenceStatus?
    var clientStatus: ClientStatus?
    var activities: [DiscordActivity]?

    enum CodingKeys: String, CodingKey {
        case user, status, activities
        case userId = "user_id"
        case clientStatus = "client_status"
    }

    var resolvedUserId: String? {
        user?.id ?? userId
    }

    struct PartialUser: Codable, Hashable, Sendable {
        let id: String
    }
}

// MARK: - Guilds & Folders
struct DiscordGuild: Codable, Identifiable, Hashable, Sendable {
    let id: String
    var name: String
    var icon: String?
    var banner: String?
    var ownerId: String?
    var channels: [DiscordChannel]?
    var roles: [DiscordRole]?
    var emojis: [DiscordEmoji]?
    var members: [GuildMember]?

    enum CodingKeys: String, CodingKey {
        case id, name, icon, banner, channels, roles, emojis, members, properties
        case ownerId = "owner_id"
    }

    private struct GuildProperties: Codable {
        var name: String?
        var icon: String?
        var banner: String?
        var ownerId: String?

        enum CodingKeys: String, CodingKey {
            case name, icon, banner
            case ownerId = "owner_id"
        }
    }

    init(id: String, name: String, icon: String? = nil, banner: String? = nil, ownerId: String? = nil, channels: [DiscordChannel]? = nil, roles: [DiscordRole]? = nil, emojis: [DiscordEmoji]? = nil) {
        self.id = id
        self.name = name
        self.icon = icon
        self.banner = banner
        self.ownerId = ownerId
        self.channels = channels
        self.roles = roles
        self.emojis = emojis
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decode(String.self, forKey: .id)
        let props = try? c.decodeIfPresent(GuildProperties.self, forKey: .properties)
        let topName = try? c.decodeIfPresent(String.self, forKey: .name)
        name = topName ?? props?.name ?? "Server"
        icon = (try? c.decodeIfPresent(String.self, forKey: .icon)) ?? props?.icon
        banner = (try? c.decodeIfPresent(String.self, forKey: .banner)) ?? props?.banner
        ownerId = (try? c.decodeIfPresent(String.self, forKey: .ownerId)) ?? props?.ownerId
        channels = try? c.decodeIfPresent([DiscordChannel].self, forKey: .channels)
        roles = try? c.decodeIfPresent([DiscordRole].self, forKey: .roles)
        emojis = try? c.decodeIfPresent([DiscordEmoji].self, forKey: .emojis)
        members = try? c.decodeIfPresent([GuildMember].self, forKey: .members)
    }

    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(id, forKey: .id)
        try c.encode(name, forKey: .name)
        try c.encodeIfPresent(icon, forKey: .icon)
        try c.encodeIfPresent(banner, forKey: .banner)
        try c.encodeIfPresent(ownerId, forKey: .ownerId)
        try c.encodeIfPresent(channels, forKey: .channels)
        try c.encodeIfPresent(roles, forKey: .roles)
        try c.encodeIfPresent(emojis, forKey: .emojis)
        try c.encodeIfPresent(members, forKey: .members)
    }

    var iconURL: URL? {
        guard let icon, !icon.isEmpty else { return nil }
        let ext = icon.hasPrefix("a_") ? "gif" : "png"
        return URL(string: "https://cdn.discordapp.com/icons/\(id)/\(icon).\(ext)?size=128")
    }

    var initials: String {
        let letters = name.split(separator: " ")
            .prefix(2)
            .compactMap { $0.first }
            .map(String.init)
            .joined()
            .uppercased()
        return letters.isEmpty ? "S" : letters
    }
}

struct DiscordGuildFolder: Codable, Identifiable, Hashable, Sendable {
    var id: Int?
    var name: String?
    var color: Int?
    var guildIds: [String]

    enum CodingKeys: String, CodingKey {
        case id, name, color
        case guildIds = "guild_ids"
    }

    var stableId: String {
        if let id { return "folder-\(id)" }
        return "single-\(guildIds.joined(separator: "-"))"
    }
}

struct PermissionOverwrite: Codable, Hashable, Sendable {
    let id: String
    var type: Int // 0 = role, 1 = member
    var allow: String
    var deny: String

    var allowBits: UInt64 { UInt64(allow) ?? 0 }
    var denyBits: UInt64 { UInt64(deny) ?? 0 }
}

struct GuildMember: Codable, Hashable, Sendable {
    var user: DiscordUser?
    var roles: [String]
}

struct DiscordRole: Codable, Identifiable, Hashable, Sendable {
    let id: String
    var name: String
    var color: Int
    var position: Int
    var permissions: String?

    var permissionBits: UInt64 { UInt64(permissions ?? "0") ?? 0 }
}

// MARK: - Channels
enum ChannelType: Int, Codable, Sendable {
    case guildText = 0
    case dm = 1
    case guildVoice = 2
    case groupDM = 3
    case guildCategory = 4
    case guildAnnouncement = 5
    case announcementThread = 10
    case publicThread = 11
    case privateThread = 12
    case guildStageVoice = 13
    case guildDirectory = 14
    case guildForum = 15
    case guildMedia = 16
    case unknown = -1

    init(from decoder: Decoder) throws {
        let raw = try decoder.singleValueContainer().decode(Int.self)
        self = ChannelType(rawValue: raw) ?? .unknown
    }
}

struct DiscordChannel: Codable, Identifiable, Hashable, Sendable {
    let id: String
    var type: ChannelType
    var guildId: String?
    var name: String?
    var topic: String?
    var position: Int?
    var parentId: String?
    var lastMessageId: String?
    var recipients: [DiscordUser]?
    var recipientIds: [String]?
    var icon: String?
    var nsfw: Bool?
    var permissionOverwrites: [PermissionOverwrite]?

    enum CodingKeys: String, CodingKey {
        case id, type, name, topic, position, recipients, icon, nsfw
        case guildId = "guild_id"
        case parentId = "parent_id"
        case lastMessageId = "last_message_id"
        case recipientIds = "recipient_ids"
        case permissionOverwrites = "permission_overwrites"
    }

    var displayName: String {
        if let name, !name.isEmpty { return name }
        if let recipients, !recipients.isEmpty {
            return recipients.map(\.displayName).joined(separator: ", ")
        }
        return "Direct Message"
    }

    var iconURL: URL? {
        guard let icon, !icon.isEmpty else { return nil }
        return URL(string: "https://cdn.discordapp.com/channel-icons/\(id)/\(icon).png?size=128")
    }

    var isVoiceLike: Bool {
        type == .guildVoice || type == .guildStageVoice
    }

    var isTextLike: Bool {
        switch type {
        case .guildText, .dm, .groupDM, .guildAnnouncement, .announcementThread, .publicThread, .privateThread, .guildForum:
            return true
        default:
            return false
        }
    }
}

// MARK: - Polls
struct DiscordPoll: Codable, Hashable, Sendable {
    var question: PollMedia
    var answers: [PollAnswer]
    var expiry: String?
    var allowMultiselect: Bool?
    var results: PollResults?

    enum CodingKeys: String, CodingKey {
        case question, answers, expiry, results
        case allowMultiselect = "allow_multiselect"
    }

    struct PollMedia: Codable, Hashable, Sendable {
        var text: String?
    }

    struct PollAnswer: Codable, Identifiable, Hashable, Sendable {
        var answerId: Int
        var pollMedia: PollMedia

        var id: Int { answerId }
        enum CodingKeys: String, CodingKey {
            case answerId = "answer_id"
            case pollMedia = "poll_media"
        }
    }

    struct PollResults: Codable, Hashable, Sendable {
        var isFinalized: Bool?
        var answerCounts: [AnswerCount]?

        enum CodingKeys: String, CodingKey {
            case isFinalized = "is_finalized"
            case answerCounts = "answer_counts"
        }

        struct AnswerCount: Codable, Hashable, Sendable {
            var id: Int
            var count: Int
            var meVoted: Bool?

            enum CodingKeys: String, CodingKey {
                case id, count
                case meVoted = "me_voted"
            }
        }
    }
}

// MARK: - Messages, Attachments, Embeds, Reactions
struct DiscordMessage: Codable, Identifiable, Hashable, Sendable {
    let id: String
    var channelId: String
    var guildId: String?
    var author: DiscordUser
    var content: String
    var timestamp: String
    var editedTimestamp: String?
    var attachments: [DiscordAttachment]?
    var embeds: [DiscordEmbed]?
    var reactions: [DiscordReaction]?
    var referencedMessage: ReferencedMessageBox?
    var poll: DiscordPoll?
    var type: Int?
    var pinned: Bool?
    var mentionEveryone: Bool?

    enum CodingKeys: String, CodingKey {
        case id, author, content, timestamp, attachments, embeds, reactions, type, pinned, poll
        case channelId = "channel_id"
        case guildId = "guild_id"
        case editedTimestamp = "edited_timestamp"
        case referencedMessage = "referenced_message"
        case mentionEveryone = "mention_everyone"
    }

    var parsedDate: Date {
        let iso = ISO8601DateFormatter()
        iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let d = iso.date(from: timestamp) { return d }
        iso.formatOptions = [.withInternetDateTime]
        return iso.date(from: timestamp) ?? Snowflake.date(from: id) ?? Date()
    }
}

final class ReferencedMessageBox: Codable, Hashable, @unchecked Sendable {
    let id: String
    let channelId: String
    let author: DiscordUser?
    let content: String?

    enum CodingKeys: String, CodingKey {
        case id, author, content
        case channelId = "channel_id"
    }

    static func == (lhs: ReferencedMessageBox, rhs: ReferencedMessageBox) -> Bool {
        lhs.id == rhs.id && lhs.content == rhs.content
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}

struct DiscordAttachment: Codable, Identifiable, Hashable, Sendable {
    let id: String
    var filename: String
    var size: Int
    var url: String
    var proxyUrl: String?
    var contentType: String?
    var width: Int?
    var height: Int?

    enum CodingKeys: String, CodingKey {
        case id, filename, size, url, width, height
        case proxyUrl = "proxy_url"
        case contentType = "content_type"
    }

    var isImage: Bool {
        if let ct = contentType, ct.hasPrefix("image/") { return true }
        let lower = filename.lowercased()
        return lower.hasSuffix(".png") || lower.hasSuffix(".jpg") || lower.hasSuffix(".jpeg") || lower.hasSuffix(".gif") || lower.hasSuffix(".webp")
    }

    var isGIF: Bool {
        if contentType == "image/gif" { return true }
        return filename.lowercased().hasSuffix(".gif")
    }

    var isVideo: Bool {
        if let ct = contentType, ct.hasPrefix("video/") { return true }
        let lower = filename.lowercased()
        return lower.hasSuffix(".mp4") || lower.hasSuffix(".mov") || lower.hasSuffix(".m4v") || lower.hasSuffix(".webm")
    }
}

struct DiscordEmbed: Codable, Hashable, Sendable {
    var type: String?
    var title: String?
    var description: String?
    var url: String?
    var color: Int?
    var author: EmbedAuthor?
    var image: EmbedMedia?
    var thumbnail: EmbedMedia?
    var video: EmbedMedia?
    var footer: EmbedFooter?
    var fields: [EmbedField]?

    struct EmbedAuthor: Codable, Hashable, Sendable {
        var name: String?
        var url: String?
        var iconUrl: String?
        enum CodingKeys: String, CodingKey {
            case name, url
            case iconUrl = "icon_url"
        }
    }

    struct EmbedMedia: Codable, Hashable, Sendable {
        var url: String?
        var proxyUrl: String?
        var width: Int?
        var height: Int?

        enum CodingKeys: String, CodingKey {
            case url, width, height
            case proxyUrl = "proxy_url"
        }
    }

    struct EmbedFooter: Codable, Hashable, Sendable {
        var text: String?
    }

    struct EmbedField: Codable, Hashable, Sendable {
        var name: String
        var value: String
        var inline: Bool?
    }
}

struct DiscordEmoji: Codable, Hashable, Sendable {
    var id: String?
    var name: String?
    var animated: Bool?

    var displayString: String {
        if let id, let name {
            return ":\(name):"
        }
        return name ?? "❓"
    }

    var apiIdentifier: String {
        if let id, let name {
            return "\(name):\(id)"
        }
        return name ?? ""
    }

    var imageURL: URL? {
        guard let id else { return nil }
        let ext = (animated ?? false) ? "gif" : "png"
        return URL(string: "https://cdn.discordapp.com/emojis/\(id).\(ext)?size=64")
    }
}

struct DiscordReaction: Codable, Hashable, Sendable {
    var count: Int
    var me: Bool
    var emoji: DiscordEmoji
}

// MARK: - Relationships & Voice
struct DiscordRelationship: Codable, Identifiable, Hashable, Sendable {
    let id: String
    var type: Int // 1=Friend, 2=Blocked, 3=Incoming, 4=Outgoing
    var userId: String?
    var user: DiscordUser?
    var nickname: String?

    enum CodingKeys: String, CodingKey {
        case id, type, user, nickname
        case userId = "user_id"
    }

    var resolvedUser: DiscordUser {
        user ?? DiscordUser(id: userId ?? id, username: nickname ?? "User")
    }
}

struct DiscordVoiceState: Codable, Hashable, Sendable {
    var guildId: String?
    var channelId: String?
    var userId: String
    var sessionId: String?
    var selfMute: Bool?
    var selfDeaf: Bool?
    var mute: Bool?
    var deaf: Bool?

    enum CodingKeys: String, CodingKey {
        case userId = "user_id"
        case guildId = "guild_id"
        case channelId = "channel_id"
        case sessionId = "session_id"
        case selfMute = "self_mute"
        case selfDeaf = "self_deaf"
        case mute, deaf
    }
}

struct DiscordReadState: Codable, Hashable, Sendable {
    let id: String
    var lastMessageId: String?
    var mentionCount: Int?

    enum CodingKeys: String, CodingKey {
        case id
        case lastMessageId = "last_message_id"
        case mentionCount = "mention_count"
    }
}

struct SearchMessagesResponse: Codable, Sendable {
    let messages: [[DiscordMessage]]
    let totalResults: Int?

    enum CodingKeys: String, CodingKey {
        case messages
        case totalResults = "total_results"
    }
}
