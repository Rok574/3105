# GlassCord

A native **iOS 26+ Liquid Glass** Discord client written in SwiftUI, featuring instant cached startup, 120Hz image caching, `WKWebView` login, Fake Nitro / Free Emojis, and automatic **Catbox.moe** large file uploads.

## Features
- **Instant Open & 120Hz Smoothness**: `DiskCache` loads your last workspace snapshot immediately on launch while Gateway v10 syncs in the background, paired with `ImageLoader` (`NSCache` + disk image cache) for zero-stutter scrolling.
- **Liquid Glass UI (iOS 26+)**: Built with `.glassEffect(_:in:)`, `GlassEffectContainer`, `glassEffectID(_:in:)`, `MeshGradient` backdrop, floating composer, inline custom emoji rendering, and `tabBarMinimizeBehavior(.onScrollDown)`.
- **Fake Nitro & Free Emojis**: Browse custom & animated emojis from every server in the built-in `EmojiPickerSheet` and send them anywhere via clean CDN emoji URLs, plus a local Nitro profile badge.
- **Catbox Large File Uploader**: Files above your configured threshold (default 10 MB) — or any upload rejected by Discord with HTTP 413 — automatically upload to `catbox.moe` (up to 200 MB) and post the link.
- **WebView Login (`WKWebView`)**: Loads `https://discord.com/login` with automatic `fetch` / `XMLHttpRequest` / `localStorage` token capture, plus a manual token paste fallback.

## Build
1. Install [XcodeGen](https://github.com/yonaskolb/XcodeGen) (`brew install xcodegen`) and run `xcodegen generate` in this folder.
2. Open `GlassCord.xcodeproj` in Xcode 26+ and run on an iOS 26+ device/simulator, **or** push to GitHub to build an unsigned `GlassCord.ipa` via `.github/workflows/build.yml` for SideStore sideloading.
