import Foundation
import WebKit

// Unused placeholder kept for project compatibility. All proxying is done by
// LocalHTTPServer (path-based /proxy/<scheme>/<host>/<path>).
final class ProxyHandler: NSObject, WKURLSchemeHandler {
    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        urlSchemeTask.didFailWithError(URLError(.cancelled))
    }
    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {}
}
