import Foundation
import Network

/// WebSocket -> raw TLS TCP bridge for Ruffle's `socketProxy`.
///
/// Ruffle opens `ws://127.0.0.1:8765` and exchanges raw socket bytes as binary
/// WebSocket messages. This bridge accepts the WebSocket (handshake/framing is
/// handled by NWProtocolWebSocket) and relays bytes to/from the real
/// SmartFox server over TLS.
final class SocketBridge {
    static let shared = SocketBridge()
    static let port: UInt16 = 8765

    private var listener: NWListener?
    private var isRunning = false
    private let lock = NSLock()

    private var targetHost = "iss02-classic-prod.animaljam.com"
    private var targetPort: UInt16 = 443

    func setTarget(host: String, port: Int) {
        lock.lock(); defer { lock.unlock() }
        targetHost = host
        targetPort = UInt16(clamping: port)
    }

    private func currentTarget() -> (String, UInt16) {
        lock.lock(); defer { lock.unlock() }
        return (targetHost, targetPort)
    }

    func startLocalBridge() {
        lock.lock(); defer { lock.unlock() }
        guard !isRunning else { return }
        do {
            let params = NWParameters.tcp
            params.allowLocalEndpointReuse = true
            let ws = NWProtocolWebSocket.Options()
            ws.autoReplyPing = true
            params.defaultProtocolStack.applicationProtocols.insert(ws, at: 0)

            let l = try NWListener(using: params, on: NWEndpoint.Port(rawValue: Self.port)!)
            l.stateUpdateHandler = { [weak self] state in
                switch state {
                case .ready:
                    print("SocketBridge ready on ws://127.0.0.1:\(Self.port)")
                case .failed(let err):
                    print("SocketBridge failed: \(err)")
                    self?.lock.lock()
                    self?.isRunning = false
                    self?.listener = nil
                    self?.lock.unlock()
                    DispatchQueue.global().asyncAfter(deadline: .now() + 1) { self?.startLocalBridge() }
                default: break
                }
            }
            l.newConnectionHandler = { [weak self] client in
                guard LocalHTTPServer.isLoopback(client.endpoint) else { client.cancel(); return }
                self?.accept(client)
            }
            l.start(queue: .global(qos: .userInitiated))
            listener = l
            isRunning = true
        } catch {
            print("SocketBridge error: \(error)")
        }
    }

    // MARK: - Per-connection relay

    private func accept(_ client: NWConnection) {
        let (host, port) = currentTarget()
        guard let nwPort = NWEndpoint.Port(rawValue: port) else { client.cancel(); return }

        let remote = NWConnection(host: NWEndpoint.Host(host), port: nwPort, using: .tls)
        let closeLock = NSLock()
        var closed = false
        let closeBoth: () -> Void = {
            closeLock.lock()
            if closed { closeLock.unlock(); return }
            closed = true
            closeLock.unlock()
            client.cancel()
            remote.cancel()
        }

        let q = DispatchQueue.global(qos: .userInitiated)
        client.stateUpdateHandler = { state in
            switch state {
            case .failed, .cancelled: closeBoth()
            default: break
            }
        }
        remote.stateUpdateHandler = { state in
            switch state {
            case .failed(let e):
                print("SocketBridge remote failed: \(e)")
                closeBoth()
            case .cancelled: closeBoth()
            default: break
            }
        }

        client.start(queue: q)
        remote.start(queue: q)

        // Client (WebSocket) -> remote (TLS TCP)
        func pumpClient() {
            client.receiveMessage { data, context, _, error in
                if error != nil { closeBoth(); return }
                if let meta = context?.protocolMetadata(definition: NWProtocolWebSocket.definition)
                    as? NWProtocolWebSocket.Metadata, meta.opcode == .close {
                    closeBoth(); return
                }
                if let data = data, !data.isEmpty {
                    remote.send(content: data, completion: .contentProcessed({ err in
                        if err != nil { closeBoth() }
                    }))
                }
                pumpClient()
            }
        }

        // Remote (TLS TCP) -> client (WebSocket binary frames)
        func pumpRemote() {
            remote.receive(minimumIncompleteLength: 1, maximumLength: 65536) { data, _, isComplete, error in
                if let data = data, !data.isEmpty {
                    let meta = NWProtocolWebSocket.Metadata(opcode: .binary)
                    let ctx = NWConnection.ContentContext(identifier: "ajbin", metadata: [meta])
                    client.send(content: data, contentContext: ctx, isComplete: true,
                                completion: .contentProcessed({ err in
                        if err != nil { closeBoth() }
                    }))
                }
                if isComplete || error != nil { closeBoth(); return }
                pumpRemote()
            }
        }

        pumpClient()
        pumpRemote()
    }
}
