import SwiftUI
import WebKit

@main
struct AJClassicApp: App {
    init() {
        LocalHTTPServer.shared.start()
        SocketBridge.shared.startLocalBridge()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @State private var useTLSSocket = true
    @StateObject private var webViewProxy = WebViewCoordinator()
    @State private var isLoggedIn = false

    var body: some View {
        ZStack(alignment: .top) {
            Color.black.ignoresSafeArea()

            AJWebViewContainer(coordinator: webViewProxy)
                .ignoresSafeArea()

            if !isLoggedIn {
                VStack {
                    LoginControlBar(useTLSSocket: $useTLSSocket) { session in
                        withAnimation { isLoggedIn = true }
                        webViewProxy.bootGame(with: session)
                    }
                    .background(.ultraThinMaterial)
                    .cornerRadius(12)
                    .padding(.horizontal, 16)
                    .padding(.top, 8)

                    Spacer()
                }
                .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .ignoresSafeArea(.keyboard)
        .preferredColorScheme(.dark)
    }
}

final class WebViewCoordinator: ObservableObject {
    weak var webView: WKWebView?
    var pageLoaded = false
    private var pendingSession: AJSession?

    /// Called by the web view once the player page has finished loading.
    func pageDidLoad() {
        pageLoaded = true
        if let s = pendingSession {
            pendingSession = nil
            bootGame(with: s)
        }
    }

    func bootGame(with session: AJSession) {
        // If the player page isn't ready yet, remember the session and start when it is.
        guard pageLoaded, let webView = webView else {
            pendingSession = session
            return
        }

        var fv = session.flashvars
        if let sfs = fv["smartfoxServer"] {
            fv["smartfoxServer"] = sfs.trimmingCharacters(in: .whitespacesAndNewlines)
        }

        let realSWF: String
        let realBase: String
        if let cu = fv["clientURL"], URL(string: cu) != nil, let slash = cu.components(separatedBy: "?")[0].lastIndex(of: "/") {
            // e.g. https://ajcontent.akamaized.net/1830/ajclient.swf?v=3
            realSWF = cu
            realBase = String(cu.components(separatedBy: "?")[0][...slash])
        } else {
            let deployVersion = fv["deploy_version"] ?? fv["smoke_version"] ?? "1830"
            var contentBase = fv["content"] ?? "https://ajcontent.akamaized.net/"
            if !contentBase.hasSuffix("/") { contentBase += "/" }
            realBase = contentBase + deployVersion + "/"
            realSWF = realBase + "ajclient.swf"
        }

        let swfURL = LocalHTTPServer.proxiedURL(realSWF)
        let baseURL = LocalHTTPServer.proxiedURL(realBase)

        // The SWF connects through SecureSocket, and SmartFoxClient.getSocketIpAddress() rewrites the
        // configured server before connecting: "<name>.(stage|prod).animaljam.internal" ->
        // "<name>-$1.animaljam.com", then prefixes "lb-". Ruffle matches socketProxy entries by the exact
        // host string the SWF asks for, and that is also the real TLS endpoint, so mirror it here.
        let sfsConfigured = (fv["smartfoxServer"] ?? "iss02-classic-prod.animaljam.com")
        let sfsHost = "lb-" + sfsConfigured.replacingOccurrences(
            of: #"\.(stage|prod)\.animaljam\.internal$"#,
            with: "-$1.animaljam.com",
            options: .regularExpression)
        let sfsPort = Int(fv["smartfoxPort"] ?? "443") ?? 443
        SocketBridge.shared.setTarget(host: sfsHost, port: sfsPort)

        let payload: [String: Any] = [
            "fv": fv,
            "swf": swfURL,
            "base": baseURL,
            "proxies": [[
                "host": sfsHost,
                "port": sfsPort,
                "proxyUrl": "ws://127.0.0.1:\(SocketBridge.port)"
            ]]
        ]
        guard let data = try? JSONSerialization.data(withJSONObject: payload),
              let json = String(data: data, encoding: .utf8) else { return }

        let js = "var __p = \(json); window.startAJWithSession(__p.fv, __p.swf, __p.base, __p.proxies);"
        DispatchQueue.main.async {
            webView.evaluateJavaScript(js) { _, err in
                if let err = err { print("startAJWithSession error: \(err)") }
            }
        }
    }
}
