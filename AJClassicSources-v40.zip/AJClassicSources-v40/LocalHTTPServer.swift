import Foundation
import Network

/// Tiny loopback HTTP server. Serves the Ruffle player page at `/` and a
/// CORS-adding reverse proxy at `/proxy/<scheme>/<host>/<path>?<query>`.
///
/// The proxy URL is *path based* (not `?url=`) on purpose: Flash/Ruffle resolve
/// relative asset URLs against the base URL, and a query-string based proxy
/// URL loses its query during relative resolution -> missing assets -> black screen.
final class LocalHTTPServer {
    static let shared = LocalHTTPServer()
    static let port: UInt16 = 8080

    private var listener: NWListener?
    private var isRunning = false
    private let lock = NSLock()

    private let session: URLSession = {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 30
        c.timeoutIntervalForResource = 120
        c.requestCachePolicy = .useProtocolCachePolicy
        return URLSession(configuration: c)
    }()

    private let userAgent = AJEnv.userAgent

    // MARK: - URL helper

    /// Turns "https://host/a/b?x=1" into "http://127.0.0.1:8080/proxy/https/host/a/b?x=1".
    static func proxiedURL(_ urlString: String) -> String {
        guard let comps = URLComponents(string: urlString),
              let scheme = comps.scheme, let host = comps.host else { return urlString }
        var out = "http://127.0.0.1:\(port)/proxy/\(scheme)/\(host)"
        if let p = comps.port { out += ":\(p)" }
        let path = comps.percentEncodedPath
        out += path.isEmpty ? "/" : path
        if let q = comps.percentEncodedQuery { out += "?\(q)" }
        return out
    }

    static func isLoopback(_ ep: NWEndpoint) -> Bool {
        if case let .hostPort(host, _) = ep {
            switch host {
            case .ipv4(let a): return a.isLoopback
            case .ipv6(let a): return a.isLoopback
            default: return false
            }
        }
        return false
    }

    // MARK: - Lifecycle

    func start() {
        lock.lock(); defer { lock.unlock() }
        guard !isRunning else { return }
        do {
            let params = NWParameters.tcp
            params.allowLocalEndpointReuse = true
            let l = try NWListener(using: params, on: NWEndpoint.Port(rawValue: Self.port)!)
            l.stateUpdateHandler = { [weak self] state in
                switch state {
                case .ready:
                    print("LocalHTTPServer ready on http://127.0.0.1:\(Self.port)")
                case .failed(let err):
                    print("LocalHTTPServer failed: \(err)")
                    self?.lock.lock()
                    self?.isRunning = false
                    self?.listener = nil
                    self?.lock.unlock()
                    // Retry shortly (e.g. port still held by a previous launch).
                    DispatchQueue.global().asyncAfter(deadline: .now() + 1) { self?.start() }
                default: break
                }
            }
            l.newConnectionHandler = { [weak self] conn in
                guard Self.isLoopback(conn.endpoint) else { conn.cancel(); return }
                conn.start(queue: .global(qos: .userInitiated))
                self?.readRequest(conn, buffer: Data())
            }
            l.start(queue: .global(qos: .userInitiated))
            listener = l
            isRunning = true
        } catch {
            print("Failed to start LocalHTTPServer: \(error)")
        }
    }

    // MARK: - Request reading

    private func readRequest(_ conn: NWConnection, buffer: Data) {
        conn.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] data, _, isComplete, error in
            guard let self = self else { conn.cancel(); return }
            var buf = buffer
            if let data = data { buf.append(data) }

            if let range = buf.range(of: Data("\r\n\r\n".utf8)) {
                let head = String(decoding: buf[..<range.lowerBound], as: UTF8.self)
                self.handleRequest(head, connection: conn)
            } else if isComplete || error != nil || buf.count > 65536 {
                conn.cancel()
            } else {
                self.readRequest(conn, buffer: buf)
            }
        }
    }

    private func handleRequest(_ head: String, connection: NWConnection) {
        let lines = head.components(separatedBy: "\r\n")
        let parts = (lines.first ?? "").components(separatedBy: " ")
        guard parts.count >= 2 else { connection.cancel(); return }
        let method = parts[0].uppercased()
        let path = parts[1]

        if method == "OPTIONS" {
            send(connection, status: 204, headers: [:], body: Data())
            return
        }

        if path.hasPrefix("/proxy") {
            guard let target = upstreamURL(from: path) else {
                sendText(connection, status: 400, text: "Bad proxy URL")
                return
            }
            forward(target, method: method, to: connection)
            return
        }

        if path == "/" || path.hasPrefix("/index") || path.hasPrefix("/?") {
            send(connection, status: 200,
                 headers: ["Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store"],
                 body: method == "HEAD" ? Data() : Data(HTMLTemplate.playerHTML.utf8))
        } else {
            sendText(connection, status: 404, text: "Not found")
        }
    }

    private func upstreamURL(from path: String) -> URL? {
        // Legacy form: /proxy?url=<encoded>
        if path.hasPrefix("/proxy?url=") {
            let enc = String(path.dropFirst("/proxy?url=".count))
            return URL(string: enc.removingPercentEncoding ?? enc)
        }
        // /proxy/<scheme>/<host[:port]>/<rest>
        guard path.hasPrefix("/proxy/") else { return nil }
        let rest = path.dropFirst("/proxy/".count)
        guard let slash = rest.firstIndex(of: "/") else { return nil }
        let scheme = String(rest[..<slash])
        guard scheme == "http" || scheme == "https" else { return nil }
        let remainder = rest[rest.index(after: slash)...]
        return URL(string: "\(scheme)://\(remainder)")
    }

    // MARK: - Forwarding

    private func forward(_ url: URL, method: String, to connection: NWConnection) {
        var req = URLRequest(url: url)
        req.httpMethod = (method == "HEAD") ? "HEAD" : "GET"
        req.setValue(userAgent, forHTTPHeaderField: "User-Agent")

        session.dataTask(with: req) { [weak self] data, response, error in
            guard let self = self else { connection.cancel(); return }
            guard let http = response as? HTTPURLResponse else {
                let msg = error?.localizedDescription ?? "Gateway error"
                print("Proxy error for \(url): \(msg)")
                self.sendText(connection, status: 502, text: msg)
                return
            }

            var headers: [String: String] = [:]
            var contentType = http.value(forHTTPHeaderField: "Content-Type")
            if contentType == nil || contentType == "application/octet-stream" {
                let ext = url.pathExtension.lowercased()
                if ext == "swf" { contentType = "application/x-shockwave-flash" }
                else if ext == "xml" { contentType = "text/xml" }
                else if ext == "json" { contentType = "application/json" }
            }
            if let ct = contentType { headers["Content-Type"] = ct }
            if let etag = http.value(forHTTPHeaderField: "ETag") { headers["ETag"] = etag }

            let body = (method == "HEAD") ? Data() : (data ?? Data())
            self.send(connection, status: http.statusCode, headers: headers, body: body)
        }.resume()
    }

    // MARK: - Responses

    private func sendText(_ conn: NWConnection, status: Int, text: String) {
        send(conn, status: status, headers: ["Content-Type": "text/plain; charset=utf-8"], body: Data(text.utf8))
    }

    private func send(_ conn: NWConnection, status: Int, headers: [String: String], body: Data) {
        var h = headers
        h["Access-Control-Allow-Origin"] = "*"
        h["Access-Control-Allow-Methods"] = "GET, HEAD, OPTIONS"
        h["Access-Control-Allow-Headers"] = "*"
        h["Cross-Origin-Resource-Policy"] = "cross-origin"
        h["Content-Length"] = "\(body.count)"
        h["Connection"] = "close"

        var head = "HTTP/1.1 \(status) \(HTTPURLResponse.localizedString(forStatusCode: status).capitalized)\r\n"
        for (k, v) in h { head += "\(k): \(v)\r\n" }
        head += "\r\n"

        var out = Data(head.utf8)
        out.append(body)
        conn.send(content: out, completion: .contentProcessed({ _ in conn.cancel() }))
    }
}
